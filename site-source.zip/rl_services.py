"""Service chips: one place for the services, their glyphs and where each chip comes from.

Used twice:
  * as a MkDocs hook (mkdocs.base.yml `hooks: [rl_services.py]`): puts the chip row under the H1 of every page
    whose front matter has `rl_service: [...]`, puts a chip in each row of the deadlines table, and gives the
    templates `rl_svc_chips(ids)` (news index cards, overrides/partials/post.html);
  * imported by gen.py, which writes `rl_service` into the generated kit and control pages (KIT_SERVICE).

Rules (Owner 2026-11-11): the chip is always a glyph PLUS the service name as text. The glyphs are our own
neutral line drawings (24x24, currentColor). They are not Microsoft's product icons and must never be replaced
by them or redrawn to look like them. Nothing is placed by hand in a page body: change the data, not the HTML.
"""
import html as _html
import logging
import re

log = logging.getLogger("mkdocs.hooks.rl_services")

# id -> (name shown as text, SVG body). Chips are shown in the order the page lists them (most prominent first).
SERVICES = {
    "entra": ("Entra", '<circle cx="8" cy="15.5" r="4"/><path d="M10.9 12.6 19.5 4M16 7.5l3 3M13.2 10.3l2.3 2.3"/>'),
    "exchange-online": ("Exchange", '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.6 7.2 8.4 6.3 8.4-6.3"/>'),
    "outlook": ("Outlook", '<path d="M3 13.5 5.6 5.4A2 2 0 0 1 7.5 4h9a2 2 0 0 1 1.9 1.4L21 13.5V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 13.5h5l1.2 2.5h5.6l1.2-2.5h5"/>'),
    "teams": ("Teams", '<path d="M4 4.5h9a2 2 0 0 1 2 2V11a2 2 0 0 1-2 2H8.5L5 15.8V13H4a2 2 0 0 1-2-2V6.5a2 2 0 0 1 2-2z"/><path d="M18 9.5h2a2 2 0 0 1 2 2V16a2 2 0 0 1-2 2h-1v2.8L15.5 18H12a2 2 0 0 1-2-2"/>'),
    "sharepoint-onedrive": ("SharePoint & OneDrive", '<path d="M3 7a2 2 0 0 1 2-2h4.2l2 2.2H19a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 10.5h18"/>'),
    "defender": ("Defender", '<path d="M12 3 5 5.8v5.4c0 4.3 2.8 7.6 7 9.8 4.2-2.2 7-5.5 7-9.8V5.8z"/><path d="m9 12 2.2 2.2L15.2 10"/>'),
    "intune": ("Intune", '<rect x="2.5" y="5" width="13" height="9" rx="1.5"/><path d="M1.5 17.5h11.5"/><rect x="16" y="9" width="6" height="11" rx="1.5"/>'),
    "purview": ("Purview", '<path d="M3.5 12.2V5a1.5 1.5 0 0 1 1.5-1.5h7.2l8.3 8.3a1.5 1.5 0 0 1 0 2.1l-6.6 6.6a1.5 1.5 0 0 1-2.1 0z"/><circle cx="8" cy="8" r="1.3"/>'),
    "copilot": ("Copilot", '<path d="m10.5 3.5 1.9 5.1 5.1 1.9-5.1 1.9-1.9 5.1-1.9-5.1-5.1-1.9 5.1-1.9z"/><path d="m18.5 14.5.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z"/>'),
    "windows": ("Windows", '<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/>'),
    "microsoft-365": ("Microsoft 365", '<path d="m12 3.5 9 4.5-9 4.5L3 8z"/><path d="m3 12 9 4.5 9-4.5"/><path d="m3 16 9 4.5 9-4.5"/>'),
    "dev-tools": ("Developer tools", '<path d="m8 7-5 5 5 5M16 7l5 5-5 5M13.5 4.5l-3 15"/>'),
    "other": ("Other vendors", '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="m4.3 7.7 7.7 4.3 7.7-4.3M12 12v9"/>'),
}

# Kit key (gen.py KITS) -> services of the kit page and of its control pages.
KIT_SERVICE = {
    "copilot": ["copilot"],
    "agents": ["copilot", "entra"],
    "ca": ["entra"],
    "pim": ["entra"],
    "sms": ["entra"],
    "exo": ["exchange-online"],
    "mde": ["defender"],
    "m365": ["microsoft-365"],
}

# Deadlines table (docs/guides/deadlines.md): the chip of a row comes from the text of its "What changes" cell.
# First rule that matches wins. A row that matches no rule gets no chip and a line in the build log.
DEADLINE_RULES = [
    (r"^Teams\b", ["teams"]),
    (r"^Entra\b|SMS and voice MFA", ["entra"]),
    (r"^CISA KEV due date for Brotli", ["dev-tools"]),
    (r"^CISA KEV\b", ["other"]),
    (r"^Windows\b", ["windows"]),
    (r"^Copilot\b|^Work IQ\b|^Power BI\b", ["copilot"]),
    (r"^Exchange Online\b", ["exchange-online"]),
    (r"^MODS\b|^Microsoft 365 admin center\b", ["microsoft-365"]),
    (r"^SharePoint and OneDrive\b", ["sharepoint-onedrive"]),
    (r"^Defender\b", ["defender"]),
    (r"^Outlook\b", ["outlook"]),
    (r"^Purview\b|^Search-UnifiedAuditLog\b", ["purview"]),
]
DEADLINES_SRC = "guides/deadlines.md"


def chip(sid):
    name, body = SERVICES[sid]
    return (f'<span class="rl-svc" data-svc="{sid}"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" focusable="false">'
            f'{body}</svg><span class="rl-svc__n">{_html.escape(name)}</span></span>')


def chips(ids, where="", cls=""):
    """HTML of a chip row for a list of service ids ('' when the list is empty). Unknown ids are reported."""
    if isinstance(ids, str):
        ids = [ids]
    known = []
    for sid in ids or []:
        if sid in SERVICES:
            if sid not in known:
                known.append(sid)
        else:
            log.warning(f"rl_service: unknown service '{sid}'{' in ' + where if where else ''} (see rl_services.py SERVICES)")
    if not known:
        return ""
    c = "rl-svcs" + (" " + cls if cls else "")
    # No group label on the per-row chips of the deadlines table and the news cards: 32 repeats are noise.
    attrs = "" if cls else ' role="group" aria-label="Services"'
    return f'<div class="{c}"{attrs}>' + " ".join(chip(s) for s in known) + "</div>"


def deadline_services(what_text):
    for pat, ids in DEADLINE_RULES:
        if re.search(pat, what_text):
            return ids
    return []


# A row whose text starts with the very name the chip already shows ("Entra: the MemberOf ...") is shown without
# that prefix, so the name is not read twice. Only an exact name (or one of these aliases) followed by ": " is
# dropped; anything longer ("Defender and Sentinel: ...", "Exchange Online Admin API: ...") stays as written.
# The markdown source keeps the prefix (deadlines_ics.py reads it); only the built HTML changes.
PREFIX_ALIASES = {"exchange-online": ["Exchange Online"], "sharepoint-onedrive": ["SharePoint and OneDrive"]}


def _drop_prefix(cell_html, ids):
    for sid in ids:
        for name in [SERVICES[sid][0]] + PREFIX_ALIASES.get(sid, []):
            pre = name + ": "
            if cell_html.startswith(pre) and len(cell_html) > len(pre):
                rest = cell_html[len(pre):]
                # capitalise only an all-lowercase first word ("the MemberOf ..."), never "iOS" or "eDiscovery"
                return rest[0].upper() + rest[1:] if rest.split(" ", 1)[0].islower() else rest
    return cell_html


_ROW = re.compile(r"(<tr>\s*<td[^>]*>.*?</td>\s*<td[^>]*>)(.*?)(</td>)", re.S)


def _deadline_rows(html, src):
    start = html.find('<div class="rl-dl"')
    if start < 0:
        log.warning(f"rl_services: no .rl-dl table found in {src}; deadlines rows get no service chips")
        return html
    end = html.find("</table>", start)
    head, table, tail = html[:start], html[start:end], html[end:]
    n = {"rows": 0, "none": 0}

    def repl(m):
        text = _html.unescape(re.sub(r"<[^>]+>", "", m.group(2))).strip()
        ids = deadline_services(text)
        n["rows"] += 1
        if not ids:
            n["none"] += 1
            log.info(f"rl_services: deadlines row without a service chip: {text[:70]}")
            return m.group(0)
        return m.group(1) + chips(ids, src, "rl-svcs--row") + _drop_prefix(m.group(2), ids) + m.group(3)

    table = _ROW.sub(repl, table)
    log.info(f"rl_services: deadlines rows {n['rows']}, without chip {n['none']}")
    return head + table + tail


# ---- MkDocs hook events -------------------------------------------------------------------------------------
def on_env(env, config, files, **kwargs):
    env.globals["rl_svc_chips"] = chips
    return env


def on_page_content(html, page, config, files, **kwargs):
    src = page.file.src_uri
    if src == DEADLINES_SRC:
        html = _deadline_rows(html, src)
    ids = (page.meta or {}).get("rl_service")
    if ids:
        row = chips(ids, src)
        if row and "</h1>" in html:
            html = html.replace("</h1>", "</h1>\n" + row, 1)
    return html
