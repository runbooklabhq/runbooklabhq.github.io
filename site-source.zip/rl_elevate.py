"""Runbook Lab v3 'elevate' hook (preview 2026-11-25).

Rebuilds the "Runbook card" note of a news brief as labelled rows (What changes / Who / By when / Do this / Check / Source),
the same card the Friday newsletter shows. It moves no words: the text of every row is the text of the note, label colons included (they are kept in the
markup and hidden only visually).
If a note does not have the expected shape it is left exactly as written.
"""
import re

_KEYS = {
    "what changes": ("what", "bolt"),
    "who": ("who", "users"),
    "affected": ("who", "users"),
    "by when": ("when", "clock"),
    "do this": ("do", "list"),
    "check": ("check", "term"),
    "source": ("source", "book"),
}
_NOTE = re.compile(
    r'<div class="admonition note">\s*<p class="admonition-title">Runbook card</p>\s*<p>(.*?)</p>\s*</div>', re.S)
_ROW = re.compile(r'^\s*<strong>([^<:]{2,24}):</strong>\s*(.*)$', re.S)


def _steps(text):
    """'1. A 2. B 3. C' becomes an ordered list, only when the numbers run 1, 2, 3... in order and the text starts with '1. '."""
    if not text.startswith("1. "):
        return text
    cuts, n, pos = [0], 2, 0
    while True:
        i = text.find(f" {n}. ", pos)
        if i < 0:
            break
        cuts.append(i + 1)
        pos, n = i + 1, n + 1
    if len(cuts) < 2:
        return text
    parts = [text[a:b].strip() for a, b in zip(cuts, cuts[1:] + [len(text)])]
    items = [re.sub(r"^\d+\.\s*", "", p_) for p_ in parts]
    if any("<" in i_ and i_.count("<") != i_.count(">") for i_ in items):
        return text
    return '<ol role="list">' + "".join(f"<li>{i_}</li>" for i_ in items) + "</ol>"


def _card(m):
    rows = []
    for part in re.split(r'<br\s*/?>', m.group(1)):
        r = _ROW.match(part)
        if not r or r.group(1).strip().lower() not in _KEYS:
            return m.group(0)  # unknown shape: keep the note as written
        slug, icon = _KEYS[r.group(1).strip().lower()]
        val = r.group(2).strip()
        if slug == "do":
            val = _steps(val)
        rows.append(
            f'<div class="rl-rc__row rl-rc__row--{slug}"><div class="rl-rc__k"><span class="rl-i rl-i--{icon}" aria-hidden="true"></span>'
            f'{r.group(1).strip()}<span class="rl-rc__colon">:</span></div><div class="rl-rc__v">{val}</div></div>')
    if len(rows) < 4:
        return m.group(0)
    return ('<section class="rl-rc" aria-label="Runbook card"><p class="rl-rc__head"><span class="rl-i rl-i--shield" aria-hidden="true"></span>'
            'Runbook card</p>' + "".join(rows) + '</section>')


def on_page_content(html, page, config, files, **kwargs):
    if 'admonition-title">Runbook card<' not in html:
        return html
    return _NOTE.sub(_card, html)


# ---- v3 section pages (2026-11-25): Kits, Controls, Guides, News, About get the same answer band as the rest of the site.
# The h1 and the lead paragraph are moved into the band unchanged; the numbers on the tiles are counted from the page itself.
_SECTIONS = {
    "kits/index.md": ("box", "Fix it as a project"),
    "controls/index.md": ("shield", "One layout for every control"),
    "guides/index.md": ("book", "Step by step, checks first"),
    "news/index.md": ("news", "Changes that need an admin"),
    "about/index.md": ("users", "Who writes this, and how"),
}
_PRIO = {"Highest": "red", "High": "amb", "Medium": "blu", "Low": "grn"}


def _tile(n, label):
    return f'<li><strong>{n}</strong>{label}</li>'


def _section(html, page, files):
    key = page.file.src_uri
    if key not in _SECTIONS:
        return html
    m = re.search(r'(<h1[^>]*>.*?</h1>)\s*(<p class="rl-lead">.*?</p>)', html, re.S)
    if not m:
        return html
    icon, eyebrow = _SECTIONS[key]
    tiles = []
    rest = html[m.end():]
    if key == "kits/index.md":
        tiles = [_tile(len(re.findall(r'class="rl-kitmeta"', rest)), "kits"), _tile(len(re.findall(r"</h2>\s*<h3", rest)), "areas")]
        rest = re.sub(r'(<h3[^>]*>.*?</h3>)\s*(<p>.*?</p>)', r'<article class="rl-kc">\1\2</article>', rest, flags=re.S)
        rest = re.sub(r'((?:<article class="rl-kc">.*?</article>\s*)+)', r'<div class="rl-kgrid">\1</div>', rest, flags=re.S)
    elif key == "controls/index.md":
        tiles = [_tile(len(re.findall(r"<tr>\s*<td>[A-Z]{2}\d\d</td>", rest)), "controls published"), _tile(len(re.findall(r"<h2", rest)), "kits")]
        for word, colour in _PRIO.items():
            rest = rest.replace(f"<td>{word}</td>", f'<td><span class="rl-pill rl-pill--{colour}">{word}</span></td>')
    elif key == "guides/index.md":
        tiles = [_tile(len(re.findall(r"<tr>\s*<td><a ", rest)), "guides")]
    elif key == "news/index.md":
        n = sum(1 for f in files if f.src_uri.startswith("news/posts/") and f.src_uri.endswith(".md"))
        tiles = [_tile(n, "briefs and roundups")]
    stats = f'<ul class="rl-sh__stats">{"".join(tiles)}</ul>' if tiles else ""
    band = (f'<header class="rl-sh rl-sh--{key.split("/")[0]}"><p class="rl-sh__eyebrow"><span class="rl-i rl-i--{icon}" aria-hidden="true"></span>'
            f'{eyebrow}</p>{m.group(1)}{m.group(2)}{stats}</header>')
    return html[:m.start()] + band + rest


def on_page_content(html, page, config, files, **kwargs):   # replaces the function above: cards first, then section bands
    if 'admonition-title">Runbook card<' in html:
        html = _NOTE.sub(_card, html)
    return _section(html, page, files)


# ---- RSS fix (2026-11-25): the RSS plugin writes category names such as "Threats & vulnerabilities" with a bare "&",
# which makes both feeds invalid XML (browsers and feed readers stop at the first item). Escape it after the build.
def on_post_build(config, **kwargs):
    import os
    for name in ("feed_rss_created.xml", "feed_rss_updated.xml"):
        path = os.path.join(config["site_dir"], name)
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as fh:
            xml = fh.read()
        fixed = re.sub(r"<category>(.*?)</category>",
                       lambda m: "<category>" + re.sub(r"&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)", "&amp;", m.group(1)) + "</category>",
                       xml, flags=re.S)
        if fixed != xml:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(fixed)
