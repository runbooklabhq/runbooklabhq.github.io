"""Runbook Lab v3 'elevate' hook (preview 2026-11-25).

Rebuilds the "Runbook card" note of a news brief as labelled rows (What changes / Who / By when / Do this / Check / Source),
the same card the Friday newsletter shows. It moves no words: the text of every row is the text of the note, label colons included (they are kept in the
markup and hidden only visually).
If a note does not have the expected shape it is left exactly as written.
"""
import re

_KEYS = {
    "what changes": ("what", "bolt"),
    "who": ("who", "users"),
    "affected": ("who", "users"),
    "by when": ("when", "clock"),
    "do this": ("do", "list"),
    "check": ("check", "term"),
    "source": ("source", "book"),
}
_NOTE = re.compile(
    r'<div class="admonition note">\s*<p class="admonition-title">Runbook card</p>\s*<p>(.*?)</p>\s*</div>', re.S)
_ROW = re.compile(r'^\s*<strong>([^<:]{2,24}):</strong>\s*(.*)$', re.S)


def _steps(text):
    """'1. A 2. B 3. C' becomes an ordered list, only when the numbers run 1, 2, 3... in order and the text starts with '1. '."""
    if not text.startswith("1. "):
        return text
    cuts, n, pos = [0], 2, 0
    while True:
        i = text.find(f" {n}. ", pos)
        if i < 0:
            break
        cuts.append(i + 1)
        pos, n = i + 1, n + 1
    if len(cuts) < 2:
        return text
    parts = [text[a:b].strip() for a, b in zip(cuts, cuts[1:] + [len(text)])]
    items = [re.sub(r"^\d+\.\s*", "", p_) for p_ in parts]
    if any("<" in i_ and i_.count("<") != i_.count(">") for i_ in items):
        return text
    return '<ol role="list">' + "".join(f"<li>{i_}</li>" for i_ in items) + "</ol>"


def _card(m):
    rows = []
    for part in re.split(r'<br\s*/?>', m.group(1)):
        r = _ROW.match(part)
        if not r or r.group(1).strip().lower() not in _KEYS:
            return m.group(0)  # unknown shape: keep the note as written
        slug, icon = _KEYS[r.group(1).strip().lower()]
        val = r.group(2).strip()
        if slug == "do":
            val = _steps(val)
        rows.append(
            f'<div class="rl-rc__row rl-rc__row--{slug}"><div class="rl-rc__k"><span class="rl-i rl-i--{icon}" aria-hidden="true"></span>'
            f'{r.group(1).strip()}<span class="rl-rc__colon">:</span></div><div class="rl-rc__v">{val}</div></div>')
    if len(rows) < 4:
        return m.group(0)
    return ('<section class="rl-rc" aria-label="Runbook card"><p class="rl-rc__head"><span class="rl-i rl-i--shield" aria-hidden="true"></span>'
            'Runbook card</p>' + "".join(rows) + '</section>')


def on_page_content(html, page, config, files, **kwargs):
    if 'admonition-title">Runbook card<' not in html:
        return html
    return _NOTE.sub(_card, html)
