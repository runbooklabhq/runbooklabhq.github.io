"""IndexNow for runbooklabhq.com (Bing, Yandex, Seznam, Naver; Google does not use IndexNow).

Run in CI after `mkdocs build`:  python indexnow.py ../_site <payload-out.json>
1. Reads the built sitemap.xml and hashes the main content of every listed page (the sitemap's <lastmod> is the
   build date for every page, so it cannot tell what changed).
2. Downloads the manifest of the live site (https://runbooklabhq.com/indexnow-manifest.json). Missing on the
   first run -> every sitemap URL counts as new (one-time full submission).
3. Writes the new manifest into the site (so the next run can compare) and, if any URL is new, changed or
   removed, writes the IndexNow JSON payload to <payload-out.json>. Nothing changed -> no payload file.
The deploy workflow POSTs the payload to https://api.indexnow.org/indexnow only AFTER the site is live,
so search engines fetch the new version. Never fails the build: problems are printed as warnings.
"""
import hashlib
import json
import os
import time
import urllib.error
import re
import sys
import urllib.request
from pathlib import Path

HOST = "runbooklabhq.com"
SITE = f"https://{HOST}"
KEY = "65daf5c8aa14ea5a219156b9540f2def"
MANIFEST = "indexnow-manifest.json"


def page_hash(site, url):
    rel = url[len(SITE):].lstrip("/")
    f = site / rel / "index.html" if (rel == "" or rel.endswith("/")) else site / rel
    if not f.exists():
        return None
    html = f.read_text(encoding="utf-8", errors="replace")
    # Whole main content (Material puts the sidebars before md-content, so nav edits do not touch every page).
    # Home page (md-content rl-home) keeps whole-page hashing on purpose: its hero and timeline sit before <main>.
    m = re.search(r'<div class="md-content(?: md-content--post)?".*?</main>', html, re.S)
    return hashlib.sha256((m.group(0) if m else html).encode("utf-8")).hexdigest()[:16]


def main(site_dir, payload_out):
    site = Path(site_dir)
    urls = re.findall(r"<loc>([^<]+)</loc>", (site / "sitemap.xml").read_text(encoding="utf-8"))
    new = {u: h for u in urls if u.startswith(SITE) and (h := page_hash(site, u))}
    old, first_run = None, False
    bust = os.environ.get("GITHUB_RUN_ID", str(int(time.time())))
    for attempt in range(3):
        try:
            with urllib.request.urlopen(f"{SITE}/{MANIFEST}?v={bust}", timeout=20) as r:
                old = json.load(r)
            if not isinstance(old, dict):
                raise ValueError("manifest is not a JSON object")
            break
        except urllib.error.HTTPError as e:
            if e.code == 404:  # the only real "first run"
                old, first_run = {}, True
                break
            err = e
        except Exception as e:  # timeout, DNS, proxy, not JSON
            old, err = None, e
        time.sleep(5)
    if old is None:
        # Keep the new manifest (each deploy replaces the whole site) but send nothing: re-sending all 80+ URLs
        # because the old manifest could not be read would look like spam to the engines.
        (site / MANIFEST).write_text(json.dumps(new, indent=0, sort_keys=True), encoding="utf-8")
        print(f"::warning title=IndexNow::live manifest not readable ({err}); nothing submitted this run")
        return
    if first_run:
        print("indexnow: no live manifest yet (404); first run, every URL counts as new")
    changed = sorted(u for u, h in new.items() if old.get(u) != h)
    removed = sorted(u for u in old if u not in new)
    (site / MANIFEST).write_text(json.dumps(new, indent=0, sort_keys=True), encoding="utf-8")
    todo = (changed + removed)[:10000]
    print(f"indexnow: {len(new)} pages, {len(changed)} new/changed, {len(removed)} removed")
    if todo:
        Path(payload_out).write_text(json.dumps({"host": HOST, "key": KEY, "keyLocation": f"{SITE}/{KEY}.txt",
                                                 "urlList": todo}), encoding="utf-8")
        for u in todo[:20]:
            print("  ", u)


if __name__ == "__main__":
    try:
        main(sys.argv[1], sys.argv[2])
    except Exception as e:
        print(f"indexnow: WARNING, skipped ({e})")
