# Runbook Lab site (source)

MkDocs Material site for runbooklabhq.com. Kit and control pages, the home page, the brief box under each news post and the file excerpts on kit pages are generated from data/: the kits' controls JSON (copies of security/*/source/*.json) and data/files/<kit>/ (the free Top 5 files: Jira CSV, Excel plan, read-only script).

    pip install -r requirements.txt
    python gen.py data                  # writes docs/kits, docs/controls, overrides/home.html, overrides/partials/rl-briefbox.html, mkdocs.yml
    mkdocs serve                        # local preview at http://127.0.0.1:8000
    mkdocs build --strict -d site       # production build (directory URLs). RL_CF_BEACON=<token> adds Cloudflare Web Analytics.
    RL_DIR_URLS=false RL_EXT=.html RL_INDEX=index.html mkdocs build --strict -d ../preview   # offline preview

News brief: docs/news/posts/YYYY-MM-DD-<slug>.md with front matter date.created (with time), slug, categories, description, rl_type: news, rl_service: [service ids from rl_services.py, most prominent first, max 4; the build fails on an unknown id], rl_kits: [kit keys], rl_controls: [control IDs]; a lead paragraph, then <!-- more -->. The home page and the brief box pick it up automatically.
Hand-written: docs/index.md (home uses home.tpl.html), docs/guides, docs/news/posts, docs/about, docs/kits/bundles.md, docs/assets.
Bundles: set live=True in gen.py BUNDLES when a bundle is published on Gumroad.
Deploy: .github/workflows/deploy.yml (GitHub Pages via Actions) — see site/GO-LIVE.md.
