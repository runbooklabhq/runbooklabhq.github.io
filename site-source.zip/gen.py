#!/usr/bin/env python3
"""Runbook Lab site generator.

Reads the kits' controls JSON (the same files the zips are built from) and writes:
  docs/kits/*.md, docs/controls/**.md, docs/controls/index.md, overrides/home.html, mkdocs.yml nav.
Hand-written pages (guides, news, about) live in docs/ and are not touched.
Run: python3 gen.py <data_dir>
"""
import html, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = Path(sys.argv[1] if len(sys.argv) > 1 else ROOT.parent / "data")
DOCS = ROOT / "docs"
GUM = "https://runbooklab.gumroad.com/l/"
GH = "https://github.com/runbooklabhq/"

# Order = what the home page and nav show first (AI first, human rule 10-27).
KITS = [
    dict(key="copilot", page="copilot-readiness", name="M365 Copilot Readiness Kit", short="Copilot readiness",
         area="AI security", files=["copilot-top5.json", "copilot-extended.json"], strict=True,
         free="copilot-readiness-top5", paid="copilot-readiness-kit", price="€39", repo="m365-copilot-readiness-free",
         outcome="Fix oversharing before Copilot finds it, then roll Copilot out with Purview guardrails.",
         guide="microsoft-365-copilot-oversharing-checklist-jira"),
    dict(key="agents", page="ai-agent-hardening", name="M365 AI Agent Hardening Kit", short="AI agent hardening",
         area="AI security", files=["agents-top5.json", "agents-extended.json"], strict=True,
         free="ai-agent-hardening-top5", paid="ai-agent-hardening-kit", price="€39", repo="m365-ai-agent-hardening-free",
         outcome="Inventory, guardrails and accountable owners for Copilot Studio agents and Entra agent identities.",
         guide="copilot-studio-agent-governance-checklist"),
    dict(key="ca", page="conditional-access", name="Conditional Access Baseline Kit", short="Conditional Access",
         area="Identity", files=["ca-top5.json", "ca-extended.json"], strict=True,
         free="entra-conditional-access-top5", paid="entra-conditional-access-kit", price="€29",
         repo="entra-conditional-access-kit-free",
         outcome="A Conditional Access baseline with phishing-resistant MFA for admins and no legacy sign-in paths.",
         guide="entra-conditional-access-baseline-report-only"),
    dict(key="pim", page="privileged-access-pim", name="Privileged Access and PIM Kit", short="Privileged access and PIM",
         area="Identity", files=["pim-top5.json", "pim-extended.json"], strict=True,
         free="privileged-access-pim-top5", paid="privileged-access-pim-kit", price="€39", repo="privileged-access-pim-kit-free",
         outcome="Fewer standing admins: eligible roles in PIM, strict Tier 0 settings and quarterly reviews.",
         guide="entra-privileged-access-pim-global-admins"),
    dict(key="sms", page="sms-mfa-exit", name="Entra SMS MFA Exit Kit", short="SMS and voice MFA exit",
         area="Identity", files=["sms-top5.json", "sms-extended.json"], strict=False,
         free="sms-mfa-exit-top5", paid="sms-mfa-exit-kit", price="€29", repo="entra-sms-mfa-exit-kit-free",
         outcome="Get phone-only users to passkeys before Microsoft's SMS and voice MFA retires on 1 February 2027.",
         guide="entra-sms-voice-mfa-retirement-passkeys"),
    dict(key="exo", page="exchange-online-protection", name="Exchange Online Protection Kit", short="Exchange Online protection",
         area="Email", files=["exo-top5.json", "exo-extended.json"], strict=True,
         free="exchange-online-protection-top5", paid="exchange-online-protection-kit", price="€29",
         repo="exchange-online-protection-kit-free",
         outcome="Preset policies, SPF, DKIM and DMARC to p=reject, no silent forwarding, and Defender for Office 365 set up properly.",
         guide="exchange-online-protection-preset-policies-dmarc"),
    dict(key="mde", page="defender-endpoint-asr", name="Defender for Endpoint and ASR Kit", short="Defender for Endpoint and ASR",
         area="Endpoint", files=["mde-top5.json", "mde-extended.json"], strict=True,
         free="defender-asr-top5", paid="defender-asr-kit", price="€29", repo="defender-endpoint-asr-kit-free",
         outcome="Every device onboarded, tamper protection on, and ASR rules moved from Audit to Block without outages.",
         guide="defender-asr-rules-audit-to-block"),
    dict(key="m365", page="m365-hardening", name="M365 Hardening Kit", short="Microsoft 365 hardening",
         area="Whole tenant", files=["m365-emergency-top10.json", "m365-extended.json"], strict=False,
         free="m365-hardening-top10", paid="m365-hardening-kit", price="€39", repo="m365-hardening-kit-free",
         outcome="A first pass across the whole tenant: Entra ID, Exchange Online, Teams, SharePoint, OneDrive and Purview.",
         guide="microsoft-365-hardening-checklist-jira"),
]

MONTHS = "January February March April May June July August September October November December".split()


def nice_date(iso):
    y, m, d = iso.split("-")
    return f"{int(d)} {MONTHS[int(m) - 1]} {y}"


def slugify(s, n=58):
    s = s.lower().replace("&", "and")
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    if len(s) > n:
        s = s[:n].rsplit("-", 1)[0]
    return s


def esc(s):
    return html.escape(s, quote=True)


def md_text(s):
    """Plain JSON text -> safe Markdown inline text (keep code-ish tokens readable)."""
    s = s.replace("<", "&lt;").replace(">", "&gt;")
    s = re.sub(r"(?<![\w*])\*(?!\s)", r"\\*", s)
    s = s.replace("_", "\\_") if False else s
    return s


def split_ps(code):
    """Split a PowerShell one-liner on top-level ';' so it reads as a script.
    Leaves ';' inside quotes, (), {} and [] alone."""
    out, cur, depth, q = [], [], 0, None
    i = 0
    while i < len(code):
        ch = code[i]
        if q:
            cur.append(ch)
            if ch == "`" and i + 1 < len(code):
                cur.append(code[i + 1]); i += 2; continue
            if ch == q:
                q = None
        elif ch in "'\"":
            q = ch; cur.append(ch)
        elif ch in "({[":
            depth += 1; cur.append(ch)
        elif ch in ")}]":
            depth -= 1; cur.append(ch)
        elif ch == ";" and depth == 0:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(ch)
        i += 1
    if "".join(cur).strip():
        out.append("".join(cur).strip())
    return "\n".join(out)


WORDS = {"mfa": "MFA", "pim": "PIM", "asr": "ASR", "dlp": "DLP", "spf": "SPF", "dkim": "DKIM", "dmarc": "DMARC",
         "sharepoint": "SharePoint", "onedrive": "OneDrive", "microsoft": "Microsoft", "entra": "Entra", "copilot": "Copilot",
         "teams": "Teams", "exchange": "Exchange", "online": "Online", "defender": "Defender", "purview": "Purview", "id": "ID",
         "eop": "EOP", "mdo": "MDO", "edr": "EDR", "fido2": "FIDO2", "laps": "LAPS", "smtp": "SMTP", "api": "API", "apis": "APIs",
         "office": "Office", "windows": "Windows", "powershell": "PowerShell", "intune": "Intune", "graph": "Graph", "dspm": "DSPM",
         "ai": "AI", "365": "365", "usb": "USB", "kql": "KQL", "ediscovery": "eDiscovery", "studio": "Studio", "power": "Power",
         "platform": "Platform", "azure": "Azure", "agent": "agent", "ca": "CA", "tap": "TAP", "sspr": "SSPR", "url": "URL"}


def source_label(url):
    """Readable link text from a Microsoft Learn URL slug (no network needed)."""
    path = url.split("://", 1)[-1].split("?")[0].split("#")[0].rstrip("/")
    host = path.split("/", 1)[0]
    slug = path.rsplit("/", 1)[-1]
    if slug in ("overview", "index", "") or len(slug) < 4:
        slug = path.rsplit("/", 2)[-2] + "-" + slug
    words = [WORDS.get(w, w) for w in slug.replace("_", "-").split("-") if w]
    text = " ".join(words)
    text = text[0].upper() + text[1:] if text else url
    site = "Microsoft Learn" if "learn.microsoft.com" in host else host
    return f"{text} ({site})"


def reviewed_date(kit, cid, version):
    m = re.search(r"facts re-read on Microsoft Learn (\d{4}-\d{2}-\d{2})", version)
    d = m.group(1) if m else None
    if kit["key"] == "agents":
        again = re.search(r"((?:AG\d\d(?: and )?)+) again (\d{4}-\d{2}-\d{2})", version)
        if again and cid in again.group(1):
            d = again.group(2)
    return d


def load(kit):
    tiers = []
    for f in kit["files"]:
        d = json.load(open(DATA / f, encoding="utf-8"))
        tiers.append(d)
    return tiers


def control_path(kit, c):
    return f"controls/{kit['page']}/{c['id'].lower()}-{slugify(c['title'])}.md"


def gum(slug, campaign):
    return f"{GUM}{slug}?utm_source=site&utm_campaign={campaign}"


# ------------------------------------------------------------------ control pages
def write_control(kit, tiers, c, prev, nxt):
    top = tiers[0]
    epics = {e["key"]: e["name"] for t in tiers for e in t["epics"]}
    rv = reviewed_date(kit, c["id"], top["version"])
    first_sentence = re.split(r"(?<=[.!?])\s", c["why"].strip())[0]
    desc = f"{c['title']}. {first_sentence}"
    if len(desc) > 158:
        desc = desc[:155].rsplit(" ", 1)[0] + "…"
    rel_kit = f"../../kits/{kit['page']}.md"
    L = []
    L.append("---")
    L.append(f"title: {json.dumps(c['title'])}")
    L.append(f"description: {json.dumps(desc)}")
    L.append("rl_type: control")
    if rv:
        L.append(f"rl_reviewed: {rv}")
    L.append("---")
    L.append("")
    L.append(f"# {md_text(c['title'])}")
    L.append("")
    # Facts strip: grouped label/value pairs. Values are markdown so the kit link is rewritten per URL style.
    facts = [("Control", c["id"]), ("Kit", f"[{kit['short']}]({rel_kit})"),
             ("Area", md_text(epics.get(c["epic"], c["epic"]))), ("Priority", c["priority"]), ("Effort", c["effort"])]
    if rv:
        facts.append(("Last reviewed", f'<time datetime="{rv}">{nice_date(rv)}</time>'))
    L.append('<div class="rl-facts" markdown>')
    for k, v in facts:
        L.append(f'<div class="rl-fact" markdown><div class="rl-fact__k">{k}</div><div class="rl-fact__v" markdown="span">{v}</div></div>')
    L.append("</div>")
    L.append("")
    L.append('!!! licence "Licence and role"')
    L.append(f"    {md_text(c['license'])}")
    L.append("")
    L.append("## Why it matters")
    L.append("")
    L.append(md_text(c["why"]))
    L.append("")
    L.append("## Steps")
    L.append("")
    for i, s in enumerate(c["steps"], 1):
        L.append(f"{i}. {md_text(s)}")
    L.append("")
    L.append("## Impact on users")
    L.append("")
    L.append(md_text(c["impact"]))
    L.append("")
    L.append("## Rollback")
    L.append("")
    L.append(md_text(c["rollback"]))
    L.append("")
    if c.get("check"):
        L.append("## Read-only check")
        L.append("")
        L.append("Reads settings only. It changes nothing in your tenant or on the device.")
        L.append("")
        conn = top.get("connect") or []
        if conn:
            L.append('??? note "Modules, connection and role"')
            L.append("")
            L.append("    ```text")
            for line in conn:
                L.append("    " + line.strip())
            L.append("    ```")
            L.append("")
        L.append("```powershell")
        L.append(split_ps(c["check"]))
        L.append("```")
        L.append("")
    L.append("## How to verify")
    L.append("")
    L.append(md_text(c["verify"]))
    L.append("")
    L.append("## Sources")
    L.append("")
    for s in c["sources"]:
        L.append(f"- [{source_label(s)}]({s})")
    L.append("")
    # Kit box
    L.append('<div class="rl-kitbox" markdown>')
    L.append("")
    L.append(f'<p class="rl-kitbox__title">This control is in the {esc(kit["name"])}</p>')
    L.append("")
    n_total = sum(len(t["controls"]) for t in tiers)
    if kit["free"]:
        more = f" The Complete kit has all {n_total} controls." if kit["paid"] else ""
        L.append(f"The free Top {len(top['controls'])} has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script.{more}")
        L.append("")
        L.append(f"[Download the free Top {len(top['controls'])}]({gum(kit['free'], 'control-' + c['id'].lower())}){{ .md-button .md-button--primary }} "
                 f"[See the kit]({rel_kit}){{ .md-button }}")
    else:
        L.append("The free Top 5 download is being published. The kit page has the status.")
        L.append("")
        L.append(f"[See the kit]({rel_kit}){{ .md-button .md-button--primary }}")
    L.append("")
    L.append("</div>")
    L.append("")
    out = "\n".join(L)
    p = DOCS / control_path(kit, c)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(out, encoding="utf-8")
    return p


# ------------------------------------------------------------------ kit pages
FILES = DATA / "files"


def cell(x):
    return md_text(str(x if x is not None else "")).replace("|", "\\|").replace("\n", " ")


def inside_the_zip(kit, n_top):
    """Excerpts of the real files in the free download, shown as tabs on the kit page."""
    d = FILES / kit["key"]
    if not d.exists():
        return []
    import csv, openpyxl
    jira = next(d.glob("*-jira-import.csv"), None)
    plan = next(d.glob("*-project-plan.xlsx"), None)
    ps1 = next(d.glob("*-readonly-checks.ps1"), None)
    I = "    "
    L = [f"### A look inside the free Top {n_top}", "",
         "Excerpts of the real files in the free download.", ""]
    if jira:
        rows = list(csv.DictReader(open(jira, encoding="utf-8-sig")))
        epics = sum(1 for r in rows if r["Issue Type"] == "Epic")
        stories = sum(1 for r in rows if r["Issue Type"] == "Story")
        L += ['=== "Jira import (CSV)"', "", I + '<div class="rl-xl rl-xl--jira" markdown>', "",
              I + "| Issue ID | Type | Summary | Priority | Parent | Sprint |", I + "|---|---|---|---|---|---|"]
        for r in rows[:7]:
            L.append(I + f"| {cell(r['Issue ID'])} | {cell(r['Issue Type'])} | {cell(r['Summary'])} | {cell(r['Priority'])} | {cell(r['Parent'])} | {cell(r['Sprint'])} |")
        L += ["", I + "</div>", "", I + f'<p class="rl-caption">First 7 of {len(rows)} rows of <code>{jira.name}</code>: {epics} epics and {stories} stories, with parent, priority, sprint and labels already set. Import with Jira Cloud\'s CSV importer.</p>', ""]
    if plan:
        wb = openpyxl.load_workbook(plan)
        ws = wb["Project plan"]
        head = [c.value for c in ws[1]]
        want = ["ID", "Control", "Sprint", "Priority", "Effort (h)", "Status"]
        idx = [head.index(w) for w in want if w in head]
        L += ['=== "Excel project plan"', "", I + '<div class="rl-xl rl-xl--plan" markdown>', "",
              I + "| " + " | ".join(head[i] for i in idx) + " |", I + "|" + "---|" * len(idx)]
        for r in ws.iter_rows(min_row=2, max_row=min(ws.max_row, 7), values_only=True):
            L.append(I + "| " + " | ".join(cell(r[i]) for i in idx) + " |")
        statuses = ""
        for dv in ws.data_validations.dataValidation:
            if dv.type == "list" and dv.formula1:
                statuses = dv.formula1.strip('"').replace(",", ", ")
        sheets = ", ".join(wb.sheetnames)
        L += ["", I + "</div>", "", I + f'<p class="rl-caption">The <em>Project plan</em> sheet of <code>{plan.name}</code>. Sheets: {sheets}. Owner, start and due dates are yours to fill in; status is a drop-down ({statuses}); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>', ""]
    if ps1:
        lines = open(ps1, encoding="utf-8-sig").read().splitlines()
        n = sum(1 for x in lines if x.startswith("Invoke-Check "))
        end = next(i for i, x in enumerate(lines) if x.startswith("#>")) + 1
        first = next(x for x in lines if x.startswith("Invoke-Check "))
        L += ['=== "Read-only PowerShell"', "", I + "```powershell"]
        L += [I + x for x in lines[:end]]
        L += [I + "...", I + first, I + "...", I + "```", "",
              I + f'<p class="rl-caption">The header and the first of {n} checks in <code>{ps1.name}</code>. Results go to <code>hardening-check-results.csv</code>.' + (" The header mentions the m365-hardening-coach skill: an optional, free Claude skill that reads that CSV and suggests the order of work. The checks don't need it; use it only if your policy allows sharing the results file with an AI tool." if any("coach" in x for x in lines[:end]) else "") + '</p>', ""]
    return L


def kit_page(kit, tiers):
    top = tiers[0]
    free_controls = top["controls"]
    paid_controls = [c for t in tiers[1:] for c in t["controls"]]
    n_total = len(free_controls) + len(paid_controls)
    epics = {e["key"]: e["name"] for t in tiers for e in t["epics"]}
    camp = "kit-" + kit["page"]
    L = ["---", f"title: {json.dumps(kit['name'])}",
         f"description: {json.dumps(kit['outcome'] + ' Free Top ' + str(len(free_controls)) + ' with Jira import, Excel plan and read-only checks.')}",
         "rl_type: kit", "---", "", f"# {kit['name']}", ""]
    L.append(f'<p class="rl-lead">{esc(kit["outcome"])}</p>')
    L.append("")
    intro = re.sub(r"\s*Free\.\s*", " ", top.get("intro", "")).strip().replace("the Extended kit", "the Complete kit")
    if intro:
        L.append(md_text(intro))
        L.append("")
    # Top: the free offer only. The paid offer and bundles sit at the very end of the page.
    L.append('<div class="rl-offer rl-offer--free" markdown>')
    L.append("")
    L.append('<div class="rl-offer__col" markdown>')
    L.append("")
    of = f" of {n_total} controls" if paid_controls else " controls"
    L.append(f'<p class="rl-offer__title">Free: Top {len(free_controls)}{of}</p>')
    L.append("")
    L.append(f"The {len(free_controls)} controls to do first, with every file listed below.")
    L.append("")
    if kit["free"]:
        L.append(f"[Download free]({gum(kit['free'], camp)}){{ .md-button .md-button--primary }}")
        if kit["repo"]:
            L.append(f"[View on GitHub]({GH}{kit['repo']}){{ .md-button }}")
    else:
        L.append('<span class="rl-status">Being published. Check back this week.</span>')
    if paid_controls:
        L.append("")
        L.append(f'<p class="rl-offer__next">Need all {n_total}? <a href="#get-the-complete-kit">See the Complete kit</a></p>')
    L.append("")
    L.append("</div>")
    L.append("")
    L.append("</div>")
    L.append("")
    L.append("## What's in the download")
    L.append("")
    L.append("| File | What it is for |")
    L.append("|---|---|")
    L.append("| Guide (Markdown) | Every control with why, steps, " + ("impact, rollback, " if kit["strict"] else "") + "the read-only check, how to verify, licence and effort" + ("" if kit["strict"] else " (impact and rollback are being added)") + " |")
    L.append("| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |")
    L.append("| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |")
    L.append("| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |")
    L.append("| Read-only PowerShell | " + (md_text(top.get("readonly_line", "Get-* cmdlets only. Changes nothing.").strip()) + " Results go to a CSV.") + " |")
    L.append("")
    L += inside_the_zip(kit, len(free_controls))
    L.append("## Controls")
    L.append("")
    L.append(f"### Free Top {len(free_controls)}")
    L.append("")
    if kit["strict"]:
        L.append("| ID | Control | Priority | Effort |")
        L.append("|---|---|---|---|")
        for c in free_controls:
            rel = "../" + control_path(kit, c)
            L.append(f"| {c['id']} | [{md_text(c['title'])}]({rel}) | {c['priority']} | {c['effort']} |")
    else:
        L.append("| ID | Control | Priority | Effort |")
        L.append("|---|---|---|---|")
        for c in free_controls:
            L.append(f"| {c['id']} | {md_text(c['title'])} | {c['priority']} | {c['effort']} |")
    L.append("")
    if paid_controls:
        L.append(f"### Added in the Complete kit ({len(paid_controls)})")
        L.append("")
        L.append("| ID | Control | Area | Effort |")
        L.append("|---|---|---|---|")
        for c in paid_controls:
            L.append(f"| {c['id']} | {md_text(c['title'])} | {md_text(epics.get(c['epic'], c['epic']))} | {c['effort']} |")
        L.append("")
    conn = top.get("connect") or []
    if conn:
        L.append("## Before you run the checks")
        L.append("")
        L.append("```text")
        for line in conn:
            L.append(line.strip())
        L.append("```")
        L.append("")
    if kit["guide"]:
        L.append("## Read first")
        L.append("")
        L.append(f"The free guide [{GUIDE_TITLES[kit['guide']]}](../guides/{kit['guide']}.md) covers the same ground step by step, with the commands inline.")
        L.append("")
    L.append("## Questions")
    L.append("")
    L.append('??? question "How is this different from Secure Score, Maester or ScubaGear?"')
    L.append("    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, " + ("what each change breaks and how to roll it back, " if kit["strict"] else "") + "and checks that only read.")
    L.append("")
    L.append('??? question "Will the script change anything?"')
    L.append("    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.")
    L.append("")
    L.append('??? question "Which version is this?"')
    older = "" if kit["strict"] else " This kit was built before the 27 October 2026 quality gate: impact and rollback are being added to its controls."
    L.append(f"    {md_text(top['version'])}.{older} Test every change on a pilot group first: no checklist knows your tenant's exceptions.")
    L.append("")
    L.append('??? question "Can I use it for clients?"')
    L.append("    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.")
    L.append("")
    L += buy_section(kit, n_total, camp, len(free_controls))
    offers = []
    if kit["free"]:
        offers.append({"@type": "Offer", "name": f"Free Top {len(free_controls)}", "price": "0", "priceCurrency": "EUR",
                       "availability": "https://schema.org/InStock", "url": f"{GUM}{kit['free']}"})
    if kit["paid"]:
        offers.append({"@type": "Offer", "name": f"Complete ({n_total} controls)", "price": str(eur(kit["price"])), "priceCurrency": "EUR",
                       "availability": "https://schema.org/InStock", "url": f"{GUM}{kit['paid']}"})
    if offers:
        ld = {"@context": "https://schema.org", "@type": "Product", "name": kit["name"], "description": kit["outcome"],
              "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": offers}
        L += ['<script type="application/ld+json">' + json.dumps(ld, ensure_ascii=False) + "</script>", ""]
    p = DOCS / "kits" / f"{kit['page']}.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(L), encoding="utf-8")


# Bundles (human-approved 10-28). Both LIVE on Gumroad 2026-10-30; the Library has 8 kits (PIM Complete added 10-30).
BUNDLES = [
    dict(name="AI and Identity Pack", slug="ai-identity-pack", kits=["copilot", "agents", "ca"], price=79, live=True),
    dict(name="Microsoft 365 Hardening Library", slug="m365-hardening-library",
         kits=["m365", "sms", "copilot", "agents", "mde", "ca", "exo", "pim"], price=149, live=True),
]


def eur(x):
    return int(str(x).replace("€", ""))


def buy_section(kit, n_total, camp, ntop=5):
    """Last section of a kit page: the Complete kit, then every bundle that contains it."""
    if not kit["paid"]:
        return ["## Complete kit", "", "Not available yet. The free Top 5 comes first; the Complete kit follows when it has passed the same checks.", ""]
    by_key = {k["key"]: k for k in KITS}
    L = ["## Get the Complete kit", "", '<div class="rl-buy" markdown>', ""]
    L += ['<div class="rl-buy__card rl-buy__card--main" markdown>', "",
          f"### {kit['name']}: Complete", "",
          f'<p class="rl-buy__price">{kit["price"]}</p>', "",
          f"All {n_total} controls in sprints, with the same files as the free Top {ntop}. If it doesn't save you at least an hour, reply to your receipt for a refund.", "",
          f"[Buy the Complete kit]({gum(kit['paid'], camp)}){{ .md-button .md-button--primary }}", "", "</div>", ""]
    for b in BUNDLES:
        if kit["key"] not in b["kits"]:
            continue
        parts = [by_key[k] for k in b["kits"]]
        separately = sum(eur(k["price"]) for k in parts)
        names = ", ".join(("**" + k["short"] + "**") if k["key"] == kit["key"] else k["short"] for k in parts)
        L += ['<div class="rl-buy__card" markdown>', "",
              f"### {b['name']}", "",
              f'<p class="rl-buy__price">€{b["price"]} <span>instead of €{separately} for the kits separately</span></p>', "",
              f"{len(parts)} Complete kits: {names}.", ""]
        if b["live"]:
            L.append(f"[Buy the bundle]({gum(b['slug'], camp + '-bundle')}){{ .md-button }}")
        else:
            L.append('<span class="rl-status">Coming soon</span><br>[About the bundles](bundles.md)')
        L += ["", "</div>", ""]
    L += ["</div>", ""]
    return L


GUIDE_TITLES = {
    "microsoft-365-hardening-checklist-jira": "Microsoft 365 hardening checklist, ready for Jira",
    "exchange-online-smtp-auth-basic-auth-checklist": "SMTP AUTH Basic auth ends in December 2026",
    "entra-sms-voice-mfa-retirement-passkeys": "Entra SMS and voice MFA retires on 1 February 2027",
    "defender-asr-rules-audit-to-block": "Defender ASR rules: from Audit to Block",
    "microsoft-365-copilot-oversharing-checklist-jira": "Microsoft 365 Copilot oversharing: five fixes before rollout",
    "entra-conditional-access-baseline-report-only": "Entra Conditional Access baseline: five policies, Report-only first",
    "entra-privileged-access-pim-global-admins": "Entra privileged access: fewer than five Global Admins, eligible roles in PIM",
    "exchange-online-protection-preset-policies-dmarc": "Exchange Online protection: preset policies, no external forwarding, DMARC to p=reject",
    "copilot-studio-agent-governance-checklist": "Copilot Studio and Entra agent governance: five controls to start with",
}


def kits_index(loaded):
    L = ["---", 'title: "Kits"',
         'description: "Microsoft 365 security kits for admins and MSPs: Copilot, AI agents, Conditional Access, PIM, Exchange Online, Defender for Endpoint. Free Top 5 for each."',
         "rl_type: kits", "---", "", "# Kits", ""]
    L.append('<p class="rl-lead">One kit per job. Each starts with a free Top 5 (Top 10 for Microsoft 365 hardening) and grows into a Complete kit you can run as a project.</p>')
    L.append("")
    area = None
    for kit, tiers in loaded:
        if kit["area"] != area:
            area = kit["area"]
            L.append(f"## {area}")
            L.append("")
        n = sum(len(t["controls"]) for t in tiers)
        price = f"Complete {n} controls, {kit['price']}" if kit["paid"] else ("Complete kit later" if kit["free"] else "Free Top 5 being published")
        L.append(f"### [{kit['name']}]({kit['page']}.md)")
        L.append("")
        L.append(f"{md_text(kit['outcome'])}  ")
        L.append(f'<span class="rl-kitmeta">Free Top {len(tiers[0]["controls"])}. {price}.</span>')
        L.append("")
    L.append("## Bundles")
    L.append("")
    L.append("Two bundles: the AI and Identity Pack (3 kits, €79) and the Microsoft 365 Hardening Library (all 8 Complete kits, €149). [See the bundles](bundles.md).")
    L.append("")
    (DOCS / "kits" / "index.md").write_text("\n".join(L), encoding="utf-8")


def kit_controls_index(kit, tiers):
    """Landing page for a kit's control section, so the section title in the left nav is a real link."""
    top = tiers[0]
    n_total = sum(len(t["controls"]) for t in tiers)
    L = ["---", f"title: {json.dumps(kit['short'] + ' controls')}",
         f"description: {json.dumps('The free Top 5 controls of the ' + kit['name'] + ' with steps, impact, rollback and read-only checks.')}",
         "rl_type: controls", "---", "", f"# {kit['short']} controls", ""]
    L.append(f'<p class="rl-lead">{esc(kit["outcome"])}</p>')
    L.append("")
    L.append("| ID | Control | Priority | Effort |")
    L.append("|---|---|---|---|")
    for c in top["controls"]:
        rel = control_path(kit, c).split("/", 2)[2]
        L.append(f"| {c['id']} | [{md_text(c['title'])}]({rel}) | {c['priority']} | {c['effort']} |")
    L.append("")
    L.append(f"These are the free Top {len(top['controls'])}. The [{kit['name']}](../../kits/{kit['page']}.md) has all {n_total} controls, with the Jira import, Excel plan and read-only script.")
    L.append("")
    p = DOCS / "controls" / kit["page"] / "index.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(L), encoding="utf-8")


def controls_index(loaded, pages):
    L = ["---", 'title: "Controls"',
         'description: "Microsoft 365 security controls with why, steps, impact, rollback, a read-only PowerShell check and the Microsoft Learn source."',
         "rl_type: controls", "---", "", "# Controls", ""]
    L.append('<p class="rl-lead">Every control page has the same parts: why it matters, the steps, what it does to users, how to roll it back, a read-only check, how to verify and the Microsoft Learn pages it is based on.</p>')
    L.append("")
    L.append(f"{len(pages)} controls are published here, the free Top 5 of each kit. The rest are listed on each kit's page.")
    L.append("")
    for kit, tiers in loaded:
        if not kit["strict"]:
            continue
        kit_controls_index(kit, tiers)
        L.append(f"## [{kit['short']}]({kit['page']}/index.md)")
        L.append("")
        L.append("| ID | Control | Priority | Effort |")
        L.append("|---|---|---|---|")
        for c in tiers[0]["controls"]:
            rel = control_path(kit, c).replace("controls/", "", 1)
            L.append(f"| {c['id']} | [{md_text(c['title'])}]({rel}) | {c['priority']} | {c['effort']} |")
        L.append("")
    (DOCS / "controls" / "index.md").write_text("\n".join(L), encoding="utf-8")


# ------------------------------------------------------------------ home
def home(loaded, news, deadlines):
    rows = []
    area = None
    for kit, tiers in loaded:
        n = sum(len(t["controls"]) for t in tiers)
        if kit["area"] != area:
            area = kit["area"]
            rows.append(f'<li class="rl-cat__area">{esc(area)}</li>')
        ntop = len(tiers[0]["controls"])
        label = (f"Free Top {ntop}, Complete {kit['price']}" if kit["paid"] else f"Free Top {ntop}, Complete later" if kit["free"] else f"Free Top {ntop} soon")
        status = f'<span class="rl-cat__price">{label}</span>'
        rows.append(
            f'<li class="rl-cat__row"><a href="{{{{ base_url }}}}/kits/{kit["page"]}{{{{ config.extra.rl_ext }}}}">'
            f'<span class="rl-cat__name">{esc(kit["name"])}</span>'
            f'<span class="rl-cat__out">{esc(kit["outcome"])}</span>'
            f'<span class="rl-cat__n">{n} controls</span>{status}</a></li>')
    dl = []
    for d in deadlines[:5]:
        attr = f' data-date="{d["iso"]}"' if d.get("iso") else ""
        link = d["href"]
        dl.append(
            f'<li class="rl-tl__item"{attr}><a href="{{{{ base_url }}}}/{link}{{{{ config.extra.rl_ext }}}}">'
            f'<span class="rl-tl__when">{esc(d["when"])}</span>'
            f'<span class="rl-tl__what">{esc(d["what"])}</span>'
            f'<span class="rl-tl__src">{esc(d["src"])}<span class="rl-tl__left"></span></span></a></li>')
    feat, more = news[0], news[1:4]
    def href(n):
        return f'{{{{ base_url }}}}/{n["href"]}{{{{ config.extra.rl_ext }}}}'
    featured = (f'<article class="rl-feature"><p class="rl-feature__meta"><span>{esc(n_cat(feat))}</span>'
                f'<time datetime="{feat["date"]}">{nice_date(feat["date"])}</time></p>'
                f'<h2 class="rl-feature__title"><a href="{href(feat)}">{esc(feat["title"])}</a></h2>'
                f'<p class="rl-feature__lead">{esc(feat["desc"])}</p>'
                f'<a class="rl-feature__go" href="{href(feat)}">Read the brief</a></article>')
    mr = [f'<li><a href="{href(n)}"><span class="rl-more__meta">{esc(n_cat(n))}, <time datetime="{n["date"]}">{nice_date(n["date"])}</time></span>'
          f'<span class="rl-more__t">{esc(n["title"])}</span></a></li>' for n in more]
    sample = loaded[2][1][0]["controls"][3]  # CA04 block legacy authentication
    tpl = HOME_TPL.replace("@@CATALOGUE@@", "\n".join(rows)).replace("@@TIMELINE@@", "\n".join(dl)).replace("@@FEATURED@@", featured).replace("@@MORE@@", "\n".join(mr))
    tpl = tpl.replace("@@S_ID@@", esc(sample["id"])).replace("@@S_TITLE@@", esc(sample["title"]))
    tpl = tpl.replace("@@S_WHY@@", esc(sample["why"])).replace("@@S_IMPACT@@", esc(sample["impact"]))
    tpl = tpl.replace("@@S_ROLLBACK@@", esc(sample["rollback"])).replace("@@S_CHECK@@", esc(split_ps(sample["check"])))
    tpl = tpl.replace("@@S_LINK@@", "controls/" + control_path(loaded[2][0], sample).replace("controls/", "", 1)[:-3])
    tpl = tpl.replace("@@S_STEP1@@", esc(sample["steps"][0]))
    lib = next(b for b in BUNDLES if b["slug"] == "m365-hardening-library")
    tpl = tpl.replace("@@LIB_LABEL@@", "The full library" if lib["live"] else "The full library (coming soon)")
    tpl = tpl.replace("@@N_CONTROLS@@", str(sum(len(t["controls"]) for _, tiers in loaded for t in tiers)))
    (ROOT / "overrides" / "home.html").write_text(tpl, encoding="utf-8")


HOME_TPL = (ROOT / "home.tpl.html").read_text(encoding="utf-8") if (ROOT / "home.tpl.html").exists() else ""

def load_news():
    """Newest first, from docs/news/posts/*.md front matter (date.created, slug, categories, description) and the H1."""
    import yaml
    items = []
    for f in sorted((DOCS / "news" / "posts").glob("*.md")):
        text = f.read_text(encoding="utf-8")
        m = re.match(r"---\n(.*?)\n---\n", text, re.S)
        if not m:
            continue
        meta = yaml.safe_load(m.group(1)) or {}
        if meta.get("draft"):
            continue
        created = (meta.get("date") or {}).get("created") if isinstance(meta.get("date"), dict) else meta.get("date")
        h1 = re.search(r"^# (.+)$", text[m.end():], re.M)
        items.append(dict(sort=str(created), date=str(created)[:10], href="news/" + meta["slug"],
                          title=h1.group(1).strip() if h1 else meta["slug"], desc=meta.get("description", ""),
                          cat=(meta.get("categories") or ["News"])[0]))
    items.sort(key=lambda x: x["sort"], reverse=True)
    return items


def n_cat(n):
    return n.get("cat", "News")


DEADLINES = [
    dict(when="First week of Nov 2026", iso=None, what="Teams: set file sharing in external chats before Microsoft turns it on",
         src="MC1479514", href="news/teams-external-chat-file-sharing-default"),
    dict(when="3 Nov 2026", iso="2026-11-03", what="Entra MemberOf dynamic rules stop updating groups, admin units and access packages",
         src="MC1529463", href="news/entra-memberof-dynamic-rule-retirement"),
    dict(when="7 Nov 2026", iso="2026-11-07", what="Entra SSPR stops accepting unregistered directory phone and email",
         src="MC1325414", href="news/entra-sspr-registered-methods-only"),
    dict(when="10 Nov 2026", iso="2026-11-10", what="Windows 11 23H2 Enterprise and Education stop getting updates",
         src="Windows message center", href="news/endpoint-devices-this-week-2026-10-31"),
    dict(when="12 Nov 2026", iso="2026-11-12", what="Copilot Studio retires older models and moves agents to new ones automatically",
         src="MC1506318", href="news/copilot-studio-model-retirement-12-november"),
    dict(when="End of Dec 2026", iso="2026-12-31", what="Exchange Online turns off SMTP AUTH Basic auth by default",
         src="MC786329", href="guides/exchange-online-smtp-auth-basic-auth-checklist"),
    dict(when="1 Feb 2027", iso="2027-02-01", what="Microsoft's own SMS and voice MFA retires for most users",
         src="MC1519855", href="guides/entra-sms-voice-mfa-retirement-passkeys"),
    dict(when="1 Feb 2027", iso="2027-02-01", what="Defender XDR Advanced Hunting APIs stop working",
         src="MC1220762", href="guides/deadlines"),
]


def briefbox(loaded):
    """overrides/partials/rl-briefbox.html: the box under every news brief, driven by rl_kits / rl_controls
    in the post's front matter. Template text lives in briefbox.tpl.html; this adds the kit and control data."""
    kits, ctl = {}, {}
    for kit, tiers in loaded:
        kits[kit["key"]] = dict(name=kit["name"], page=kit["page"], free=kit["free"] or "",
                                ntop=len(tiers[0]["controls"]), paid=bool(kit["paid"]))
        if kit["strict"]:
            for c in tiers[0]["controls"]:
                ctl[c["id"]] = dict(title=c["title"], path=control_path(kit, c)[:-3])
    tpl = (ROOT / "briefbox.tpl.html").read_text(encoding="utf-8")
    tpl = tpl.replace("@@KITS@@", json.dumps(kits)).replace("@@CONTROLS@@", json.dumps(ctl))
    (ROOT / "overrides" / "partials" / "rl-briefbox.html").write_text(tpl, encoding="utf-8")
    top = (ROOT / "kittop.tpl.html").read_text(encoding="utf-8").replace("@@KITS@@", json.dumps(kits))
    (ROOT / "overrides" / "partials" / "rl-kittop.html").write_text(top, encoding="utf-8")


def main():
    loaded = [(k, load(k)) for k in KITS]
    pages = []
    for kit, tiers in loaded:
        kit_page(kit, tiers)
        if kit["strict"]:
            cs = tiers[0]["controls"]
            for i, c in enumerate(cs):
                pages.append(write_control(kit, tiers, c, cs[i - 1] if i else None, cs[i + 1] if i + 1 < len(cs) else None))
    kits_index(loaded)
    controls_index(loaded, pages)
    home(loaded, load_news(), DEADLINES)
    briefbox(loaded)
    import deadlines_ics  # docs/deadlines.ics from the table in docs/guides/deadlines.md
    deadlines_ics.safe_build()
    # nav
    nav = ["nav:", "  - Home: index.md", "  - Kits:", "    - kits/index.md"]
    area = None
    for kit, _ in loaded:
        nav.append(f"    - {kit['short']}: kits/{kit['page']}.md")
    nav.append("    - Bundles: kits/bundles.md")
    nav += ["  - Controls:", "    - controls/index.md"]
    for kit, tiers in loaded:
        if not kit["strict"]:
            continue
        nav.append(f"    - {kit['short']}:")
        nav.append(f"      - controls/{kit['page']}/index.md")
        for c in tiers[0]["controls"]:
            nav.append(f"      - {json.dumps(c['id'] + ' ' + c['title'])}: {control_path(kit, c)}")
    nav += ["  - Guides:", "    - guides/index.md", "    - Security deadlines: guides/deadlines.md"]
    for slug, t in GUIDE_TITLES.items():
        nav.append(f"    - {json.dumps(t)}: guides/{slug}.md")
    nav += ["  - News:", "    - news/index.md", "  - About:", "    - about/index.md",
            "    - How we check: about/method.md", "    - Follow: about/follow.md", "    - Privacy: about/privacy.md"]
    cfg = (ROOT / "mkdocs.base.yml").read_text(encoding="utf-8") + "\n" + "\n".join(nav) + "\n"
    (ROOT / "mkdocs.yml").write_text(cfg, encoding="utf-8")
    print(f"kits {len(loaded)}, control pages {len(pages)}, total controls {sum(len(t['controls']) for _, ts in loaded for t in ts)}")


if __name__ == "__main__":
    main()
