#!/usr/bin/env python3
"""One-time port of the 5 storefront guide pages (runbooklabhq.github.io/guide-*.html) to Markdown.
Usage: python3 port_guides.py <pages_dir>. Output: docs/guides/<slug>.md (hand-edited afterwards is fine)."""
import re, sys
from pathlib import Path
from bs4 import BeautifulSoup, NavigableString

SRC = Path(sys.argv[1])
OUT = Path(__file__).resolve().parent / "docs" / "guides"
OUT.mkdir(parents=True, exist_ok=True)

OLD = "https://runbooklabhq.github.io/guide-"
KIT_FOR = {
    "microsoft-365-hardening-checklist-jira": "m365-hardening",
    "exchange-online-smtp-auth-basic-auth-checklist": "exchange-online-protection",
    "entra-sms-voice-mfa-retirement-passkeys": "sms-mfa-exit",
    "defender-asr-rules-audit-to-block": "defender-endpoint-asr",
    "microsoft-365-copilot-oversharing-checklist-jira": "copilot-readiness",
}


def fix_href(h, slug):
    if h.startswith(OLD):
        return h[len(OLD):].split("#")[0].replace(".html", ".md")
    if h.rstrip("/") == "https://runbooklabhq.github.io":
        return "../index.md"
    h = h.replace("https://gumroad.com/l/", "https://runbooklab.gumroad.com/l/")
    if "gumroad.com/l/" in h:
        base = h.split("?")[0]
        return f"{base}?utm_source=site&utm_campaign=guide-{slug}"
    return h


def inline(node, slug):
    out = []
    for ch in node.children:
        if isinstance(ch, NavigableString):
            t = str(ch).replace("<", "&lt;").replace(">", "&gt;")
            out.append(re.sub(r"\s+", " ", t))
        elif ch.name == "code":
            out.append("`" + ch.get_text() + "`")
        elif ch.name in ("b", "strong"):
            out.append("**" + inline(ch, slug).strip() + "**")
        elif ch.name in ("i", "em"):
            out.append("*" + inline(ch, slug).strip() + "*")
        elif ch.name == "a":
            out.append(f"[{inline(ch, slug).strip()}]({fix_href(ch.get('href', ''), slug)})")
        elif ch.name == "br":
            out.append("  \n")
        else:
            out.append(inline(ch, slug))
    return "".join(out)


def lang_for(code):
    if re.search(r"^\s*\|\s*where|DeviceEvents|summarize|ago\(", code, re.M):
        return "kusto"
    if re.search(r"^(v=|_dmarc|TXT)", code):
        return "text"
    return "powershell"


def block(el, slug, L):
    n = el.name
    if n is None:
        return
    cls = el.get("class") or []
    if n == "h2":
        L += [f"## {inline(el, slug).strip()}", ""]
    elif n == "h3":
        L += [f"### {inline(el, slug).strip()}", ""]
    elif n == "p":
        t = inline(el, slug).strip()
        if t:
            L += [t, ""]
    elif n == "pre":
        code = el.get_text().rstrip()
        L += [f"```{lang_for(code)}", code, "```", ""]
    elif n == "table":
        rows = el.find_all("tr")
        for i, r in enumerate(rows):
            cells = [inline(c, slug).strip().replace("|", "\\|") for c in r.find_all(["th", "td"])]
            L.append("| " + " | ".join(cells) + " |")
            if i == 0:
                L.append("|" + "---|" * len(cells))
        L.append("")
    elif n in ("ul", "ol"):
        for i, li in enumerate(el.find_all("li", recursive=False), 1):
            L.append(("1. " if n == "ol" else "- ") + inline(li, slug).strip())
        L.append("")
    elif n == "a" and "btn" in cls:
        kind = "{ .md-button .md-button--primary }" if "p" in cls else "{ .md-button }"
        L.append(f"[{inline(el, slug).strip()}]({fix_href(el.get('href', ''), slug)}){kind}")
        L.append("")
    elif n in ("div", "section", "article"):
        for ch in el.children:
            block(ch, slug, L)
    elif n == "footer":
        return


for f in sorted(SRC.glob("guide-*.html")):
    slug = f.stem[len("guide-"):]
    soup = BeautifulSoup(f.read_text(encoding="utf-8"), "lxml")
    wrap = soup.select_one(".wrap") or soup.body
    meta_desc = (soup.find("meta", attrs={"name": "description"}) or {}).get("content", "")
    title_tag = soup.title.get_text().split("|")[0].strip() if soup.title else ""
    first = wrap.find("p", class_="muted")
    updated = None
    if first:
        m = re.search(r"Updated (\d{1,2} \w+ \d{4})", first.get_text())
        updated = m.group(1) if m else None
        first.decompose()
    h1 = wrap.find("h1")
    h1_text = re.sub(r"\s+", " ", h1.get_text()).strip()
    h1.decompose()
    for ft in wrap.find_all("footer"):
        ft.decompose()
    L = ["---", f'title: "{title_tag or h1_text}"', f'description: "{meta_desc}"', "rl_type: guide"]
    if updated:
        L.append(f'rl_updated: "{updated}"')
    L += ["---", "", f"# {h1_text}", ""]
    if updated:
        L += [f'<p class="rl-updated">Last reviewed {updated}</p>', ""]
    lead = wrap.find("p", class_="lead")
    if lead:
        L += [f'<p class="rl-lead">{inline(lead, slug).strip()}</p>', ""]
        lead.decompose()
    for ch in wrap.children:
        block(ch, slug, L)
    md = "\n".join(L)
    md = re.sub(r"(\{ \.md-button[^}]*\})\n\n(\[[^\n]*\{ \.md-button)", r"\1\n\2", md)
    md = re.sub(r"(\{ \.md-button[^}]*\})\n\n(\[[^\n]*\{ \.md-button)", r"\1\n\2", md)
    md = re.sub(r"\n{3,}", "\n\n", md)
    (OUT / f"{slug}.md").write_text(md, encoding="utf-8")
    print(slug, len(md))
