/* Runbook Lab: days-left on the home deadline rail, plus small accessibility fixes. Items whose date has passed are hidden,
   so the rail never shows a stale date even if a rebuild is late. No cookies. */
(function () {
  function run() {
    var rail = document.querySelector(".rl-tl");
    if (!rail) return;
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var shown = 0;
    rail.querySelectorAll(".rl-tl__item").forEach(function (li) {
      var iso = li.getAttribute("data-date");
      if (!iso) { shown++; return; }
      var p = iso.split("-");
      var d = new Date(+p[0], +p[1] - 1, +p[2]);
      var days = Math.round((d - today) / 86400000);
      var out = li.querySelector(".rl-tl__left");
      if (days < 0) { li.hidden = true; return; }
      shown++;
      if (out) out.textContent = days === 0 ? "today" : days === 1 ? "1 day left" : days + " days left";
      if (days <= 21) li.classList.add("is-soon");
    });
    if (!shown) rail.hidden = true;
    rail.classList.add("is-ready");
  }
  /* Accessibility: wide tables and code blocks that scroll sideways must be reachable by keyboard. */
  function scrollRegions() {
    document.querySelectorAll(".md-typeset__scrollwrap, .md-typeset pre > code, .md-typeset .tabbed-labels").forEach(function (el) {
      var box = el;
      if (box.scrollWidth > box.clientWidth + 1 && !box.hasAttribute("tabindex")) {
        box.setAttribute("tabindex", "0");
        box.setAttribute("role", "region");
        box.setAttribute("aria-label", el.tagName === "CODE" ? "Code, scrolls sideways" : "Table, scrolls sideways");
      }
    });
  }
  if (typeof document$ !== "undefined" && document$.subscribe) document$.subscribe(scrollRegions);
  else document.addEventListener("DOMContentLoaded", scrollRegions);
  // Code in a tab that was hidden at load only overflows once the reader opens that tab.
  document.addEventListener("change", function (e) { if (e.target && e.target.closest && e.target.closest(".tabbed-set")) setTimeout(scrollRegions, 0); });
  if (typeof document$ !== "undefined" && document$.subscribe) document$.subscribe(run);
  else if (document.readyState !== "loading") run();
  else document.addEventListener("DOMContentLoaded", run);
})();

/* Runbook Lab analytics (tracking plan: _ops/data/TRACKING-PLAN.md).
   Product analytics with PostHog EU in cookieless mode: no cookies, no local or session storage, no profiles, no replay.
   Loaded only when the build has a project key, after the page is idle. ?rl_internal=1 turns it off for that page load;
   ?rl_debug=1 logs every event to the console. */
(function () {
  var qs = location.search || "";
  var internal = /[?&]rl_internal=1/.test(qs);
  var debug = /[?&]rl_debug=1/.test(qs);
  var phMeta = document.querySelector('meta[name="rl-ph"]');
  var pageMeta = document.querySelector('meta[name="rl-page"]');
  var path = location.pathname;

  function pageType() {
    var t = pageMeta ? pageMeta.getAttribute("content") : "other";
    if (t && t !== "other") return t;
    if (/\/news\/topic\//.test(path)) return "news_topic";
    if (/\/news\/(index\.html)?$/.test(path)) return "news_index";
    if (/\/kits\/bundles/.test(path)) return "bundles";
    return "other";
  }
  function kitFromPath() {
    var m = path.match(/\/(kits|controls)\/([a-z0-9-]+)/);
    return m && m[2] !== "index.html" && m[2] !== "bundles" ? m[2].replace(/\.html$/, "") : "";
  }
  var ctx = {
    page_type: pageType(),
    category: pageMeta ? pageMeta.getAttribute("data-category") || "" : "",
    kit: (pageMeta && pageMeta.getAttribute("data-kit")) || kitFromPath()
  };
  var ctrl = (document.querySelector(".rl-fact__v") || {}).textContent || "";
  if (ctx.page_type === "control" && /^[A-Z]{2,3}\d{2}$/.test(ctrl.trim())) ctx.control_id = ctrl.trim();

  var queue = [];
  var ph = null;
  function track(name, props) {
    var p = {};
    for (var k in ctx) if (ctx[k]) p[k] = ctx[k];
    for (var j in props || {}) if (props[j] !== undefined && props[j] !== "") p[j] = props[j];
    if (debug) try { console.log("[rl-analytics]", name, p); } catch (e) {}
    if (internal || !phMeta) return;
    if (ph) ph.capture(name, p); else queue.push([name, p]);
  }
  window.rlTrack = track;

  function load() {
    if (internal || !phMeta) return;
    var s = document.createElement("script");
    s.src = phMeta.getAttribute("data-src");
    s.async = true;
    s.onload = function () {
      if (!window.posthog || !window.posthog.init) return;
      window.posthog.init(phMeta.getAttribute("content"), {
        api_host: "https://eu.i.posthog.com",
        ui_host: "https://eu.posthog.com",
        cookieless_mode: "always",
        person_profiles: "never",
        persistence: "memory",
        disable_session_recording: true,
        disable_surveys: true,
        disable_external_dependency_loading: true,
        advanced_disable_flags: true,
        autocapture: true,
        capture_pageview: true,
        capture_pageleave: true,
        loaded: function (inst) {
          ph = inst;
          var reg = {};
          for (var k in ctx) if (ctx[k]) reg[k] = ctx[k];
          inst.register(reg);
          queue.splice(0).forEach(function (e) { inst.capture(e[0], e[1]); });
        }
      });
    };
    document.head.appendChild(s);
  }
  if (document.readyState === "complete") setTimeout(load, 1500);
  else window.addEventListener("load", function () {
    if (window.requestIdleCallback) requestIdleCallback(load, { timeout: 3000 }); else setTimeout(load, 1500);
  });

  /* Clicks: CTAs, outbound links, deadlines, code copy. */
  function placement(el) {
    var map = [[".rl-offer", "offer"], [".rl-buy__card, .rl-buy", "buy"], [".rl-kittop", "kittop"], [".rl-briefbox", "briefbox"], [".rl-kitbox", "kitbox"],
      [".rl-hero, .rl-front, .rl-cat__row, .rl-start, .rl-sec", "home"], [".md-header, .md-tabs, .md-nav", "nav"], [".md-footer", "footer"]];
    for (var i = 0; i < map.length; i++) if (el.closest(map[i][0])) return map[i][1];
    return "content";
  }
  document.addEventListener("click", function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var copy = t.closest('.md-clipboard, .md-code__button[data-md-type="copy"]');
    if (copy) {
      var blocks = Array.prototype.slice.call(document.querySelectorAll('.md-clipboard, .md-code__button[data-md-type="copy"]'));
      track("code_copied", { block_index: blocks.indexOf(copy) + 1 });
      return;
    }
    var dl = t.closest(".rl-tl__item");
    if (dl) track("deadline_clicked", { item: (dl.querySelector(".rl-tl__what") || dl).textContent.trim().slice(0, 100) });
    var a = t.closest("a[href]");
    if (!a) return;
    var href = a.href;
    var place = placement(a);
    var g = href.match(/gumroad\.com\/l\/([a-z0-9-]+)/i);
    if (g) {
      var slug = g[1].toLowerCase();
      var cta = /library|pack$/.test(slug) ? "buy_bundle" : /top\d+$/.test(slug) ? "download_free" : "buy_complete";
      track("cta_clicked", { cta: cta, product: slug, placement: place, href: href.split("?")[0] });
      return;
    }
    var gh = href.match(/github\.com\/runbooklabhq\/([a-z0-9-]+)/i);
    if (gh && !/\.github\.io$/.test(gh[1])) { track("cta_clicked", { cta: "view_github", product: gh[1], placement: place, href: href.split("?")[0] }); return; }
    if (/feed_rss|\.xml$/.test(href)) { track("cta_clicked", { cta: "rss", placement: place }); return; }
    if (/\/about\/follow/.test(href) || /(x\.com|twitter\.com)\/runbooklab|bsky\.app\/profile\/runbooklab|linkedin\.com\/company\/runbooklab|dev\.to\/runbooklab/.test(href)) {
      track("cta_clicked", { cta: "follow", placement: place, href: href.split("?")[0] }); return;
    }
    if (a.host === location.host) {
      var k = a.pathname.match(/\/kits\/([a-z0-9-]+)/);
      if (k && ctx.page_type !== "kit" && k[1] !== "index" && k[1] !== "bundles") track("cta_clicked", { cta: "see_kit", product: k[1].replace(/\.html$/, ""), placement: place });
      return;
    }
    if (/^https?:/.test(href)) track("outbound_clicked", { domain: a.hostname, href: href.split("?")[0].slice(0, 200), placement: place });
  }, true);

  /* Tabs, FAQ, theme. */
  document.addEventListener("change", function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    if (t.closest(".tabbed-set") && t.checked) {
      var lab = document.querySelector('label[for="' + t.id + '"]');
      track("tab_viewed", { tab: lab ? lab.textContent.trim().slice(0, 40) : t.id });
    } else if (t.name === "__palette") {
      track("theme_changed", { to: t.getAttribute("data-md-color-scheme") || (document.body.getAttribute("data-md-color-scheme") === "slate" ? "light" : "dark") });
    }
  }, true);
  document.addEventListener("toggle", function (e) {
    var d = e.target;
    if (d && d.tagName === "DETAILS" && d.open) {
      var s = d.querySelector("summary");
      track("faq_opened", { question: s ? s.textContent.trim().slice(0, 120) : "" });
    }
  }, true);

  /* Site search: what people look for, in their words. */
  var searchTimer = null, lastQuery = "";
  document.addEventListener("input", function (e) {
    var t = e.target;
    if (!t || !t.classList || !t.classList.contains("md-search__input")) return;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () {
      var q = (t.value || "").trim().toLowerCase().slice(0, 80);
      if (q.length < 3 || q === lastQuery) return;
      lastQuery = q;
      track("search_performed", { query: q, results: document.querySelectorAll(".md-search-result__item").length });
    }, 1500);
  }, true);

  /* Reading depth: 50 % and 90 %, and a completed read (90 % and at least 30 s). */
  var start = Date.now(), seen50 = false, seen90 = false, done = false;
  function depth() {
    var h = document.documentElement;
    var max = Math.max(1, h.scrollHeight - window.innerHeight);
    return Math.min(1, (window.scrollY || h.scrollTop) / max);
  }
  function checkRead() {
    var d = depth();
    if (!seen50 && d >= 0.5) { seen50 = true; track("scroll_depth", { depth: 50 }); }
    if (!seen90 && d >= 0.9) { seen90 = true; track("scroll_depth", { depth: 90 }); }
    var secs = Math.round((Date.now() - start) / 1000);
    if (!done && seen90 && secs >= 30) { done = true; track("read_completed", { seconds: secs }); }
  }
  window.addEventListener("scroll", function () { if (!done) checkRead(); }, { passive: true });
  setInterval(function () { if (!done && seen90) checkRead(); }, 5000);
})();
