/* Runbook Lab: days-left on the home deadline rail, plus small accessibility fixes. Items whose date has passed are hidden,
   so the rail never shows a stale date even if a rebuild is late. No cookies, no tracking. */
(function () {
  function run() {
    var rail = document.querySelector(".rl-tl");
    if (!rail) return;
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var shown = 0;
    rail.querySelectorAll(".rl-tl__item").forEach(function (li) {
      var iso = li.getAttribute("data-date");
      if (!iso) { shown++; return; }
      var p = iso.split("-");
      var d = new Date(+p[0], +p[1] - 1, +p[2]);
      var days = Math.round((d - today) / 86400000);
      var out = li.querySelector(".rl-tl__left");
      if (days < 0) { li.hidden = true; return; }
      shown++;
      if (out) out.textContent = days === 0 ? "today" : days === 1 ? "1 day left" : days + " days left";
      if (days <= 21) li.classList.add("is-soon");
    });
    if (!shown) rail.hidden = true;
    rail.classList.add("is-ready");
  }
  /* Accessibility: wide tables and code blocks that scroll sideways must be reachable by keyboard. */
  function scrollRegions() {
    document.querySelectorAll(".md-typeset__scrollwrap, .md-typeset pre > code, .md-typeset .tabbed-labels").forEach(function (el) {
      var box = el;
      if (box.scrollWidth > box.clientWidth + 1 && !box.hasAttribute("tabindex")) {
        box.setAttribute("tabindex", "0");
        box.setAttribute("role", "region");
        box.setAttribute("aria-label", el.tagName === "CODE" ? "Code, scrolls sideways" : "Table, scrolls sideways");
      }
    });
  }
  if (typeof document$ !== "undefined" && document$.subscribe) document$.subscribe(scrollRegions);
  else document.addEventListener("DOMContentLoaded", scrollRegions);
  // Code in a tab that was hidden at load only overflows once the reader opens that tab.
  document.addEventListener("change", function (e) { if (e.target && e.target.closest && e.target.closest(".tabbed-set")) setTimeout(scrollRegions, 0); });
  if (typeof document$ !== "undefined" && document$.subscribe) document$.subscribe(run);
  else if (document.readyState !== "loading") run();
  else document.addEventListener("DOMContentLoaded", run);
})();
