/* v3 (2026-11-25): home, "The next four weeks". Draws four calendar weeks from the dated list that gen.py writes from
   docs/guides/deadlines.md. Rules, the same as in gen.py: an exact date leaves when its day has passed; a window leaves when
   its END has passed; a window that has opened counts at its end and is never drawn on a day. Exact days are coloured
   (red: within 7 days, amber: within 14, violet: later). Up to eight rows of the drawn weeks are listed, the rest are
   counted in one link. Without JavaScript the plain list stays readable. No cookies, nothing sent anywhere. */
(function () {
  function day(iso) { var p = iso.split("-"); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function diff(a, b) { return Math.round((a - b) / 86400000); }
  function run() {
    var box = document.querySelector(".rl3-cal");
    var today = new Date(); today.setHours(0, 0, 0, 0);
    var briefs = document.querySelector('[data-rl3="briefs"]');
    if (briefs && briefs.getAttribute("data-dates")) {
      var n = 0;
      briefs.getAttribute("data-dates").split(",").forEach(function (iso) {
        var d = diff(today, day(iso));
        if (d >= 0 && d <= 6) n++;   /* seven calendar days, today included */
      });
      briefs.textContent = n;
    }
    if (!box) return;
    var grid = box.querySelector(".rl3-cal__grid");
    var MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var start = new Date(today); start.setDate(start.getDate() - ((start.getDay() + 6) % 7));   /* Monday of this week */
    var marks = {}, shown = 0, inWindow = 0;
    Array.prototype.forEach.call(box.querySelectorAll(".rl3-cal__item"), function (li) {
      var iso = li.getAttribute("data-date"); if (!iso) return;
      var approx = li.hasAttribute("data-approx");
      var endIso = li.getAttribute("data-end") || iso;
      if (diff(day(approx ? endIso : iso), today) < 0) { li.hidden = true; return; }       /* passed */
      var open = approx && diff(day(iso), today) < 0;                                      /* window opened since the build */
      var key = open ? day(endIso) : day(iso);
      if (diff(key, start) >= 28) { li.hidden = true; return; }                            /* after the drawn weeks */
      inWindow++;
      var days = diff(day(iso), today);
      var u = days <= 7 ? "u1" : days <= 14 ? "u2" : "u3";
      if (!approx && (!marks[iso] || u < marks[iso])) marks[iso] = u;
      shown++;
      if (shown > 8) { li.hidden = true; return; }
      var when = li.querySelector(".rl3-cal__when"), left = li.querySelector(".rl3-cal__left");
      if (open && when) when.textContent = "Now";
      if (when && !approx) when.classList.add(u);
      if (left && !approx) { left.classList.add(u); left.textContent = days === 0 ? "today" : days === 1 ? "in 1 day" : "in " + days + " days"; }
    });
    var stat = document.querySelector('[data-rl3="dates"]');
    if (stat) stat.textContent = inWindow;
    box.classList.add("is-ready");
    var more = box.querySelector(".rl3-cal__more");
    if (more) { if (inWindow > 8) { more.textContent = "+ " + (inWindow - 8) + " more in these four weeks"; more.hidden = false; } else more.hidden = true; }
    if (!grid) return;
    var html = "";
    ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].forEach(function (d) { html += '<span class="rl3-cal__dow">' + d.toUpperCase() + "</span>"; });
    for (var i = 0; i < 28; i++) {
      var d = new Date(start); d.setDate(start.getDate() + i);
      var iso = d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
      var cls = "rl3-cal__day" + (d < today ? " is-past" : "") + (+d === +today ? " is-today" : "") + (marks[iso] ? " is-mark " + marks[iso] : "");
      html += '<span class="' + cls + '">' + (d.getDate() === 1 && i ? d.getDate() + " " + MON[d.getMonth()] : d.getDate()) + "</span>";
    }
    grid.innerHTML = html;
    grid.hidden = false;
  }
  if (document.readyState !== "loading") run(); else document.addEventListener("DOMContentLoaded", run);
})();
