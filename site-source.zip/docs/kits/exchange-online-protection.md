---
title: "Exchange Online Protection Kit"
description: "Preset policies, SPF, DKIM and DMARC to p=reject, no silent forwarding, and Defender for Office 365 set up properly. Free Top 5 with Jira import, Excel plan and read-only checks."
rl_type: kit
---

# Exchange Online Protection Kit

<p class="rl-lead">Preset policies, SPF, DKIM and DMARC to p=reject, no silent forwarding, and Defender for Office 365 set up properly.</p>

Five Exchange Online protection controls to put in place first: the Standard preset security policy (Strict for priority accounts), automatic external forwarding blocked, SPF and DKIM for every sending domain, DMARC on its way to p=reject, and the anti-malware attachment filter with zero-hour auto purge. Each control has why, steps, impact, rollback, a read-only PowerShell check, how to verify, licence, effort and the Microsoft Learn page it is based on.

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 5 of 20 controls</p>

The 5 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/exchange-online-protection-top5?utm_source=site&utm_campaign=kit-exchange-online-protection){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/exchange-online-protection-kit-free){ .md-button }

<p class="rl-offer__next">Need all 20? <a href="#get-the-complete-kit">See the Complete kit</a></p>

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, impact, rollback, the read-only check, how to verify, licence and effort |
| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Read-only: Get-* cmdlets and DNS lookups only. Changes nothing in your tenant. Results go to a CSV. |

### A look inside the free Top 5

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Sprint |
    |---|---|---|---|---|---|
    | 1 | Epic | Exchange Online Protection Kit: Preset policies and baseline | High |  |  |
    | 2 | Epic | Exchange Online Protection Kit: Email authentication (SPF, DKIM, DMARC) | High |  |  |
    | 3 | Epic | Exchange Online Protection Kit: Outbound mail and forwarding | High |  |  |
    | 4 | Story | [EX01] Turn on the Standard preset security policy for all users (Strict for priority accounts) | Highest | 1 | Sprint 1 - Baseline |
    | 5 | Story | [EX02] Block automatic forwarding to external addresses and review the forwards that already exist | Highest | 3 | Sprint 1 - Baseline |
    | 6 | Story | [EX03] Publish SPF and turn on DKIM signing for every domain that sends mail | Highest | 2 | Sprint 2 - Authenticate your domains |
    | 7 | Story | [EX04] Publish DMARC for every domain and move it from p=none to p=reject | High | 2 | Sprint 2 - Authenticate your domains |

    </div>

    <p class="rl-caption">First 7 of 8 rows of <code>exchange-online-protection-kit-top-5-jira-import.csv</code>: 3 epics and 5 stories, with parent, priority, sprint and labels already set. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | EX01 | Turn on the Standard preset security policy for all users (Strict for priority accounts) | Sprint 1 - Baseline | Highest | 2 | To do |
    | EX02 | Block automatic forwarding to external addresses and review the forwards that already exist | Sprint 1 - Baseline | Highest | 2 | To do |
    | EX03 | Publish SPF and turn on DKIM signing for every domain that sends mail | Sprint 2 - Authenticate your domains | Highest | 3 | To do |
    | EX04 | Publish DMARC for every domain and move it from p=none to p=reject | Sprint 2 - Authenticate your domains | High | 1 | To do |
    | EX05 | Anti-malware: common attachments filter on with Reject, zero-hour auto purge on, admin-only quarantine | Sprint 1 - Baseline | High | 0.5 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>exchange-online-protection-kit-top-5-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     Exchange Online Protection Kit: Top 5 - read-only checks (Runbook Lab)
     Read-only: Get-* cmdlets and DNS lookups only. Changes nothing in your tenant.
     Requires: ExchangeOnlineManagement module (3.x). DNS checks use Resolve-DnsName (Windows PowerShell 5.1 or PowerShell 7 on Windows).
     Connect first:
       Connect-ExchangeOnline
       Connect-IPPSSession   # only for the alert policy check (EX20)
     Role: Global Reader, Security Reader or View-Only Organization Management is enough for these reads.
     Output: .\hardening-check-results.csv (ID, Control, Status, Output).
    #>
    ...
    Invoke-Check 'EX01' 'Turn on the Standard preset security policy for all users (Strict for priority accounts)' { foreach ($n in 'Standard Preset Security Policy','Strict Preset Security Policy') { foreach ($r in @(Get-EOPProtectionPolicyRule -Identity $n -ErrorAction SilentlyContinue)) { "EOP | $n | State: $($r.State) | domains: $(@($r.RecipientDomainIs) -join ',') | groups: $(@($r.SentToMemberOf) -join ',')" }; foreach ($r in @(Get-ATPProtectionPolicyRule -Identity $n -ErrorAction SilentlyContinue)) { "MDO | $n | State: $($r.State)" } }; "Rules only exist after a preset was turned on once in the portal. No output above = presets never enabled." }
    ...
    ```

    <p class="rl-caption">The header and the first of 5 checks in <code>exchange-online-protection-kit-top-5-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>.</p>

## Controls

### Free Top 5

| ID | Control | Priority | Effort |
|---|---|---|---|
| EX01 | [Turn on the Standard preset security policy for all users (Strict for priority accounts)](../controls/exchange-online-protection/ex01-turn-on-the-standard-preset-security-policy-for-all-users.md) | Highest | 2 h |
| EX02 | [Block automatic forwarding to external addresses and review the forwards that already exist](../controls/exchange-online-protection/ex02-block-automatic-forwarding-to-external-addresses-and.md) | Highest | 2 h |
| EX03 | [Publish SPF and turn on DKIM signing for every domain that sends mail](../controls/exchange-online-protection/ex03-publish-spf-and-turn-on-dkim-signing-for-every-domain.md) | Highest | 3 h |
| EX04 | [Publish DMARC for every domain and move it from p=none to p=reject](../controls/exchange-online-protection/ex04-publish-dmarc-for-every-domain-and-move-it-from-p-none-to.md) | High | 1 h set-up + 4 to 8 weeks monitoring |
| EX05 | [Anti-malware: common attachments filter on with Reject, zero-hour auto purge on, admin-only quarantine](../controls/exchange-online-protection/ex05-anti-malware-common-attachments-filter-on-with-reject.md) | High | 30 min |

### Added in the Complete kit (15)

| ID | Control | Area | Effort |
|---|---|---|---|
| EX06 | Inbound anti-spam: Standard values for bulk, spam and phishing, zero-hour auto purge on | Preset policies and baseline | 1 h |
| EX07 | Outbound spam: sending limits and block the user when a limit is reached | Outbound mail and forwarding | 30 min |
| EX08 | Anti-phishing: spoof intelligence on, honour DMARC p=quarantine and p=reject, first contact safety tip | Preset policies and baseline | 30 min |
| EX09 | Impersonation protection: users and domains to protect, mailbox intelligence, phishing threshold 3 | Defender for Office 365 (phishing, links, attachments) | 2 h |
| EX10 | Safe Attachments: Block for email, and turn it on for SharePoint, OneDrive and Teams | Defender for Office 365 (phishing, links, attachments) | 1 h |
| EX11 | Safe Links: scan at click time for email, Teams and Office apps, no click-through | Defender for Office 365 (phishing, links, attachments) | 1 h |
| EX12 | Quarantine policies: admin-only for phishing and malware, notifications for spam | Quarantine, reporting and operations | 1 h |
| EX13 | User-reported messages: Report button to Microsoft and a reporting mailbox, excluded from filtering | Quarantine, reporting and operations | 1 h |
| EX14 | Tenant Allow/Block List and spoofed-sender allows: every allow entry has an owner and an end date | Quarantine, reporting and operations | 1 h |
| EX15 | Connection filter and anti-spam allow lists: no broad IP allows, safe list decided on purpose | Quarantine, reporting and operations | 30 min |
| EX16 | Turn on the External sender tag in Outlook and retire subject-line [EXTERNAL] rules | Preset policies and baseline | 30 min |
| EX17 | Review mail flow rules that bypass spam filtering (SCL -1) or forward and redirect mail | Quarantine, reporting and operations | 1 h |
| EX18 | SMTP AUTH: off for the organisation, allowed only on named mailboxes, ready for Basic auth off by default | Outbound mail and forwarding | 2 h + time to move devices |
| EX19 | Priority accounts: Strict preset, Priority account tag and filtered views for alerts and quarantine | Defender for Office 365 (phishing, links, attachments) | 1 h |
| EX20 | Monthly review: Configuration analyzer, drift, and the default email alert policies | Quarantine, reporting and operations | 30 min per month |

## Before you run the checks

```text
Requires: ExchangeOnlineManagement module (3.x). DNS checks use Resolve-DnsName (Windows PowerShell 5.1 or PowerShell 7 on Windows).
Connect first:
Connect-ExchangeOnline
Connect-IPPSSession   # only for the alert policy check (EX20)
Role: Global Reader, Security Reader or View-Only Organization Management is enough for these reads.
```

## Read first

The free guide [Exchange Online protection: preset policies, no external forwarding, DMARC to p=reject](../guides/exchange-online-protection-preset-policies-dmarc.md) covers the same ground step by step, with the commands inline.

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, what each change breaks and how to roll it back, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.0 (2026-10-28; facts re-read on Microsoft Learn 2026-10-28; validated: quality gate, read-only guard, syntax check, Excel recalc). Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Get the Complete kit

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### Exchange Online Protection Kit: Complete

<p class="rl-buy__price">€29</p>

All 20 controls in sprints, with the same files as the free Top 5. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Complete kit](https://runbooklab.gumroad.com/l/exchange-online-protection-kit?utm_source=site&utm_campaign=kit-exchange-online-protection){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €272 for the kits separately</span></p>

8 Complete kits: Microsoft 365 hardening, SMS and voice MFA exit, Copilot readiness, AI agent hardening, Defender for Endpoint and ASR, Conditional Access, **Exchange Online protection**, Privileged access and PIM.

[Buy the bundle](https://runbooklab.gumroad.com/l/m365-hardening-library?utm_source=site&utm_campaign=kit-exchange-online-protection-bundle){ .md-button }

</div>

</div>

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "Exchange Online Protection Kit", "description": "Preset policies, SPF, DKIM and DMARC to p=reject, no silent forwarding, and Defender for Office 365 set up properly.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 5", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/exchange-online-protection-top5"}, {"@type": "Offer", "name": "Complete (20 controls)", "price": "29", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/exchange-online-protection-kit"}]}</script>
