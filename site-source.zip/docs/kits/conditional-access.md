---
title: "Conditional Access Baseline Kit"
description: "A Conditional Access baseline with phishing-resistant MFA for admins and no legacy sign-in paths. Free Top 5 with Jira import, Excel plan and read-only checks."
rl_type: kit
---

# Conditional Access Baseline Kit

<p class="rl-lead">A Conditional Access baseline with phishing-resistant MFA for admins and no legacy sign-in paths.</p>

Five Conditional Access controls to put in place first in Microsoft Entra ID: emergency access accounts excluded and monitored, report-only discipline, MFA for all users with an authentication strength, legacy authentication blocked, and phishing-resistant MFA for administrators. Each control has why, steps, impact, rollback, a read-only PowerShell check, how to verify, licence, effort and the Microsoft Learn page it is based on.

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 5 of 20 controls</p>

The 5 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=kit-conditional-access){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/entra-conditional-access-kit-free){ .md-button }

<p class="rl-offer__next">Need all 20? <a href="#get-the-complete-kit">See the Complete kit</a></p>

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, impact, rollback, the read-only check, how to verify, licence and effort |
| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Read-only: Get-* cmdlets and Microsoft Graph GET requests only. Changes nothing in your tenant. Results go to a CSV. |

### A look inside the free Top 5

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Sprint |
    |---|---|---|---|---|---|
    | 1 | Epic | Conditional Access Baseline Kit: Foundation and emergency access | High |  |  |
    | 2 | Epic | Conditional Access Baseline Kit: Strong authentication for everyone | High |  |  |
    | 3 | Epic | Conditional Access Baseline Kit: Block weak sign-in paths | High |  |  |
    | 4 | Story | [CA01] Create two emergency access accounts, exclude them from every policy and alert on their use | Highest | 1 | Sprint 1 - Foundation |
    | 5 | Story | [CA02] Name policies by persona and create every new policy in Report-only first | Highest | 1 | Sprint 1 - Foundation |
    | 6 | Story | [CA03] Require MFA for all users on all resources with an authentication strength | Highest | 2 | Sprint 2 - Enforce MFA and block legacy |
    | 7 | Story | [CA04] Block legacy authentication for all users | Highest | 3 | Sprint 2 - Enforce MFA and block legacy |

    </div>

    <p class="rl-caption">First 7 of 8 rows of <code>conditional-access-baseline-kit-top-5-jira-import.csv</code>: 3 epics and 5 stories, with parent, priority, sprint and labels already set. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | CA01 | Create two emergency access accounts, exclude them from every policy and alert on their use | Sprint 1 - Foundation | Highest | 2 | To do |
    | CA02 | Name policies by persona and create every new policy in Report-only first | Sprint 1 - Foundation | Highest | 1 | To do |
    | CA03 | Require MFA for all users on all resources with an authentication strength | Sprint 2 - Enforce MFA and block legacy | Highest | 2 | To do |
    | CA04 | Block legacy authentication for all users | Sprint 2 - Enforce MFA and block legacy | Highest | 1 | To do |
    | CA05 | Require phishing-resistant MFA for administrators | Sprint 2 - Enforce MFA and block legacy | Highest | 2 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>conditional-access-baseline-kit-top-5-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     Conditional Access Baseline Kit: Top 5 - read-only checks (Runbook Lab)
     Read-only: Get-* cmdlets and Microsoft Graph GET requests only. Changes nothing in your tenant.
     Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.SignIns, .Reports, .Identity.DirectoryManagement).
     Connect first:
       Connect-MgGraph -Scopes Policy.Read.All,AuditLog.Read.All,UserAuthenticationMethod.Read.All,Directory.Read.All
     Role: Global Reader or Security Reader is enough for these reads.
     Output: .\hardening-check-results.csv (ID, Control, Status, Output).
    #>
    ...
    Invoke-Check 'CA01' 'Create two emergency access accounts, exclude them from every policy and alert on their use' { $p = Get-MgIdentityConditionalAccessPolicy -All; $p | Where-Object { $_.State -ne 'disabled' } | ForEach-Object { "$($_.DisplayName) | $($_.State) | excluded users: $(@($_.Conditions.Users.ExcludeUsers).Count) | excluded groups: $(@($_.Conditions.Users.ExcludeGroups).Count)" }; "Active policies with NO user or group exclusion (break-glass not excluded?): $(@($p | Where-Object { $_.State -ne 'disabled' -and -not $_.Conditions.Users.ExcludeUsers -and -not $_.Conditions.Users.ExcludeGroups }).Count)" }
    ...
    ```

    <p class="rl-caption">The header and the first of 5 checks in <code>conditional-access-baseline-kit-top-5-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>.</p>

## Controls

### Free Top 5

| ID | Control | Priority | Effort |
|---|---|---|---|
| CA01 | [Create two emergency access accounts, exclude them from every policy and alert on their use](../controls/conditional-access/ca01-create-two-emergency-access-accounts-exclude-them-from.md) | Highest | 2 h |
| CA02 | [Name policies by persona and create every new policy in Report-only first](../controls/conditional-access/ca02-name-policies-by-persona-and-create-every-new-policy-in.md) | Highest | 1 h |
| CA03 | [Require MFA for all users on all resources with an authentication strength](../controls/conditional-access/ca03-require-mfa-for-all-users-on-all-resources-with-an.md) | Highest | 2 h + 7 days report-only |
| CA04 | [Block legacy authentication for all users](../controls/conditional-access/ca04-block-legacy-authentication-for-all-users.md) | Highest | 1 h + 7 days report-only |
| CA05 | [Require phishing-resistant MFA for administrators](../controls/conditional-access/ca05-require-phishing-resistant-mfa-for-administrators.md) | Highest | 2 h + 7 days report-only |

### Added in the Complete kit (15)

| ID | Control | Area | Effort |
|---|---|---|---|
| CA06 | Enable passkeys (FIDO2) with passkey profiles | Authentication methods and passwordless | 2 h |
| CA07 | Set up Temporary Access Pass for onboarding and recovery | Authentication methods and passwordless | 1 h |
| CA08 | Turn on the registration campaign for passkeys | Authentication methods and passwordless | 30 min |
| CA09 | Plan for the retirement of Microsoft-provided SMS and voice MFA | Authentication methods and passwordless | 2 h |
| CA10 | Protect security info registration with Conditional Access | Authentication methods and passwordless | 1 h + 7 days report-only |
| CA11 | Block device code flow | Block weak sign-in paths | 1 h + 7 days report-only |
| CA12 | Require strong authentication for medium and high sign-in risk | Risk and session controls | 1 h + 7 days report-only |
| CA13 | Require risk remediation for high user risk | Risk and session controls | 1 h + 7 days report-only |
| CA14 | Shorten sessions on unmanaged devices and admin portals | Risk and session controls | 1 h |
| CA15 | Pilot token protection for Windows and Apple native apps | Risk and session controls | 2 h + 14 days report-only |
| CA16 | Require MFA for guests and decide on cross-tenant MFA trust | Strong authentication for everyone | 1 h |
| CA17 | Review named locations and trusted networks | Block weak sign-in paths | 1 h |
| CA18 | Turn on the Conditional Access insights and reporting workbook | Operate and review | 2 h |
| CA19 | Review every policy exclusion each quarter | Operate and review | 1 h per quarter |
| CA20 | Export all policies as a dated JSON backup and track changes | Operate and review | 30 min per quarter |

## Before you run the checks

```text
Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.SignIns, .Reports, .Identity.DirectoryManagement).
Connect first:
Connect-MgGraph -Scopes Policy.Read.All,AuditLog.Read.All,UserAuthenticationMethod.Read.All,Directory.Read.All
Role: Global Reader or Security Reader is enough for these reads.
```

## Read first

The free guide [Entra Conditional Access baseline: five policies, Report-only first](../guides/entra-conditional-access-baseline-report-only.md) covers the same ground step by step, with the commands inline.

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, what each change breaks and how to roll it back, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.0 (2026-10-28; facts re-read on Microsoft Learn 2026-10-28; validated: quality gate, read-only guard, PowerShell 7.4 parse, Excel recalc). Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Get the Complete kit

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### Conditional Access Baseline Kit: Complete

<p class="rl-buy__price">€29</p>

All 20 controls in sprints, with the same files as the free Top 5. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Complete kit](https://runbooklab.gumroad.com/l/entra-conditional-access-kit?utm_source=site&utm_campaign=kit-conditional-access){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### AI and Identity Pack

<p class="rl-buy__price">€79 <span>instead of €107 for the kits separately</span></p>

3 Complete kits: Copilot readiness, AI agent hardening, **Conditional Access**.

[Buy the bundle](https://runbooklab.gumroad.com/l/ai-identity-pack?utm_source=site&utm_campaign=kit-conditional-access-bundle){ .md-button }

</div>

<div class="rl-buy__card" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €272 for the kits separately</span></p>

8 Complete kits: Microsoft 365 hardening, SMS and voice MFA exit, Copilot readiness, AI agent hardening, Defender for Endpoint and ASR, **Conditional Access**, Exchange Online protection, Privileged access and PIM.

[Buy the bundle](https://runbooklab.gumroad.com/l/m365-hardening-library?utm_source=site&utm_campaign=kit-conditional-access-bundle){ .md-button }

</div>

</div>

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "Conditional Access Baseline Kit", "description": "A Conditional Access baseline with phishing-resistant MFA for admins and no legacy sign-in paths.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 5", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/entra-conditional-access-top5"}, {"@type": "Offer", "name": "Complete (20 controls)", "price": "29", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/entra-conditional-access-kit"}]}</script>
