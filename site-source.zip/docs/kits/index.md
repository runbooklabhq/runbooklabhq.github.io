---
title: "Kits"
description: "Microsoft 365 security kits for admins and MSPs: Copilot, AI agents, Conditional Access, PIM, Exchange Online, Defender for Endpoint. Free Top 5 for each."
rl_type: kits
---

# Kits

<p class="rl-lead">One kit per job. Each starts with a free Top 5 (Top 10 for Microsoft 365 hardening) and grows into a Complete kit you can run as a project.</p>

## AI security

### [M365 Copilot Readiness Kit](copilot-readiness.md)

Fix oversharing before Copilot finds it, then roll Copilot out with Purview guardrails.  
<span class="rl-kitmeta">Free Top 5. Complete 24 controls, €39.</span>

### [M365 AI Agent Hardening Kit](ai-agent-hardening.md)

Inventory, guardrails and accountable owners for Copilot Studio agents and Entra agent identities.  
<span class="rl-kitmeta">Free Top 5. Complete 20 controls, €39.</span>

## Identity

### [Conditional Access Baseline Kit](conditional-access.md)

A Conditional Access baseline with phishing-resistant MFA for admins and no legacy sign-in paths.  
<span class="rl-kitmeta">Free Top 5. Complete 20 controls, €29.</span>

### [Privileged Access and PIM Kit](privileged-access-pim.md)

Fewer standing admins: eligible roles in PIM, strict Tier 0 settings and quarterly reviews.  
<span class="rl-kitmeta">Free Top 5. Complete kit later.</span>

### [Entra SMS MFA Exit Kit](sms-mfa-exit.md)

Get phone-only users to passkeys before Microsoft's SMS and voice MFA retires on 1 February 2027.  
<span class="rl-kitmeta">Free Top 5. Complete 12 controls, €29.</span>

## Email

### [Exchange Online Protection Kit](exchange-online-protection.md)

Preset policies, SPF, DKIM and DMARC to p=reject, no silent forwarding, and Defender for Office 365 set up properly.  
<span class="rl-kitmeta">Free Top 5. Complete 20 controls, €29.</span>

## Endpoint

### [Defender for Endpoint and ASR Kit](defender-endpoint-asr.md)

Every device onboarded, tamper protection on, and ASR rules moved from Audit to Block without outages.  
<span class="rl-kitmeta">Free Top 5. Complete 15 controls, €29.</span>

## Whole tenant

### [M365 Hardening Kit](m365-hardening.md)

A first pass across the whole tenant: Entra ID, Exchange Online, Teams, SharePoint, OneDrive and Purview.  
<span class="rl-kitmeta">Free Top 10. Complete 58 controls, €39.</span>

## Bundles

Two bundles are on the way: the AI and Identity Pack and the Microsoft 365 Hardening Library. [See the bundles](bundles.md).
