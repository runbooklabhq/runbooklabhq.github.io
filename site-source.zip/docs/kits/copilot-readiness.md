---
title: "M365 Copilot Readiness Kit"
description: "Fix oversharing before Copilot finds it, then roll Copilot out with Purview guardrails. Free Top 5 with Jira import, Excel plan and read-only checks."
rl_type: kit
---

# M365 Copilot Readiness Kit

<p class="rl-lead">Fix oversharing before Copilot finds it, then roll Copilot out with Purview guardrails.</p>

Five controls to stop Microsoft 365 Copilot from surfacing files people should never have seen. Copilot only shows what a user can already open, so the work is fixing oversharing before rollout, then setting safer defaults. Each control has why, steps, impact, rollback, a read-only PowerShell check, how to verify, licence, effort and the Microsoft Learn page it is based on. It follows the order of Microsoft's own Copilot oversharing blueprint (remediate oversharing, set up guardrails, meet regulations).

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 5 of 24 controls</p>

The 5 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=kit-copilot-readiness){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/m365-copilot-readiness-free){ .md-button }

<p class="rl-offer__next">Need all 24? <a href="#get-the-complete-kit">See the Complete kit</a></p>

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, impact, rollback, the read-only check, how to verify, licence and effort |
| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Read-only: Get-* and Search-* cmdlets only. Changes nothing in your tenant. Results go to a CSV. |

### A look inside the free Top 5

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Sprint |
    |---|---|---|---|---|---|
    | 1 | Epic | M365 Copilot Readiness Kit: Find and fix oversharing | High |  |  |
    | 2 | Epic | M365 Copilot Readiness Kit: Safer sharing defaults | High |  |  |
    | 3 | Epic | M365 Copilot Readiness Kit: Copilot audit and evidence | High |  |  |
    | 4 | Story | [CR01] Find the overshared sites before Copilot does | Highest | 1 | Sprint 1 - Before Copilot pilot |
    | 5 | Story | [CR02] Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery) | Highest | 1 | Sprint 1 - Before Copilot pilot |
    | 6 | Story | [CR03] Make 'Specific people, view' the default sharing link and put an expiry on Anyone links | High | 2 | Sprint 1 - Before Copilot pilot |
    | 7 | Story | [CR04] Remove 'Everyone except external users' from sensitive sites and hide it in the people picker | High | 2 | Sprint 2 - Remediate and guard |

    </div>

    <p class="rl-caption">First 7 of 8 rows of <code>m365-copilot-readiness-kit-top-5-jira-import.csv</code>: 3 epics and 5 stories, with parent, priority, sprint and labels already set. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | CR01 | Find the overshared sites before Copilot does | Sprint 1 - Before Copilot pilot | Highest | 2 | To do |
    | CR02 | Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery) | Sprint 1 - Before Copilot pilot | Highest | 1 | To do |
    | CR03 | Make 'Specific people, view' the default sharing link and put an expiry on Anyone links | Sprint 1 - Before Copilot pilot | High | 1 | To do |
    | CR04 | Remove 'Everyone except external users' from sensitive sites and hide it in the people picker | Sprint 2 - Remediate and guard | High | 2 | To do |
    | CR05 | Confirm Copilot interactions are audited and searchable | Sprint 1 - Before Copilot pilot | High | 0.5 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>m365-copilot-readiness-kit-top-5-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     M365 Copilot Readiness Kit: Top 5 - read-only checks (Runbook Lab)
     Read-only: Get-* and Search-* cmdlets only. Changes nothing in your tenant.
     Requires: Microsoft.Online.SharePoint.PowerShell (SharePoint settings), ExchangeOnlineManagement (audit).
     Connect first:
       Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
       Connect-ExchangeOnline
     Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). CR05 will move to the Graph AuditLogQuery API before then.
     Output: .\hardening-check-results.csv (ID, Control, Status, Output).
    #>
    ...
    Invoke-Check 'CR01' 'Find the overshared sites before Copilot does' { $s = Get-SPOSite -Limit All | Where-Object { $_.SharingCapability -ne 'Disabled' }; "Sites with external sharing on: $($s.Count)"; $s | Group-Object SharingCapability | ForEach-Object { "$($_.Name): $($_.Count)" }; $s | Where-Object { $_.SharingCapability -eq 'ExternalUserAndGuestSharing' } | Select-Object -First 50 | ForEach-Object { "Anyone links allowed: $($_.Url)" } }
    ...
    ```

    <p class="rl-caption">The header and the first of 5 checks in <code>m365-copilot-readiness-kit-top-5-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>.</p>

## Controls

### Free Top 5

| ID | Control | Priority | Effort |
|---|---|---|---|
| CR01 | [Find the overshared sites before Copilot does](../controls/copilot-readiness/cr01-find-the-overshared-sites-before-copilot-does.md) | Highest | 2 h |
| CR02 | [Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery)](../controls/copilot-readiness/cr02-hide-the-riskiest-sites-from-copilot-while-you-fix-them.md) | Highest | 1 h |
| CR03 | [Make 'Specific people, view' the default sharing link and put an expiry on Anyone links](../controls/copilot-readiness/cr03-make-specific-people-view-the-default-sharing-link-and.md) | High | 1 h |
| CR04 | [Remove 'Everyone except external users' from sensitive sites and hide it in the people picker](../controls/copilot-readiness/cr04-remove-everyone-except-external-users-from-sensitive.md) | High | 2 h + site owner time |
| CR05 | [Confirm Copilot interactions are audited and searchable](../controls/copilot-readiness/cr05-confirm-copilot-interactions-are-audited-and-searchable.md) | High | 30 min |

### Added in the Complete kit (19)

| ID | Control | Area | Effort |
|---|---|---|---|
| CR06 | Plan the pilot ring and match licences to it | Pilot, licences and Copilot settings | 2 h |
| CR07 | Decide web search for Copilot and set it in Cloud Policy | Pilot, licences and Copilot settings | 30 min |
| CR08 | Limit who can use and share agents in the Microsoft 365 admin center | Pilot, licences and Copilot settings | 30 min |
| CR09 | Lock business-critical sites to named groups (Restricted Access Control) | Find and fix oversharing | 2 h |
| CR10 | Make Anyone links view-only and short-lived, then clean up the old ones | Safer sharing defaults | 1 h |
| CR11 | Fix broken inheritance on sensitive libraries and folders | Find and fix oversharing | 2 h + owner time |
| CR12 | Give every site an owner (site ownership policy) | Site lifecycle and ownership | 1 h |
| CR13 | Run DSPM data risk assessments in the current DSPM, not the classic view | Find and fix oversharing | 1 h |
| CR14 | Publish sensitivity labels and turn on labels for files in SharePoint and OneDrive | Purview guardrails for Copilot | 2 h |
| CR15 | Set a default sensitivity label on sensitive document libraries | Purview guardrails for Copilot | 1 h |
| CR16 | Label sensitive files at rest with an auto-labeling policy (simulation first) | Purview guardrails for Copilot | 2 h |
| CR17 | Stop Copilot from processing your most sensitive labels (DLP for Copilot) | Purview guardrails for Copilot | 1 h |
| CR18 | Test DLP for sensitive data in Copilot prompts (preview, simulation only) | Purview guardrails for Copilot | 1 h |
| CR19 | Watch for risky AI use with Insider Risk Management | Purview guardrails for Copilot | 2 h |
| CR20 | Retire inactive sites (inactive site policy and Microsoft 365 Archive) | Site lifecycle and ownership | 1 h |
| CR21 | Decide how long to keep Copilot audit records | Copilot audit and evidence | 30 min |
| CR22 | Set a retention policy for Copilot prompts and responses | Copilot audit and evidence | 1 h |
| CR23 | Write the eDiscovery procedure for Copilot content | Copilot audit and evidence | 1 h |
| CR24 | Monthly review: re-run the reports and remove interim protections | Find and fix oversharing | 1 h per month |

## Before you run the checks

```text
Requires: Microsoft.Online.SharePoint.PowerShell (SharePoint settings), ExchangeOnlineManagement (audit).
Connect first:
Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
Connect-ExchangeOnline
Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). CR05 will move to the Graph AuditLogQuery API before then.
```

## Read first

The free guide [Microsoft 365 Copilot oversharing: five fixes before rollout](../guides/microsoft-365-copilot-oversharing-checklist-jira.md) covers the same ground step by step, with the commands inline.

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, what each change breaks and how to roll it back, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.0 (2026-10-28; facts re-read on Microsoft Learn 2026-10-28; validated: quality gate, read-only guard, PowerShell 7.4 parse, Excel recalc). Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Get the Complete kit

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### M365 Copilot Readiness Kit: Complete

<p class="rl-buy__price">€39</p>

All 24 controls in sprints, with the same files as the free Top 5. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Complete kit](https://runbooklab.gumroad.com/l/copilot-readiness-kit?utm_source=site&utm_campaign=kit-copilot-readiness){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### AI and Identity Pack

<p class="rl-buy__price">€79 <span>instead of €107 for the kits separately</span></p>

3 Complete kits: **Copilot readiness**, AI agent hardening, Conditional Access.

[Buy the bundle](https://runbooklab.gumroad.com/l/ai-identity-pack?utm_source=site&utm_campaign=kit-copilot-readiness-bundle){ .md-button }

</div>

<div class="rl-buy__card" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €272 for the kits separately</span></p>

8 Complete kits: Microsoft 365 hardening, SMS and voice MFA exit, **Copilot readiness**, AI agent hardening, Defender for Endpoint and ASR, Conditional Access, Exchange Online protection, Privileged access and PIM.

[Buy the bundle](https://runbooklab.gumroad.com/l/m365-hardening-library?utm_source=site&utm_campaign=kit-copilot-readiness-bundle){ .md-button }

</div>

</div>

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "M365 Copilot Readiness Kit", "description": "Fix oversharing before Copilot finds it, then roll Copilot out with Purview guardrails.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 5", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/copilot-readiness-top5"}, {"@type": "Offer", "name": "Complete (24 controls)", "price": "39", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/copilot-readiness-kit"}]}</script>
