---
title: "Entra SMS MFA Exit Kit"
description: "Get phone-only users to passkeys before Microsoft's SMS and voice MFA retires on 1 February 2027. Free Top 5 with Jira import, Excel plan and read-only checks."
rl_type: kit
rl_service: ["entra"]
---

# Entra SMS MFA Exit Kit

<p class="rl-lead">Get phone-only users to passkeys before Microsoft&#x27;s SMS and voice MFA retires on 1 February 2027.</p>

The five steps to do first before Microsoft retires its SMS and voice MFA. Microsoft-provided SMS and voice authentication retires on 1 February 2027 for all users except Global Administrators and external users (internal guests are in scope), and on 1 July 2027 for Global Administrators and external users (Microsoft Learn, 'Passkeys by default and retirement of Microsoft-provided SMS and voice authentication', and message center post MC1426371 state both dates). The July date applies only while the Global Administrator role is active: users who are only eligible for it (for example in PIM) follow 1 February 2027. After the date, users whose only MFA method is SMS or voice get a blocking prompt to register a passkey. There is no opt-out for enforcement. The Complete kit adds admins and break-glass, guests, SSPR, the telephony-provider decision, the temporary opt-out, helpdesk onboarding and weekly tracking (12 controls).

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 5 of 12 controls</p>

The 5 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/sms-mfa-exit-top5?utm_source=site&utm_campaign=kit-sms-mfa-exit){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/entra-sms-mfa-exit-kit-free){ .md-button }

<p class="rl-offer__next">Need all 12? <a href="#get-the-complete-kit">See the Complete kit</a></p>

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, the read-only check, how to verify, licence and effort (impact and rollback are being added) |
| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Get-* cmdlets only. Changes nothing. Results go to a CSV. |

### A look inside the free Top 5

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Due date |
    |---|---|---|---|---|---|
    | 1 | Epic | Entra SMS MFA Exit Kit: Find who is affected | High |  |  |
    | 2 | Epic | Entra SMS MFA Exit Kit: Move users to passkeys | High |  |  |
    | 3 | Task | [SM01] List the users whose only MFA method is SMS or voice | Highest | 1 |  |
    | 4 | Task | [SM02] Check where SMS and voice are enabled in the Authentication methods policy | Highest | 1 |  |
    | 5 | Task | [SM03] Enable Passkey (FIDO2) for the affected users | Highest | 2 |  |
    | 6 | Task | [SM04] Run a registration campaign for passkeys aimed at the affected group | High | 2 |  |
    | 7 | Task | [SM05] Tell users in three waves: awareness, action, reminder | High | 2 |  |

    </div>

    <p class="rl-caption">First 7 of 7 rows of <code>entra-sms-mfa-exit-kit-top-5-jira-import.csv</code>: 2 epics and 5 tickets, with parent, priority and labels set, and a due date where Microsoft has set one. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | SM01 | List the users whose only MFA method is SMS or voice | Sprint 1 - Find | Highest | 0.5 | To do |
    | SM02 | Check where SMS and voice are enabled in the Authentication methods policy | Sprint 1 - Find | Highest | 0.5 | To do |
    | SM03 | Enable Passkey (FIDO2) for the affected users | Sprint 1 - Find | Highest | 1 | To do |
    | SM04 | Run a registration campaign for passkeys aimed at the affected group | Sprint 2 - Move | High | 0.5 | To do |
    | SM05 | Tell users in three waves: awareness, action, reminder | Sprint 2 - Move | High | 2 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>entra-sms-mfa-exit-kit-top-5-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     Entra SMS MFA Exit Kit: Top 5 - read-only checks (Runbook Lab)
     Uses Get-* cmdlets and Graph GET requests only. Changes nothing in your tenant; writes local CSV files.
     Requires: Microsoft.Graph.Authentication, Microsoft.Graph.Identity.SignIns, Microsoft.Graph.Reports.
     The script does not connect by itself: it uses your current Microsoft Graph session. Connect first (read-only scopes):
       Connect-MgGraph -Scopes AuditLog.Read.All,Policy.Read.AuthenticationMethod
     Output: .\hardening-check-results.csv (ID, Control, Output or Error).
    #>
    ...
    Invoke-Check 'SM01' 'List the users whose only MFA method is SMS or voice' { $r = @(Get-MgReportAuthenticationMethodUserRegistrationDetail -All); $ph = { param($m) @($m | Where-Object { $_ -match 'phone' }).Count -gt 0 -and @($m | Where-Object { $_ -notmatch 'phone' -and $_ -notin 'email','securityQuestion','securityQuestions','temporaryAccessPass' }).Count -eq 0 }; $only = @($r | Where-Object { & $ph @($_.MethodsRegistered) }); "Users in registration report: $($r.Count)"; if ($r.Count -eq 0) { 'REVIEW: the report returned no users (permission, licence or report delay)' } elseif ($only.Count -gt 0) { "APPLIES: phone-only users (SMS/voice is their only MFA method): $($only.Count)" } else { 'NOT FOUND: no phone-only users in the report' }; "  of which admins (any admin role): $(@($only | Where-Object { $_.IsAdmin }).Count)"; "  of which guests: $(@($only | Where-Object { $_.UserType -eq 'guest' }).Count)"; $only | Select-Object UserPrincipalName, UserType, IsAdmin, @{n='Methods';e={$_.MethodsRegistered -join ';'}} | Export-Csv -NoTypeInformation -Encoding UTF8 .\phone-only-users.csv; 'Exported .\phone-only-users.csv' }
    ...
    ```

    <p class="rl-caption">The header and the first of 4 checks in <code>entra-sms-mfa-exit-kit-top-5-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>.</p>

## Controls

### Free Top 5

| ID | Control | Priority | Effort |
|---|---|---|---|
| SM01 | List the users whose only MFA method is SMS or voice | Highest | 30 min |
| SM02 | Check where SMS and voice are enabled in the Authentication methods policy | Highest | 30 min |
| SM03 | Enable Passkey (FIDO2) for the affected users | Highest | 1 h |
| SM04 | Run a registration campaign for passkeys aimed at the affected group | High | 30 min |
| SM05 | Tell users in three waves: awareness, action, reminder | High | 2 h |

### Added in the Complete kit (7)

| ID | Control | Area | Effort |
|---|---|---|---|
| SM06 | Plan Global Administrators and external users for 1 July 2027 | Admins, guests, SSPR and exceptions | 1 h |
| SM07 | Handle internal guests (in scope on 1 February 2027) | Admins, guests, SSPR and exceptions | 1 h |
| SM08 | Decide whether you really need a telephony provider | Admins, guests, SSPR and exceptions | 2 h |
| SM09 | Check self-service password reset (SSPR) for phone-only users | Admins, guests, SSPR and exceptions | 1 h |
| SM10 | Know whether your tenant used the temporary opt-out | Admins, guests, SSPR and exceptions | 15 min |
| SM11 | Give the helpdesk a safe way to onboard users who are stuck | Move users to passkeys | 1 h |
| SM12 | Track the count to zero every week until 1 February 2027 | Find who is affected | 15 min/week |

## Read first

The free guide [Entra SMS and voice MFA retires on 1 February 2027](../guides/entra-sms-voice-mfa-retirement-passkeys.md) covers the same ground step by step, with the commands inline.

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.1 (2026-11-16; Microsoft Learn and message center re-read 16 Nov 2026). This kit was built before the 27 October 2026 quality gate: impact and rollback are being added to its controls. Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Get the Complete kit

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### Entra SMS MFA Exit Kit: Complete

<p class="rl-buy__price">€29</p>

All 12 controls in sprints, with the same files as the free Top 5. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Complete kit](https://runbooklab.gumroad.com/l/sms-mfa-exit-kit?utm_source=site&utm_campaign=kit-sms-mfa-exit){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €272 for the kits separately</span></p>

8 Complete kits: Microsoft 365 hardening, **SMS and voice MFA exit**, Copilot readiness, AI agent hardening, Defender for Endpoint and ASR, Conditional Access, Exchange Online protection, Privileged access and PIM.

[Buy the bundle](https://runbooklab.gumroad.com/l/m365-hardening-library?utm_source=site&utm_campaign=kit-sms-mfa-exit-bundle){ .md-button }

</div>

</div>

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "Entra SMS MFA Exit Kit", "description": "Get phone-only users to passkeys before Microsoft's SMS and voice MFA retires on 1 February 2027.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 5", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/sms-mfa-exit-top5"}, {"@type": "Offer", "name": "Complete (12 controls)", "price": "29", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/sms-mfa-exit-kit"}], "image": "https://runbooklabhq.com/assets/kits/sms-mfa-exit.png"}</script>
