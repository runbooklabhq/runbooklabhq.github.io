---
title: "M365 Hardening Kit"
description: "A first pass across the whole tenant: Entra ID, Exchange Online, Teams, SharePoint, OneDrive and Purview. Free Top 10 with Jira import, Excel plan and read-only checks."
rl_type: kit
---

# M365 Hardening Kit

<p class="rl-lead">A first pass across the whole tenant: Entra ID, Exchange Online, Teams, SharePoint, OneDrive and Purview.</p>

The ten Microsoft 365 controls to do first, in one sprint. Each control has why, steps, a read-only PowerShell check where one exists, how to verify, licence and effort. Continue with the Complete kit (Sprints 2-5, 48 controls).

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 10 of 58 controls</p>

The 10 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/m365-hardening-top10?utm_source=site&utm_campaign=kit-m365-hardening){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/m365-hardening-kit-free){ .md-button }

<p class="rl-offer__next">Need all 58? <a href="#get-the-complete-kit">See the Complete kit</a></p>

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, the read-only check, how to verify, licence and effort (impact and rollback are being added) |
| Jira import (CSV) | Jira CSV with labels, priority and Microsoft due dates, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Get-* cmdlets only. Changes nothing. Results go to a CSV. |

### A look inside the free Top 10

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Due date |
    |---|---|---|---|---|---|
    | 1 | Epic | M365 Hardening Kit: Identity & access (Entra ID) | High |  |  |
    | 2 | Epic | M365 Hardening Kit: Exchange Online & email security | High |  |  |
    | 3 | Epic | M365 Hardening Kit: Audit & governance | High |  |  |
    | 4 | Task | [E01] Create two break-glass (emergency access) accounts | Highest | 1 |  |
    | 5 | Task | [E02] Require MFA for all users | Highest | 1 |  |
    | 6 | Task | [E03] Block legacy authentication | Highest | 1 |  |
    | 7 | Task | [E04] Reduce and separate admin accounts | High | 1 |  |

    </div>

    <p class="rl-caption">First 7 of 13 rows of <code>m365-hardening-kit-emergency-top-10-jira-import.csv</code>: 3 epics and 10 tickets, with parent, priority and labels set, and a due date where Microsoft has set one. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | E01 | Create two break-glass (emergency access) accounts | Sprint 1 - Emergency | Highest | 0.5 | To do |
    | E02 | Require MFA for all users | Sprint 1 - Emergency | Highest | 2 | To do |
    | E03 | Block legacy authentication | Sprint 1 - Emergency | Highest | 1 | To do |
    | E04 | Reduce and separate admin accounts | Sprint 1 - Emergency | High | 2 | To do |
    | E05 | Restrict user consent to applications | Sprint 1 - Emergency | High | 0.5 | To do |
    | E06 | Confirm audit logging is on | Sprint 1 - Emergency | High | 0.25 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>m365-hardening-kit-emergency-top-10-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     M365 Hardening Kit: Emergency Top 10 - read-only checks (Runbook Lab)
     Uses Get-* cmdlets only. Changes nothing in your tenant.
     Requires: Microsoft.Graph, ExchangeOnlineManagement, MicrosoftTeams, Microsoft.Online.SharePoint.PowerShell (as needed).
     Connect first, e.g.:
       Connect-MgGraph -Scopes Policy.Read.All,Directory.Read.All,AuditLog.Read.All,RoleManagement.Read.Directory
       Connect-ExchangeOnline; Connect-IPPSSession; Connect-MicrosoftTeams; Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
     Output: .\hardening-check-results.csv (ID, Control, Output or Error). Feed it to the m365-hardening-coach skill.
    #>
    ...
    Invoke-Check 'E02' 'Require MFA for all users' { Get-MgPolicyIdentitySecurityDefaultEnforcementPolicy | Select-Object IsEnabled; Get-MgIdentityConditionalAccessPolicy | Select-Object DisplayName, State }
    ...
    ```

    <p class="rl-caption">The header and the first of 8 checks in <code>m365-hardening-kit-emergency-top-10-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>. The header mentions the m365-hardening-coach skill: an optional, free Claude skill that reads that CSV and suggests the order of work. The checks don't need it; use it only if your policy allows sharing the results file with an AI tool.</p>

## Controls

### Free Top 10

| ID | Control | Priority | Effort |
|---|---|---|---|
| E01 | Create two break-glass (emergency access) accounts | Highest | 30 min |
| E02 | Require MFA for all users | Highest | 1-2 h |
| E03 | Block legacy authentication | Highest | 1 h |
| E04 | Reduce and separate admin accounts | High | 1-2 h |
| E05 | Restrict user consent to applications | High | 30 min |
| E06 | Confirm audit logging is on | High | 15 min |
| E07 | Block automatic external email forwarding | High | 30 min |
| E08 | Apply the Standard preset security policy | High | 30 min |
| E09 | Set up SPF, DKIM and DMARC | High | 1 h + DNS wait |
| E10 | Self-service password reset with banned passwords | Medium | 1 h |

### Added in the Complete kit (48)

| ID | Control | Area | Effort |
|---|---|---|---|
| X01 | Manage all MFA and SSPR methods in the Authentication methods policy | Identity & access (Entra ID) | 1-2 h |
| X02 | Require phishing-resistant MFA for admin roles | Identity & access (Entra ID) | 2 h |
| X03 | Remove SMS and voice as sign-in methods where possible | Identity & access (Entra ID) | 1 h |
| X04 | Block the device code authentication flow | Identity & access (Entra ID) | 1 h |
| X05 | Risk-based Conditional Access (sign-in risk and user risk) | Identity & access (Entra ID) | 1 h |
| X06 | Require a compliant or hybrid-joined device for admins | Identity & access (Entra ID) | 2-4 h |
| X07 | Shorter sessions for admins and unmanaged devices | Identity & access (Entra ID) | 30 min |
| X08 | Block sign-ins from countries you never operate in | Identity & access (Entra ID) | 1 h |
| X09 | Lock down default user permissions | Identity & access (Entra ID) | 30 min |
| X10 | Restrict guest permissions and who can invite guests | Identity & access (Entra ID) | 30 min |
| X11 | Quarterly guest account review | Identity & access (Entra ID) | 1 h + recurring |
| X12 | Just-in-time admin access with PIM | Identity & access (Entra ID) | 2 h |
| X13 | Passwords never expire (with MFA in place) | Identity & access (Entra ID) | 15 min |
| X14 | Require MFA to register or join devices and security info | Identity & access (Entra ID) | 30 min |
| M01 | Move every SMTP AUTH sender off Basic auth before the end of December 2026 | Exchange Online & Defender for Office 365 | 2-4 h |
| M02 | Strict preset policy for priority accounts | Exchange Online & Defender for Office 365 | 30 min |
| M03 | Impersonation protection for key people and domains | Exchange Online & Defender for Office 365 | 1 h |
| M04 | Quarantine policies: users cannot release malware or high-confidence phish | Exchange Online & Defender for Office 365 | 30 min |
| M05 | Tag external senders in Outlook | Exchange Online & Defender for Office 365 | 10 min |
| M06 | Block third-party storage providers in Outlook on the web | Exchange Online & Defender for Office 365 | 15 min |
| M07 | Stop users installing Outlook add-ins | Exchange Online & Defender for Office 365 | 30 min |
| M08 | Block sign-in to shared mailboxes | Exchange Online & Defender for Office 365 | 15 min |
| M09 | Review mail flow rules and allow lists that bypass filtering | Exchange Online & Defender for Office 365 | 1 h |
| M10 | Move DMARC to quarantine, then reject | Exchange Online & Defender for Office 365 | 30 min + 2-4 weeks |
| M11 | Turn on the Report button and route reports to a mailbox | Exchange Online & Defender for Office 365 | 15 min |
| T01 | Limit external access to approved domains and block unmanaged Teams accounts | Microsoft Teams | 30 min |
| T02 | Decide on file sharing in external Teams chats (MC1479514, before early November 2026) | Microsoft Teams | 15 min |
| T03 | Decide what guests can do in Teams | Microsoft Teams | 30 min |
| T04 | Meeting lobby and presenter defaults | Microsoft Teams | 30 min |
| T05 | Control third-party and custom Teams apps | Microsoft Teams | 30 min |
| T06 | Turn off email into channels | Microsoft Teams | 10 min |
| T07 | Block third-party cloud storage in Teams | Microsoft Teams | 10 min |
| T08 | Let users report suspicious Teams messages | Microsoft Teams | 15 min |
| S01 | Set org-level external sharing to existing or new guests, not Anyone | SharePoint & OneDrive | 30 min |
| S02 | If Anyone links stay on: expiry and view-only | SharePoint & OneDrive | 15 min |
| S03 | Default sharing link = Specific people, permission = View | SharePoint & OneDrive | 10 min |
| S04 | Guest access expiry and same-account sign-in | SharePoint & OneDrive | 15 min |
| S05 | Allow sharing only with approved domains | SharePoint & OneDrive | 15 min |
| S06 | Browser-only access from unmanaged devices | SharePoint & OneDrive | 1 h |
| S07 | Block download of files flagged as malicious and legacy auth to SharePoint | SharePoint & OneDrive | 10 min |
| S08 | Find and fix oversharing before Microsoft 365 Copilot | SharePoint & OneDrive | 1-2 h |
| P01 | Route default alert policies to a monitored mailbox | Purview, monitoring & governance | 30 min |
| P02 | Publish a simple sensitivity label set | Purview, monitoring & governance | 2-4 h |
| P03 | Start a DLP policy in simulation mode | Purview, monitoring & governance | 2 h |
| P04 | Agree and apply retention for mail, Teams and files | Purview, monitoring & governance | 1 h |
| P05 | Secure Score baseline and monthly review | Purview, monitoring & governance | 30 min + monthly |
| P06 | Extend audit retention and export sign-in logs | Purview, monitoring & governance | 1 h |
| P07 | Review OAuth app permissions and unused service principals | Purview, monitoring & governance | 1 h |

## Read first

The free guide [Microsoft 365 hardening checklist, ready for Jira](../guides/microsoft-365-hardening-checklist-jira.md) covers the same ground step by step, with the commands inline.

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.1. This kit was built before the 27 October 2026 quality gate: impact and rollback are being added to its controls. Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Get the Complete kit

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### M365 Hardening Kit: Complete

<p class="rl-buy__price">€39</p>

All 58 controls in sprints, with the same files as the free Top 10. Open the plan as Jira tickets with one command (Import-RunbookLabPlan.ps1): skips tickets that exist and records each read-only check result on its ticket. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Complete kit](https://runbooklab.gumroad.com/l/m365-hardening-kit?utm_source=site&utm_campaign=kit-m365-hardening){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €272 for the kits separately</span></p>

8 Complete kits: **Microsoft 365 hardening**, SMS and voice MFA exit, Copilot readiness, AI agent hardening, Defender for Endpoint and ASR, Conditional Access, Exchange Online protection, Privileged access and PIM.

[Buy the bundle](https://runbooklab.gumroad.com/l/m365-hardening-library?utm_source=site&utm_campaign=kit-m365-hardening-bundle){ .md-button }

</div>

</div>

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "M365 Hardening Kit", "description": "A first pass across the whole tenant: Entra ID, Exchange Online, Teams, SharePoint, OneDrive and Purview.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 10", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/m365-hardening-top10"}, {"@type": "Offer", "name": "Complete (58 controls)", "price": "39", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/m365-hardening-kit"}], "image": "https://runbooklabhq.com/assets/kits/m365-hardening.png"}</script>
