---
title: "M365 AI Agent Hardening Kit"
description: "Inventory, guardrails and accountable owners for Copilot Studio agents and Entra agent identities. Free Top 5 with Jira import, Excel plan and read-only checks."
rl_type: kit
---

# M365 AI Agent Hardening Kit

<p class="rl-lead">Inventory, guardrails and accountable owners for Copilot Studio agents and Entra agent identities.</p>

Five controls to put guardrails around AI agents in Microsoft 365: Copilot Studio agents and Microsoft Entra agent identities. Each control has why, steps, a read-only PowerShell check, how to verify, licence, effort and the Microsoft Learn page it is based on. Controls AG01-AG04 work without Microsoft Agent 365. AG05 needs Agent 365, and the guide says so.

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 5 of 20 controls</p>

The 5 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=kit-ai-agent-hardening){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/m365-ai-agent-hardening-free){ .md-button }

<p class="rl-offer__next">Need all 20? <a href="#get-the-complete-kit">See the Complete kit</a></p>

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, impact, rollback, the read-only check, how to verify, licence and effort |
| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Read-only: Get-* and Search-* cmdlets and Microsoft Graph GET requests only. Changes nothing in your tenant. Results go to a CSV. |

### A look inside the free Top 5

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Sprint |
    |---|---|---|---|---|---|
    | 1 | Epic | M365 AI Agent Hardening Kit: Agent inventory & monitoring | High |  |  |
    | 2 | Epic | M365 AI Agent Hardening Kit: Copilot Studio guardrails | High |  |  |
    | 3 | Epic | M365 AI Agent Hardening Kit: Agent identities (Microsoft Entra Agent ID) | High |  |  |
    | 4 | Story | [AG01] Inventory every agent in the tenant | Highest | 1 | Sprint 1 - AI agent baseline |
    | 5 | Story | [AG02] Require user authentication for Copilot Studio agents | Highest | 2 | Sprint 1 - AI agent baseline |
    | 6 | Story | [AG03] Block HTTP requests and channels you don't use | High | 2 | Sprint 1 - AI agent baseline |
    | 7 | Story | [AG04] Watch agent creation, publishing, sharing and authentication changes | High | 1 | Sprint 1 - AI agent baseline |

    </div>

    <p class="rl-caption">First 7 of 8 rows of <code>m365-ai-agent-hardening-kit-top-5-jira-import.csv</code>: 3 epics and 5 stories, with parent, priority, sprint and labels already set. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | AG01 | Inventory every agent in the tenant | Sprint 1 - AI agent baseline | Highest | 1 | To do |
    | AG02 | Require user authentication for Copilot Studio agents | Sprint 1 - AI agent baseline | Highest | 0.5 | To do |
    | AG03 | Block HTTP requests and channels you don't use | Sprint 1 - AI agent baseline | High | 1 | To do |
    | AG04 | Watch agent creation, publishing, sharing and authentication changes | Sprint 1 - AI agent baseline | High | 1 | To do |
    | AG05 | Block high-risk agent identities with Conditional Access | Sprint 1 - AI agent baseline | High | 0.5 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>m365-ai-agent-hardening-kit-top-5-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     M365 AI Agent Hardening Kit: Top 5 - read-only checks (Runbook Lab)
     Read-only: Get-* and Search-* cmdlets and Microsoft Graph GET requests only. Changes nothing in your tenant.
     Requires: Microsoft.Graph (Conditional Access + agent identities), ExchangeOnlineManagement (audit search), Microsoft.PowerApps.Administration.PowerShell (data policies).
     Connect first:
       Connect-MgGraph -Scopes AgentIdentity.Read.All,Policy.Read.All
       Connect-ExchangeOnline
       Add-PowerAppsAccount
     Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). AG04 will move to the Graph AuditLogQuery API before then.
     Output: .\hardening-check-results.csv (ID, Control, Status, Output).
    #>
    ...
    Invoke-Check 'AG01' 'Inventory every agent in the tenant' { $u = 'https://graph.microsoft.com/v1.0/servicePrincipals/microsoft.graph.agentIdentity?$select=id,displayName,accountEnabled,agentIdentityBlueprintId,createdDateTime'; $all = @(); while ($u) { $r = Invoke-MgGraphRequest -Method GET -Uri $u; $all += $r.value; $u = $r.'@odata.nextLink' }; "Agent identities: $($all.Count)"; $all | ForEach-Object { "$($_.displayName) | enabled: $($_.accountEnabled) | created: $($_.createdDateTime)" } }
    ...
    ```

    <p class="rl-caption">The header and the first of 5 checks in <code>m365-ai-agent-hardening-kit-top-5-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>.</p>

## Controls

### Free Top 5

| ID | Control | Priority | Effort |
|---|---|---|---|
| AG01 | [Inventory every agent in the tenant](../controls/ai-agent-hardening/ag01-inventory-every-agent-in-the-tenant.md) | Highest | 1 h |
| AG02 | [Require user authentication for Copilot Studio agents](../controls/ai-agent-hardening/ag02-require-user-authentication-for-copilot-studio-agents.md) | Highest | 30 min |
| AG03 | [Block HTTP requests and channels you don't use](../controls/ai-agent-hardening/ag03-block-http-requests-and-channels-you-don-t-use.md) | High | 1 h |
| AG04 | [Watch agent creation, publishing, sharing and authentication changes](../controls/ai-agent-hardening/ag04-watch-agent-creation-publishing-sharing-and.md) | High | 1 h |
| AG05 | [Block high-risk agent identities with Conditional Access](../controls/ai-agent-hardening/ag05-block-high-risk-agent-identities-with-conditional-access.md) | High | 30 min |

### Added in the Complete kit (15)

| ID | Control | Area | Effort |
|---|---|---|---|
| AG06 | Route makers out of the default environment | Environments, sharing and cost | 1 h |
| AG07 | Show makers the rules when they start (maker welcome content) | Environments, sharing and cost | 30 min |
| AG08 | Limit how widely Copilot Studio agents can be shared | Environments, sharing and cost | 30 min |
| AG09 | Decide whether agents with generative AI features may be published at all | Copilot Studio guardrails | 30 min |
| AG10 | Cap Copilot credits per environment and per agent | Environments, sharing and cost | 30 min |
| AG11 | Control who can use and share agents in Microsoft 365 Copilot | Copilot Studio guardrails | 30 min |
| AG12 | Make sure every agent identity has a sponsor who is still here | Agent identities (Microsoft Entra Agent ID) | 1 h |
| AG13 | Give agents access through access packages that expire | Agent identities (Microsoft Entra Agent ID) | 2 h |
| AG14 | Allow only approved agent identities to sign in (Conditional Access allowlist) | Agent identities (Microsoft Entra Agent ID) | 1 h |
| AG15 | Require a compliant device for agent users that run on endpoints (preview) | Agent identities (Microsoft Entra Agent ID) | 1 h |
| AG16 | Block risky agent users (preview) | Agent identities (Microsoft Entra Agent ID) | 30 min |
| AG17 | Alert on agent sharing and authentication changes in your SIEM | Agent inventory & monitoring | 2 h |
| AG18 | Move audit scripts to the AuditLogQuery Graph API before October 2027 | Agent inventory & monitoring | 2 h |
| AG19 | Review every agent each quarter with the agent register | Agent inventory & monitoring | 1 h per quarter |
| AG20 | Run new agents through an approval workflow before they reach production | Copilot Studio guardrails | 2 h |

## Before you run the checks

```text
Requires: Microsoft.Graph (Conditional Access + agent identities), ExchangeOnlineManagement (audit search), Microsoft.PowerApps.Administration.PowerShell (data policies).
Connect first:
Connect-MgGraph -Scopes AgentIdentity.Read.All,Policy.Read.All
Connect-ExchangeOnline
Add-PowerAppsAccount
Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). AG04 will move to the Graph AuditLogQuery API before then.
```

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, what each change breaks and how to roll it back, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.0 (2026-10-28; facts re-read on Microsoft Learn 2026-10-24, AG02 and AG05 again 2026-10-28; validated: quality gate, read-only guard, PowerShell 7.4 parse, Excel recalc). Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Get the Complete kit

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### M365 AI Agent Hardening Kit: Complete

<p class="rl-buy__price">€39</p>

All 20 controls in sprints, with the same files as the free Top 5. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Complete kit](https://runbooklab.gumroad.com/l/ai-agent-hardening-kit?utm_source=site&utm_campaign=kit-ai-agent-hardening){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### AI and Identity Pack

<p class="rl-buy__price">€79 <span>instead of €107 for the kits separately</span></p>

3 Complete kits: Copilot readiness, **AI agent hardening**, Conditional Access.

<span class="rl-status">Coming soon</span><br>[About the bundles](bundles.md)

</div>

<div class="rl-buy__card" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €233 for the kits separately</span></p>

7 Complete kits: Microsoft 365 hardening, SMS and voice MFA exit, Copilot readiness, **AI agent hardening**, Defender for Endpoint and ASR, Conditional Access, Exchange Online protection.

<span class="rl-status">Coming soon</span><br>[About the bundles](bundles.md)

</div>

</div>

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "M365 AI Agent Hardening Kit", "description": "Inventory, guardrails and accountable owners for Copilot Studio agents and Entra agent identities.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 5", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/ai-agent-hardening-top5"}, {"@type": "Offer", "name": "Complete (20 controls)", "price": "39", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/ai-agent-hardening-kit"}]}</script>
