---
title: "Privileged Access and PIM Kit"
description: "Fewer standing admins: eligible roles in PIM, strict Tier 0 settings and quarterly reviews. Free Top 5 with Jira import, Excel plan and read-only checks."
rl_type: kit
---

# Privileged Access and PIM Kit

<p class="rl-lead">Fewer standing admins: eligible roles in PIM, strict Tier 0 settings and quarterly reviews.</p>

Five privileged access controls to put in place first in Microsoft Entra ID: an inventory of every privileged role with Global Administrators below five, admin roles made eligible in PIM, strict PIM settings for Tier 0 roles, separate cloud-only admin accounts, and a quarterly access review with an alert on roles assigned outside PIM. Each control has why, steps, impact, rollback, a read-only PowerShell check, how to verify, licence, effort and the Microsoft Learn page it is based on.

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 5 controls</p>

The 5 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=kit-privileged-access-pim){ .md-button .md-button--primary }

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, impact, rollback, the read-only check, how to verify, licence and effort |
| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Read-only: Get-* cmdlets and Microsoft Graph GET requests only. Changes nothing in your tenant. Results go to a CSV. |

### A look inside the free Top 5

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Sprint |
    |---|---|---|---|---|---|
    | 1 | Epic | Privileged Access and PIM Kit: Inventory and least privilege | High |  |  |
    | 2 | Epic | Privileged Access and PIM Kit: Just-in-time access with PIM | High |  |  |
    | 3 | Epic | Privileged Access and PIM Kit: Admin accounts and reviews | High |  |  |
    | 4 | Story | [PA01] Inventory every privileged role assignment and bring Global Administrators below five | Highest | 1 | Sprint 1 - Inventory |
    | 5 | Story | [PA02] Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts | Highest | 2 | Sprint 2 - Just-in-time |
    | 6 | Story | [PA03] Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people | Highest | 2 | Sprint 2 - Just-in-time |
    | 7 | Story | [PA04] Give every admin a separate cloud-only admin account, not synced from on-premises | High | 3 | Sprint 1 - Inventory |

    </div>

    <p class="rl-caption">First 7 of 8 rows of <code>privileged-access-and-pim-kit-top-5-jira-import.csv</code>: 3 epics and 5 stories, with parent, priority, sprint and labels already set. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | PA01 | Inventory every privileged role assignment and bring Global Administrators below five | Sprint 1 - Inventory | Highest | 3 | To do |
    | PA02 | Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts | Sprint 2 - Just-in-time | Highest | 4 | To do |
    | PA03 | Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people | Sprint 2 - Just-in-time | Highest | 2 | To do |
    | PA04 | Give every admin a separate cloud-only admin account, not synced from on-premises | Sprint 1 - Inventory | High | 3 | To do |
    | PA05 | Run a quarterly access review of privileged roles and alert on roles assigned outside PIM | Sprint 2 - Just-in-time | High | 2 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>privileged-access-and-pim-kit-top-5-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     Privileged Access and PIM Kit: Top 5 - read-only checks (Runbook Lab)
     Read-only: Get-* cmdlets and Microsoft Graph GET requests only. Changes nothing in your tenant.
     Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.Governance, .Users, .DirectoryObjects, .Authentication).
     Connect first:
       Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
     Role: Global Reader is normally enough. If a PIM read is denied, run it as Privileged Role Administrator: the script still only reads.
     Output: .\hardening-check-results.csv (ID, Control, Status, Output).
    #>
    ...
    Invoke-Check 'PA01' 'Inventory every privileged role assignment and bring Global Administrators below five' { $roles = 'Global Administrator','Privileged Role Administrator','Privileged Authentication Administrator','Security Administrator','Conditional Access Administrator','Exchange Administrator','SharePoint Administrator','User Administrator','Authentication Administrator','Application Administrator','Cloud Application Administrator','Hybrid Identity Administrator','Intune Administrator'; foreach ($n in $roles) { $d = Get-MgRoleManagementDirectoryRoleDefinition -Filter "displayName eq '$n'"; if ($d) { $a = @(Get-MgRoleManagementDirectoryRoleAssignment -All -Filter "roleDefinitionId eq '$($d.Id)'"); $e = @(Get-MgRoleManagementDirectoryRoleEligibilityScheduleInstance -All -Filter "roleDefinitionId eq '$($d.Id)'"); "$n | active now: $($a.Count) | eligible: $($e.Count)" } }; "Target: Global Administrator active below 5 (including the two emergency accounts); privileged assignments below 10 in total." }
    ...
    ```

    <p class="rl-caption">The header and the first of 5 checks in <code>privileged-access-and-pim-kit-top-5-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>.</p>

## Controls

### Free Top 5

| ID | Control | Priority | Effort |
|---|---|---|---|
| PA01 | [Inventory every privileged role assignment and bring Global Administrators below five](../controls/privileged-access-pim/pa01-inventory-every-privileged-role-assignment-and-bring.md) | Highest | 3 h |
| PA02 | [Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts](../controls/privileged-access-pim/pa02-make-admin-roles-eligible-in-pim-no-permanent-active.md) | Highest | 4 h |
| PA03 | [Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people](../controls/privileged-access-pim/pa03-set-pim-role-settings-for-tier-0-roles-short-activation.md) | Highest | 2 h |
| PA04 | [Give every admin a separate cloud-only admin account, not synced from on-premises](../controls/privileged-access-pim/pa04-give-every-admin-a-separate-cloud-only-admin-account-not.md) | High | 3 h |
| PA05 | [Run a quarterly access review of privileged roles and alert on roles assigned outside PIM](../controls/privileged-access-pim/pa05-run-a-quarterly-access-review-of-privileged-roles-and.md) | High | 2 h |

## Before you run the checks

```text
Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.Governance, .Users, .DirectoryObjects, .Authentication).
Connect first:
Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
Role: Global Reader is normally enough. If a PIM read is denied, run it as Privileged Role Administrator: the script still only reads.
```

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, what each change breaks and how to roll it back, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.0 (2026-10-28; facts re-read on Microsoft Learn 2026-10-28; validated: quality gate, read-only guard, syntax check, Excel recalc). Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Complete kit

Not available yet. The free Top 5 comes first; the Complete kit follows when it has passed the same checks.

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "Privileged Access and PIM Kit", "description": "Fewer standing admins: eligible roles in PIM, strict Tier 0 settings and quarterly reviews.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 5", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/privileged-access-pim-top5"}]}</script>
