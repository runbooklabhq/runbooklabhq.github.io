---
title: "Defender for Endpoint and ASR Kit"
description: "Every device onboarded, tamper protection on, and ASR rules moved from Audit to Block without outages. Free Top 5 with Jira import, Excel plan and read-only checks."
rl_type: kit
---

# Defender for Endpoint and ASR Kit

<p class="rl-lead">Every device onboarded, tamper protection on, and ASR rules moved from Audit to Block without outages.</p>

Five controls that decide whether Microsoft Defender for Endpoint actually protects your Windows devices: every device onboarded, Defender Antivirus active with cloud protection, tamper protection on, ASR rules rolled out from Audit, and network protection blocking bad domains. Each control has why, steps, impact, rollback, a read-only PowerShell check, how to verify, licence, effort and the Microsoft Learn page it is based on. The checks read the local Defender configuration, so run them on a sample of devices.

<div class="rl-offer rl-offer--free" markdown>

<div class="rl-offer__col" markdown>

<p class="rl-offer__title">Free: Top 5 of 15 controls</p>

The 5 controls to do first, with every file listed below.

[Download free](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=kit-defender-endpoint-asr){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/defender-endpoint-asr-kit-free){ .md-button }

<p class="rl-offer__next">Need all 15? <a href="#get-the-complete-kit">See the Complete kit</a></p>

</div>

</div>

## What's in the download

| File | What it is for |
|---|---|
| Guide (Markdown) | Every control with why, steps, impact, rollback, the read-only check, how to verify, licence and effort |
| Jira import (CSV) | Epics and stories with sprint, priority and labels, ready for Jira Cloud's CSV import |
| Excel project plan | Owners, dates, a status drop-down, % complete and a progress dashboard, for teams without Jira |
| Tracker (CSV) | The same backlog for Planner, Azure DevOps or Linear |
| Read-only PowerShell | Read-only: Get-* cmdlets only (Get-MpComputerStatus, Get-MpPreference, Get-Service, Get-ItemProperty). Changes nothing. Run in an elevated PowerShell on a sample device. Results go to a CSV. |

### A look inside the free Top 5

Excerpts of the real files in the free download.

=== "Jira import (CSV)"

    <div class="rl-xl rl-xl--jira" markdown>

    | Issue ID | Type | Summary | Priority | Parent | Sprint |
    |---|---|---|---|---|---|
    | 1 | Epic | Defender for Endpoint and ASR Kit: Onboarding and antivirus baseline | High |  |  |
    | 2 | Epic | Defender for Endpoint and ASR Kit: Attack surface reduction | High |  |  |
    | 3 | Epic | Defender for Endpoint and ASR Kit: Network and web protection | High |  |  |
    | 4 | Story | [DE01] Check every device is onboarded and its sensor is healthy | Highest | 1 | Sprint 1 - Endpoint baseline |
    | 5 | Story | [DE02] Make sure Defender Antivirus is active with cloud protection and block at first sight | Highest | 1 | Sprint 1 - Endpoint baseline |
    | 6 | Story | [DE03] Turn on tamper protection tenant-wide | Highest | 1 | Sprint 1 - Endpoint baseline |
    | 7 | Story | [DE04] Put all ASR rules in Audit and block the three standard protection rules | High | 2 | Sprint 1 - Endpoint baseline |

    </div>

    <p class="rl-caption">First 7 of 8 rows of <code>defender-for-endpoint-and-asr-kit-top-5-jira-import.csv</code>: 3 epics and 5 stories, with parent, priority, sprint and labels already set. Import with Jira Cloud's CSV importer.</p>

=== "Excel project plan"

    <div class="rl-xl rl-xl--plan" markdown>

    | ID | Control | Sprint | Priority | Effort (h) | Status |
    |---|---|---|---|---|---|
    | DE01 | Check every device is onboarded and its sensor is healthy | Sprint 1 - Endpoint baseline | Highest | 1 | To do |
    | DE02 | Make sure Defender Antivirus is active with cloud protection and block at first sight | Sprint 1 - Endpoint baseline | Highest | 1 | To do |
    | DE03 | Turn on tamper protection tenant-wide | Sprint 1 - Endpoint baseline | Highest | 0.5 | To do |
    | DE04 | Put all ASR rules in Audit and block the three standard protection rules | Sprint 1 - Endpoint baseline | High | 2 | To do |
    | DE05 | Turn on network protection (audit, then block) | Sprint 1 - Endpoint baseline | High | 1 | To do |

    </div>

    <p class="rl-caption">The <em>Project plan</em> sheet of <code>defender-for-endpoint-and-asr-kit-top-5-project-plan.xlsx</code>. Sheets: Read me, Dashboard, Project plan. Owner, start and due dates are yours to fill in; status is a drop-down (To do, In progress, Blocked, Done, Not applicable); the Dashboard shows % complete, overdue items and hours left by area and sprint.</p>

=== "Read-only PowerShell"

    ```powershell
    <#
     Defender for Endpoint and ASR Kit: Top 5 - read-only checks (Runbook Lab)
     Read-only: Get-* cmdlets only (Get-MpComputerStatus, Get-MpPreference, Get-Service, Get-ItemProperty). Changes nothing. Run in an elevated PowerShell on a sample device.
     Requires: Windows with Microsoft Defender Antivirus (Defender PowerShell module is built in). No tenant connection.
     Run on 3-5 sample devices per device type (laptops, kiosks, servers) as administrator.
     Tenant-wide views are in the Microsoft Defender portal (Reports > Device health; Advanced hunting) as described in each control.
     Output: .\hardening-check-results.csv (ID, Control, Status, Output).
    #>
    ...
    Invoke-Check 'DE01' 'Check every device is onboarded and its sensor is healthy' { Get-Service -Name Sense | Select-Object Name, Status, StartType | Format-List | Out-String; $s = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status' -ErrorAction SilentlyContinue; "OnboardingState (1 = onboarded): $($s.OnboardingState)" }
    ...
    ```

    <p class="rl-caption">The header and the first of 5 checks in <code>defender-for-endpoint-and-asr-kit-top-5-readonly-checks.ps1</code>. Results go to <code>hardening-check-results.csv</code>.</p>

## Controls

### Free Top 5

| ID | Control | Priority | Effort |
|---|---|---|---|
| DE01 | [Check every device is onboarded and its sensor is healthy](../controls/defender-endpoint-asr/de01-check-every-device-is-onboarded-and-its-sensor-is-healthy.md) | Highest | 1 h |
| DE02 | [Make sure Defender Antivirus is active with cloud protection and block at first sight](../controls/defender-endpoint-asr/de02-make-sure-defender-antivirus-is-active-with-cloud.md) | Highest | 1 h |
| DE03 | [Turn on tamper protection tenant-wide](../controls/defender-endpoint-asr/de03-turn-on-tamper-protection-tenant-wide.md) | Highest | 30 min |
| DE04 | [Put all ASR rules in Audit and block the three standard protection rules](../controls/defender-endpoint-asr/de04-put-all-asr-rules-in-audit-and-block-the-three-standard.md) | High | 2 h + 2-4 weeks audit |
| DE05 | [Turn on network protection (audit, then block)](../controls/defender-endpoint-asr/de05-turn-on-network-protection-audit-then-block.md) | High | 1 h + 2 weeks audit |

### Added in the Complete kit (10)

| ID | Control | Area | Effort |
|---|---|---|---|
| DE06 | Block potentially unwanted apps (audit first) | Onboarding and antivirus baseline | 30 min + 2 weeks audit |
| DE07 | Turn on EDR in block mode where another antivirus is primary | Onboarding and antivirus baseline | 15 min |
| DE08 | Review antivirus exclusions and give each one an owner | Onboarding and antivirus baseline | 2 h |
| DE09 | Move the remaining ASR rules from Audit to Warn to Block in rings | Attack surface reduction | 2 h per ring |
| DE10 | Start web content filtering with an audit-only policy | Network and web protection | 1 h |
| DE11 | Pilot controlled folder access in audit mode | Device and data controls | 1 h + 2 weeks audit |
| DE12 | Control removable storage (see first, then deny by default with allow-lists) | Device and data controls | 2 h |
| DE13 | Rotate local admin passwords with Windows LAPS | Device and data controls | 1 h |
| DE14 | Keep Defender platform and security intelligence current | Onboarding and antivirus baseline | 30 min per month |
| DE15 | Review ASR and device control events every week | Attack surface reduction | 30 min per week |

## Before you run the checks

```text
Requires: Windows with Microsoft Defender Antivirus (Defender PowerShell module is built in). No tenant connection.
Run on 3-5 sample devices per device type (laptops, kiosks, servers) as administrator.
Tenant-wide views are in the Microsoft Defender portal (Reports > Device health; Advanced hunting) as described in each control.
```

## Read first

The free guide [Defender ASR rules: from Audit to Block](../guides/defender-asr-rules-audit-to-block.md) covers the same ground step by step, with the commands inline.

## Questions

??? question "How is this different from Secure Score, Maester or ScubaGear?"
    Use those too. They tell you what is off. This kit gives you the project to fix it: an ordered backlog you import on day one, what each change breaks and how to roll it back, and checks that only read.

??? question "Will the script change anything?"
    No. Apart from signing in (Connect-* and, for Power Platform, Add-PowerAppsAccount), it uses read commands only: Get-*, Search-* and Microsoft Graph GET requests. Every kit passes a check that rejects Set-, New-, Remove- and similar commands in the checks before release.

??? question "Which version is this?"
    1.0 (2026-10-28; facts re-read on Microsoft Learn 2026-10-28; validated: quality gate, read-only guard, PowerShell 7.4 parse, Excel recalc). Test every change on a pilot group first: no checklist knows your tenant's exceptions.

??? question "Can I use it for clients?"
    Yes, in your own organisation and in your clients' tenants. Please don't resell the kit files.

## Get the Complete kit

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### Defender for Endpoint and ASR Kit: Complete

<p class="rl-buy__price">€29</p>

All 15 controls in sprints, with the same files as the free Top 5. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Complete kit](https://runbooklab.gumroad.com/l/defender-asr-kit?utm_source=site&utm_campaign=kit-defender-endpoint-asr){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €272 for the kits separately</span></p>

8 Complete kits: Microsoft 365 hardening, SMS and voice MFA exit, Copilot readiness, AI agent hardening, **Defender for Endpoint and ASR**, Conditional Access, Exchange Online protection, Privileged access and PIM.

[Buy the bundle](https://runbooklab.gumroad.com/l/m365-hardening-library?utm_source=site&utm_campaign=kit-defender-endpoint-asr-bundle){ .md-button }

</div>

</div>

<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Product", "name": "Defender for Endpoint and ASR Kit", "description": "Every device onboarded, tamper protection on, and ASR rules moved from Audit to Block without outages.", "brand": {"@type": "Brand", "name": "Runbook Lab"}, "category": "Software documentation", "offers": [{"@type": "Offer", "name": "Free Top 5", "price": "0", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/defender-asr-top5"}, {"@type": "Offer", "name": "Complete (15 controls)", "price": "29", "priceCurrency": "EUR", "availability": "https://schema.org/InStock", "url": "https://runbooklab.gumroad.com/l/defender-asr-kit"}]}</script>
