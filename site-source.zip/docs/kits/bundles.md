---
title: Bundles
description: Two Runbook Lab bundles - the AI and Identity Pack (3 Complete kits, €79) and the Microsoft 365 Hardening Library (all 8 Complete kits, 189 controls, €149).
rl_type: kit
---

# Bundles

<p class="rl-lead">For teams that need more than one kit. Same files, same read-only checks, one download.</p>

| Bundle | Kits | Separately | Bundle |
|---|---|---|---|
| **AI and Identity Pack** | [Copilot readiness](copilot-readiness.md), [AI agent hardening](ai-agent-hardening.md), [Conditional Access](conditional-access.md) | €107 | €79 |
| **Microsoft 365 Hardening Library** | All eight Complete kits: [Microsoft 365 hardening](m365-hardening.md), [SMS and voice MFA exit](sms-mfa-exit.md), [Copilot readiness](copilot-readiness.md), [AI agent hardening](ai-agent-hardening.md), [Defender for Endpoint and ASR](defender-endpoint-asr.md), [Conditional Access](conditional-access.md), [Exchange Online protection](exchange-online-protection.md), [Privileged access and PIM](privileged-access-pim.md) | €272 | €149 |

<div class="rl-buy" markdown>

<div class="rl-buy__card rl-buy__card--main" markdown>

### Microsoft 365 Hardening Library

<p class="rl-buy__price">€149 <span>instead of €272 for the kits separately</span></p>

All 8 Complete kits, 189 controls: Jira CSVs, Excel plans, step-by-step guides and read-only PowerShell checks. If it doesn't save you at least an hour, reply to your receipt for a refund.

[Buy the Library](https://runbooklab.gumroad.com/l/m365-hardening-library?utm_source=site&utm_campaign=bundles-page){ .md-button .md-button--primary }

</div>

<div class="rl-buy__card" markdown>

### AI and Identity Pack

<p class="rl-buy__price">€79 <span>instead of €107 for the kits separately</span></p>

Copilot readiness, AI agent hardening and the Conditional Access baseline: 64 controls for the tenant that is switching on Copilot and agents.

[Buy the pack](https://runbooklab.gumroad.com/l/ai-identity-pack?utm_source=site&utm_campaign=bundles-page){ .md-button }

</div>

</div>

Licence: use in your own organisation and in your clients' tenants. Don't resell the kit files.
