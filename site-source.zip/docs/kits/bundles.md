---
title: Bundles
description: Two Runbook Lab bundles are coming soon - the AI and Identity Pack (3 kits, €79) and the Microsoft 365 Hardening Library (7 kits, €149).
rl_type: kit
---

# Bundles

<p class="rl-lead">For teams that need more than one kit. Same files, same read-only checks, one download.</p>

!!! note "Coming soon"
    The bundles are being set up on Gumroad. Until then, each kit is available on its own from its page.

| Bundle | Kits | Separately | Bundle |
|---|---|---|---|
| **AI and Identity Pack** | [Copilot readiness](copilot-readiness.md), [AI agent hardening](ai-agent-hardening.md), [Conditional Access](conditional-access.md) | €107 | €79 |
| **Microsoft 365 Hardening Library** | All seven paid kits: [Microsoft 365 hardening](m365-hardening.md), [SMS and voice MFA exit](sms-mfa-exit.md), [Copilot readiness](copilot-readiness.md), [AI agent hardening](ai-agent-hardening.md), [Defender for Endpoint and ASR](defender-endpoint-asr.md), [Conditional Access](conditional-access.md), [Exchange Online protection](exchange-online-protection.md) | €233 | €149 |

Licence: use in your own organisation and in your clients' tenants. Don't resell the kit files.
