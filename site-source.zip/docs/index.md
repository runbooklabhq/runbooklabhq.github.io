---
title: Runbook Lab
description: Security news you can act on. Microsoft 365, cybersecurity and AI security for admins, security engineers and MSPs - what changed, who has to act, by when and how to check it.
template: home.html
hide:
  - toc
  - path
  - footer
rl_type: home
search:
  exclude: true
---

# Runbook Lab
