---
title: Privacy
description: Runbook Lab's website sets no cookies. Page views are counted with Cloudflare Web Analytics, which uses no cookies or local storage. Fonts and search run from this site.
rl_type: about
---

# Privacy

<p class="rl-lead">This site sets no cookies and builds no profile of you. It loads one script from another company: Cloudflare's page-view counter.</p>

- **Page views** are counted with Cloudflare Web Analytics, so we know which pages people read. Cloudflare says it uses no cookies or local storage for this and does not fingerprint visitors. We see totals per page, country, browser and referrer, not individuals. See [Cloudflare Web Analytics](https://www.cloudflare.com/web-analytics/) and the [Cloudflare privacy policy](https://www.cloudflare.com/privacypolicy/).
- **Fonts and other scripts** are served from this site. Nothing is loaded from Google or another font or script provider.
- **Search** runs in your browser. What you type is not sent anywhere.
- **Light or dark mode**: your choice is stored in your browser's local storage so the next page uses it. It never leaves your device.
- **Hosting**: the site is hosted on GitHub Pages and its domain uses Cloudflare DNS. GitHub may log technical data such as IP addresses to run and protect the service; see the [GitHub privacy statement](https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement).
- **Buying or downloading a kit** happens on Gumroad, which handles payment and email. See [Gumroad's privacy policy](https://gumroad.com/privacy).
- **Links** to Microsoft Learn, GitHub, X, Bluesky, LinkedIn and dev.to take you to those sites and their own policies.

If this changes, this page will say so first.

Questions: runbooklab@outlook.com
