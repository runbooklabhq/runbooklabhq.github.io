---
title: Privacy
description: Runbook Lab's website sets no cookies and builds no profile of you. Page views are counted with Cloudflare Web Analytics; reading and clicks are counted anonymously with PostHog in the EU, without cookies.
rl_type: about
---

# Privacy

<p class="rl-lead">This site sets no cookies and builds no profile of you. We count page views, and which pages are read and which buttons are used, so we know what to write and build next.</p>

- **Page views** are counted with Cloudflare Web Analytics, so we know which pages people read. Cloudflare says it uses no cookies or local storage for this and does not fingerprint visitors. We see totals per page, country, browser and referrer, not individuals. See [Cloudflare Web Analytics](https://www.cloudflare.com/web-analytics/) and the [Cloudflare privacy policy](https://www.cloudflare.com/privacypolicy/).
- **Reading and clicks** are counted with [PostHog](https://posthog.com/), using its EU cloud (Frankfurt) in cookieless mode: which pages are read to the end, which buttons and links are used, when a code block is copied, and what is typed into the site search. In this mode PostHog stores nothing in your browser (no cookies, no local or session storage) and we never identify you. To count visits, PostHog makes a daily-changing, one-way identifier on its servers from technical data such as the IP address and browser, and deletes the daily key once that day's events are processed. We do not record sessions or screens. The PostHog script is served from this site. See the [PostHog privacy policy](https://posthog.com/privacy).
- **Fonts and other scripts** are served from this site. Nothing is loaded from Google or another font or script provider.
- **Search** runs in your browser. The words you search for are counted anonymously (see above) so we can see which topics people are looking for.
- **Light or dark mode**: your choice is stored in your browser's local storage so the next page uses it. It never leaves your device.
- **Hosting**: the site is hosted on GitHub Pages and its domain uses Cloudflare DNS. GitHub may log technical data such as IP addresses to run and protect the service; see the [GitHub privacy statement](https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement).
- **Buying or downloading a kit** happens on Gumroad, which handles payment and email. See [Gumroad's privacy policy](https://gumroad.com/privacy).
- **Links** to Microsoft Learn, GitHub, X, Bluesky, LinkedIn and dev.to take you to those sites and their own policies.

If this changes, this page will say so first.

Questions: runbooklab@outlook.com
