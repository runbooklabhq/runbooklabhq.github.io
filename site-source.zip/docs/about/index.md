---
title: About Runbook Lab
description: Runbook Lab makes Microsoft 365 security kits for admins and MSPs - controls with steps, impact, rollback and read-only checks, as a Jira import and an Excel plan.
rl_type: about
---

# About Runbook Lab

<p class="rl-lead">Runbook Lab makes the security project you were going to write yourself: the controls in order, what each one breaks, how to undo it, and a check that proves it is done.</p>

Most Microsoft&nbsp;365 security advice ends at "turn on MFA" or a list of settings. The work starts after that: who owns it, which users it hits, what to test first, how to roll back on a Friday afternoon. Runbook Lab kits are written for that part.

Each kit is a backlog you import on day one (Jira CSV, or an Excel project plan for teams without Jira), a guide with every control, and a PowerShell script that only reads. Every kit starts with a free Top&nbsp;5.

## Who is behind it

A security practitioner with 15 years in IT and cybersecurity:

- first at a systems integrator,
- then as a Big&nbsp;4 consultant,
- now as a cybersecurity expert at a regulated EU bank.

The kits are written the way changes are handled in a regulated environment: every control comes with its impact on users, a rollback and a check that proves it is done. AI assistance is used for drafting and cross-checking. No employer is named, and none is involved in Runbook Lab. [How we check every control](method.md).

## What we don't do

- We don't claim a kit makes you "compliant" with any standard. Controls reference Microsoft Learn and, where they were checked against the text, public baselines.
- We don't sell your data, set cookies or build profiles of visitors. [Privacy](privacy.md).
- We are not affiliated with or endorsed by Microsoft.

## Contact

Questions about a kit you bought: reply to your Gumroad receipt. Anything else: runbooklab@outlook.com, or a message on [LinkedIn](https://www.linkedin.com/company/runbooklab/) or [X](https://x.com/runbooklab).

Found a mistake in a control? Tell us. We fix it and note the change on the page.
