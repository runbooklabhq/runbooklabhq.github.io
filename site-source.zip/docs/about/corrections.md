---
title: Corrections
description: "Every correction to a live Runbook Lab page: what the page said, what it says now, why it changed and when. Newest first, with links to the corrected item."
rl_type: about
---

# Corrections

<p class="rl-lead">When a page we published turns out to be wrong or out of date, we fix it, put a dated note at the top of that page and list it here. Nothing is changed silently.</p>

<p class="rl-updated">Last updated 11 November 2026</p>

Two kinds of correction appear below. **Source changed**: Microsoft or another primary source changed a fact after we published, and our page still showed the old one. **Our error**: we got a fact wrong or left out something that mattered. Small fixes to wording, links or layout are not listed. Dated updates that add new facts (for example a vulnerability that is later exploited) are noted on the page itself and appear here only when the page had said the opposite. A rollout date that Microsoft moved and that we updated on the page within a day is noted on that page only; this list starts with the corrections of 3 November 2026.

| Corrected | Page | What it said | What it says now | Why |
|---|---|---|---|---|
| 11 Nov 2026 | [Email & collaboration this week (31 October)](../news/posts/2026-10-31-email-collaboration-this-week.md#teams-malicious-qr-detection) | Teams malicious QR code detection rolls out from early November, finishing mid-November 2026 | From mid-November, finishing late November 2026 (MC1526651, updated 10 November 2026) | Source changed |
| 11 Nov 2026 | [Outlook blocks MSIX attachments](../news/posts/2026-11-03-outlook-blocks-msix-attachments-owa-mailbox-policy.md) | Rollout begins early November and completes by mid-November 2026 | Begins early December and completes by mid-December 2026 (MC1488841, updated 10 November 2026) | Source changed |
| 11 Nov 2026 | [Exchange OWA and mail flow hit by October Windows updates](../news/posts/2026-10-31-exchange-owa-mail-flow-october-windows-server-updates.md) | Status "Mitigated"; no fix released; apply the registry workaround | Status "Resolved" by the Windows updates of 10 November 2026 (KB5131080, KB5131090, KB5131085, KB5131291); install them and the workaround is not needed | Source changed |
| 11 Nov 2026 | [Email & collaboration this week (6 November)](../news/posts/2026-11-06-email-collaboration-this-week.md#mc1446796-cross-tenant-calendar-sharing-moves-to-cross-tenant-access-policy-by-6-november-2026) | Cross-tenant Calendar Sharing moves to Cross-Tenant Access Policy by 6 November 2026 | Worldwide expected completion 23 November 2026; Gov clouds paused (MC1446796 and the Exchange Team Blog, both updated 9 November 2026) | Source changed |
| 10 Nov 2026 | [Threats & vulnerabilities this week (6 November)](../news/posts/2026-11-06-threats-vulnerabilities-this-week.md#barracuda-esg-cve-2026-116606-chains-to-root-2-november-2026) | Barracuda's advisory said nothing about exploitation of CVE-2026-116606 | Barracuda reports exploitation activity affecting a small number of organisations (advisory updated 9 November 2026) | Source changed |
| 10 Nov 2026 | [Threats & vulnerabilities this week (6 November)](../news/posts/2026-11-06-threats-vulnerabilities-this-week.md#openssh-on-alpine-password-authentication-bypass-cve-2026-123158-5-november-2026) | OpenSSH CVE-2026-123158 not in CISA KEV; no successful attack shown | In CISA KEV since 9 November 2026 (due 12 November); GreyNoise reports successful exploitation | Source changed |
| 4 Nov 2026 | [Copilot Studio GPT-4.1 and GPT-5 retire 12 November](../news/posts/2026-10-28-copilot-studio-model-retirement.md) | Two replacement models named as GPT-5.6 Terra and GPT-6 Sol | GPT-6 Luna and GPT-6.1 Sol, per the updated MC1506318 | Source changed |
| 4 Nov 2026 | [.NET out-of-band Brotli security update](../news/posts/2026-10-31-dotnet-october-oob-brotli-security-update.md) | "We do not call it exploited"; only .NET listed as affected | In CISA KEV since 27 October 2026; PowerShell 7, Visual Studio and Azure Linux 3 also affected | Our error |
| 3 Nov 2026 | [CISA KEV this week: Cisco ASA, GitLab, Ivanti, PHP](../news/posts/2026-10-31-cisa-kev-cisco-asa-gitlab-ivanti-php.md#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527) | Run Ivanti's Integrity Checker Tool, with no caveat | A clean result does not rule out compromise for this exploit chain (Volexity); added log, /tmp/ and forensics checks | Our error |

Each corrected page carries a dated "Updated" note at the top saying what changed and, where it matters, what you should do differently. The dated rows on [Microsoft 365 security deadlines](../guides/deadlines.md) and its calendar feed change on the same day.

Found something wrong? Tell us through any channel on the [Follow](follow.md) page. How we source and check content: [How we check every control](method.md).

Runbook Lab is not affiliated with Microsoft.
