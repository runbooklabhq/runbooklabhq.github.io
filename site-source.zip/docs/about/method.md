---
title: How we check every control
description: How Runbook Lab writes and checks its Microsoft 365 controls - Microsoft Learn sources, a quality gate on every control, read-only scripts and dated reviews.
rl_type: about
---

# How we check every control

<p class="rl-lead">Every control goes through the same steps before it is released, and every page says when it was last reviewed.</p>

## 1. Sources first

Each control is written from Microsoft Learn and, for dated changes, the Microsoft&nbsp;365 message center. Portal paths, licences, preview or general availability, cmdlet names and dates are re-read within seven days before a kit is released. The Learn pages are listed under every control.

News briefs follow the same rule: a fact goes in only when the primary source states it (the Microsoft message center, a vendor advisory or Microsoft Learn), or when two independent security analyses agree. Each brief lists its sources.

## 2. A quality gate on every control

For every kit released since 27 October 2026, a script rejects the kit if any control is missing one of these: why it matters, at least two steps, impact on users, rollback, how to verify, licence, effort and at least one Microsoft Learn source. It also rejects placeholder text and wording such as "compliant with" or "100% secure".

The two older kits (Microsoft&nbsp;365 hardening and SMS and voice MFA exit) were built before this gate. Impact and rollback are being added to their controls, and their kit pages say so.

## 3. Checks that only read

Every check uses Get-* and Search-* cmdlets or Microsoft Graph GET requests. The gate fails the kit if a check contains Set-, New-, Remove-, Enable-, Disable- or a similar command, or a Graph write request. Scripts are syntax-checked before release, and the Excel plan is recalculated to confirm there are no formula errors.

## 4. AI assistance, stated plainly

Drafting and cross-checking are done with AI assistance. The facts come from the sources above, not from the model, and the gate runs on every build.

## 5. What we can't promise

No checklist knows your tenant's exceptions. Test each change on a pilot group first, and read the impact and rollback sections before you start.

## 6. Corrections

When Microsoft changes something or a reader finds a mistake, the control is updated, the "Last reviewed" date changes, and the next kit build includes the fix. News briefs and guides get a dated "Updated" note at the top. Every correction to a live page is listed on our [Corrections](corrections.md) page.
