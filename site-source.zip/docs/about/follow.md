---
title: Follow Runbook Lab
description: Get every Runbook Lab news brief by RSS, or follow on X, Bluesky or LinkedIn.
rl_type: about
---

# Follow Runbook Lab

<p class="rl-lead">Every news brief goes out on the same day by RSS and on our social accounts. No newsletter sign-up, no cookies.</p>

## RSS

Add this address to your feed reader, for example Feedly or Inoreader:

```text
https://runbooklabhq.com/feed_rss_created.xml
```

The feed has the title, date, topic and summary of each brief, with a link to the full page.

## Social

- [X: @runbooklab](https://x.com/runbooklab), short cards
- [Bluesky: runbooklab.bsky.social](https://bsky.app/profile/runbooklab.bsky.social)
- [LinkedIn: Runbook Lab](https://www.linkedin.com/company/runbooklab/)
- [dev.to: runbooklab](https://dev.to/runbooklab), longer articles
- [GitHub: runbooklabhq](https://github.com/runbooklabhq), the free kits
