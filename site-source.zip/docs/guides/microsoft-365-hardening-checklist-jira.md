---
title: "Microsoft 365 Hardening Checklist as a Jira Backlog (2026)"
description: "Free Microsoft 365 hardening checklist: 10 emergency controls as a Jira import with read-only PowerShell checks. Includes the SMTP AUTH Basic auth deadline (end of December 2026) and the Teams external file sharing setting."
rl_type: guide
---

# Microsoft 365 hardening checklist, ready to import into Jira

<p class="rl-lead">Ten controls to do first, as epics and stories with steps, a read-only PowerShell check and a clear "done" test. Free. When you are through Sprint 1, the full kit adds 48 more across Entra ID, Exchange Online, Teams, SharePoint/OneDrive and Purview.</p>

[Download the free Top 10](https://runbooklab.gumroad.com/l/m365-hardening-top10?utm_source=site&utm_campaign=guide-microsoft-365-hardening-checklist-jira){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/m365-hardening-kit-free){ .md-button }

## What's changing in late 2026

### Teams external chats: file sharing default

MC1479514 switches on attachments in federated chats for tenants that haven't disabled them. On 15 October Microsoft removed the rollout dates; it still asks admins to set their choice by the first week of November. Set the policy explicitly and a later rollout changes nothing.

```powershell
Get-CsTeamsFilesPolicy -Identity Global |
  Select FileSharingInChatsWithExternalUsers
```

### SMTP AUTH Basic auth off by default

Printers, scanners and apps that send with a username and password stop working. Find them first: [six-step SMTP AUTH checklist](exchange-online-smtp-auth-basic-auth-checklist.md).

```powershell
Get-TransportConfig |
  Select SmtpClientAuthenticationDisabled
```

## The free Emergency Top 10

| ID | Control | Licence |
|---|---|---|
| `E01` | Create two break-glass (emergency access) accounts | Any |
| `E02` | Require MFA for all users | Free (Security defaults) or Entra ID P1 (Conditional Access) |
| `E03` | Block legacy authentication | Entra ID P1 (or Security defaults) |
| `E04` | Reduce and separate admin accounts | Any (PIM needs Entra ID P2) |
| `E05` | Restrict user consent to applications | Any |
| `E06` | Confirm audit logging is on | Any (retention depends on licence) |
| `E07` | Block automatic external email forwarding | Exchange Online |
| `E08` | Apply the Standard preset security policy | EOP (Defender for Office 365 for Safe Links/Attachments) |
| `E09` | Set up SPF, DKIM and DMARC | Any |
| `E10` | Self-service password reset with banned passwords | Entra ID P1 for SSPR with on-prem writeback and custom banned list |

Files in the zip: `m365-hardening-kit-emergency-top-10-guide.md` · `…-jira-import.csv` (epics + stories, parent links, priority, sprint) · `…-tracker.csv` (Planner / Azure DevOps / Excel) · `…-readonly-checks.ps1` · README.md · LICENSE. MIT licence.

[Get it free](https://runbooklab.gumroad.com/l/m365-hardening-top10?utm_source=site&utm_campaign=guide-microsoft-365-hardening-checklist-jira){ .md-button .md-button--primary }

## The full kit: 58 controls in 5 sprints

| Sprint | Controls |
|---|---|
| Sprint 1 - Emergency | 10 |
| Sprint 2 - Identity | 14 |
| Sprint 3 - Email | 11 |
| Sprint 4 - Collaboration | 16 |
| Sprint 5 - Data & monitoring | 7 |

Plus 48 read-only checks in one script and the `m365-hardening-coach` Claude skill: give it the results CSV and your licences, get readiness %, this week's five fixes, licence gaps and a three-sentence summary for management.

[M365 Hardening Kit: Complete · €39](https://runbooklab.gumroad.com/l/m365-hardening-kit?utm_source=site&utm_campaign=guide-microsoft-365-hardening-checklist-jira){ .md-button .md-button--primary }

## FAQ

### Is Teams turning on file sharing in external chats by default?

Yes, it's still planned, but without a date. MC1479514 switches on attachments in external (federated) chats for tenants that haven't explicitly disabled them. On 15 October 2026 Microsoft removed the rollout dates and said it will announce new ones in Message center; it still asks admins to set their choice by the first week of November. A policy set before the rollout is respected. Control T02 in the kit has both PowerShell options.

### When is SMTP AUTH Basic auth switched off?

Per Microsoft's January 2026 timeline update, Basic auth for SMTP AUTH client submission is disabled by default for existing tenants in late December 2026. Control M01 uses the SMTP AUTH clients report to find printers and apps that will break.

### Do the PowerShell checks change my tenant?

No. The scripts only call Get-* cmdlets and write a results CSV. The kit builder refuses any check containing Set-, New-, Remove-, Update-, Enable- or Disable- cmdlets.

### Does the Jira CSV create sprints?

Stories carry a Sprint value and a sprint-N label. If your Jira project does not map the Sprint column on import, filter by label and bulk-move.
