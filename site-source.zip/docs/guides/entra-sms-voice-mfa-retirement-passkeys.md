---
title: "Entra SMS and Voice MFA Retirement (1 Feb 2027): Passkey Checklist"
description: "Microsoft retires its SMS and voice MFA on 1 February 2027 (Global Admins and external users: 1 July 2027). Find phone-only users with a read-only Graph check, enable passkeys, run a registration campaign and track the count to zero."
rl_type: guide
rl_updated: "27 October 2026"
---

# Entra SMS and voice MFA retires 1 February 2027: move users to passkeys

<p class="rl-updated">Last reviewed 27 October 2026</p>

<p class="rl-lead">Microsoft retires its own SMS and voice MFA for all users except Global Administrators and external users on 1 February 2027, and for those two groups on 1 July 2027. Users whose only method is SMS or voice then get a blocking passkey prompt at sign-in, with no opt-out for enforcement. Six steps to get the number of affected users to zero first.</p>

[Get the free Top 5 kit](https://runbooklab.gumroad.com/l/sms-mfa-exit-top5?utm_source=site&utm_campaign=guide-entra-sms-voice-mfa-retirement-passkeys){ .md-button .md-button--primary }
[Microsoft 365 hardening checklist](microsoft-365-hardening-checklist-jira.md){ .md-button }

## The dates

| Date | What happens |
|---|---|
| 30 Oct 2026 | Organisations with a documented need can set up a telephony provider from Microsoft Security Store. |
| 1 Feb 2027 | Microsoft-provided SMS and voice retire for all users except Global Administrators and external users. Internal guests are included. |
| 1 Jul 2027 | Retirement for Global Administrators and external users. |

Source: Microsoft 365 message MC1519855 (21 Oct 2026) and Microsoft Learn, "Passkeys by default and retirement of Microsoft-provided SMS and voice authentication". Public cloud only. Dates can change: re-check the message before you plan around them.

## The six steps

### 1. List the phone-only users

Read-only. Needs Entra ID P1/P2, `AuditLog.Read.All` and a reader role. Put the result in a group such as `SMS-Voice-Exit`.

```powershell
$r = @(Get-MgReportAuthenticationMethodUserRegistrationDetail -All)
$ph = @('mobilePhone','alternateMobilePhone','officePhone')
$weak = $ph + @('email','securityQuestion')
$only = $r | Where-Object {
  $m = @($_.MethodsRegistered)
  ($m | Where-Object { $ph -contains $_ }) -and
  -not ($m | Where-Object { $weak -notcontains $_ }) }
"Phone-only users: $(@($only).Count)"
$only | Select-Object UserPrincipalName, UserType, IsAdmin |
  Export-Csv -NoTypeInformation .\phone-only-users.csv
```

### 2. See where SMS and voice are enabled

In the Entra admin center: Entra ID &gt; Authentication methods &gt; Policies &gt; SMS and Voice call. Microsoft's own scanner, `microsoft/entra-sms-voice-usage-analyzer` on GitHub, reports the policy scope (not users).

### 3. Enable Passkey (FIDO2) for that group

Authentication methods &gt; Policies &gt; Passkey (FIDO2). Users can use a passkey in Microsoft Authenticator, a synced passkey or a FIDO2 security key. Pilot with IT first.

### 4. Run a registration campaign

Authentication methods &gt; Registration campaign, target the group and passkeys. Snoozes are unlimited by default, so set the date when you stop allowing them.

### 5. Tell users in three waves

Awareness now, action with per-device steps, then reminders to whoever is still on the list. Microsoft publishes templates at `aka.ms/mfatemplates`.

### 6. Re-run step 1 every week

The only number that matters is how many users would be blocked on the date. Escalate the remaining names two weeks before 1 February 2027.

## Don't forget

### Admins and break-glass

Global Admins have until 1 July 2027, but move them first. Break-glass accounts should use FIDO2 keys, never SMS.

### Password reset (SSPR)

The retirement applies to SSPR too. Phone-only users need another reset method.

### Stuck users

Use a short-lived, one-time Temporary Access Pass after identity verification, not a password or SMS.

## Get the kit

### Top 5

Steps 1–5 as a guide, a Jira import, a tracker CSV and read-only PowerShell checks that export phone-only-users.csv.

[Download free](https://runbooklab.gumroad.com/l/sms-mfa-exit-top5?utm_source=site&utm_campaign=guide-entra-sms-voice-mfa-retirement-passkeys){ .md-button .md-button--primary }

### Complete (12 controls)

Adds admins and break-glass, internal guests, SSPR, the telephony-provider decision, the opt-out check, helpdesk onboarding with Temporary Access Pass and weekly tracking. 7 read-only checks.

€29

[Get the Complete kit](https://runbooklab.gumroad.com/l/sms-mfa-exit-kit?utm_source=site&utm_campaign=guide-entra-sms-voice-mfa-retirement-passkeys){ .md-button }

## FAQ

### When does Microsoft retire SMS and voice MFA in Entra ID?

Microsoft-provided SMS and voice authentication retires on 1 February 2027 for all users except Global Administrators and external users (internal guests are included), and on 1 July 2027 for Global Administrators and external users. The timeline applies to public cloud tenants (Microsoft 365 message MC1519855 and Microsoft Learn).

### What happens to users whose only MFA method is SMS or voice?

After the retirement date they get a blocking prompt to register a passkey during sign-in and can't skip it. Microsoft says there is no opt-out for enforcement. Users moved to a telephony provider from Microsoft Security Store before their date don't get the prompt.

### How do I find users who only have SMS or voice registered?

Use the user registration details report (Entra ID &gt; Authentication methods &gt; Activity, or Microsoft Graph reports/authenticationMethods/userRegistrationDetails, cmdlet Get-MgReportAuthenticationMethodUserRegistrationDetail) and keep users whose registered methods are only phone methods, plus email or security questions. The report needs Entra ID P1 or P2 and a role such as Reports Reader.

### Does the change affect self-service password reset?

Yes. Microsoft says the retirement applies across Microsoft Entra, including SSPR, so users who reset passwords only by SMS or call need another method.

### Do I need to buy a telephony provider?

Only if you have a documented regulated or operational need for SMS or voice. Microsoft recommends passkeys for everyone else, and moving SMS and voice users to passkeys has no additional cost. Provider pricing varies by provider and region.
