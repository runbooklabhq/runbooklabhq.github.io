---
title: Microsoft 365 security deadlines 2026–2027
description: "Microsoft 365 security deadlines for 2026 and 2027: Entra SSPR and SMS MFA, Exchange Online SMTP AUTH, Teams, Copilot Studio and Defender changes, with who has to act and the message center source."
rl_type: guide
---

# Microsoft 365 security deadlines 2026–2027

<p class="rl-lead">Upcoming changes with a date, who has to act and the source. Microsoft moves dates; each line links the message so you can check the latest version.</p>

<p class="rl-updated">Last checked 29 October 2026</p>

| When | What changes | Who acts | Source | More |
|---|---|---|---|---|
| First week of Nov 2026 | Teams: file sharing in external (federated) chats is turned on unless you turned it off | Teams admins | [MC1479514](https://mc.merill.net/message/MC1479514) | [Brief](../news/posts/2026-10-28-teams-external-chat-file-sharing.md) |
| Early Nov 2026 to early Jan 2027 | Entra: users can register a passkey as their first MFA method (phase 1) | Identity admins, helpdesk | [MC1450133](https://mc.merill.net/message/MC1450133) | [Brief](../news/posts/2026-10-28-entra-passkey-first-mfa.md) |
| Early Nov to early Dec 2026 | Teams flags suspected phishing in chats; QR codes in messages are checked from mid-November | Helpdesk briefing | [MC1519866](https://mc.merill.net/message/MC1519866), [MC1526651](https://mc.merill.net/message/MC1526651) | |
| 7 Nov 2026 (act by 6 Nov) | Entra self-service password reset accepts only methods users registered themselves; directory phone numbers and emails stop working for SSPR | Identity admins, helpdesk | [MC1325414](https://mc.merill.net/message/MC1325414) | [Brief](../news/posts/2026-10-29-entra-sspr-registered-methods-only.md) |
| 12 Nov 2026 | Copilot Studio moves agents on GPT-4.1, GPT-4.1 Mini and GPT-5 models to replacement models | Power Platform admins, agent owners | [MC1506318](https://mc.merill.net/message/MC1506318) | [Brief](../news/posts/2026-10-28-copilot-studio-model-retirement.md) |
| End of Dec 2026 | Exchange Online: SMTP AUTH Basic authentication off by default in existing tenants | Exchange admins | [MC786329](https://mc.merill.net/message/MC786329) | [Guide](exchange-online-smtp-auth-basic-auth-checklist.md) |
| 1 Feb 2027 | Microsoft's own SMS and voice MFA retires for all users except Global Administrators and external users | Identity admins | [MC1519855](https://mc.merill.net/message/MC1519855) | [Guide](entra-sms-voice-mfa-retirement-passkeys.md) |
| 1 Feb 2027 | Defender XDR Advanced Hunting APIs stop working; move to the Microsoft Graph security API | SecOps, SIEM owners | [MC1220762](https://mc.merill.net/message/MC1220762) | |
| 1 Jul 2027 | SMS and voice MFA retires for Global Administrators and external users | Identity admins | [MC1519855](https://mc.merill.net/message/MC1519855) | [Guide](entra-sms-voice-mfa-retirement-passkeys.md) |
| 15 Oct 2027 | `Search-UnifiedAuditLog` retires; scripts move to the Microsoft Graph audit log query API | Script and report owners | [MC1505599](https://mc.merill.net/message/MC1505599) | |

Message center posts are only visible inside a tenant's admin center. The links go to a public mirror of the message center (mc.merill.net), which keeps each version.
