---
title: Microsoft 365 security deadlines 2026–2027
description: "Microsoft 365 security deadlines for 2026 and 2027: Entra SSPR and SMS MFA, Exchange Online SMTP AUTH, Teams, Copilot Studio and Defender changes, with who has to act and the message center source."
rl_type: guide
---

# Microsoft 365 security deadlines 2026–2027

<p class="rl-lead">Upcoming changes with a date, who has to act and the source. Microsoft moves dates; each line links the message so you can check the latest version.</p>

<p class="rl-updated">Last checked 5 November 2026</p>

!!! tip "Get these dates in your calendar"
    Subscribe online <span id="rl-newtab">(each opens in a new tab)</span>: [Outlook (work or school)](https://outlook.office.com/calendar/0/addfromweb?url=https%3A%2F%2Frunbooklabhq.com%2Fdeadlines.ics&name=Runbook%20Lab%3A%20Microsoft%20365%20security%20deadlines){ target="_blank" rel="noopener" aria-describedby="rl-newtab" } · [Outlook.com](https://outlook.live.com/calendar/0/addfromweb?url=https%3A%2F%2Frunbooklabhq.com%2Fdeadlines.ics&name=Runbook%20Lab%3A%20Microsoft%20365%20security%20deadlines){ target="_blank" rel="noopener" aria-describedby="rl-newtab" } · [Google Calendar (on a computer)](https://calendar.google.com/calendar/r?cid=webcal%3A%2F%2Frunbooklabhq.com%2Fdeadlines.ics){ target="_blank" rel="noopener" aria-describedby="rl-newtab" }. On iPhone, iPad or Mac: [Apple Calendar](webcal://runbooklabhq.com/deadlines.ics). Or [download the .ics file](../deadlines.ics).

    To add it by hand, use this address: `https://runbooklabhq.com/deadlines.ics` (new Outlook and Outlook on the web: **Add calendar** → **Subscribe from web**; classic Outlook for Windows: **Add Calendar** → **From Internet**; Google Calendar on a computer: **Other calendars** → **+** → **From URL**).

    Subscribed calendars pick up changes automatically, usually within a day, sometimes longer; a downloaded file does not update. Date ranges keep Microsoft's own wording in the title.

| When | What changes | Who acts | Source | More |
|---|---|---|---|---|
| First week of Nov 2026 | Teams: Microsoft asks you to set the file sharing policy for external (federated) chats by this date; it removed the rollout dates on 15 October and has not announced new ones | Teams admins | [MC1479514](https://mc.merill.net/message/MC1479514) | [Brief](../news/posts/2026-10-28-teams-external-chat-file-sharing.md) |
| 3 Nov 2026 | Entra: the MemberOf dynamic rule operator retires; dynamic groups, admin units and access package policies that use it stop updating | Identity admins | [MC1529463](https://mc.merill.net/message/MC1529463) | [Brief](../news/posts/2026-10-31-entra-memberof-dynamic-rule-retirement.md) |
| 4 Nov 2026 (rollout early to late Nov) | Entra: default users can create agent blueprints unless "Users can create agent blueprints" is set to No; agent blueprints stop getting AgentIdentity.CreateAsManager automatically (app-only creation fails with 403 without an admin grant) | Identity admins, agent owners | [MC1506733](https://mc.merill.net/message/MC1506733), [MC1506728](https://mc.merill.net/message/MC1506728) | [Brief](../news/posts/2026-11-04-entra-agent-blueprints-default-users-createasmanager.md) |
| Early Nov 2026 to early Jan 2027 | Entra: users can register a passkey as their first MFA method (phase 1) | Identity admins, helpdesk | [MC1450133](https://mc.merill.net/message/MC1450133) | [Brief](../news/posts/2026-10-28-entra-passkey-first-mfa.md) |
| Early Nov to early Dec 2026 | Teams flags suspected phishing in chats; QR codes in messages are checked from mid-November | Helpdesk briefing | [MC1519866](https://mc.merill.net/message/MC1519866), [MC1526651](https://mc.merill.net/message/MC1526651) | |
| Early Nov to mid-Nov 2026 | Outlook on the web and new Outlook for Windows: .msix and .msixbundle added to BlockedFileTypes in every OWA mailbox policy; allow them first only if users need them | Exchange admins | [MC1488841](https://mc.merill.net/message/MC1488841) | [Brief](../news/posts/2026-11-03-outlook-blocks-msix-attachments-owa-mailbox-policy.md) |
| 7 Nov 2026 (act by 6 Nov) | Entra self-service password reset accepts only methods users registered themselves; directory phone numbers and emails stop working for SSPR | Identity admins, helpdesk | [MC1325414](https://mc.merill.net/message/MC1325414) | [Brief](../news/posts/2026-10-29-entra-sspr-registered-methods-only.md) |
| 10 Nov 2026 | CISA KEV due date for Brotli CVE-2026-111497: update .NET 8, 9 and 10, PowerShell 7.4, 7.5 and 7.6 and Visual Studio to the fixed builds | Server, developer and endpoint admins | [CISA KEV](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) | [Brief](../news/posts/2026-10-31-dotnet-october-oob-brotli-security-update.md) |
| 10 Nov 2026 | Windows 11 version 23H2 Enterprise and Education reach end of updates | Endpoint admins | [Windows message center](https://learn.microsoft.com/windows/release-health/windows-message-center) | [Roundup](../news/posts/2026-10-31-endpoint-devices-this-week.md) |
| 12 Nov 2026 | Copilot Studio moves agents on GPT-4.1, GPT-4.1 Mini and GPT-5 models to replacement models | Power Platform admins, agent owners | [MC1506318](https://mc.merill.net/message/MC1506318) | [Brief](../news/posts/2026-10-28-copilot-studio-model-retirement.md) |
| 15 Nov 2026 (act by; example says 10 Nov) | Exchange Online: selected properties no longer returned by Get-Mailbox -Migration and New-Mailbox -Migration; from 15 Dec 2026 they cannot be set with New-Mailbox -Migration | Exchange admins, migration tool owners | [MC1511071](https://mc.merill.net/message/MC1511071) | [Brief](../news/posts/2026-11-04-microsoft-365-changes-november-2026.md) |
| End of Nov 2026 | SharePoint and OneDrive: SPO one-time passcode retirement completes; external users without an Entra B2B guest account get access denied on old links until reshared | SharePoint and identity admins | [MC1243549](https://mc.merill.net/message/MC1243549) | [Brief](../news/posts/2026-11-04-microsoft-365-changes-november-2026.md) |
| 2 Dec 2026 (act by; rollout early Dec 2026 to late Jan 2027) | Defender and Sentinel: Microsoft Defender RBAC is turned on automatically about 30 days after the portal notice; review the imported roles first | Defender and SOC admins, MSPs (GDAP) | [MC1537494](https://mc.merill.net/message/MC1537494) | [Brief](../news/posts/2026-11-05-defender-rbac-auto-enable-review-imported-roles.md) |
| End of Dec 2026 | Exchange Online: SMTP AUTH Basic authentication off by default in existing tenants | Exchange admins | [MC786329](https://mc.merill.net/message/MC786329) | [Guide](exchange-online-smtp-auth-basic-auth-checklist.md) |
| 12 Jan 2027 | Windows Server 2016 and Windows 10 Enterprise LTSC 2021 reach end of updates | Server and endpoint admins | [Windows message center](https://learn.microsoft.com/windows/release-health/windows-message-center) | [Roundup](../news/posts/2026-10-31-endpoint-devices-this-week.md) |
| Mid-Jan to end of Jan 2027 | Purview: legacy Teams retention policies that also covered Copilot become Teams-only | Compliance admins | [MC1481313](https://mc.merill.net/message/MC1481313) | [Roundup](../news/posts/2026-10-31-data-compliance-this-week.md) |
| 1 Feb 2027 | Microsoft's own SMS and voice MFA retires for all users except Global Administrators and external users | Identity admins | [MC1519855](https://mc.merill.net/message/MC1519855) | [Guide](entra-sms-voice-mfa-retirement-passkeys.md) |
| 1 Feb 2027 | Defender XDR Advanced Hunting APIs stop working; move to the Microsoft Graph security API | SecOps, SIEM owners | [MC1220762](https://mc.merill.net/message/MC1220762) | |
| Mid-Mar to late Mar 2027 | Purview: DSPM classic and DSPM for AI classic views retire (moved from late January on 30 Oct 2026) | Purview admins | [MC1481315](https://mc.merill.net/message/MC1481315) | [Roundup](../news/posts/2026-10-31-data-compliance-this-week.md) |
| 1 Jul 2027 | SMS and voice MFA retires for Global Administrators and external users | Identity admins | [MC1519855](https://mc.merill.net/message/MC1519855) | [Guide](entra-sms-voice-mfa-retirement-passkeys.md) |
| 15 Oct 2027 | `Search-UnifiedAuditLog` retires; scripts move to the Microsoft Graph audit log query API | Script and report owners | [MC1505599](https://mc.merill.net/message/MC1505599) | |

Message center posts are only visible inside a tenant's admin center. The links go to a public mirror of the message center (mc.merill.net), which keeps each version.
