---
title: "Entra Privileged Access: Fewer Than Five Global Admins, Eligible Roles in PIM"
description: "Cut standing admin access in Microsoft Entra ID in five steps: a role inventory with Global Administrators below five, eligible roles in Privileged Identity Management, strict PIM settings for Tier 0 roles, cloud-only admin accounts and a quarterly access review. Read-only Graph PowerShell checks for each step."
rl_type: guide
rl_updated: "30 October 2026"
---

# Entra privileged access: fewer than five Global Admins, eligible roles in PIM

<p class="rl-updated">Last reviewed 30 October 2026 · facts re-read on Microsoft Learn 28 and 30 October 2026</p>

<p class="rl-lead">Most tenants carry more standing admin access than anyone planned: Global Administrator on the account that reads email, roles that never expire, a contractor who left in spring. Five steps that bring it down to what Microsoft recommends, in an order that keeps a way back. Every check on this page only reads.</p>

[Get the free Privileged Access and PIM Top 5 kit](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=guide-entra-privileged-access-pim){ .md-button .md-button--primary }
[All Microsoft 365 security deadlines](deadlines.md){ .md-button }

## Before you start

| Check | Why |
|---|---|
| Two emergency access accounts exist | They keep permanent Global Administrator and sit outside Conditional Access. See [step 1 of the Conditional Access guide](entra-conditional-access-baseline-report-only.md). |
| Microsoft Entra ID P2 or Microsoft Entra ID Governance for everyone who will activate a role | PIM needs one of them. P2 is part of Microsoft 365 E5. The inventory (step 1) and admin accounts (step 4) work on any edition. |
| Microsoft Graph PowerShell, Global Reader | All checks use Get-* cmdlets or Graph GET requests and change nothing. |

```powershell
Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
```

## The five steps

### 1. List every privileged role holder and get Global Administrators below five

Microsoft recommends fewer than five Global Administrator assignments (the Entra Overview page shows an alert card at five or more) and fewer than 10 privileged role assignments in total, the two emergency accounts included. For each Global Administrator, write down the tasks they really do and find the least privileged role for each task. Add the new roles first, wait a few days, then remove Global Administrator.

```powershell
foreach ($n in 'Global Administrator','Privileged Role Administrator','Privileged Authentication Administrator','Security Administrator','Exchange Administrator','User Administrator') {
  $d = Get-MgRoleManagementDirectoryRoleDefinition -Filter "displayName eq '$n'"
  $a = @(Get-MgRoleManagementDirectoryRoleAssignment -All -Filter "roleDefinitionId eq '$($d.Id)'")
  $e = @(Get-MgRoleManagementDirectoryRoleEligibilityScheduleInstance -All -Filter "roleDefinitionId eq '$($d.Id)'")
  "$n | active now: $($a.Count) | eligible: $($e.Count)"
}
```

Control page: [PA01 Inventory and fewer than five Global Administrators](../controls/privileged-access-pim/pa01-inventory-every-privileged-role-assignment-and-bring.md)

### 2. Make admin roles eligible, not permanent

With Privileged Identity Management an admin is eligible and activates the role for a limited time; PIM removes it when the time ends. Set the role settings first (step 3), then add each admin as Eligible, ask them to activate once, and only then remove the Active assignment. Start with Global Administrator, Privileged Role Administrator and Privileged Authentication Administrator, one role per day. Only the two emergency accounts stay permanent.

Path: ID Governance > Privileged Identity Management > Microsoft Entra roles > Assignments.

Watch for scripts or service accounts that relied on a person holding a standing role. Move them to an app identity with the least permission before you start.

Control page: [PA02 Eligible roles in PIM](../controls/privileged-access-pim/pa02-make-admin-roles-eligible-in-pim-no-permanent-active.md)

### 3. Strict PIM settings for Tier 0 roles

In PIM > Microsoft Entra roles > Settings, open each Tier 0 role. Activation can last from 1 to 24 hours; keep it short (we suggest 4 hours or less). Require MFA on activation, or better a Conditional Access authentication context that asks for phishing-resistant MFA. Require a justification. Require approval with two named approvers: Microsoft recommends at least two and warns that approval with no approvers configured can lock you out. Turn off permanent active assignment and send activation alerts to a monitored security mailbox.

One detail from the PIM settings page: if no Conditional Access policy targets the authentication context, activation falls back to plain MFA. That fallback does not apply if the policy is off, in Report-only or excludes the user, so check the policy before you rely on it.

Control page: [PA03 PIM settings for Tier 0 roles](../controls/privileged-access-pim/pa03-set-pim-role-settings-for-tier-0-roles-short-activation.md)

### 4. A separate cloud-only account for admin work

Microsoft recommends cloud-native accounts for Microsoft Entra roles: if an account synced from on-premises Active Directory is compromised, what it administers in Entra can be too. Give each admin a second account on the tenant domain, with no mailbox unless a task needs one, register a passkey or Windows Hello for Business for it, and make that account eligible instead of the daily one.

```powershell
Get-MgUser -All -Property userPrincipalName,onPremisesSyncEnabled |
  Where-Object { $_.OnPremisesSyncEnabled } |
  Select-Object -First 5 UserPrincipalName
# The kit's PA04 check joins this with the privileged role list
```

Control page: [PA04 Cloud-only admin accounts](../controls/privileged-access-pim/pa04-give-every-admin-a-separate-cloud-only-admin-account-not.md)

### 5. A quarterly access review, and an alert on roles added outside PIM

PIM access reviews for Entra roles can run one time, weekly, monthly, quarterly, semi-annually or annually. Use Quarterly, two named reviewers (not self-review for Tier 0), Auto apply on, and "If reviewers don't respond" = Remove access. Then check the PIM alert "Roles are being assigned outside of Privileged Identity Management" (High severity) is on, so a standing assignment added straight in the admin center doesn't go unnoticed.

```powershell
Get-MgIdentityGovernanceAccessReviewDefinition -All |
  Select-Object DisplayName, Status
```

Control page: [PA05 Quarterly access review](../controls/privileged-access-pim/pa05-run-a-quarterly-access-review-of-privileged-roles-and.md)

## What each step can break

| Step | Who notices | Way back |
|---|---|---|
| 1 Fewer Global Admins | An admin who rarely needs a permission they lost | Re-add the role while you find the narrower one |
| 2 Eligible roles | Admins activate before admin work; scripts on a person's role stop | Add the Active assignment back for that person |
| 3 Tier 0 settings | Activation needs approval and expires sooner | Relax the setting on that role |
| 4 Admin accounts | Admins use a second account in a separate browser profile | Keep the role on the old account a little longer |
| 5 Access review | Admins whose role is not approved lose it | They request it again through PIM |

## The kit for steps 1–5

The free **Privileged Access and PIM Kit: Top 5** turns this page into a project: the five controls with why, steps, impact and rollback, a Jira import, an Excel project plan and a read-only PowerShell script that runs all the checks above. The [Complete kit](../kits/privileged-access-pim.md) adds 15 controls: PIM for Groups and Azure resources, restricted management administrative units, apps holding Graph permissions that can grant more access, Microsoft Entra Connect as Tier 0, admin devices, stale admins, partner access, log retention and emergency account alerts.

[Download the free Top 5](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=guide-entra-privileged-access-pim){ .md-button .md-button--primary }
[See the kit](../kits/privileged-access-pim.md){ .md-button }

## FAQ

### How many Global Administrators should a tenant have?

Microsoft recommends fewer than five Global Administrator assignments, including the two cloud-only emergency access accounts, and fewer than 10 privileged role assignments in total. The Microsoft Entra Overview page shows an alert card at five or more.

### Which licence does Privileged Identity Management need?

Microsoft Entra ID P2 or Microsoft Entra ID Governance for the people who activate roles. P2 is included in Microsoft 365 E5 and EMS E5.

### How long can a PIM activation last?

The maximum activation duration is set per role, from 1 to 24 hours. For Tier 0 roles such as Global Administrator a short window, for example 4 hours or less, keeps the exposure low.

### Do the emergency access accounts go into PIM?

No. Microsoft's guidance keeps two cloud-only emergency access accounts with permanent Global Administrator, outside Conditional Access, protected with a passkey or certificate and monitored so every sign-in raises an alert.

## Sources

- Microsoft Learn: Best practices for Microsoft Entra roles
- Microsoft Learn: Configure Microsoft Entra role settings in Privileged Identity Management
- Microsoft Learn: Security alerts for Microsoft Entra roles in PIM
- Microsoft Learn: Create an access review of Microsoft Entra roles in PIM
- Microsoft Learn: Manage emergency access accounts in Microsoft Entra ID
