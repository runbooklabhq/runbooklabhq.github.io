---
title: "Mandatory MFA and break-glass accounts: am I affected?"
description: "Microsoft requires MFA on the Azure, Entra, Intune and Microsoft 365 admin centers, break-glass accounts included. A read-only Graph check and the fix in order."
rl_type: guide
rl_service: [entra]
rl_area: identity
rl_kits: [m365]
rl_updated: "19 November 2026"
rl_nl_place: leadmagnet
---

# Mandatory MFA and break-glass accounts: am I affected?

<p class="rl-updated">Last reviewed 19 November 2026</p>

<p class="rl-lead">Microsoft requires multifactor authentication to sign in to the Azure portal, the Microsoft Entra admin center and the Intune admin center (since October 2024) and the Microsoft&nbsp;365 admin center (since February 2025). Emergency access (break-glass) accounts are not exempt, and Conditional Access exclusions do not change that. The check below tells you, per account, whether your break-glass accounts are ready.</p>

## Am I affected?

Run the [read-only check](#the-read-only-check) with the user principal names of your emergency access accounts. It gives one of three answers per account:

| Answer | What it means | What to do |
|---|---|---|
| **APPLIES** | No MFA method is registered for the account. It cannot complete the MFA that the admin centers now ask for. | Register a passkey (FIDO2) security key, or use certificate-based authentication. [Steps](#steps-in-order). |
| **NOT FOUND** | A device-bound passkey (FIDO2 security key, shown as `passKeyDeviceBound`) is registered and the account is MFA capable. | Test a sign-in with the key (MFA capable can come from another method, so the sign-in test is what proves the key works) and confirm the alert on emergency account use fires. |
| **REVIEW** | No record was returned (wrong UPN, or a disabled account: Microsoft says "This method doesn't work for disabled users"), the report could not be read (for example, you lack one of the roles below), a security key is registered but the account is not MFA capable (the method may not be allowed by the Authentication methods policy), or MFA is registered without a FIDO2 security key (for example a passkey in Microsoft Authenticator or Windows Hello, which is tied to a phone or a PC). Microsoft lists the registered method values only as examples, so the check counts only the exact value `passKeyDeviceBound` as a security key. | Look at the account by hand. When the check cannot be sure, it says REVIEW, never "no". |

Microsoft's report documentation does not say whether certificate-based authentication appears in the registered methods, so an account that uses only certificate-based authentication may get APPLIES with a note: check its certificate mapping before you change anything.

## What changes and when

| Phase | What needs MFA | Since |
|---|---|---|
| Phase 1 | Sign-in to the Azure portal, Microsoft Entra admin center and Microsoft Intune admin center, for any create, read, update or delete operation | October 2024 |
| Phase 1 | Sign-in to the Microsoft&nbsp;365 admin center (admin.cloud.microsoft, admin.microsoft.com, portal.office.com/adminportal) | February 2025, rolled out gradually |
| Phase 2 | Azure CLI, Azure PowerShell, Azure mobile app, IaC tools, Azure SDK and REST API endpoints, for create, update and delete operations; "Read operations won't require MFA" | 1 October 2025, rolled out gradually |

Microsoft's page says "There's no way to opt out." The postponements it describes have run out: Phase 1 could be postponed "until September 30, 2025" and Phase 2 "until July 1st, 2026". After Phase 2 enforcement, a Global Administrator can ask Microsoft Support to lift it temporarily. Enforcement applies to the public Azure cloud, not, currently, Azure for US Government or other sovereign clouds.

## Who is in scope

- **Every user account that signs in to those portals and tools**, including break-glass accounts. Microsoft: "Break glass or emergency access accounts are also required to sign in with MFA once enforcement begins."
- **Accounts excluded in Conditional Access.** If you relied on an exclusion: "If you configured exceptions or exclusions in the policy, they no longer apply."
- **User accounts used as service accounts** for scripts and automation: "those user identities need to sign in with MFA once enforcement begins." Move that automation to a workload identity.
- **Not in scope:** "Workload identities, such as managed identities and service principals, aren't impacted by either phase of this MFA enforcement."

## The read-only check

The script reads the authentication methods registration report with Microsoft Graph PowerShell (`GET /v1.0/reports/authenticationMethods/userRegistrationDetails`). It needs the Microsoft.Graph.Authentication module 2.x and the AuditLog.Read.All permission; a Reports Reader, Security Reader, Security Administrator or Global Reader can run it. It changes nothing in the tenant. The first `Connect-MgGraph` can show a consent prompt, and accepting it records a permission grant in your tenant. It writes the result to `break-glass-mfa-check.csv` in the current folder.

```powershell
# Save as break-glass-mfa-check.ps1, then run:
#   .\break-glass-mfa-check.ps1 -BreakGlassUpn 'bg1@contoso.onmicrosoft.com','bg2@contoso.onmicrosoft.com'
# Runbook Lab - "Am I affected?" check: mandatory MFA and your break-glass accounts
# Version 1.0.1 (2026-11-18). Sources re-read 2026-11-18.
# Reads only (Graph GET). Note: the first Connect-MgGraph may show a consent prompt; accepting it records a
# permission grant in your tenant. Needs the Microsoft.Graph.Authentication module 2.x.
# Sources (opened 2026-11-17, re-read 2026-11-18):
#   https://learn.microsoft.com/en-us/entra/identity/authentication/concept-mandatory-multifactor-authentication
#   https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access
#   https://learn.microsoft.com/en-us/graph/api/authenticationmethodsroot-list-userregistrationdetails?view=graph-rest-1.0
#   https://learn.microsoft.com/en-us/graph/api/resources/userregistrationdetails?view=graph-rest-1.0
# Permission: AuditLog.Read.All (delegated; role Reports Reader, Security Reader, Security Administrator or Global Reader).
# Answers: APPLIES / NOT FOUND / REVIEW. When the script cannot be sure, the answer is REVIEW.
param(
    [Parameter(Mandatory = $true)]
    [string[]] $BreakGlassUpn   # the UPNs of your emergency access accounts
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ctx = Get-MgContext
if (-not $ctx -or $ctx.Scopes -notcontains 'AuditLog.Read.All') { Connect-MgGraph -Scopes 'AuditLog.Read.All' -NoWelcome }

$results = foreach ($upn in $BreakGlassUpn) {
    $safe   = $upn.Replace("'", "''")
    $filter = [uri]::EscapeDataString("userPrincipalName eq '$safe'")
    $uri    = "/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=$filter"
    try {
        $r = @((Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop).value)
    } catch {
        [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = ''; ReportUpdated = ''; Reason = "Could not read registration details: $($_.Exception.Message)" }
        continue
    }
    if ($r.Count -eq 0) {
        [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = ''; ReportUpdated = ''; Reason = 'No registration record returned. Check the UPN. If the account is disabled: "This method doesn''t work for disabled users," so the report cannot answer for it.' }
        continue
    }
    $d       = $r[0]
    $m       = @($d.methodsRegistered)
    $methods = $m -join ','
    $updated = "$($d.lastUpdatedDateTime)"
    # Learn lists methodsRegistered values only as examples ('such as mobilePhone, email, passKeyDeviceBound'),
    # so only the exact value passKeyDeviceBound counts as a passkey (FIDO2) security key. Any other passkey-like
    # value (for example a passkey in Microsoft Authenticator or Windows Hello) is not counted and leads to REVIEW.
    $keys    = @($m | Where-Object { $_ -ceq 'passKeyDeviceBound' })
    $other   = @($m | Where-Object { $_ -match 'passkey|fido' -and $_ -cne 'passKeyDeviceBound' })
    if (-not $d.isMfaRegistered) {
        [pscustomobject]@{ Account = $upn; Answer = 'APPLIES'; Methods = $methods; ReportUpdated = $updated; Reason = 'No MFA method registered in this report. Mandatory MFA also applies to emergency access accounts and Conditional Access exclusions do not exempt them. If the account uses certificate-based authentication, check its certificate mapping; otherwise register a passkey (FIDO2).' }
    } elseif ($keys.Count -gt 0 -and $d.isMfaCapable -eq $true) {
        [pscustomobject]@{ Account = $upn; Answer = 'NOT FOUND'; Methods = $methods; ReportUpdated = $updated; Reason = 'A device-bound passkey (passKeyDeviceBound) is registered and the account is MFA capable. Test a sign-in with the FIDO2 key and confirm the alert on emergency account use fires.' }
    } elseif ($keys.Count -gt 0) {
        [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = $methods; ReportUpdated = $updated; Reason = 'A passkey is registered but the account is not MFA capable: the method may not be allowed by the Authentication methods policy (or key restrictions).' }
    } elseif ($other.Count -gt 0) {
        [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = $methods; ReportUpdated = $updated; Reason = "MFA is registered and a passkey-type method was found ($($other -join ',')), but not a FIDO2 security key (passKeyDeviceBound). A passkey in Microsoft Authenticator or Windows Hello is tied to a phone or a PC. Microsoft recommends a passkey (FIDO2) or certificate-based authentication for these accounts, separate from normal admin methods; confirm which one it uses." }
    } else {
        [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = $methods; ReportUpdated = $updated; Reason = 'MFA is registered but no passkey security key was recognised (a passkey in Microsoft Authenticator lives on a phone). Microsoft recommends a passkey (FIDO2) or certificate-based authentication for these accounts, separate from normal admin methods; confirm which one it uses.' }
    }
}

$results | Format-Table -AutoSize
$results | Export-Csv -Path 'break-glass-mfa-check.csv' -NoTypeInformation -Encoding UTF8
```

The report has a `lastUpdatedDateTime` column (shown as ReportUpdated). If you registered a key a moment ago, the report may not show it yet; Microsoft's page does not say how quickly it updates.

<!--rl-newsletter-->

## Steps in order

1. **List your emergency access accounts.** Microsoft recommends "two or more", cloud-only accounts on the \*.onmicrosoft.com domain, not federated or synchronised, in a dedicated group (for example EmergencyAccess). Run the check above against each of them.
2. **Register strong MFA for every account with APPLIES.** Microsoft: "We recommend that you update these accounts to use passkey (FIDO2) or configure certificate-based authentication for MFA. Both methods satisfy the MFA requirement." Microsoft marks passkey (FIDO2) as recommended and certificate-based authentication for organisations that already run a PKI. Use a method that differs from your other admin accounts, and keep the keys for different accounts in separate safe places.
3. **Make sure the method is allowed.** The report shows an account as MFA capable only when its method is allowed by the Authentication methods policy, so check that the Passkey (FIDO2) method, including any key restrictions, covers these accounts.
4. **Keep the Conditional Access exclusion where it belongs.** Exclude emergency access accounts from policies that block or restrict sign-in ([control CA01](../controls/conditional-access/ca01-create-two-emergency-access-accounts-exclude-them-from.md)). The exclusion no longer skips the platform's mandatory MFA, so it is not a substitute for step 2. Report-only policies do not block access and need no exclusion. A stricter policy that still targets these accounts, such as one requiring phishing-resistant MFA, stays enforced, so check which policies include them.
5. **Alert on every use.** Microsoft: "Configure alerts for every use of an emergency access account."
6. **Test a sign-in at least every 90 days.** Microsoft: "Validate account functionality at least every 90 days." Run the check again: every account should show NOT FOUND, or a confirmed certificate mapping.

## Impact

Registering a passkey on a break-glass account changes nothing for other users. Until an account has a working MFA method, it cannot be used in the admin centers listed above, which is the moment you would need it most.

## Rollback

Nothing to roll back for the check. If a newly registered key is lost or fails, sign in with the second emergency account, remove the method from the first account and register a new one. Do not remove the old method from both accounts at the same time.

## Related

- [Entra Conditional Access baseline: five policies, Report-only first](entra-conditional-access-baseline-report-only.md)
- [Entra PIM implementation checklist: fewer than five Global Admins](entra-privileged-access-pim-global-admins.md)
- [Entra SMS and voice MFA retires on 1 February 2027](entra-sms-voice-mfa-retirement-passkeys.md)
- [All Microsoft&nbsp;365 security deadlines](deadlines.md)
- The free [M365 Hardening Kit Top 10](../kits/m365-hardening.md) with more read-only checks and a Jira import

## Sources

- Microsoft Learn: [Mandatory multifactor authentication for Azure and admin portals](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-mandatory-multifactor-authentication), last updated 3 April 2026, read 19 November 2026.
- Microsoft Learn: [Manage emergency access admin accounts](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access), last updated 5 June 2026, read 19 November 2026.
- Microsoft Learn: [List userRegistrationDetails](https://learn.microsoft.com/en-us/graph/api/authenticationmethodsroot-list-userregistrationdetails?view=graph-rest-1.0) and [userRegistrationDetails resource](https://learn.microsoft.com/en-us/graph/api/resources/userregistrationdetails?view=graph-rest-1.0), read 17 and 18 November 2026 (by the check's author).

Runbook Lab is independent and not affiliated with Microsoft.
