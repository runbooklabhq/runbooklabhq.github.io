---
title: "Mandatory MFA and break-glass accounts: am I affected?"
description: "Microsoft requires MFA on the Azure, Entra, Intune and Microsoft 365 admin centers, break-glass accounts included. A read-only Graph check and the fix in order."
rl_type: guide
rl_service: [entra]
rl_area: identity
rl_kits: [m365]
rl_updated: "25 November 2026"
rl_nl_place: leadmagnet
rl_checkflow: break-glass
---

<header class="rl-ah" markdown="1">
<p class="rl-ah__top"><span class="rl-ah__eyebrow"><span class="rl-i rl-i--help" aria-hidden="true"></span>Am I affected?</span> <span class="rl-pill rl-pill--red">Already enforced</span></p>

# Mandatory MFA and break-glass accounts: am I affected?

<p class="rl-lead">Microsoft requires multifactor authentication to sign in to the Azure portal, the Microsoft Entra admin center and the Intune admin center (since October 2024) and the Microsoft&nbsp;365 admin center (since February 2025). Emergency access (break-glass) accounts are not exempt, and Conditional Access exclusions do not change that. The check below tells you, per account, whether your break-glass accounts are ready.</p>

<ul class="rl-facts3">
<li style="--c:#FB7185"><span class="rl-facts3__k"><span class="rl-i rl-i--clock" aria-hidden="true"></span>Since</span><strong>October 2024</strong>Portals first, the Microsoft&nbsp;365 admin center from February 2025, Azure CLI, Azure PowerShell and other tools from 1 October 2025.</li>
<li><span class="rl-facts3__k"><span class="rl-i rl-i--users" aria-hidden="true"></span>Who</span><strong>Every user account</strong>That signs in to those portals and tools. Break-glass accounts are not exempt.</li>
<li style="--c:#FBBF24"><span class="rl-facts3__k"><span class="rl-i rl-i--term" aria-hidden="true"></span>The check</span><strong>Read-only</strong>One Graph GET per account. Needs AuditLog.Read.All. Changes nothing in the tenant.</li>
</ul>

<div class="rl-ah__go" markdown="1">
[Run the read-only check](#the-read-only-check){ .md-button .md-button--primary }
[Steps in order](#steps-in-order){ .md-button }

<p class="rl-updated">Last reviewed 25 November 2026</p>
</div>
</header>

!!! info "Updated 25 November 2026: two corrections"
    Until today this page said Microsoft's page "does not say how quickly" the registration report updates. Microsoft Learn says the report updates for most users within 36 hours. It also said Microsoft's report documentation does not say whether certificate-based authentication appears in the registered methods. That holds for the Graph pages only: the portal report lists Certificate-based authentication among Methods registered. The check itself, the script and the six steps did not change. See [Before you trust the result](#before-you-trust-the-result).

## Am I affected?

Run the [read-only check](#the-read-only-check) with the user principal names of your emergency access accounts. It gives one of three answers per account:

<div class="rl-res">
<a class="rl-res__c rl-res__c--a" href="#steps-in-order">
<span class="rl-res__head"><span class="rl-i rl-i--warn" aria-hidden="true"></span>APPLIES</span>
<span class="rl-res__body"><strong>No MFA method is registered</strong>The account cannot complete the MFA that the admin centers now ask for.</span>
<span class="rl-res__next"><span class="rl-i rl-i--arrow" aria-hidden="true"></span><span><b>Next:</b> register a passkey (FIDO2) security key, or use certificate-based authentication. Step 2.</span></span>
</a>
<a class="rl-res__c rl-res__c--n" href="#steps-in-order">
<span class="rl-res__head"><span class="rl-i rl-i--ok" aria-hidden="true"></span>NOT FOUND</span>
<span class="rl-res__body"><strong>A security key is registered</strong>A device-bound passkey (FIDO2 security key, shown as <code>passKeyDeviceBound</code>) is registered and the account is MFA capable.</span>
<span class="rl-res__next"><span class="rl-i rl-i--arrow" aria-hidden="true"></span><span><b>Next:</b> test a sign-in with the key and confirm the alert on emergency account use fires. Steps 5 and 6.</span></span>
</a>
<a class="rl-res__c rl-res__c--r" href="#why-an-account-gets-review">
<span class="rl-res__head"><span class="rl-i rl-i--eye" aria-hidden="true"></span>REVIEW</span>
<span class="rl-res__body"><strong>The check cannot be sure</strong>When the check cannot be sure, it says REVIEW, never "no".</span>
<span class="rl-res__next"><span class="rl-i rl-i--arrow" aria-hidden="true"></span><span><b>Next:</b> look at the account by hand. The five reasons are below.</span></span>
</a>
</div>

NOT FOUND is not the end of the job: MFA capable can come from another method, so the sign-in test is what proves the key works.

### Why an account gets REVIEW

<ul class="rl-why">
<li><span class="rl-i rl-i--userx" aria-hidden="true"></span><span><strong>No record was returned.</strong> A wrong UPN, or a disabled account: Microsoft says "This method doesn't work for disabled users".</span></li>
<li><span class="rl-i rl-i--ban" aria-hidden="true"></span><span><strong>The report could not be read.</strong> For example, you lack one of the roles the check needs.</span></li>
<li><span class="rl-i rl-i--sliders" aria-hidden="true"></span><span><strong>A security key is registered but the account is not MFA capable.</strong> The method may not be allowed by the Authentication methods policy.</span></li>
<li><span class="rl-i rl-i--phone" aria-hidden="true"></span><span><strong>MFA is registered without a FIDO2 security key.</strong> For example a passkey in Microsoft Authenticator or Windows Hello, which is tied to a phone or a PC.</span></li>
<li><span class="rl-i rl-i--tag" aria-hidden="true"></span><span><strong>The method name is not the exact one.</strong> Microsoft lists the registered method values only as examples, so the check counts only the exact value <code>passKeyDeviceBound</code> as a security key.</span></li>
</ul>

The Graph resource page does not say whether certificate-based authentication appears in `methodsRegistered`; the portal report lists Certificate-based authentication among Methods registered. An account that uses only certificate-based authentication may still get APPLIES with a note: check its certificate mapping before you change anything.

## The read-only check

The script reads the authentication methods registration report with Microsoft Graph PowerShell (`GET /v1.0/reports/authenticationMethods/userRegistrationDetails`). It needs the Microsoft.Graph.Authentication module 2.x and the AuditLog.Read.All permission; a Reports Reader, Security Reader, Security Administrator or Global Reader can run it. It changes nothing in the tenant. The first `Connect-MgGraph` can show a consent prompt, and accepting it records a permission grant in your tenant. It writes the result to `break-glass-mfa-check.csv` in the current folder.

<!--rl-checkflow-->

=== "PowerShell script"

    ```powershell
    # Save as break-glass-mfa-check.ps1, then run:
    #   .\break-glass-mfa-check.ps1 -BreakGlassUpn 'bg1@contoso.onmicrosoft.com','bg2@contoso.onmicrosoft.com'
    # Runbook Lab - "Am I affected?" check: mandatory MFA and your break-glass accounts
    # Version 1.0.1 (2026-11-18). Sources re-read 2026-11-18.
    # Reads only (Graph GET). Note: the first Connect-MgGraph may show a consent prompt; accepting it records a
    # permission grant in your tenant. Needs the Microsoft.Graph.Authentication module 2.x.
    # Sources (opened 2026-11-17, re-read 2026-11-18):
    #   https://learn.microsoft.com/en-us/entra/identity/authentication/concept-mandatory-multifactor-authentication
    #   https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access
    #   https://learn.microsoft.com/en-us/graph/api/authenticationmethodsroot-list-userregistrationdetails?view=graph-rest-1.0
    #   https://learn.microsoft.com/en-us/graph/api/resources/userregistrationdetails?view=graph-rest-1.0
    # Permission: AuditLog.Read.All (delegated; role Reports Reader, Security Reader, Security Administrator or Global Reader).
    # Answers: APPLIES / NOT FOUND / REVIEW. When the script cannot be sure, the answer is REVIEW.
    param(
        [Parameter(Mandatory = $true)]
        [string[]] $BreakGlassUpn   # the UPNs of your emergency access accounts
    )
    Set-StrictMode -Version Latest
    $ErrorActionPreference = 'Stop'

    $ctx = Get-MgContext
    if (-not $ctx -or $ctx.Scopes -notcontains 'AuditLog.Read.All') { Connect-MgGraph -Scopes 'AuditLog.Read.All' -NoWelcome }

    $results = foreach ($upn in $BreakGlassUpn) {
        $safe   = $upn.Replace("'", "''")
        $filter = [uri]::EscapeDataString("userPrincipalName eq '$safe'")
        $uri    = "/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=$filter"
        try {
            $r = @((Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop).value)
        } catch {
            [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = ''; ReportUpdated = ''; Reason = "Could not read registration details: $($_.Exception.Message)" }
            continue
        }
        if ($r.Count -eq 0) {
            [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = ''; ReportUpdated = ''; Reason = 'No registration record returned. Check the UPN. If the account is disabled: "This method doesn''t work for disabled users," so the report cannot answer for it.' }
            continue
        }
        $d       = $r[0]
        $m       = @($d.methodsRegistered)
        $methods = $m -join ','
        $updated = "$($d.lastUpdatedDateTime)"
        # Learn lists methodsRegistered values only as examples ('such as mobilePhone, email, passKeyDeviceBound'),
        # so only the exact value passKeyDeviceBound counts as a passkey (FIDO2) security key. Any other passkey-like
        # value (for example a passkey in Microsoft Authenticator or Windows Hello) is not counted and leads to REVIEW.
        $keys    = @($m | Where-Object { $_ -ceq 'passKeyDeviceBound' })
        $other   = @($m | Where-Object { $_ -match 'passkey|fido' -and $_ -cne 'passKeyDeviceBound' })
        if (-not $d.isMfaRegistered) {
            [pscustomobject]@{ Account = $upn; Answer = 'APPLIES'; Methods = $methods; ReportUpdated = $updated; Reason = 'No MFA method registered in this report. Mandatory MFA also applies to emergency access accounts and Conditional Access exclusions do not exempt them. If the account uses certificate-based authentication, check its certificate mapping; otherwise register a passkey (FIDO2).' }
        } elseif ($keys.Count -gt 0 -and $d.isMfaCapable -eq $true) {
            [pscustomobject]@{ Account = $upn; Answer = 'NOT FOUND'; Methods = $methods; ReportUpdated = $updated; Reason = 'A device-bound passkey (passKeyDeviceBound) is registered and the account is MFA capable. Test a sign-in with the FIDO2 key and confirm the alert on emergency account use fires.' }
        } elseif ($keys.Count -gt 0) {
            [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = $methods; ReportUpdated = $updated; Reason = 'A passkey is registered but the account is not MFA capable: the method may not be allowed by the Authentication methods policy (or key restrictions).' }
        } elseif ($other.Count -gt 0) {
            [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = $methods; ReportUpdated = $updated; Reason = "MFA is registered and a passkey-type method was found ($($other -join ',')), but not a FIDO2 security key (passKeyDeviceBound). A passkey in Microsoft Authenticator or Windows Hello is tied to a phone or a PC. Microsoft recommends a passkey (FIDO2) or certificate-based authentication for these accounts, separate from normal admin methods; confirm which one it uses." }
        } else {
            [pscustomobject]@{ Account = $upn; Answer = 'REVIEW'; Methods = $methods; ReportUpdated = $updated; Reason = 'MFA is registered but no passkey security key was recognised (a passkey in Microsoft Authenticator lives on a phone). Microsoft recommends a passkey (FIDO2) or certificate-based authentication for these accounts, separate from normal admin methods; confirm which one it uses.' }
        }
    }

    $results | Format-Table -AutoSize
    $results | Export-Csv -Path 'break-glass-mfa-check.csv' -NoTypeInformation -Encoding UTF8
    ```

=== "No script: the portal path"

    The same report, read by hand. Path checked 20 November 2026 and read again on 25 November 2026. Microsoft says a Microsoft Entra ID P1 or P2 licence is needed to open it.

    1. Sign in to the **Microsoft Entra admin center** with one of these roles: Reports Reader, Security Reader, Global Reader or Security Administrator.
    2. Go to **Entra ID** > **Authentication methods** > **Activity**.
    3. Open the **Registration** tab and find the user registration details.
    4. Search for the UPN of each break-glass account.
    5. Read two columns: **MFA Capable** and **Methods registered**.

    The portal shows method display names (for example FIDO2 security key); the script reads the Graph value `passKeyDeviceBound`.

=== "What the output looks like"

    <div class="rl-out" role="group" aria-label="Example output">
    <div class="rl-out__bar"><i></i><i></i><i></i><span>break-glass-mfa-check.csv · example with made-up accounts</span></div>
    <table>
    <thead><tr><th>Account</th><th>Answer</th><th>Methods</th><th>Reason</th></tr></thead>
    <tbody>
    <tr><td>bg1@contoso.onmicrosoft.com</td><td class="a">APPLIES</td><td></td><td>No MFA method registered in this report.</td></tr>
    <tr><td>bg2@contoso.onmicrosoft.com</td><td class="n">NOT FOUND</td><td>passKeyDeviceBound</td><td>A device-bound passkey is registered and the account is MFA capable.</td></tr>
    <tr><td>bg3@contoso.onmicrosoft.com</td><td class="r">REVIEW</td><td>mobilePhone</td><td>MFA is registered but no passkey security key was recognised.</td></tr>
    </tbody>
    </table>
    </div>

    The file also has a `ReportUpdated` column: when the report was last updated. Microsoft says this value is not related to the user's method registration.

The report has a `lastUpdatedDateTime` column (shown as ReportUpdated). If you registered a key a moment ago, the report may not show it yet: Microsoft says the report updates for most users within 36 hours.

<!--rl-newsletter-->

## Before you trust the result

<p class="rl-sub">Seven things that sit on five different Microsoft Learn pages. Each one changes how you read the answer.</p>

<div class="rl-notes">
<article class="rl-note rl-note--wide">
<span class="rl-note__ic"><span class="rl-i rl-i--sand" aria-hidden="true"></span></span>
<h3 id="the-report-can-be-36-hours-behind">The report can be 36 hours behind</h3>
<p>A key you registered this morning can still show <b>APPLIES</b> tomorrow. Microsoft says the registration report updates for most users within 36 hours; in the rare case that a user falls outside that, look again after 24 hours. If the <code>ReportUpdated</code> time is earlier than the time you registered the key, the report has not caught up. A later time does not prove it has: Microsoft says that value is not related to the user's method registration.</p>
<p class="rl-note__src"><span class="rl-i rl-i--book" aria-hidden="true"></span>Microsoft Learn: Authentication methods activity</p>
</article>
<article class="rl-note">
<span class="rl-note__ic"><span class="rl-i rl-i--userx" aria-hidden="true"></span></span>
<h3 id="disabled-accounts-are-not-in-the-report">Disabled accounts are not in the report</h3>
<p>Disabled and recently deleted users are not listed. A break-glass account that you keep disabled gets <b>REVIEW</b>, not an answer.</p>
<p class="rl-note__src"><span class="rl-i rl-i--book" aria-hidden="true"></span>Authentication methods activity; List userRegistrationDetails</p>
</article>
<article class="rl-note">
<span class="rl-note__ic"><span class="rl-i rl-i--swap" aria-hidden="true"></span></span>
<h3 id="the-portal-and-graph-use-different-names">The portal and Graph use different names</h3>
<p>The portal column shows display names such as FIDO2 security key. Graph returns values such as <code>passKeyDeviceBound</code>. The two pages named below do not map one to the other. We read FIDO2 security key as the portal name for <code>passKeyDeviceBound</code>: confirm it on one account whose key you know.</p>
<p class="rl-note__src"><span class="rl-i rl-i--book" aria-hidden="true"></span>Authentication methods activity; userRegistrationDetails resource</p>
</article>
<article class="rl-note">
<span class="rl-note__ic"><span class="rl-i rl-i--sliders" aria-hidden="true"></span></span>
<h3 id="mfa-capable-is-not-the-same-as-has-a-key">"MFA capable" is not the same as "has a key"</h3>
<p>The report shows an account as MFA capable only when its method is allowed by the Authentication methods policy. A key registered under a policy or key restriction that leaves these accounts out can give <b>REVIEW</b>. If another allowed method makes the account MFA capable, the answer is <b>NOT FOUND</b>, which is why the sign-in test matters.</p>
<p class="rl-note__src"><span class="rl-i rl-i--book" aria-hidden="true"></span>userRegistrationDetails resource</p>
</article>
<article class="rl-note">
<span class="rl-note__ic"><span class="rl-i rl-i--phone" aria-hidden="true"></span></span>
<h3 id="a-passkey-on-a-phone-is-not-a-security-key">A passkey on a phone is not a security key</h3>
<p>A passkey in Microsoft Authenticator or Windows Hello is tied to a phone or a PC. Microsoft recommends a passkey (FIDO2) or certificate-based authentication for these accounts, separate from your normal admin methods.</p>
<p class="rl-note__src"><span class="rl-i rl-i--book" aria-hidden="true"></span>Manage emergency access admin accounts (the recommendation)</p>
</article>
<article class="rl-note">
<span class="rl-note__ic"><span class="rl-i rl-i--cert" aria-hidden="true"></span></span>
<h3 id="certificate-only-accounts-can-show-applies">Certificate-only accounts can show APPLIES</h3>
<p>The Graph resource page does not say whether certificate-based authentication appears in <code>methodsRegistered</code>. The portal report does list Certificate-based authentication among Methods registered. Check the certificate mapping before you change anything.</p>
<p class="rl-note__src"><span class="rl-i rl-i--book" aria-hidden="true"></span>userRegistrationDetails resource; Authentication methods activity</p>
</article>
<article class="rl-note">
<span class="rl-note__ic"><span class="rl-i rl-i--shield" aria-hidden="true"></span></span>
<h3 id="the-conditional-access-exclusion-still-has-a-job">The Conditional Access exclusion still has a job</h3>
<p>It no longer skips the platform's mandatory MFA, but it still keeps these accounts out of policies that block or restrict sign-in. A stricter policy that still targets them, such as one requiring phishing-resistant MFA, stays enforced. Report-only policies need no exclusion.</p>
<p class="rl-note__src"><span class="rl-i rl-i--book" aria-hidden="true"></span>Mandatory MFA; Manage emergency access admin accounts</p>
</article>
</div>

## Steps in order

<div class="rl-steps" markdown="1">

1. **List your emergency access accounts.** Microsoft recommends "two or more", cloud-only accounts on the \*.onmicrosoft.com domain, not federated or synchronised, in a dedicated group (for example EmergencyAccess). Run the check above against each of them.
2. **Register strong MFA for every account with APPLIES.** Microsoft: "We recommend that you update these accounts to use passkey (FIDO2) or configure certificate-based authentication for MFA. Both methods satisfy the MFA requirement." Microsoft marks passkey (FIDO2) as recommended and certificate-based authentication for organisations that already run a PKI. Use a method that differs from your other admin accounts, and keep the keys for different accounts in separate safe places.
3. **Make sure the method is allowed.** The report shows an account as MFA capable only when its method is allowed by the Authentication methods policy, so check that the Passkey (FIDO2) method, including any key restrictions, covers these accounts.
4. **Keep the Conditional Access exclusion where it belongs.** Exclude emergency access accounts from policies that block or restrict sign-in ([control CA01](../controls/conditional-access/ca01-create-two-emergency-access-accounts-exclude-them-from.md)). The exclusion no longer skips the platform's mandatory MFA, so it is not a substitute for step 2. Report-only policies do not block access and need no exclusion. A stricter policy that still targets these accounts, such as one requiring phishing-resistant MFA, stays enforced, so check which policies include them.
5. **Alert on every use.** Microsoft: "Configure alerts for every use of an emergency access account."
6. **Test a sign-in at least every 90 days.** Microsoft: "Validate account functionality at least every 90 days." Run the check again: every account should show NOT FOUND, or a confirmed certificate mapping.

</div>

<div class="rl-proof">
<span class="rl-i rl-i--file" aria-hidden="true"></span>
<div>
<p class="rl-proof__t">For the change ticket</p>
<p>Keep <code>break-glass-mfa-check.csv</code> from before and after the change (rename the first file, the script writes the same name each time). It has the account, the answer, the registered methods, the time the report was updated and the reason. Wait for the report to catch up (up to 36 hours) before the second run.</p>
</div>
</div>

## What changes and when

<ol class="rl-phase">
<li><span class="rl-phase__d">October 2024</span><span class="rl-phase__k">Phase 1</span>Sign-in to the Azure portal, Microsoft Entra admin center and Microsoft Intune admin center, for any create, read, update or delete operation.</li>
<li><span class="rl-phase__d">February 2025</span><span class="rl-phase__k">Phase 1, rolled out gradually</span>Sign-in to the Microsoft&nbsp;365 admin center (admin.cloud.microsoft, admin.microsoft.com, portal.office.com/adminportal).</li>
<li><span class="rl-phase__d">1 October 2025</span><span class="rl-phase__k">Phase 2, rolled out gradually</span>Azure CLI, Azure PowerShell, Azure mobile app, IaC tools, Azure SDK and REST API endpoints, for create, update and delete operations; "Read operations won't require MFA".</li>
<li class="is-end"><span class="rl-phase__d">1 July 2026</span><span class="rl-phase__k">Postponements ended</span>Phase 1 could be postponed "until September 30, 2025" and Phase 2 "until July 1st, 2026". Both dates have passed.</li>
</ol>

Microsoft's page says "There's no way to opt out." After Phase 2 enforcement, a Global Administrator can ask Microsoft Support to lift it temporarily. Enforcement applies to the public Azure cloud, not, currently, Azure for US Government or other sovereign clouds.

## Who is in scope

<div class="rl-duo">
<div class="is-in">
<h3 id="in-scope"><span class="rl-i rl-i--ok" aria-hidden="true"></span>In scope</h3>
<ul>
<li><span class="rl-i rl-i--ok" aria-hidden="true"></span><span><strong>Every user account that signs in to those portals and tools</strong>, including break-glass accounts. Microsoft: "Break glass or emergency access accounts are also required to sign in with MFA once enforcement begins."</span></li>
<li><span class="rl-i rl-i--ok" aria-hidden="true"></span><span><strong>Accounts excluded in Conditional Access.</strong> If you relied on an exclusion: "If you configured exceptions or exclusions in the policy, they no longer apply."</span></li>
<li><span class="rl-i rl-i--ok" aria-hidden="true"></span><span><strong>User accounts used as service accounts</strong> for scripts and automation: "those user identities need to sign in with MFA once enforcement begins." Move that automation to a workload identity.</span></li>
</ul>
</div>
<div class="is-out">
<h3 id="not-in-scope"><span class="rl-i rl-i--no" aria-hidden="true"></span>Not in scope</h3>
<ul>
<li><span class="rl-i rl-i--no" aria-hidden="true"></span><span>"Workload identities, such as managed identities and service principals, aren't impacted by either phase of this MFA enforcement."</span></li>
<li><span class="rl-i rl-i--no" aria-hidden="true"></span><span>Azure for US Government and other sovereign clouds, currently.</span></li>
</ul>
</div>
</div>

<div class="rl-duo" markdown="1">
<div class="is-impact" markdown="1">

## Impact

Registering a passkey on a break-glass account changes nothing for other users. Until an account has a working MFA method, it cannot be used in the admin centers listed above, which is the moment you would need it most.

</div>
<div class="is-back" markdown="1">

## Rollback

Nothing to roll back for the check. If a newly registered key is lost or fails, sign in with the second emergency account, remove the method from the first account and register a new one. Do not remove the old method from both accounts at the same time.

</div>
</div>

## Related

- [Entra Conditional Access baseline: five policies, Report-only first](entra-conditional-access-baseline-report-only.md)
- [Entra PIM implementation checklist: fewer than five Global Admins](entra-privileged-access-pim-global-admins.md)
- [Entra SMS and voice MFA retires on 1 February 2027](entra-sms-voice-mfa-retirement-passkeys.md)
- [All Microsoft&nbsp;365 security deadlines](deadlines.md)
- The free [M365 Hardening Kit Top 10](../kits/m365-hardening.md) with more read-only checks and a Jira import

## Sources

- Microsoft Learn: [Mandatory multifactor authentication for Azure and admin portals](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-mandatory-multifactor-authentication), last updated 3 April 2026, read 19 November 2026.
- Microsoft Learn: [Manage emergency access admin accounts](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access), last updated 5 June 2026, read 19 November 2026.
- Microsoft Learn: [List userRegistrationDetails](https://learn.microsoft.com/en-us/graph/api/authenticationmethodsroot-list-userregistrationdetails?view=graph-rest-1.0) and [userRegistrationDetails resource](https://learn.microsoft.com/en-us/graph/api/resources/userregistrationdetails?view=graph-rest-1.0), read 17 and 18 November 2026 (by the check's author).
- Microsoft Learn: [Authentication methods activity](https://learn.microsoft.com/en-us/entra/identity/authentication/howto-authentication-methods-activity), last updated 17 November 2026, read 25 November 2026.

Runbook Lab is independent and not affiliated with Microsoft.
