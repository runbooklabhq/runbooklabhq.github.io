---
title: "Exchange Online Protection: Preset Policies, No External Forwarding, DMARC to p=reject"
description: "Five Exchange Online protection steps Microsoft recommends: Standard and Strict preset security policies, automatic external forwarding off, SPF and DKIM for every sending domain, DMARC from p=none to p=reject, and the common attachments filter with zero-hour auto purge. Read-only PowerShell checks for each step."
rl_type: guide
rl_updated: "30 October 2026"
---

# Exchange Online protection: preset policies, no external forwarding, DMARC to p=reject

<p class="rl-updated">Last reviewed 30 October 2026 · facts re-read on Microsoft Learn 28 October 2026</p>

<p class="rl-lead">Most Exchange Online tenants still run the default policies they were created with, a forward to a personal mailbox nobody remembers, and a DMARC record stuck at p=none. Five steps that get mail protection to Microsoft's recommended settings without losing good mail. Every check on this page only reads.</p>

[Get the free Exchange Online Protection Top 5 kit](https://runbooklab.gumroad.com/l/exchange-online-protection-top5?utm_source=site&utm_campaign=guide-exchange-online-protection){ .md-button .md-button--primary }
[All Microsoft 365 security deadlines](deadlines.md){ .md-button }

## Before you start

| Check | Why |
|---|---|
| Exchange Online PowerShell (`Connect-ExchangeOnline`) with a read role | All checks use Get-* cmdlets and change nothing. |
| A list of every service that sends mail as your domains | CRM, marketing, ticketing, scanners. DMARC breaks the ones nobody listed. |
| Defender for Office 365 Plan 1 or 2? | Business Premium and E5 include it. Without it, step 1 still applies the EOP parts. |

## The five steps

### 1. Turn on the Standard preset for everyone, Strict for priority accounts

Preset security policies apply Microsoft's recommended anti-spam, anti-malware and anti-phishing settings, and with Defender for Office 365 also Safe Links, Safe Attachments and impersonation protection. They are assigned to nobody until you turn them on, and they win over custom policies for the same recipients.

Path: Defender portal > Email & collaboration > Policies & rules > Threat policies > Preset security policies.

```powershell
Get-EOPProtectionPolicyRule | Select-Object Name, State
Get-ATPProtectionPolicyRule -ErrorAction SilentlyContinue | Select-Object Name, State
```

No output means the presets were never turned on.

Control page: [EX01 Standard and Strict preset policies](../controls/exchange-online-protection/ex01-turn-on-the-standard-preset-security-policy-for-all-users.md)

### 2. Stop automatic forwarding to outside addresses

An attacker who takes over a mailbox adds a forward and reads the mail for months. Microsoft recommends Automatic forwarding Off in the outbound spam policy and advises setting On or Off explicitly, because the default Automatic behaves differently from tenant to tenant. Approved business forwards get their own outbound policy, scoped to those senders.

```powershell
Get-HostedOutboundSpamFilterPolicy | Select-Object Name, AutoForwardingMode
Get-Mailbox -ResultSize Unlimited |
  Where-Object { $_.ForwardingSmtpAddress -or $_.ForwardingAddress } |
  Select-Object UserPrincipalName, ForwardingSmtpAddress
```

Tell the helpdesk about the NDR users will see: 5.7.520 Access denied, Your organization does not allow external forwarding.

Control page: [EX02 Block automatic external forwarding](../controls/exchange-online-protection/ex02-block-automatic-forwarding-to-external-addresses-and.md)

### 3. SPF and DKIM for every domain that sends

One SPF TXT record per sending domain ending in `-all`, under 10 DNS lookups; domains that never send get `v=spf1 -all`. For DKIM, publish the two selector CNAME records from Get-DkimSigningConfig, then turn on signing in the Defender portal. Rotate 1024-bit keys to 2048.

```powershell
Get-DkimSigningConfig | Select-Object Name, Enabled, Selector1KeySize
foreach ($d in (Get-AcceptedDomain).DomainName) {
  (Resolve-DnsName -Type TXT -Name $d -ErrorAction SilentlyContinue |
    Where-Object { $_.Strings -match '^v=spf1' }).Strings -join ' '
}
```

Control page: [EX03 SPF and DKIM](../controls/exchange-online-protection/ex03-publish-spf-and-turn-on-dkim-signing-for-every-domain.md)

### 4. DMARC from p=none to p=reject

Microsoft's goal for every custom domain and subdomain is `p=reject`, reached step by step. Publish `v=DMARC1; p=none; rua=mailto:<reports address>`, read the aggregate reports for 2 to 4 weeks, fix every legitimate sender that fails both SPF and DKIM alignment, then move to `p=quarantine` and on to `p=reject`. Subdomains first, the parent domain last. Domains that never send get `p=reject` straight away.

```powershell
foreach ($d in (Get-AcceptedDomain).DomainName) {
  $t = (Resolve-DnsName -Type TXT -Name "_dmarc.$d" -ErrorAction SilentlyContinue).Strings -join ' '
  "DMARC $d : $t"
}
```

Control page: [EX04 DMARC to p=reject](../controls/exchange-online-protection/ex04-publish-dmarc-for-every-domain-and-move-it-from-p-none-to.md)

### 5. Common attachments filter, zero-hour auto purge, admin-only quarantine

Microsoft's Standard and Strict values turn on the common attachments filter with Reject with NDR, zero-hour auto purge (ZAP) to pull malware out of mailboxes after delivery, and the AdminOnlyAccessPolicy quarantine policy so users can't release malware.

```powershell
Get-MalwareFilterPolicy |
  Select-Object Name, EnableFileFilter, FileTypeAction, ZapEnabled, QuarantineTag
```

Control page: [EX05 Anti-malware settings](../controls/exchange-online-protection/ex05-anti-malware-common-attachments-filter-on-with-reject.md)

## What each step can break

| Step | Who notices | Way back |
|---|---|---|
| 1 Preset policies | A few bulk senders move to Junk in the first week | Exclude a user from the preset, or turn it off |
| 2 No external forwarding | Users forwarding to personal or partner mailboxes get an NDR | A scoped outbound policy with forwarding On |
| 3 SPF and DKIM | Nobody, if every sending service is listed | Edit the DNS record |
| 4 DMARC | Mail from a service that fails both SPF and DKIM alignment | Back to p=none or a lower pct |
| 5 Attachments | Senders of blocked file types get an NDR | Remove a file type from the list |

## Deadline that touches mail

- **SMTP AUTH Basic authentication** is turned off by default for existing tenants at the end of December 2026. See [the SMTP AUTH guide](exchange-online-smtp-auth-basic-auth-checklist.md) and [all deadlines](deadlines.md).

## The kit for steps 1–5

The free **Exchange Online Protection Kit: Top 5** turns this page into a project: the five controls with why, steps, impact and rollback, a Jira import, an Excel project plan and a read-only PowerShell script that runs all the checks above. The [Complete kit](../kits/exchange-online-protection.md) adds 15 more controls: inbound and outbound spam values, anti-phishing and impersonation protection, Safe Attachments and Safe Links, quarantine policies, user-reported messages, allow-list hygiene, the external sender tag, mail flow rules that bypass filtering, SMTP AUTH, priority accounts and a monthly review.

[Download the free Top 5](https://runbooklab.gumroad.com/l/exchange-online-protection-top5?utm_source=site&utm_campaign=guide-exchange-online-protection){ .md-button .md-button--primary }
[See the kit](../kits/exchange-online-protection.md){ .md-button }

## FAQ

### Do preset security policies override my custom policies?

Yes, for the same recipients. Standard and Strict preset policies take precedence over custom anti-spam, anti-malware and anti-phishing policies, and Strict wins over Standard for users in both. Retire the custom policies or exclude those users from the preset on purpose.

### What should AutoForwardingMode be set to?

Off in the outbound spam policy for most users. Microsoft recommends setting On or Off explicitly instead of the default Automatic, and using a separate outbound policy for the few senders who need external forwarding.

### How long should DMARC stay at p=none?

Long enough to read 2 to 4 weeks of aggregate reports and fix every legitimate sender that fails both SPF and DKIM alignment. Then move to p=quarantine, optionally in pct steps, and on to p=reject.

### Which licence do I need?

The EOP parts (presets, forwarding, SPF, DKIM, DMARC, anti-malware) work with any Exchange Online plan. Safe Links, Safe Attachments and impersonation protection in the presets need Defender for Office 365 Plan 1 or 2.

## Sources

- Microsoft Learn: Preset security policies in EOP and Microsoft Defender for Office 365
- Microsoft Learn: Recommended settings for EOP and Microsoft Defender for Office 365 security
- Microsoft Learn: Control automatic external email forwarding
- Microsoft Learn: Set up SPF / Set up DKIM / Set up DMARC
