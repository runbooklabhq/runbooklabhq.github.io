---
title: "Entra Conditional Access Baseline: Five Policies, Report-only First"
description: "Roll out a Microsoft Entra Conditional Access baseline without locking anyone out: emergency access accounts, Report-only for 7 days, MFA for all users with an authentication strength, legacy authentication blocked and phishing-resistant MFA for admins. Read-only Graph PowerShell checks for each step."
rl_type: guide
rl_updated: "30 October 2026"
---

# Entra Conditional Access baseline: five policies, Report-only first

<p class="rl-updated">Last reviewed 30 October 2026 · facts re-read on Microsoft Learn 28 October 2026</p>

<p class="rl-lead">Most Conditional Access lockouts come from a policy that went straight to On. Five steps that give you a baseline Microsoft recommends, in an order that keeps two ways back in: emergency access accounts and Report-only mode. Every check on this page only reads.</p>

[Get the free Conditional Access Top 5 kit](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=guide-entra-conditional-access-baseline){ .md-button .md-button--primary }
[All Microsoft 365 security deadlines](deadlines.md){ .md-button }

## Before you start

| Check | Why |
|---|---|
| Microsoft Entra ID P1 (Business Premium, E3 or E5) | Conditional Access and authentication strengths need P1. Risk-based policies need P2. |
| Security defaults are off, or you know you will turn them off | Security defaults and Conditional Access policies don't run together. Switch only when the replacement policies are ready. |
| Microsoft Graph PowerShell with `Policy.Read.All` | All checks below use `Get-MgIdentityConditionalAccessPolicy` and change nothing. |

```powershell
Connect-MgGraph -Scopes "Policy.Read.All","AuditLog.Read.All","UserAuthenticationMethod.Read.All"
```

## The five steps

### 1. Two emergency access accounts, excluded everywhere

Two cloud-only accounts on the `*.onmicrosoft.com` domain, Global Administrator, a passkey (FIDO2) or certificate-based authentication each, kept in two separate places. Put both in one group and exclude that group from every policy that blocks or restricts access. Send their sign-ins to Log Analytics and alert on every one.

Read-only check: which active policies have no exclusion at all?

```powershell
$p = Get-MgIdentityConditionalAccessPolicy -All
$p | Where-Object { $_.State -ne 'disabled' -and
    -not $_.Conditions.Users.ExcludeUsers -and
    -not $_.Conditions.Users.ExcludeGroups } |
  Select-Object DisplayName, State
```

Control page: [CA01 Emergency access accounts](../controls/conditional-access/ca01-create-two-emergency-access-accounts-exclude-them-from.md)

### 2. A naming convention and Report-only for 7 days

Name policies by number, persona, app and control, for example `CA001-AllUsers-AllApps-RequireMFA`. The team rule: every new or edited policy runs in Report-only for at least 7 days, then goes On after a look at the sign-in logs. Use What If for one test user before the switch.

```powershell
Get-MgIdentityConditionalAccessPolicy -All |
  Sort-Object DisplayName |
  Select-Object DisplayName, State, ModifiedDateTime
```

Report-only shows as `enabledForReportingButNotEnforced`. Report-only exists for a reason.

Control page: [CA02 Naming and Report-only](../controls/conditional-access/ca02-name-policies-by-persona-and-create-every-new-policy-in.md)

### 3. MFA for all users on all resources, with an authentication strength

One policy: All users (exclude the emergency group and, in hybrid tenants, the Directory Synchronization Accounts role), All resources with no app exclusions, Grant = Require authentication strength > Multifactor authentication. Report-only first.

The authentication strength, instead of the older "Require multifactor authentication" tick box, lets you raise the bar to phishing-resistant later without rebuilding the policy.

Control page: [CA03 MFA for all users](../controls/conditional-access/ca03-require-mfa-for-all-users-on-all-resources-with-an.md)

### 4. Block legacy authentication

All users, All resources, Conditions > Client apps > Exchange ActiveSync clients and Other clients, Grant = Block access. Before you enforce, see who still signs in that way:

```powershell
$since = (Get-Date).ToUniversalTime().AddDays(-7).ToString('yyyy-MM-ddTHH:mm:ssZ')
Get-MgAuditLogSignIn -Filter "createdDateTime ge $since" -All |
  Group-Object ClientAppUsed | Select-Object Count, Name
```

The scanner in accounts will be the first to notice. Give each remaining app an owner and a move date, not a permanent exclusion.

Control page: [CA04 Block legacy authentication](../controls/conditional-access/ca04-block-legacy-authentication-for-all-users.md)

### 5. Phishing-resistant MFA for administrators

Target the admin directory roles (Microsoft lists at least 14, including Global, Security, Exchange, SharePoint, User, Helpdesk and Conditional Access Administrator) with the built-in Phishing-resistant MFA strength. Check first that every admin has a passkey or Windows Hello for Business; a Temporary Access Pass gets them there.

```powershell
Get-MgReportAuthenticationMethodUserRegistrationDetail -All |
  Where-Object { $_.IsAdmin } |
  Select-Object UserPrincipalName, MethodsRegistered
```

Control page: [CA05 Phishing-resistant MFA for admins](../controls/conditional-access/ca05-require-phishing-resistant-mfa-for-administrators.md)

## What each step can break

| Step | Who notices | Way back |
|---|---|---|
| 1 Emergency accounts | Nobody | Not needed |
| 2 Naming, Report-only | Nobody | Not needed |
| 3 MFA for all | Users without a registered method get a registration prompt | Set the policy to Report-only |
| 4 Legacy auth block | Old mail clients, scanners and scripts using basic credentials | Report-only, or a temporary exclusion for one account |
| 5 Admins phishing-resistant | Admins with only SMS, voice or push | Report-only, or a Temporary Access Pass |

## Deadlines that touch this baseline

- **SMS and voice MFA:** Microsoft-provided SMS and voice MFA retires on 1 February 2027 (Global Administrators and external users: 1 July 2027). Source: MC1519855. See [the SMS and voice MFA guide](entra-sms-voice-mfa-retirement-passkeys.md).
- **Self-service password reset:** from 7–9 November 2026 SSPR only accepts methods a user registered. Source: MC1325414. See [the brief](../news/posts/2026-10-29-entra-sspr-registered-methods-only.md).

## The kit for steps 1–5

The free **Entra Conditional Access Baseline Kit: Top 5** turns this page into a project: the five controls with why, steps, impact and rollback, a Jira import, an Excel project plan and a read-only PowerShell script that runs all the checks above. The paid Complete kit adds 15 more controls (passkey profiles, Temporary Access Pass, device code flow, sign-in and user risk, token protection, guests, a quarterly exclusion review and a JSON backup of every policy).

[Download the free Top 5](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=guide-entra-conditional-access-baseline){ .md-button .md-button--primary }
[See the kit](../kits/conditional-access.md){ .md-button }

## FAQ

### Should a new Conditional Access policy go straight to On?

No. Create it in Report-only, leave it at least 7 days so it is evaluated on real sign-ins, review the results in the sign-in logs or the insights and reporting workbook, then switch it to On. Report-only logs what the policy would have done and enforces nothing.

### How many emergency access accounts do I need?

Microsoft recommends at least two cloud-only emergency access accounts, excluded from policies that block or restrict access, protected with a passkey (FIDO2) or certificate-based authentication, and monitored so every sign-in raises an alert.

### Is "Require multifactor authentication" the same as an authentication strength?

Both ask for MFA. The built-in "Multifactor authentication" authentication strength can later be swapped for passwordless or phishing-resistant strength in the same policy, so the policy doesn't need to be rebuilt when you raise the bar.

### How do I find who still uses legacy authentication?

Group the last 7 days of sign-in logs by client app (Get-MgAuditLogSignIn, property ClientAppUsed) and look for Exchange ActiveSync and other legacy clients. A legacy-auth block policy in Report-only shows the same accounts before anything is blocked.

### Which licence do I need for Conditional Access?

Microsoft Entra ID P1, included in Microsoft 365 Business Premium, E3 and E5. Policies based on sign-in risk or user risk need Entra ID P2 (included in E5).

## Sources

- Microsoft Learn: Manage emergency access accounts in Microsoft Entra ID
- Microsoft Learn: Conditional Access report-only mode
- Microsoft Learn: Require MFA for all users with an authentication strength
- Microsoft Learn: Block legacy authentication with Conditional Access
- Microsoft Learn: Require phishing-resistant MFA for administrators
- Microsoft Learn: Conditional Access authentication strengths
