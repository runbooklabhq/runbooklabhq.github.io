---
title: Guides
description: Step-by-step Microsoft 365 security guides with read-only PowerShell checks, for the changes and deadlines admins are dealing with now.
rl_type: guides
---

# Guides

<p class="rl-lead">Step-by-step guides for the changes admins are dealing with now. Each one starts with checks that only read.</p>

| Guide | When it matters |
|---|---|
| [Microsoft 365 security deadlines 2026–2027](deadlines.md) | The next Microsoft&nbsp;365 changes with a date, and the source for each |
| [Microsoft 365 Copilot oversharing: five fixes before rollout](microsoft-365-copilot-oversharing-checklist-jira.md) | Before a Copilot pilot |
| [SMTP AUTH Basic auth ends in December 2026](exchange-online-smtp-auth-basic-auth-checklist.md) | End of December 2026 |
| [Entra SMS and voice MFA retires on 1 February 2027](entra-sms-voice-mfa-retirement-passkeys.md) | 1 February 2027 |
| [Defender ASR rules: from Audit to Block](defender-asr-rules-audit-to-block.md) | Any ASR rollout |
| [Microsoft 365 hardening checklist, ready for Jira](microsoft-365-hardening-checklist-jira.md) | A new tenant or a first review |
