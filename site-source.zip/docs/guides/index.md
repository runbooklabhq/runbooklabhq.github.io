---
title: Guides
description: Step-by-step Microsoft 365 security guides with read-only PowerShell checks, for the changes and deadlines admins are dealing with now.
rl_type: guides
---

# Guides

<p class="rl-lead">Step-by-step guides for the changes admins are dealing with now. Each one starts with checks that only read.</p>

| Guide | When it matters |
|---|---|
| [Microsoft 365 security deadlines 2026–2027](deadlines.md) | The next Microsoft&nbsp;365 changes with a date, and the source for each |
| [Microsoft 365 Copilot oversharing: five fixes before rollout](microsoft-365-copilot-oversharing-checklist-jira.md) | Before a Copilot pilot |
| [SMTP AUTH Basic auth ends in December 2026](exchange-online-smtp-auth-basic-auth-checklist.md) | End of December 2026 |
| [Entra SMS and voice MFA retires on 1 February 2027](entra-sms-voice-mfa-retirement-passkeys.md) | 1 February 2027 |
| [Defender ASR rules: from Audit to Block](defender-asr-rules-audit-to-block.md) | Any ASR rollout |
| [Entra Conditional Access baseline: five policies, Report-only first](entra-conditional-access-baseline-report-only.md) | Before you turn off security defaults, or before the 1 February 2027 SMS and voice MFA retirement |
| [Copilot Studio and Entra agent governance: five controls to start with](copilot-studio-agent-governance-checklist.md) | Before makers publish agents, or when autonomous agents get their own identities |
| [Entra privileged access: fewer than five Global Admins, eligible roles in PIM](entra-privileged-access-pim-global-admins.md) | Any admin role review, or before an audit |
| [Exchange Online protection: preset policies, no external forwarding, DMARC to p=reject](exchange-online-protection-preset-policies-dmarc.md) | A new tenant, a spoofing incident, or before SMTP AUTH Basic auth goes off in December 2026 |
| [Microsoft 365 hardening checklist, ready for Jira](microsoft-365-hardening-checklist-jira.md) | A new tenant or a first review |
