---
title: "SharePoint Oversharing Assessment for Copilot: 5 Fixes"
description: "A SharePoint oversharing assessment before Microsoft 365 Copilot: find overshared sites, use Restricted Content Discovery, fix default links. Read-only checks."
rl_type: guide
rl_updated: "28 October 2026"
---

# SharePoint oversharing assessment for Microsoft 365 Copilot: five fixes before rollout

<p class="rl-updated">Last reviewed 28 October 2026</p>

<p class="rl-lead">Copilot doesn't break permissions. It just finds everything your permissions already allow, very quickly. A salary spreadsheet shared with "Everyone except external users" years ago is now one prompt away. Five steps to deal with that first, in the order Microsoft's own Copilot oversharing blueprint uses.</p>

[Get the free Top 5 kit](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=guide-microsoft-365-copilot-oversharing-checklist-jira){ .md-button .md-button--primary }
[Microsoft 365 hardening checklist](microsoft-365-hardening-checklist-jira.md){ .md-button }

## SharePoint oversharing assessment: the five steps { #the-five-steps }

### 1. Find the overshared sites

SharePoint admin center &gt; Reports &gt; Data access governance: permission state report and the 'Everyone except external users' insights. Add a read-only list of sites that still allow Anyone links:

```powershell
Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
$s = Get-SPOSite -Limit All |
  Where-Object { $_.SharingCapability -eq 'ExternalUserAndGuestSharing' }
"Sites that allow Anyone links: $(@($s).Count)"
$s | Select-Object Url, Title | Export-Csv -NoTypeInformation .\anyone-sites.csv
```

### 2. Hide the worst sites from Copilot while you fix them

Active sites &gt; site &gt; Settings &gt; 'Restrict content from Microsoft Copilot'. Use it on a short list only: every restricted site makes answers less complete. Write a removal date next to each site.

### 3. Make new sharing narrow by default

Policies &gt; Sharing: default link 'Specific people', permission View, and an expiry on Anyone links (or turn them off). This only affects new links.

```powershell
Get-SPOTenant | Select-Object SharingCapability, DefaultSharingLinkType,
  DefaultLinkPermission, RequireAnonymousLinksExpireInDays
```

### 4. Remove 'Everyone except external users' from sensitive sites

Start site access reviews from the EEEU report so owners remove it, then hide the claim in the people picker. Expect a few access tickets.

### 5. Check that Copilot is audited

Before the pilot, not after the first incident:

```powershell
Connect-ExchangeOnline
(Get-AdminAuditLogConfig).UnifiedAuditLogIngestionEnabled
Search-UnifiedAuditLog -StartDate (Get-Date).AddDays(-7) -EndDate (Get-Date) `
  -RecordType CopilotInteraction -ResultSize 100
```

## What it won't do

### Not a permissions fix

Restricted Content Discovery hides content from Copilot and organisation-wide search. People with access can still open the files.

### Not instant

Large sites can take over a week to reflect the restriction. Data access governance reports can take hours.

### Preview features

DLP that blocks sensitive data in Copilot prompts was still in preview on 5 October 2026. Labelled-file blocking is the safer start.

## Get the kit

### Copilot Readiness Top 5

The five steps as a guide with impact and rollback per control, a Jira import, a tracker CSV, an Excel project plan and read-only PowerShell checks.

[Download free](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=guide-microsoft-365-copilot-oversharing-checklist-jira){ .md-button .md-button--primary }
[See all 24 controls](../kits/copilot-readiness.md){ .md-button }

### Whole tenant first?

The M365 Hardening Kit covers identity, email, Teams, SharePoint and monitoring in 58 controls, including Copilot oversharing basics.

[See the Complete kit](https://runbooklab.gumroad.com/l/m365-hardening-kit?utm_source=site&utm_campaign=guide-microsoft-365-copilot-oversharing-checklist-jira){ .md-button }

## FAQ

### Does Microsoft 365 Copilot show users files they can't open?

No. Copilot only uses content the signed-in user already has permission to open. The risk is oversharing: files shared with 'Everyone except external users', company-wide links or broken inheritance that nobody noticed before Copilot made them easy to find.

### What is Restricted Content Discovery?

A SharePoint Advanced Management setting that keeps a site's content out of organisation-wide search and Copilot answers while you fix its permissions. It does not change permissions, works on SharePoint sites only (not OneDrive), and sites with more than 500,000 items can take over a week to reflect the change. Microsoft calls it an interim protection.

### Do I need extra licences for SharePoint Advanced Management?

Microsoft Learn says SharePoint Advanced Management is included with Microsoft Copilot licences. Purview capabilities depend on your plan: foundational features are in Microsoft 365 E3, optimised ones in E5 or E7.

### Can Purview DLP stop Copilot from using sensitive files?

Yes, a DLP policy for the Microsoft 365 Copilot and Copilot Chat location can block processing of files and emails with chosen sensitivity labels. Blocking sensitive information types in prompts was still in preview on Microsoft Learn (5 October 2026).

### Are Copilot prompts audited?

Yes. Copilot interactions are logged in Audit (Standard) under the CopilotInteraction record type, provided auditing is turned on in your tenant. Search them in Microsoft Purview &gt; Audit.
