---
title: "Defender ASR Rules: Audit to Block Rollout Checklist"
description: "Roll out Microsoft Defender attack surface reduction (ASR) rules without breaking line-of-business apps: read-only checks, an Advanced hunting query for audit events, exclusions that stay narrow, and a ring plan from Audit to Warn to Block."
rl_type: guide
rl_updated: "28 October 2026"
---

# Defender ASR rules: from Audit to Block without breaking things

<p class="rl-updated">Last reviewed 28 October 2026</p>

<p class="rl-lead">Attack surface reduction rules stop Office macros, scripts and credential theft before they run. Turned on in Block mode all at once, they also stop the finance team's macro and the backup agent. Six steps to roll them out in rings, starting with read-only checks.</p>

[Get the free Defender & ASR Top 5 kit](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=guide-defender-asr-rules-audit-to-block){ .md-button .md-button--primary }
[Microsoft 365 hardening checklist](microsoft-365-hardening-checklist-jira.md){ .md-button }

## Before you start

| Check | Why |
|---|---|
| Microsoft Defender Antivirus is the active antivirus with real-time protection on | ASR rules do nothing when another antivirus is primary or Defender runs in passive mode. |
| Devices are onboarded to Defender for Endpoint or Defender for Business | Without onboarding you get no central reporting, so Audit mode tells you nothing. |
| One policy source per device (Intune, Group Policy or Configuration Manager) | Two sources setting the same rule is the most common cause of "the rule is on but nothing happens". |

## The six steps

### 1. Read what is set today

Read-only, on a sample device. Actions: `0` off, `1` Block, `2` Audit, `6` Warn.

```powershell
$p = Get-MpPreference
$i = 0
foreach ($id in $p.AttackSurfaceReductionRules_Ids) {
  [pscustomobject]@{ Rule = $id
    Action = $p.AttackSurfaceReductionRules_Actions[$i] }
  $i++ }
```

### 2. Put every rule in Audit

Intune &gt; Endpoint security &gt; Attack surface reduction &gt; create an ASR rules policy, all rules on **Audit**, assigned to all devices. Leave it for two to four weeks so month-end jobs show up too.

### 3. Find the noisy rules

Defender portal &gt; Advanced hunting (Plan 2 / E5). On Business Premium use Reports &gt; Attack surface reduction rules instead.

```kusto
DeviceEvents
| where Timestamp > ago(30d)
| where ActionType startswith "Asr"
| summarize Events = count(), Devices = dcount(DeviceId)
    by ActionType, FileName, InitiatingProcessFileName
| order by Events desc
```

### 4. Add narrow exclusions

One exclusion per legitimate tool, as a full file path, per rule where you can. No folder-wide or wildcard exclusions, and never exclude a whole user profile. Give every exclusion an owner and a review date in your tracker.

### 5. Move to Warn, then Block, in rings

Ring 0: IT devices. Ring 1: a pilot group of 5–10% of users. Ring 2: everyone. Warn lets a user unblock once, so it shows you what still breaks; a few rules don't support Warn, so check Microsoft's rule reference.

### 6. Keep watching

Re-run the step 3 query weekly. A rule that suddenly fires hundreds of times a day is either a new tool that needs an exclusion or an attack. Both need an owner.

## Which rules go first

| Rule | GUID | Suggested ring to Block |
|---|---|---|
| Block credential stealing from LSASS | `9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2` | Standard protection |
| Block abuse of exploited vulnerable signed drivers | `56a863a9-875e-4185-98a7-b882c64b5ce5` | Standard protection |
| Block persistence through WMI event subscription | `e6db77e5-3df2-4cf1-b95a-636979351e5b` | Standard protection |
| Block executable content from email client and webmail | `be9ba2d9-53ea-4cdc-84e5-9b1eeee46550` | Ring 2 |
| Block all Office applications from creating child processes | `d4f940ab-401b-4efc-aadc-ad5f3c50688a` | Ring 2 (macro-heavy teams last) |
| Block Office applications from creating executable content | `3b576869-a4ec-4529-8536-b80a7769e899` | Ring 2 |
| Block execution of potentially obfuscated scripts | `5beb7efe-fd9a-4556-801d-275e5ffc04cc` | Ring 3 (admin scripts) |
| Block process creations from PSExec and WMI commands | `d1e49aac-8f56-4280-b9ba-993a6d77406c` | Ring 3 (breaks some management tools) |

The first three are Microsoft's "standard protection" rules, with minimal compatibility impact. Audit them anyway. Full list and the rules that don't support Warn: Microsoft Learn, "Attack surface reduction rules reference".

## The kit for steps 1–6

The free **Defender for Endpoint and ASR Kit: Top 5** turns the first part of this page into a project: onboarding and sensor health, Defender Antivirus in active mode with cloud protection, tamper protection, all ASR rules in Audit with the three standard protection rules in Block, and network protection. Guide with impact and rollback per control, Jira import, tracker, Excel plan and read-only device checks.

[Download the free Top 5](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=guide-defender-asr-rules-audit-to-block){ .md-button .md-button--primary }

## ASR covers the endpoints. Now the tenant.

ASR rules protect Windows devices. Most Microsoft 365 incidents still start in the tenant: no MFA, legacy authentication left on, external forwarding, a missing break-glass account. The free Microsoft 365 Emergency Top 10 turns those ten controls into a Jira import, a tracker CSV and read-only PowerShell checks.

[Download the free Top 10](https://runbooklab.gumroad.com/l/m365-hardening-top10?utm_source=site&utm_campaign=guide-defender-asr-rules-audit-to-block){ .md-button .md-button--primary }
[See all 10 controls](microsoft-365-hardening-checklist-jira.md){ .md-button }

Need the whole tenant? The [M365 Hardening Kit: Complete](https://runbooklab.gumroad.com/l/m365-hardening-kit?utm_source=site&utm_campaign=guide-defender-asr-rules-audit-to-block) has 58 controls in 5 sprints and 48 read-only checks · €39.

## FAQ

### Should I turn on attack surface reduction rules in Block mode straight away?

No. Start every rule in Audit mode for two to four weeks, review what would have been blocked, add narrow exclusions for legitimate tools, then move rules to Warn or Block in rings: IT devices first, then a pilot group, then everyone.

### How do I see which ASR rules are active on a Windows device?

Run Get-MpPreference in PowerShell and read AttackSurfaceReductionRules_Ids and AttackSurfaceReductionRules_Actions. The action values are 0 = off, 1 = Block, 2 = Audit, 6 = Warn. This only reads settings and changes nothing.

### How do I find ASR audit events in Microsoft Defender?

In Advanced hunting, query DeviceEvents where ActionType starts with Asr. Events ending in Audited are what the rule would have blocked; events ending in Blocked were stopped. Group by rule, file and initiating process to find the noisy ones.

### Which ASR rules are safest to block first?

Microsoft lists three standard protection rules with minimal compatibility impact: Block credential stealing from the Windows local security authority subsystem (LSASS), Block abuse of exploited vulnerable signed drivers, and Block persistence through WMI event subscription. Still audit them first in your own environment.
