---
title: "SMTP AUTH Basic Auth Ends December 2026: Exchange Online Checklist"
description: "Exchange Online turns off SMTP AUTH Basic authentication by default at the end of December 2026. Six-step checklist with read-only PowerShell to find every printer, scanner and app that will stop sending mail."
rl_type: guide
rl_updated: "27 October 2026"
---

# SMTP AUTH Basic auth ends in December 2026: the Exchange Online checklist

<p class="rl-updated">Last reviewed 27 October 2026</p>

<p class="rl-lead">At the end of December 2026 Exchange Online disables Basic authentication for SMTP AUTH by default in existing tenants. Every printer, scanner and app that sends mail with a username and password stops sending. Six steps to find them and fix them first, starting with read-only checks.</p>

[Get the free tracker + checks](https://runbooklab.gumroad.com/l/m365-hardening-top10?utm_source=site&utm_campaign=guide-exchange-online-smtp-auth-basic-auth-checklist){ .md-button .md-button--primary }
[View on GitHub](https://github.com/runbooklabhq/m365-hardening-kit-free){ .md-button }

## Timeline

| When | What changes |
|---|---|
| Now to December 2026 | No change. Basic auth for SMTP AUTH works as before. |
| End of December 2026 | Existing tenants: off by default, admins can turn it back on. New tenants: not available, OAuth only. |
| Second half of 2027 | Microsoft announces the final removal date. |

Source: Microsoft Exchange Team, "Updated Exchange Online SMTP AUTH Basic Authentication Deprecation Timeline" (January 2026), message center MC786329.

## The six steps

### 1. Check the tenant-wide setting

Read-only. `True` means SMTP AUTH is already off for the whole organisation.

```powershell
Get-TransportConfig |
  Select-Object SmtpClientAuthenticationDisabled
```

### 2. Find mailboxes that override it

Read-only. `False` on a mailbox switches SMTP AUTH on for that mailbox even when the tenant has it off. Blank means it follows the tenant.

```powershell
Get-CASMailbox -ResultSize Unlimited |
  Where-Object { $_.SmtpClientAuthenticationDisabled -eq $false } |
  Select-Object PrimarySmtpAddress, SmtpClientAuthenticationDisabled
```

### 3. List every sender still on Basic auth

Exchange admin center &gt; Reports &gt; Mail flow &gt; **SMTP AUTH clients report**. Request the detailed report: `TlsAuthLogin` = Basic auth, `XOAUTH2` = modern auth. Put each Basic-auth sender in a tracker row with an owner.

### 4. Pick a fix per sender

**App supports OAuth** → switch it to OAuth (XOAUTH2). **Printer or scanner** → firmware with OAuth, or an SMTP relay connector (port 25, your public IP or a certificate). **Internal bulk or alert mail** → consider High Volume Email or a relay connector. **Old PowerShell script** → Microsoft Graph sendMail with an app registration.

### 5. Test before the switch

Turn SMTP AUTH off for one pilot mailbox, send a test from each fixed device, and keep the result in the tracker. Only then plan the tenant-wide change.

### 6. Close the per-mailbox exceptions

When the report shows no more Basic-auth rows for a mailbox, remove its override from step 2. Re-run the report weekly until the end of December.

## Track it like a project

The SMTP AUTH clean-up is control M01 in the [M365 Hardening Kit](../kits/m365-hardening.md) and control EX18 in the [Exchange Online Protection Kit](../kits/exchange-online-protection.md): steps, a Jira import, an Excel project plan and a read-only check, so the work has owners and a "done" test.

Starting from zero? The free Microsoft 365 Emergency Top 10 has the ten controls to do first, including blocking legacy authentication (E03), break-glass accounts and external forwarding.

[Download the free Top 10](https://runbooklab.gumroad.com/l/m365-hardening-top10?utm_source=site&utm_campaign=guide-exchange-online-smtp-auth-basic-auth-checklist){ .md-button .md-button--primary }
[Exchange Online Protection Kit](../kits/exchange-online-protection.md){ .md-button }

## FAQ

### When is SMTP AUTH Basic auth switched off in Exchange Online?

Per Microsoft's January 2026 timeline update (message MC786329), Basic authentication for SMTP AUTH client submission is disabled by default for existing tenants at the end of December 2026. Admins can still turn it back on for now; Microsoft says it will announce the final removal date in the second half of 2027.

### What breaks when Basic auth for SMTP AUTH is turned off?

Anything that signs in to smtp.office365.com on port 587 with a username and password: multifunction printers and scanners that scan to email, line-of-business apps, ERP and accounting systems, website contact forms, monitoring and backup alerts, and old scripts using Send-MailMessage.

### How do I find which devices and apps still use Basic auth for SMTP?

In the Exchange admin center open Reports &gt; Mail flow &gt; SMTP AUTH clients report and look at the Authentication protocol column. Request the detailed report for sender addresses: rows with authMethod TlsAuthLogin are Basic auth, XOAUTH2 is modern auth.

### Does this checklist change my tenant?

No. Steps 1 to 3 only read settings and reports. The changes in steps 4 to 6 are yours to make, one sender at a time, after you have a fix for each one.
