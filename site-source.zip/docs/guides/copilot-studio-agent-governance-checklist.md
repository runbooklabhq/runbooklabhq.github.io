---
title: "Copilot Studio and Entra Agent Governance: Five Controls to Start With"
description: "Five controls for AI agents in Microsoft 365: an inventory of Copilot Studio agents and Entra agent identities, user authentication required, HTTP and unused channels blocked, audit of publish and share events, and a Conditional Access policy for high-risk agent identities. Read-only checks for each step."
rl_type: guide
rl_updated: "30 October 2026"
---

# Copilot Studio and Entra agent governance: five controls to start with

<p class="rl-updated">Last reviewed 30 October 2026 · facts re-read on Microsoft Learn 24 and 28 October 2026</p>

<p class="rl-lead">Agents arrive without an admin doing anything: a maker builds one in Copilot Studio over lunch, an autonomous agent gets its own Entra identity. Five controls that show you what exists and close the easiest paths out of the tenant. Every check on this page only reads.</p>

[Get the free AI Agent Hardening Top 5 kit](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=guide-copilot-studio-agent-governance){ .md-button .md-button--primary }
[All Microsoft 365 security deadlines](deadlines.md){ .md-button }

## Before you start

| Check | Why |
|---|---|
| Power Platform administrator, Global Reader or AI reader | Needed for the agent inventory in the Power Platform admin center. |
| Microsoft Graph PowerShell with `AgentIdentity.Read.All` and `Policy.Read.All` | The checks list agent identities and Conditional Access policies. They change nothing. |
| Power Platform admin PowerShell (`Get-DlpPolicy`) | Reads the data policies that decide what agents can connect to. |

## The five steps

### 1. Inventory every agent

Agents show up in two places: Copilot Studio agents in Power Platform environments, and Microsoft Entra agent identities that act with their own permissions. Export the first from Power Platform admin center > Manage > Inventory (Download gives a CSV with owner, environment and created date). List the second with Graph. Give every agent an owner and a purpose; an agent with no owner goes on the review list. Repeat monthly.

```powershell
$u = 'https://graph.microsoft.com/v1.0/servicePrincipals/microsoft.graph.agentIdentity?$select=displayName,accountEnabled,createdDateTime'
(Invoke-MgGraphRequest -Method GET -Uri $u).value |
  ForEach-Object { "$($_.displayName) | enabled: $($_.accountEnabled)" }
```

Control page: [AG01 Inventory every agent](../controls/ai-agent-hardening/ag01-inventory-every-agent-in-the-tenant.md)

### 2. Require user authentication for Copilot Studio agents

An agent published with No authentication answers anyone who reaches its channel, from whatever knowledge and tools the maker connected. In Power Platform admin center > Security > Data and privacy > Data policy, block the connector "Chat without Microsoft Entra ID authentication in Copilot Studio" for your Copilot Studio environments. Makers then can't publish an unauthenticated agent until they pick Authenticate with Microsoft or Authenticate manually.

Microsoft Learn doesn't say whether agents already published without authentication keep working, so test on one environment first and tell makers before you switch it on.

Control page: [AG02 Require user authentication](../controls/ai-agent-hardening/ag02-require-user-authentication-for-copilot-studio-agents.md)

### 3. Block HTTP requests and channels you don't use

The HTTP connector lets an agent call any endpoint, which is the easiest exfiltration path. In the same data policy, block "HTTP" or allow only the endpoints your approved agents use (Configure connector > Connector endpoints). Block the channels nobody uses: Direct Line, Facebook, WhatsApp, Omnichannel and SharePoint channels in Copilot Studio. Keep connectors one agent uses together in the same data group, or the agent is flagged as a violation.

```powershell
$j = Get-DlpPolicy | ConvertTo-Json -Depth 30
"HTTP connector referenced in a data policy: $($j -match '"HTTP"')"
```

Control page: [AG03 Block HTTP and unused channels](../controls/ai-agent-hardening/ag03-block-http-requests-and-channels-you-don-t-use.md)

### 4. Watch publish, share and authentication changes

Copilot Studio logs maker activity to the Microsoft Purview audit log by default. Review these operations every week: BotCreate, BotUpdateOperation-BotPublish, BotUpdateOperation-BotShare, BotUpdateOperation-BotAuthUpdate and BotDelete. If you use Microsoft Sentinel, alert on the share and authentication changes.

```powershell
$ops = 'BotCreate','BotUpdateOperation-BotPublish','BotUpdateOperation-BotShare','BotUpdateOperation-BotAuthUpdate','BotDelete'
Search-UnifiedAuditLog -StartDate (Get-Date).AddDays(-30) -EndDate (Get-Date) -Operations $ops -ResultSize 5000 |
  Group-Object Operations | Select-Object Count, Name
```

Users need an assigned Microsoft 365 licence for their Copilot Studio events to be recorded.

Control page: [AG04 Watch agent changes](../controls/ai-agent-hardening/ag04-watch-agent-creation-publishing-sharing-and.md)

### 5. Block high-risk agent identities with Conditional Access

Autonomous agents sign in with their own agent identity, so your user policies don't cover them. Microsoft provides a policy pattern: Agents > All agent identities, All resources, Conditions > Agent risk (Preview) = High, Grant = Block. Start in Report-only. A policy on agent identities does not cover agent users or agents acting on behalf of a user; those need their own policies.

```powershell
Get-MgIdentityConditionalAccessPolicy -All |
  Where-Object { ($_ | ConvertTo-Json -Depth 10) -match 'agent' } |
  Select-Object DisplayName, State
```

Licence: Microsoft Agent 365 plus Entra ID P2 or Microsoft 365 E5, or Microsoft 365 E7. Agent risk is in preview.

Control page: [AG05 Block high-risk agent identities](../controls/ai-agent-hardening/ag05-block-high-risk-agent-identities-with-conditional-access.md)

## What each step can break

| Step | Who notices | Way back |
|---|---|---|
| 1 Inventory | Nobody | Not needed |
| 2 Authentication required | Makers can't publish unauthenticated agents; users must sign in | Move the connector out of Blocked |
| 3 HTTP and channels blocked | Agents that call a blocked endpoint or use a blocked channel | Allow the endpoint or channel in the data policy |
| 4 Audit review | Nobody | Not needed |
| 5 High-risk agents blocked | A legitimate agent if the risk signal is a false positive | Report-only, or exclude that agent |

## The kit for steps 1–5

The free **M365 AI Agent Hardening Kit: Top 5** turns this page into a project: the five controls with why, steps, impact and rollback, a Jira import, an Excel project plan and a read-only PowerShell script that runs the checks above. The [Complete kit](../kits/ai-agent-hardening.md) adds 15 controls for the full agent lifecycle: maker environments, sharing limits, Copilot credit caps, agent sponsors, access packages that expire, a Conditional Access allowlist, SIEM alerts, a quarterly agent review and an approval workflow. Building on Copilot too? The [Copilot oversharing guide](microsoft-365-copilot-oversharing-checklist-jira.md) covers the SharePoint side.

[Download the free Top 5](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=guide-copilot-studio-agent-governance){ .md-button .md-button--primary }
[See the kit](../kits/ai-agent-hardening.md){ .md-button }

## FAQ

### Where do I find all the agents in my tenant?

Copilot Studio and Agent Builder agents are listed in the Power Platform admin center under Manage > Inventory, with a CSV download. Microsoft Entra agent identities are listed in the Entra admin center under Agent ID, or through the Microsoft Graph agentIdentity endpoint.

### How do I stop makers publishing agents without authentication?

Block the connector "Chat without Microsoft Entra ID authentication in Copilot Studio" in the data policy that covers your Copilot Studio environments. Agents set to No authentication then show an error banner and can't be published until the maker chooses an authentication option.

### Do my user Conditional Access policies apply to agents?

Not to agent identities. Autonomous agents sign in with their own agent identity, so they need policies that target agents, for example the policy that blocks agent identities with high agent risk. Agent users need separate policies again.

### Which Copilot Studio events should I audit?

At least BotCreate, BotUpdateOperation-BotPublish, BotUpdateOperation-BotShare, BotUpdateOperation-BotAuthUpdate and BotDelete in the Microsoft Purview audit log.

## Sources

- Microsoft Learn: Power Platform inventory
- Microsoft Learn: List agentIdentity objects (Microsoft Graph)
- Microsoft Learn: Copilot Studio data policies and the authentication connector example
- Microsoft Learn: View audit logs for Copilot Studio
- Microsoft Learn: Block high-risk agent identities with Conditional Access
