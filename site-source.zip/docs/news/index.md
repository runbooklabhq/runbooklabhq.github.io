---
title: News
description: Changes in Microsoft 365, AI and security that need an admin to act, with the date, the check and the source.
rl_type: news-index
---

# News

<p class="rl-lead">Changes in Microsoft&nbsp;365, AI and security that need an admin to do something. Each brief has the date, who is affected, what to check and the primary source.</p>

Follow along on [X](https://x.com/runbooklab), [Bluesky](https://bsky.app/profile/runbooklab.bsky.social), [LinkedIn](https://www.linkedin.com/company/runbooklab/) or the [RSS feed](../about/follow.md).
