---
date:
  created: 2026-11-20 10:33:00
slug: endpoint-devices-this-week-2026-11-20
categories:
  - Endpoint & devices
description: "Endpoint news to 20 November 2026: Windows settings backup on by default in 26H2, Windows Update certificates expire in 2027, slmgr fix KBs, Ignite updates."
rl_type: news
rl_area: endpoint
rl_service: [windows, intune, defender]
rl_kits: [mde]
rl_controls: []
---

# Endpoint & devices this week: 10 changes (20 November 2026)

Ten confirmed Windows, Intune and Defender items from the week to 20 November 2026, plus two that already have their own briefs. The nearest date is 13 January 2027, when Windows Server 2016 reaches the end of extended support. The quiet default to decide now: from Windows 11, version 26H2, Windows settings backup is on by default on eligible devices unless you set a policy.

<!-- more -->

This is our weekly Endpoint & devices roundup. Items rest on the facts our Research desk read at each primary source between 13 and 20 November 2026.

## Already briefed

1. **FastUnlock, an unpatched Windows lock-screen bypass through Narrator (19 November 2026).** Windows and Intune admins: find laptops with TPM-only BitLocker and a linked Microsoft account. Check: `Get-BitLockerVolume -MountPoint $env:SystemDrive | Select-Object -ExpandProperty KeyProtector`. Brief: [FastUnlock: Windows lock-screen bypass via Narrator](2026-11-20-fastunlock-windows-lock-screen-bypass-narrator.md).
2. **Defender vulnerability shielding is on by default in preview (17 November 2026).** Defender and Intune admins: list servers that must never get automatic changes. Brief: [Defender vulnerability shielding on by default](2026-11-17-defender-vulnerability-shielding-on-by-default.md).

## New this week

### Windows Server 2016 and Windows 10 Enterprise LTSC 2021: support milestones on 13 January 2027

MC1551896: "On January 13, 2027, all editions of Windows Server 2016 will reach the end of extended support. The January 2027 Windows security update will be the last update provided during extended support. After that date, monthly security updates will continue only for Windows Server 2016 devices enrolled in Extended Security Updates (ESU)." Support for Windows Server 2016 Essentials features, including Remote Web Access, also ends on that date. MC1551897, titled as the end of updates for Windows 10 Enterprise LTSC 2021, says in its body: "On January 13, 2027, Windows 10 Enterprise LTSC 2021 will reach the end of mainstream support", with monthly security updates continuing only for devices enrolled in ESU. We had shown 12 January 2027 on our deadlines page and corrected it today ([corrections](../../about/corrections.md)).

- **Who acts:** server and endpoint admins.
- **Check:** list Server 2016 hosts and LTSC 2021 devices in your inventory (Intune admin center > Devices > Windows, by OS version, or your server CMDB). Decide upgrade or ESU for each.
- **Source:** [MC1551896](https://mc.merill.net/message/MC1551896), [MC1551897](https://mc.merill.net/message/MC1551897) (13 November 2026).

### Windows settings backup is on by default from Windows 11, version 26H2 (9 November 2026)

"Windows Backup for Organizations is now Windows settings backup and restore." "Starting with Windows 11, version 26H2, backup is enabled by default on eligible devices." "Any explicitly configured backup policy, whether enabled or disabled, continues to be honored", and "this change applies to backup only. Manage the restore capability separately as it requires explicit administrator configuration." A WindowsBackupAdmin PowerShell module can "View attributes", "Export backup information" and "Delete a user's backup data or profiles".

- **Who acts:** Intune and Group Policy admins of Windows 11 fleets moving to 26H2. No date stated.
- **Check:** in Intune, look for a configured Windows backup policy assigned to your 26H2 devices. If there is none, the default (on) applies.
- **Do this:** if settings must not leave the device, set the backup policy explicitly to disabled. If you keep it, restore stays off until you configure it.
- **Source:** [Enhanced resilience with Windows settings backup and restore](https://techcommunity.microsoft.com/blog/windows-itpro-blog/enhanced-resilience-with-windows-settings-backup-and-restore/4571757) (Windows IT Pro Blog, 9 November 2026).

### Windows Update certificates expire on 17 May and 19 June 2027

"A set of these certificates will expire on May 17, 2027 and June 19, 2027." "If unaddressed, affected devices will stop connecting and receiving all types of updates from Windows Update." "This doesn't apply to devices receiving updates from Windows Server Update Services (WSUS)." Microsoft's table: Windows 11, version 25H2 and later need nothing. Windows 11 24H2 and Windows Server 2025: "Install the September 2025 Windows security update or later before June 19, 2027." Other supported Windows 11 versions, Windows Server 2022 and supported Windows 10: "Install the July 2026 Windows security update or later before June 19, 2027." Read the blog's table for LTSB and LTSC rows.

- **Who acts:** Windows and Intune admins with stale or long-term servicing devices.
- **Check:** Intune > Reports > Windows updates (or your patch report): devices whose last quality update is older than July 2026, or older than September 2025 for 24H2 and Server 2025.
- **Source:** [Prepare for Windows Update certificate rotation in 2027](https://techcommunity.microsoft.com/blog/windows-itpro-blog/prepare-for-windows-update-certificate-rotation-in-2027/4562463) (Windows IT Pro Blog, 8 October 2026).

### November updates: slmgr activation commands fail with 0x80041008; optional fix released 13 November 2026

After the November 2026 updates, "Affected devices might encounter error 0x80041008, Invalid parameter (SWbemObjectEx), when running commands to activate Windows, configure Key Management Service (KMS), or manage product keys", for example `slmgr.vbs /skms-domain <domain>` and `slmgr.vbs /ipk <key>`. "Devices that are already activated remain activated." Microsoft released an optional non-security out-of-band update on 13 November (MC1551898): Server 2025 KB5136489, Server 2022 KB5136487, Server 2019 and Windows 10 Enterprise LTSC 2019 KB5136490, Windows 11 23H2 KB5136483, Windows 10 22H2 ESU and Windows 10 Enterprise LTSC 2021 KB5136493. Except for Windows 11 23H2, these come only from the Microsoft Update Catalog.

- **Who acts:** admins whose imaging or task sequences run `slmgr /skms-domain` or `/ipk`.
- **Check:** search your task sequences and scripts for `slmgr`. If found, import the KB for your version from the Update Catalog first.
- **Source:** [MC1551898](https://mc.merill.net/message/MC1551898) (13 November 2026); [KB5131087 known issues](https://support.microsoft.com/en-us/servicing/os/windows-11/2026/11/kb5131087-windows-11-23h2-security-update).

### Defender and Sentinel at Ignite: local-agent runtime protection GA on Windows, ClickFix blocking (17 November 2026)

Microsoft: "runtime protection for local agents is now generally available* on Windows… Supported agents include Claude Code, GitHub Copilot CLI, OpenClaw, ChatGPT Desktop (Chat)"; "in Block mode, Defender also stops the action and notifies the user". Defender adds "new capabilities to detect and block malicious copy-and-paste attacks called ClickFix attacks, which accounted for 12.8% of all intrusions observed by Microsoft Defender this year." QR code detection in Teams chats works "with no additional administrator setup required. Now in public preview."

- **Who acts:** Defender for Endpoint admins with developers or users who run local AI agents.
- **Check:** list devices where those agents run before you choose audit or block mode for agent runtime protection.
- **Source:** [Ignite 2026: What's new in Microsoft Defender & Sentinel](https://techcommunity.microsoft.com/blog/microsoftthreatprotectionblog/ignite-2026-whats-new-in-microsoft-defender--sentinel/4569975) (17 November 2026). Related: [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md).

### Windows at Ignite: Windows baseline protection preview, Intune and Autopatch for Windows Server preview (17 November 2026)

"With Windows baseline protection, now available in preview, Windows brings foundational protections, including secure boot, virtualization-based security, and memory integrity together into a single, versioned security state." "Administrator protection helps users operate with standard permissions by default and elevate privileges when needed." "Microsoft is also extending Intune and Windows Autopatch to eligible Windows Server scenarios, in preview." MC1557973: "No immediate action is required."

- **Who acts:** Windows and Intune admins planning pilots. No deadline.
- **Check:** before a pilot, report the three parts baseline protection bundles on a sample of devices: `Confirm-SecureBootUEFI` and `Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard` (read-only, elevated prompt).
- **Source:** [Windows security at Ignite 2026](https://blogs.windows.com/windowsexperience/2026/11/17/windows-security-at-ignite-2026-start-secure-protect-what-matters-prepare-for-ai/) (Windows Experience Blog, 17 November 2026).

## Also logged

- **Intune service release 2611 (week of 16 November): the macOS settings catalog adds "Microsoft Defender: AI Agent Network Inspection, AI Agent Protection"; Windows PowerShell scripts get "Group exclusions and built-in group targeting"; "Maintenance windows for operating system and driver updates on Windows".** [What's new in Intune](https://learn.microsoft.com/en-us/intune/intune-service/fundamentals/whats-new).
- **MC1556107, Defender portal "Similar cases" tab (up to 20 related incidents); "Public preview is available now; full rollout completes by early December 2026".** No action. [MC1556107](https://mc.merill.net/message/MC1556107).
- **Windows Server 2028 is in public preview (17 November) with "A hardened Server Core configuration by default and a new security baseline".** No GA date given. [Windows Server 2028 announcement](https://techcommunity.microsoft.com/blog/windowsservernewsandbestpractices/windows-server-2028-a-trusted-foundation-for-an-evolving-enterprise/4574112).
- **Windows November 2026 non-security preview update (19 November) for 26H2, 26H1 and 25H2: user experience changes only in the highlights; "there will be no December 2026 non-security preview update in the second part of the month."** [Windows message center](https://learn.microsoft.com/en-us/windows/release-health/windows-message-center).

Related: [Microsoft 365 security deadlines](../../guides/deadlines.md) · [Defender ASR rules from audit to block](../../guides/defender-asr-rules-audit-to-block.md).

More: [all Endpoint & devices news](../topic/endpoint-devices/).

Last reviewed: 20 November 2026. Runbook Lab is not affiliated with Microsoft.
