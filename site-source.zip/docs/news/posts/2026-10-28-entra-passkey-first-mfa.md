---
date:
  created: 2026-10-28 10:00:00
slug: entra-passkey-first-mfa-method
categories:
  - Identity & access
description: From November 2026 Microsoft Entra lets password-only users register a passkey as their first MFA method instead of SMS or voice. Phase 1 runs from early November 2026 to early January 2027.
rl_type: news
rl_service: [entra]
rl_kits: [ca, sms]
rl_controls: [CA03, CA05]
---

# Entra will offer passkeys as the first MFA method from November

Users who only have a password will be able to register a passkey as their first multifactor authentication method in Microsoft Entra ID. Until now they first had to register another MFA method, such as SMS or voice. Users who are enabled for passkeys will be prompted to register one by default.

<!-- more -->

## What changes

- The registration prompts that MFA enforcement and Conditional Access authentication strengths trigger will offer a passkey first, for users enabled for passkeys.
- Phase 1, from early November 2026 to early January 2027: synced passkeys, Microsoft Entra passkeys on Windows and FIDO2 security keys.
- Phase 2, completing in late February 2027: Windows Hello for Business, macOS Platform SSO, passkeys in Microsoft Authenticator and Authenticator passwordless sign-in.
- Security defaults registration prompts follow in January and February 2027.

Microsoft moved the Phase 1 dates on 26 October 2026: the start was late October and the end late November.

## Who needs to act, and by when

Microsoft says no action is required. Identity admins should still check three things before November, because the prompts users see will change.

## What to do

1. See whether passkeys (FIDO2) are enabled, and for whom. This only reads:

    ```powershell
    Connect-MgGraph -Scopes Policy.Read.All
    $c = Get-MgPolicyAuthenticationMethodPolicyAuthenticationMethodConfiguration -AuthenticationMethodConfigurationId Fido2
    $c | Select-Object Id, State
    $c.AdditionalProperties.includeTargets   # who it is enabled for
    ```

2. Review the Conditional Access policies that protect security info registration. Microsoft suggests requiring MFA to register security info.
3. Update onboarding and helpdesk guidance: new users may now see a passkey prompt before anything else.

## Why it matters for security

This removes a common reason SMS ended up as a user's first MFA method. It also lines up with the retirement of Microsoft's own SMS and voice MFA on 1 February 2027, after which phone-only users get a blocking passkey prompt. The fewer users who start on SMS, the shorter that clean-up.

## Sources

- [MC1450133 on the public message center mirror](https://mc.merill.net/message/MC1450133) (last updated 26 October 2026)
- [Microsoft Learn: Enable passkeys (FIDO2) for your organization](https://learn.microsoft.com/en-us/entra/identity/authentication/how-to-enable-passkey-fido2)
