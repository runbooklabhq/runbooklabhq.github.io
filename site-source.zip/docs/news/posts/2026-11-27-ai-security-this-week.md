---
date:
  created: 2026-11-27 10:23:00
slug: ai-security-this-week-2026-11-27
categories:
  - AI security
description: "AI security news to 27 November 2026: Microsoft's ARTEX defender guidance, stolen prompts at AI inference providers, Copilot app and Edge password sync."
rl_type: news
rl_area: ai
rl_service: [copilot, defender, other]
rl_kits: [copilot, agents]
rl_controls: []
---

# AI security this week: 13 changes (27 November 2026)

Thirteen confirmed AI security items from the week to 27 November 2026, plus an update to one brief. The first check is for Defender and Microsoft 365 admins: Microsoft Threat Intelligence published its defender guide to ARTEX, the AI penetration testing framework that six named threat actors now use, with user agent strings and mitigations you can apply today.

<!-- more -->

This is our weekly AI security roundup. Items rest on the facts our Research desk read at each primary source between 20 and 27 November 2026; the ARTEX post and the Message Center items were re-read on 27 November 2026.

## Already briefed

1. **MC1560922 update: the in-app browser policies for the Microsoft Copilot desktop app are generally available now (MC1568702, 25 November).** They apply only where the BrowsingEnabled policy is on. In-app browsing is still on by default from early January 2027; Act by 3 January 2027. Brief: [Copilot app in-app browsing on by default](2026-11-20-copilot-app-in-app-browsing-default-mc1560922.md).

## New this week

### Microsoft Threat Intelligence on ARTEX: six actors, user agent strings and what to fix first (25 November 2026)

Microsoft: "Since its release in July 2026, the AI-powered penetration testing framework ARTEX has been abused by many threat actors to accelerate their existing workflows related to network reconnaissance, credential attacks, and web application exploitation." It names "Storm-0940, Storm-3358, Onyx Sleet, Pearl Sleet, Crystal Typhoon, and Salt Typhoon" (Microsoft's attribution). "ARTEX doesn't introduce new attack techniques. It runs common penetration testing tools and tries one approach after another at machine speed." The post lists two user agent strings, `artex-enrich/*` and `norma/*`, and warns that actors "frequently change these values". Its mitigations "close exposure before scanning finds it, slow down bursts of requests, protect credentials and application secrets, and contain a compromise automatically".

- **Who acts:** Defender, Azure and Microsoft 365 admins. No deadline.
- **Check:** web server, Application Gateway and Front Door logs for user agents `artex-enrich/` and `norma/`; Defender External Attack Surface Management for internet-facing hosts you did not know you had.
- **Do this:** run the post's hunting queries in Defender XDR advanced hunting; switch Web Application Firewall from detection to prevention after tuning and add rate limiting; protect credentials and application secrets: Microsoft says ARTEX searched public repositories for exposed secrets.
- **Source:** [What defenders need to know about ARTEX](https://www.microsoft.com/en-us/security/blog/2026/11/25/what-defenders-need-to-know-artex-agentic-ai-framework-threat-actors-abuse/) (Microsoft Security blog, 25 November 2026, read 27 November 2026). Earlier: [ConnectWise and Storm-0940 brief, with the FBI FLASH update](2026-11-03-connectwise-cloud-apps-storm-0940-m365-tenants.md).

### Dragos: attackers inside three AI inference providers stole prompts and the AWS keys in them (19 November 2026)

Dragos: "We observed activity indicating that data from at least three AI providers was exposed." "The earliest incident dates back to the middle of July, and none of the three providers knew about their breach until we notified them." "In the other two breaches, some of the stolen requests were marked as ZDR. A privacy flag doesn't help when the attacker is already inside." Stolen AWS keys were tested "in some cases within a few hours". "On November 1, the same attacker added ARTEX", with user agents "artex-agent and artex-judge-r121". Dragos does not name the providers. OpenRouter (22 November): "These findings did not show any breach or unauthorized access of OpenRouter"; it "Off-boarded three providers" and "Removed 125 endpoints from Zero Data Retention (ZDR) eligibility". No Microsoft service is named.

- **Who acts:** admins and MSPs whose scripts, agents or ticket automation send prompts to AI routers or low-cost inference providers.
- **Check:** which AI endpoints your automation calls (pipeline API keys, RMM scripts, Power Automate and Copilot Studio HTTP actions to third-party models). If you use OpenRouter, look for its customer notice.
- **Do this:** rotate any credential that ever appeared in a prompt, keep secrets out of prompts, and hunt AWS CloudTrail and proxy logs for the two user agents.
- **Source:** [Dragos](https://www.dragos.com/blog/ai-supply-chain-security-canary-tokens) (19 November 2026); [OpenRouter](https://openrouter.ai/blog/announcements/data-processing-incidents-on-inference-providers/) (22 November 2026).

### MC1562269: the Copilot desktop app can sync Edge passwords and history, mid to end of December 2026

Microsoft: "Optional sync of passwords, personal info, settings, and browsing history between Copilot desktop app and Microsoft Edge will roll out worldwide in December 2026. Sync is account-based, opt-in, excludes payment info". Rollout: "General Availability (Worldwide): We will begin rolling out in mid-December 2026 and expect to complete by end of December 2026." Microsoft asks admins to "Review governance before enabling". It names no admin control yet. With in-app browsing on by default from January (MC1560922), the Copilot app becomes a second browser that can hold synced passwords.

- **Who acts:** endpoint and Microsoft 365 admins, before mid-December 2026.
- **Check:** your Edge sync policies (for example `SyncDisabled`, or `SyncTypesListDisabled` with passwords). These are Edge policy names; Microsoft has not said they govern the Copilot app.
- **Do this:** decide on this sync together with the BrowsingEnabled decision, and re-read MC1562269 in mid-December for the Copilot-side control.
- **Source:** [MC1562269](https://mc.merill.net/message/MC1562269) (published 20 November 2026, read 27 November 2026).

## Also logged

- **Amazon Threat Intelligence: a Chinese-nexus actor (Amazon: "moderate confidence") ran Cairn AI agents that "found a zero-day in an open-source application and used it to gain full control of a server", "In about 11 minutes".** The maintainers "released a fix and a GitHub Security Advisory". Search network logs for the two IP addresses Amazon lists (8 to 10 September 2026). The same week CISA added MONAI Label CVE-2026-133968 to KEV (see the Threats roundup); BleepingComputer names MONAI Label as the application, Amazon does not. [AWS Security Blog](https://aws.amazon.com/blogs/security/chinese-nexus-actors-cairn-ai-agents-found-a-zero-day-on-their-own/) (20 November 2026).
- **MC1562275, Microsoft 365 Copilot app: "enabling modern search controls by default starting late November 2026" for users without a Copilot licence**; rollout late November to mid-December 2026 (Deferred Release late December 2026 to mid-January 2027). "Users can toggle back to classic search." Results respect existing permissions, so files that are overshared today become easier to find: check sharing first. [MC1562275](https://mc.merill.net/message/MC1562275).
- **MC1557754, Copilot Credits: users can keep using models after their licence limits through usage-based billing; "Admins manage access and spending through updated policies and controls. Rollout begins December 2026."** Set the spending controls before users see the option. [MC1557754](https://mc.merill.net/message/MC1557754).
- **MC1561862, Copilot Studio workflows: "Run Python code as a workflow step", GA 1 December 2026 (date as read on 21 November).** Review which makers can publish workflows with code steps. [MC1561862](https://mc.merill.net/message/MC1561862).
- **MC1561859, Copilot Studio workflows: "Generate documents from the Agent node in workflows", GA 3 December 2026 (date as read on 21 November).** Check where generated documents are stored and who can open them. [MC1561859](https://mc.merill.net/message/MC1561859).
- **MC1562277, Copilot in Teams channels with channel-wide context: "Public Preview (Worldwide): Rollout will begin in early December 2026 and is expected to complete by the end of December 2026."** Channel content becomes Copilot context; check channel membership on sensitive teams. [MC1562277](https://mc.merill.net/message/MC1562277).
- **MC1567263, optional notification when admins pin Copilot to the Windows taskbar: "This capability is not enabled by default."** Late November to late December 2026. [MC1567263](https://mc.merill.net/message/MC1567263).
- **MC1523085, Viva Insights: GitHub Copilot metrics on by default, "Beginning in mid-December 2026 (previously mid-November) and expected to complete by mid-January 2027 (previously mid-December 2026)".** "Existing roles and permissions will control data access"; tell the people who see the dashboard. [MC1523085](https://mc.merill.net/message/MC1523085).
- **MC1560920, "Copilot video creation in Clipchamp Video Hub is now live in Frontier Public"** (updated 24 November). No admin action. [MC1560920](https://mc.merill.net/message/MC1560920).
- **MC1568700, Microsoft 365 Copilot "Copy with sources": "Rollout will begin in mid-December 2026 and is expected to complete by late December 2026."** "Copy with sources is enabled by default." Copied answers include citations unless the user turns the option off. [MC1568700](https://mc.merill.net/message/MC1568700).

Related: [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md) · [M365 AI Agent Hardening Kit](../../kits/ai-agent-hardening.md) · [Copilot oversharing checklist](../../guides/microsoft-365-copilot-oversharing-checklist-jira.md).

More: [all AI security news](../topic/ai-security/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 27 November 2026. Runbook Lab is not affiliated with Microsoft.
