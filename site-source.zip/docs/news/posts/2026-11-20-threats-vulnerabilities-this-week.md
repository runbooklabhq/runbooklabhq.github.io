---
date:
  created: 2026-11-20 10:36:00
  updated: 2026-11-21 10:30:00
slug: threats-vulnerabilities-this-week-2026-11-20
categories:
  - Threats & vulnerabilities
description: "Threats to 20 November 2026: patch the vCenter zero-day CVE-2026-123890, close Check Point PHP2Shell, Puppet, Synology and F5 flaws, update Java and PHP."
rl_type: news
rl_area: detection-response
rl_service: [other, windows]
rl_kits: [mde]
rl_controls: []
---

# Threats & vulnerabilities this week: 9 changes (20 November 2026)

Nine confirmed threat and vulnerability items from the week to 20 November 2026. The first action is for anyone who runs VMware vCenter: Broadcom fixed authentication bypass CVE-2026-123890 on 19 November, and Mandiant reports it was exploited as a zero-day from early September 2026.

<!-- more -->

!!! info "Updated 21 November 2026: vCenter CVE-2026-123890 is now in CISA KEV"
    CISA added CVE-2026-123890 to the Known Exploited Vulnerabilities catalogue on 20 November 2026, after our first read that morning. Due date for US federal agencies: 23 November 2026. Known ransomware use: "Unknown". The vCenter item below has one added line.

This is our weekly Threats & vulnerabilities roundup. Items rest on the facts our Research desk read at each primary source between 12 and 20 November 2026. CISA KEV entries are as read on 19 and 20 November 2026 (CVE-2026-123890's entry as read on 21 November 2026); CISA published no catalogue update on 19 November (read 20 November, 07:10 UTC).

## New this week

### VMware vCenter CVE-2026-123890 exploited as a zero-day since early September 2026 (VMSA-2026-0009, 19 November)

Broadcom: "On November 19, 2026, Broadcom released a critical VMware Security Advisory (VMSA), VMSA-2026-0009". "The vCenter issue permits an attacker with network access to vCenter to bypass authentication and gain unauthorized access to the system." The same advisory covers SDDC Manager CVE-2026-123891, CVE-2026-123892 and CVE-2026-123893, and VMware Tools for Windows CVE-2026-123894. BleepingComputer, citing Mandiant: "While Broadcom has not confirmed that the flaw was exploited, researchers at Google's Mandiant have documented attacks exploiting CVE-2026-123890." Mandiant names a group it tracks as Armory Castle (formerly UNC5221) and says exploitation began "in early September 2026"; "Successful exploitation results in a remote authentication bypass which creates an authenticated session established as administrator@vsphere.local". The tools named include SAWSNAKE, which forges SAML tokens. "Broadcom says there are no official workarounds". The CVE was not in CISA KEV when we read the catalogue on 20 November at 07:10 UTC. Update 21 November: CISA added it to KEV on 20 November 2026 (due date 23 November 2026), read 21 November.

- **Who acts:** owners of vCenter, SDDC Manager and Windows guests with VMware Tools.
- **Check:** your vCenter build against the fixed versions in VMSA-2026-0009 for your branch. If you ran BeyondTrust Remote Support before the CVE-2026-102764 fix, treat vCenter as possibly compromised: look for new vCenter SSO administrator accounts.
- **Do this:** patch, then rotate the vCenter SAML signing certificates. Keep vCenter management off user networks and the internet. Update VMware Tools on Windows guests.
- **Source:** [VMSA-2026-0009 Questions & Answers](https://github.com/vmware/vcf-security-and-compliance-guidelines/blob/main/security-advisories/vmsa-2026-0009/README.md) (Broadcom, 19 November 2026); [BleepingComputer](https://www.bleepingcomputer.com/news/security/vmware-patches-vcenter-zero-day-exploited-in-attacks-since-september/) (19 November 2026); [The Hacker News](https://thehackernews.com/2026/11/china-linked-hackers-exploit-critical.html) (20 November 2026); [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 21 November 2026). Related: [BeyondTrust CVE-2026-102764 brief](2026-11-03-beyondtrust-remote-support-cve-2026-102764-patch-hunt.md).

### Check Point gateways: PHP2Shell on Mobile Access portals, then CVE-2026-123039 to root (CISA KEV 13 November 2026)

Check Point: "Check Point observed an active exploit of this vulnerability against a couple of dozen customers." CVE-2026-123039 (CVSS 7.8) "requires the attacker to already have local code execution on the appliance"; affected versions "R82.20, R82.10, R82, R81.20, R81.10, R81". CISA added it on 13 November with a due date of 16 November. Check Point Research (12 November): "Beginning on 30 October 2026, an attacker executed scanning and exploitation activity against organizations with unpatched Check Point Security Gateways, using Mobile Access portals with PHP2Shell as initial access followed by CVE-2026-123039." The attacker then moved "to a VMware ESXi host over SSH, authenticating with the vpxuser service account". Check Point: "the evidence does not allow us to assess with high confidence the true nature of this operation".

- **Who acts:** owners of Check Point gateways with Mobile Access, and MSPs.
- **Check:** in Expert mode, `ps auxw | grep -v grep | grep 'dynamic_server'`. Hunt for `zz*.tpl` files in the portal templates directory and for `/lib/libcpfwcommon.so`.
- **Do this:** patch PHP2Shell (CVE-2026-109618 and CVE-2026-109619) and CVE-2026-123039 (sk1000362, which also lists a mitigation). Block SSH from gateways to ESXi hosts.
- **Source:** [sk1000362](https://support.checkpoint.com/results/sk/sk1000362); [Check Point Research](https://research.checkpoint.com/2026/php2shell-exploitation-on-check-point-gateway/) (12 November 2026).

### CISA KEV 18 November: Synology DSM, Apache Axis and REDCap, due 21 November 2026

CISA added "Synology DiskStation Manager (DSM) Improper Encoding or Escaping of Output Vulnerability" (CVE-2024-10441), which "could allow a remote attacker to execute arbitrary code via unspecified vectors", "Apache Axis Unsafe Reflection Vulnerability" (CVE-2026-90436) and "Vanderbilt University Research Electronic Data Capture (REDCap) Code Injection Vulnerability" (CVE-2026-90817). All three are due on 21 November 2026.

- **Who acts:** NAS owners, and owners of Java web services or REDCap.
- **Check:** Defender Vulnerability Management > Weaknesses, search each CVE id. Synology: Control Panel > Update & Restore, then update DSM as Synology's advisory says and take DSM management off the internet.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 19 November 2026).

### CISA KEV 17 November: Puppet Enterprise CVE-2026-115731, due 1 December 2026

CISA: the flaw "allows a client with any CA-signed agent certificate to execute arbitrary code on the Puppet Server as the service user"; "If the certificate authority automatically signs requests without strong verification, an unauthenticated network attacker can obtain a valid certificate and exploit the vulnerability."

- **Who acts:** owners of Puppet Server.
- **Check:** `puppet config print autosign --section server`. If autosign is on, turn it off or move to policy-based autosigning, then patch as Perforce's note says.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog); [Perforce note](https://portal.perforce.com/s/cve/a91Qi000003IaHpIAK/report-deserialization-code-execution).

### Java4Shell: OpenJDK CVE-2026-114938, fixed 17 November 2026

OpenJDK: "The affected versions are 27.0.1.0.3, 25.0.5.0.3, 21.0.13.0.3, 17.0.21.0.3, 11.0.33, 8u512, and earlier." "We recommend that you upgrade as soon as possible." The hotspot compiler flaw scores 8.1. The Hacker News: "The flaw is present in Java 17.0.6 and later, and the vulnerable code runs only on x86-64 Intel and AMD chips that support the AVX-512 VBMI feature", and Canada's Cyber Centre "was not aware of any attacks exploiting the flaw". The researchers say it allows pre-authentication code execution in Jira, Jenkins and Keycloak.

- **Who acts:** owners of Java 17 or later servers on AVX-512 VBMI CPUs.
- **Check:** `java -version` on each Jira, Jenkins or Keycloak host and, on Linux, `grep -o avx512vbmi /proc/cpuinfo | head -1`. Defender Vulnerability Management > Software inventory: search "openjdk".
- **Source:** [OpenJDK advisory 2026-11-17](https://openjdk.org/groups/vulnerability/advisories/2026-11-17); [The Hacker News](https://thehackernews.com/2026/11/java4shell-cve-2026-114938-enables-pre.html).

### F5 out-of-band notification: 25 advisories for BIG-IP and NGINX (18 November 2026)

"On November 18, 2026, F5 announced the following security issues", among them BIG-IP iRule and APM flaws and NGINX HTTP/2 module flaws CVE-2026-123007 and CVE-2026-123633. The Hacker News: "Six critical vulnerabilities in F5 BIG-IP allow an attacker to crash the Traffic Management Microkernel (TMM) without logging in", "Each flaw needs a specific setup on a virtual server", and "None of the company's advisories says the flaws have been exploited."

- **Who acts:** BIG-IP owners with iRules or APM on virtual servers; NGINX owners with HTTP/2.
- **Check:** `tmsh show sys version` and `tmsh list ltm virtual rules profiles`, then match each against F5's per-CVE articles. NGINX: `nginx -V` and look for `http2` in listen directives.
- **Source:** [K000164058](https://my.f5.com/manage/s/article/K000164058) (F5, 18 November 2026).

## Also logged

- **CISA KEV 13 November: UnrealIRCd CVE-2026-114713 "allows any user on a network with two or more linked servers to inject server-to-server commands"; due 16 November.** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog).
- **PostgreSQL 18.7, 17.12, 16.16, 15.20 and 14.25 (12 November): "This release fixes 52 security vulnerabilities and over 140 bugs"; "This is the final release of PostgreSQL 14."** Patch self-hosted PostgreSQL behind line-of-business apps and plan off 14. [PostgreSQL release notes](https://www.postgresql.org/about/news/postgresql-187-1712-1616-1520-1425-and-19-rc-2-released-3442/).
- **PHP security releases 8.5.13, 8.4.28, 8.3.37 and 8.2.36 (19 November).** PHP said the critical issues "require either non-default configuration or uncommon setups"; no exploitation stated. Update PHP on Windows and IIS hosts too. [php.net](https://www.php.net/).

Related: [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

More: [all Threats & vulnerabilities news](../topic/threats-vulnerabilities/).

Last reviewed: 20 November 2026. Runbook Lab is not affiliated with Microsoft.
