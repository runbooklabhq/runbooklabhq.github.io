---
date:
  created: 2026-11-13 12:10:00
slug: email-collaboration-this-week-2026-11-13
categories:
  - Email & collaboration
description: "Email & collaboration news to 13 November 2026: move Exchange Admin API apps by 30 November, review MDO policy recipient rules, set Outlook All Accounts policy."
rl_type: news
rl_area: email-collab
rl_service: [defender, outlook, exchange-online, sharepoint-onedrive]
rl_kits: [exo, m365]
rl_controls: []
---

# Email & collaboration this week: 9 changes (13 November 2026)

Nine confirmed Exchange, Outlook, Teams, SharePoint and Defender for Office 365 items from the week to 13 November 2026, each with who acts, the check and the source. Microsoft 365 outage MO1550821 was still ongoing at Microsoft's status page update of 07:29 UTC on 13 November, and the nearest date is 30 November 2026, when owners of apps on the Exchange Online Admin API must finish moving to the new permissions.

<!-- more -->

This is our weekly Email & collaboration roundup. Items rest on the facts Research read at each primary source between 7 and 12 November 2026. Our searches on 13 November found the Message Center titles for MC1519843 and MC1546447 but not their text, so we did not re-read them today.

## Already briefed

1. **Microsoft 365 outage MO1550821 (13 November): ongoing as of Microsoft's status page update at 07:29 UTC on 13 November 2026.** Microsoft 365 admins, SOC teams and help desks. Check: status.cloud.microsoft > Microsoft 365 (Business or Enterprise) > Show details; in the admin center, if it loads: Health > Service health > MO1550821. Brief: [Microsoft 365 outage MO1550821](2026-11-13-microsoft-365-outage-mo1550821.md). Source: [Microsoft service health status](https://status.cloud.microsoft/).
2. **Exchange Online Admin API apps must move to the new permissions by 30 November 2026 (7 November); the old ones are deprecated on 1 December 2026.** Owners of apps, scripts and third-party tools that call the Admin API v2.0, and Entra admins who grant consent. Check: Entra admin center > Entra ID > Enterprise apps > the app > Security > Permissions, for Exchange.ManageV2 or Exchange.ManageAsAppV2. Brief: [Move Exchange Admin API apps by 30 November](2026-11-07-exchange-online-admin-api-permissions-mc1540345.md). Source: [MC1540345](https://mc.merill.net/message/MC1540345).

## New this week

### MC1546447: Defender for Office 365 policy recipient conditions change from Match all to Match any, early December 2026

Microsoft is changing the recipient inclusion logic in Defender for Office 365 threat protection policies from Match all (AND) to Match any (OR). "We will begin rolling out in early December 2026 and expect to complete by early December 2026." The change "does not auto-convert existing policies", and "No action is required for existing policies that you do not modify." The new logic applies when you next edit a policy. A policy that today targets a group AND a domain would then apply to anyone in the group OR the domain, which can be many more recipients. The post was published on 10 November 2026 and carries no Act by date.

- **Who acts:** Defender for Office 365 admins who maintain custom Safe Links, Safe Attachments or anti-phishing policies with more than one recipient condition.
- **Check:** in Exchange Online PowerShell, `Get-SafeLinksRule | Format-List Name, SentTo, SentToMemberOf, RecipientDomainIs`, and the same for `Get-SafeAttachmentRule` and `Get-AntiPhishRule`. Write down every rule that combines users, groups or domains before you edit it.
- **Source:** [MC1546447](https://mc.merill.net/message/MC1546447). Related: [Exchange Online Protection Kit](../../kits/exchange-online-protection.md) · [EOP preset policies and DMARC](../../guides/exchange-online-protection-preset-policies-dmarc.md).

### MC1519843: new Outlook for Windows All Accounts view on by default, admin controls added 6 November 2026

The new Outlook for Windows adds an All Accounts view, a single inbox for every account a user has added, including personal ones. It is on by default for users with more than one account. Microsoft now expects the rollout to "complete by late November 2026 (previously late October)". On 6 November Microsoft added: "Admin controls for All Accounts view (Unified Inbox) are now available." If your policy does not allow personal and work mail in one view, the two Cloud Policy settings are "Configure the unified inbox view" and "Allow user to override this setting".

- **Who acts:** Microsoft 365 Apps admins in organisations whose policy separates work and personal mail on managed devices.
- **Check:** Microsoft 365 Apps admin center > Cloud Policy: look for a policy configuration that sets "Configure the unified inbox view" and "Allow user to override this setting", and the groups it targets. If none exists, the default (on) applies.
- **Source:** [MC1519843](https://mc.merill.net/message/MC1519843) (updated 6 November 2026). Related: [Microsoft 365 Hardening Kit](../../kits/m365-hardening.md).

## Also logged

- **Exchange Server November 2026 security update (Exchange Team Blog, 10 November): Exchange SE RTM only.** Exchange 2016 and 2019 are "no longer tested for vulnerabilities and there are no updates released". The October Windows-update instability is fixed by the November Windows Server updates, and the October registry key is no longer required. Install it on every Exchange SE server and management workstation, then run Health Checker. [Released: November 2026 Exchange Server Security Updates](https://techcommunity.microsoft.com/blog/exchange/released-november-2026-exchange-server-security-updates/4570368). Related: [November Patch Tuesday](2026-11-10-outlook-zero-day-cve-2026-124194-november-patch-tuesday.md) · [Exchange 2016/2019 ESU end](2026-11-03-exchange-server-2016-2019-esu-end-no-more-updates.md).
- **MC1546409, Teams off-network invitations to Teams Free retire: "We will begin rolling out in early December 2026 and expect to complete by late December 2026."** Federation does not change. "No admin action is required"; update user guidance "before December 6, 2026". [MC1546409](https://mc.merill.net/message/MC1546409).
- **MC1540513, SharePoint and OneDrive Copilot Search experience: "Act by Jan 18, 2027".** GA "begins in mid-January 2027 … complete by mid-April 2027", and admins can defer it at tenant or site level. [MC1540513](https://mc.merill.net/message/MC1540513).
- **MC1540348, SharePoint data access governance report for group permissions: late November to early December 2026.** Useful for finding oversharing through group permissions. [MC1540348](https://mc.merill.net/message/MC1540348).
- **MC1540330, Opal (Frontier) usage-based billing from 9 November 2026.** Set Copilot Credits cost controls. [MC1540330](https://mc.merill.net/message/MC1540330).

Related guides: [Exchange Online SMTP AUTH basic auth checklist](../../guides/exchange-online-smtp-auth-basic-auth-checklist.md) · [Microsoft 365 Copilot oversharing checklist](../../guides/microsoft-365-copilot-oversharing-checklist-jira.md).

More: [all Email & collaboration news](../topic/email-collaboration/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 13 November 2026. Runbook Lab is not affiliated with Microsoft.
