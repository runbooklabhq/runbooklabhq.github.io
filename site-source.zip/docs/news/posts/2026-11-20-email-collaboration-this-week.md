---
date:
  created: 2026-11-20 10:32:00
slug: email-collaboration-this-week-2026-11-20
categories:
  - Email & collaboration
description: "Email & collaboration news to 20 November 2026: Reject Direct Send is GA in Exchange Online, N-able Mail Assure incident, Teams and OneDrive dates logged."
rl_type: news
rl_area: email-collab
rl_service: [exchange-online, defender, teams, sharepoint-onedrive]
rl_kits: [exo, m365]
rl_controls: []
---

# Email & collaboration this week: 12 changes (20 November 2026)

Twelve confirmed Exchange Online, Teams, SharePoint, OneDrive and Defender for Office 365 items from the week to 20 November 2026. The main one: Reject Direct Send is now generally available in Exchange Online, on by default and not removable for new tenants, and still opt-in for existing ones. MSPs using N-able Mail Assure or SpamExperts Hosted Cloud should read N-able's partner email about this week's security incident.

<!-- more -->

This is our weekly Email & collaboration roundup. Items rest on the facts our Research desk read at each primary source between 13 and 20 November 2026. We found the Reject Direct Send post four days after Microsoft published it.

## Already briefed

1. **Microsoft 365 outage MO1550821 and the phishing that followed it.** Microsoft reported a phishing campaign that impersonates Microsoft 365 service health notices about the outage. Who acts: Defender for Office 365 admins and help desks. Brief with the sender domains and Microsoft's hunting steps: [Microsoft 365 outage MO1550821](2026-11-13-microsoft-365-outage-mo1550821.md).

## New this week

### Reject Direct Send is generally available in Exchange Online (16 November 2026)

"Today, we're pleased to announce that Reject Direct Send is now Generally Available for Exchange Online worldwide tenants." Microsoft says "more than 70,000 organizations have enabled Reject Direct Send", and "we plan to enable Reject Direct Send by default for new Exchange Online tenants, without the option to disable it … This is being rolled out at the time of publishing." For everyone else: "The setting remains opt-in and off by default for existing tenants." Two details that matter when you test: "Only the P1 MAIL FROM (envelope sender) address is evaluated. The P2 From header is not checked." Rejected mail gets "550 5.7.68 TenantInboundAttribution; Direct Send not allowed for this organization from unauthorized sources". "Changes propagate across the service within 30 minutes." Microsoft lists third-party forwarding without SRS as a known issue.

- **Who acts:** Exchange admins of existing tenants, when ready. MSPs that create new tenants: now, because printers and apps that send through Direct Send are rejected in new tenants.
- **Check:** Exchange admin center > Reports > Mail flow > Change Optics Report, Direct Send scenario: list the devices and apps that use Direct Send. For one message: `Get-MessageTraceV2 -MessageId "<message ID>" | Get-MessageTraceDetailV2 | Format-List`. Current setting: `Get-OrganizationConfig | Format-List RejectDirectSend` (read-only).
- **Do this:** create a partner inbound connector (TLS certificate or IP) for each legitimate sender, then turn the setting on with `Set-OrganizationConfig -RejectDirectSend $true`.
- **Source:** [Reject Direct Send now generally available in Exchange Online](https://techcommunity.microsoft.com/blog/exchange/reject-direct-send-now-generally-available-in-exchange-online/4573787) (Exchange Team Blog, 16 November 2026). Related: [Exchange Online Protection Kit](../../kits/exchange-online-protection.md).

### N-able Mail Assure and SpamExperts Hosted Cloud: security incident (17 to 19 November 2026)

N-able's status page (event 202672, start 17 November 2026 03:00 UTC): "we determined that the disruption was caused by a security incident affecting the Mail Assure and SpamExperts Hosted Cloud environment." "We are aware of unauthorized access to one of the servers in the Mail Assure and SpamExperts Hosted Cloud." "at this time we do not have evidence that customer data was compromised, including access to tenants' mailboxes." "This is unrelated to the N-central incident." On 18 November N-able "contacted Mail Assure and SpamExperts Hosted Cloud partners directly by email with information relevant to their environment and whether action is required or not". Update of 19 November, 15:16 UTC: "Core mail flow is still available, and inbound and outbound mail filtering continue to operate normally. Portal and API access remain disabled as a precaution."

- **Who acts:** MSPs and admins who filter Microsoft 365 or Exchange mail through Mail Assure or SpamExperts Hosted Cloud.
- **Check:** N-able's partner email for "whether action is required". While the portal is off, quarantine release and log review are not possible: watch Exchange admin center > Mail flow > Message trace for delivery gaps. If the service uses an app in Entra, review it: Entra admin center > Enterprise applications > the app > Sign-in logs (service principal sign-ins) and Permissions.
- **Source:** [N-able status, event 202672](https://uptime.n-able.com/event/202672/) (read 19 November 2026); [The Hacker News](https://thehackernews.com/2026/11/n-able-confirms-hackers-accessed-cloud.html) (19 November 2026).

### MC1474106: Teams message snippets in Advanced Hunting, GA completes late November 2026

Defender for Office 365 adds a "MessageContents table in Advanced Hunting for Microsoft Teams messages" with "access to Teams message snippets and associated message metadata". GA: "Beginning in late September 2026 and expected to complete by late November 2026 (previously mid-November)".

- **Who acts:** Defender for Office 365 and SOC admins, privacy and compliance leads.
- **Check:** before GA completes, list who can run Advanced Hunting in your tenant (Defender portal > Permissions), because they will see Teams message snippets.
- **Source:** [MC1474106](https://mc.merill.net/message/MC1474106).

## Also logged

- **Defender for Office 365, November 2026: "The SyntheticMediaDetectionEvents table in Microsoft Defender XDR advanced hunting contains details about synthetic media (deepfake) detected in Microsoft Teams".** Check that the table exists in your tenant's schema (Defender XDR > Hunting > Advanced hunting) before you write rules on it. [What's new in Defender for Office 365](https://learn.microsoft.com/en-us/defender-office-365/defender-for-office-365-whats-new).
- **MC1556088, Teams ends support for iOS 17 and iPadOS 17 "starting mid-December 2026"; Act by 2 January 2027.** Existing app versions keep working without support. [MC1556088](https://mc.merill.net/message/MC1556088).
- **Exchange Team Blog, 9 November: mailbox migrations (MRS) between on-premises Exchange and Microsoft 365 can use OAuth.** "OAuth offers a secure alternative to using the Basic authentication credentials (username and password) of a privileged on-premises Active Directory user." It needs Exchange Server SE or Exchange 2019 CU15 with the October 2026 ESU, worldwide tenants only; "No action is required". Create new migration endpoints with OAuth and retire the privileged account after current batches finish. [Now available: OAuth for on-premises Exchange mailbox migrations](https://techcommunity.microsoft.com/blog/exchange/now-available-oauth-authentication-for-on-premises-exchange-mailbox-migrations-t/4571777).
- **MC1551122, SharePoint temporary authentication URLs retire: "Starting April 1, 2027, SharePoint temporary authentication URLs will be retired."** Action only for custom Power Apps or Power Automate controls, actions or connectors that use them. [MC1551122](https://mc.merill.net/message/MC1551122).
- **MC1552394, Viva Engage: "Starting December 7, 2026, users will no longer be able to create new Teams town hall events from Engage."** "Previously scheduled events will run as planned." [MC1552394](https://mc.merill.net/message/MC1552394).
- **MC1279093, Defender for Office 365 Promotions tag and folder: rollout "is expected to complete by mid-February 2027 (previously late November 2026)"; DoD, GCC and GCC High "end of March 2027".** [MC1279093](https://mc.merill.net/message/MC1279093).
- **MC1392563, OneDrive on onedrive.cloud.microsoft: "expect to complete by end of September 2027 (previously early August 2026)".** "Existing links continue to work". Make sure proxies, firewalls and Conditional Access app controls allow *.cloud.microsoft. [MC1392563](https://mc.merill.net/message/MC1392563).
- **MC1558030, OneDrive sync will "exclude new folders named node_modules from syncing by default, beginning December 14, 2026"; Act by 14 December 2026.** No security impact. [MC1558030](https://mc.merill.net/message/MC1558030).
- **Teams date moves (19 November): MC1518033 onboarding workflow and MC1540351 tag members to channels GA "mid-March 2027", MC1528011 external presenter support "late March 2027", and MC1532259 retires Translate slides in PowerPoint Live.** None changes a security setting. [MC1518033](https://mc.merill.net/message/MC1518033).

Related guides: [Exchange Online SMTP AUTH basic auth checklist](../../guides/exchange-online-smtp-auth-basic-auth-checklist.md) · [EOP preset policies and DMARC](../../guides/exchange-online-protection-preset-policies-dmarc.md).

More: [all Email & collaboration news](../topic/email-collaboration/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 20 November 2026. Runbook Lab is not affiliated with Microsoft.
