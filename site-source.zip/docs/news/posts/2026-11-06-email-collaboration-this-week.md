---
date:
  created: 2026-11-06 12:10:00
slug: email-collaboration-this-week-2026-11-06
categories:
  - Email & collaboration
description: "Exchange Online Calendar Sharing moves to XTAP by 23 November, last Exchange 2016/2019 update, Teams QR blur and bot block dates, an Outlook file sharing slip."
rl_type: news
rl_kits: [exo, m365]
rl_controls: []
---

# Email & collaboration this week: 16 changes (6 November 2026)

Sixteen confirmed Exchange, Outlook, Teams and Defender for Office 365 changes from the week to 6 November 2026, each with who acts, the check and the source. One date moved after publication: Microsoft's rollout of cross-tenant Calendar Sharing through Cross-Tenant Access Policy was due to complete on 6 November and is now expected by 23 November 2026 (Worldwide).

<!-- more -->

!!! info "Updated 11 November 2026: correction"
    Two dates in this roundup moved after we published it. Cross-tenant Calendar Sharing to Cross-Tenant Access Policy: MC1446796, updated 9 November 2026, now gives Worldwide completion as "November 23, 2026", and the Exchange Team Blog (table updated 9 November 2026) agrees; the Gov rollout "is still paused". The .msix attachment block (MC1488841) now rolls out early to mid-December 2026. See [the Calendar Sharing item](#mc1446796-cross-tenant-calendar-sharing-moves-to-cross-tenant-access-policy-by-6-november-2026).

This is our weekly Email & collaboration roundup. We re-read the primary source for every item on 6 November 2026, except the Planner Agent post (MC1539002), where we rely on our notes from 5 November.

## Already briefed

1. **Project usage report retires on 4 December 2026; export the data before 20 November.** Microsoft 365 admins who keep Project usage data. Brief: [Project usage report retirement](2026-11-06-project-usage-report-retirement-mc1539001.md). Source: [MC1539001](https://mc.merill.net/message/MC1539001).
2. **Exchange Server 2016 and 2019 get no more security updates after October 2026.** Anyone still running them, including hybrid management servers. Brief: [Exchange 2016/2019 ESU end](2026-11-03-exchange-server-2016-2019-esu-end-no-more-updates.md). Source: [KB5128896](https://support.microsoft.com/en-gb/servicing/exchange/server/update/2026/5128896).
3. **Outlook adds .msix to the default blocked attachment types, rolling out early to mid-December 2026 (MC1488841 updated 10 November; previously to mid-November).** Exchange Online admins with custom OwaMailboxPolicy settings. Brief: [Outlook blocks .msix attachments](2026-11-03-outlook-blocks-msix-attachments-owa-mailbox-policy.md). Source: [MC1488841](https://mc.merill.net/message/MC1488841).
4. **The month's dated Microsoft 365 admin changes in one list.** Brief: [Microsoft 365 changes in November 2026](2026-11-04-microsoft-365-changes-november-2026.md).

## New this week

### MC1446796: cross-tenant Calendar Sharing moves to Cross-Tenant Access Policy by 23 November 2026 { #mc1446796-cross-tenant-calendar-sharing-moves-to-cross-tenant-access-policy-by-6-november-2026 }

Updated 11 November 2026: Microsoft updated MC1446796 on 9 November 2026. Worldwide, it now expects to complete "by September 15, 2026 for Free/Busy, Mailtips and November 23, 2026 (previously November 3) for Calendar Sharing", and says "Gov rollout of this feature is still paused at this time." The Exchange Team Blog post (change log "11/9/2026: Updated availability dates in the table") gives the same date and shows "Rollout paused" for GCC, GCC High and DoD Calendar Sharing; Free/Busy and MailTips show "Completed" for Worldwide and GCC. Previously this item gave 6 November as the completion date, from the version of MC1446796 we read on 6 November.

Exchange Online is moving cross-tenant Free/Busy, MailTips and Calendar Sharing off EWS organization relationships and onto Microsoft 365 Cross-Tenant Access Policy (XTAP). Microsoft expects to complete the rollout "by September 15, 2026 for Free/Busy, Mailtips and November 6, 2026 (previously October 30) for Calendar Sharing". "Exchange Web Services (EWS) deprecation begins October 1, 2026", and temporary EWS access lasts "until the final EWS shutdown on April 1, 2027." If you do nothing, partner organisations may stop seeing your tenant's "Free/Busy, MailTips, or shared calendars." The post was last updated on 30 October 2026 and says "Gov rollout of this feature is paused at this time."

- **Who acts:** Exchange Online admins with organization relationships or sharing policies to other Microsoft 365 tenants. The post's Act by date (1 October 2026) has already passed.
- **Check:** in Exchange Online PowerShell, `Get-OrganizationRelationship | Format-List Name, DomainNames, Enabled, FreeBusyAccessEnabled, FreeBusyAccessLevel, FreeBusyAccessScope, MailTipsAccessEnabled, MailTipsAccessLevel, MailTipsAccessScope` and `Get-SharingPolicy | Format-List Name, Domains, Enabled, Default`. Any enabled relationship to a Microsoft 365 partner needs moving to XTAP using Microsoft's migration guide.
- **Source:** [MC1446796](https://mc.merill.net/message/MC1446796) (updated 9 November 2026; read 11 November 2026) · [Exchange Team Blog: Cross-tenant Free/Busy, MailTips, and Calendar Sharing are moving to Cross-Tenant Access Policy](https://techcommunity.microsoft.com/blog/exchange/cross-tenant-freebusy-mailtips-and-calendar-sharing-are-moving-to-cross-tenant-a/4545169) (table updated 9 November 2026; read 11 November 2026). Guide: [Migrating to Microsoft 365 Cross-Tenant Access Policy for sharing Free/Busy, Calendars, and MailTips](https://learn.microsoft.com/exchange/sharing/migrate-to-m365-xtap). Related: [Exchange Online Protection Kit](../../kits/exchange-online-protection.md).

### Exchange Server October 2026 security update (13 October): the last one for 2016 and 2019

Microsoft's October 2026 security updates cover Exchange SE RTM, Exchange 2019 CU14 and CU15, and Exchange 2016 CU23. For 2016 and 2019 you "must be enrolled into the Period 2 ESU program". Microsoft says "October 2026 is the last month when customers who enrolled in the Period 2 Extended Security Update (ESU) program are eligible", and from now "Updates will be released for Exchange Subscription Edition (SE) only." The update also fixes two issues: published calendars (.ics) returning HTTP 500 (KB5126672) and a ContentEngine deadlock from missing Korean WordBreaker rule files (KB5130098). The Exchange 2019 CU15 KB lists CVE-2026-70571 among the fixes. The post was published on 13 October and updated on 16 October.

- **Who acts:** on-premises and hybrid Exchange admins, and MSPs with Exchange estates. Microsoft says to install the update on every Exchange server and on machines that run the Exchange Management Tools.
- **Check:** run the Exchange Server Health Checker script on each server, or `Get-ExchangeServer | Format-Table Name, Edition, AdminDisplayVersion` in the Exchange Management Shell, and confirm every server reports the October 2026 build. Any 2016 or 2019 server left after that is a plan for Exchange SE, not a patch job.
- **Source:** [Released: October 2026 Exchange Server Security Updates](https://techcommunity.microsoft.com/t5/exchange-team-blog/released-october-2026-exchange-server-security-updates/ba-p/4563014) · [KB5128896](https://support.microsoft.com/en-gb/servicing/exchange/server/update/2026/5128896). Related: [Exchange 2016/2019 ESU end](2026-11-03-exchange-server-2016-2019-esu-end-no-more-updates.md) · [Exchange, OWA and mail flow after the October Windows Server updates](2026-10-31-exchange-owa-mail-flow-october-windows-server-updates.md).

## Also logged

- **MC1530613, Teams meeting impersonation protection: GA from mid-December to late December 2026.** Teams shows warnings and risk indicators when it detects a possible impersonation attempt in a meeting. "No immediate admin action is required"; tell the helpdesk and the SOC what users will see. [MC1530613](https://mc.merill.net/message/MC1530613).
- **MC1532241, Defender XDR advanced hunting for Teams calls and meetings: GA "Beginning in early November 2026 and expected to complete by mid-November 2026".** It adds the CallActivityEvents table, which joins to MessageEvents on ThreadId. "This capability is available to organizations with Microsoft Defender for Office 365 Plan 2." Check: Defender portal > Advanced hunting, run `CallActivityEvents | take 10` once the table appears. [MC1532241](https://mc.merill.net/message/MC1532241).
- **MC1536045, Defender URBAC: "Emails associated with alerts" now covers URL-click alerts, "Available now".** Analysts with the "Email & collaboration content: Emails associated with alerts" permission can now preview and download emails tied to potentially malicious URL-click alerts too. Check who holds it in Defender portal > System > Permissions > Microsoft Defender XDR > Roles. [MC1536045](https://mc.merill.net/message/MC1536045). Related: [Defender RBAC auto-enable](2026-11-05-defender-rbac-auto-enable-review-imported-roles.md).
- **MC1536056, Teams Facilitator Protection skill: "Beginning in late January 2027 and expected to complete by mid-February 2027".** In meetings with external people, it scans the transcript for attempts to get users to reveal sensitive information and offers to end the meeting or limit sharing. "No action is required to enable the Protection skill." [MC1536056](https://mc.merill.net/message/MC1536056).
- **MC1509801, Teams Weaponizable File Protection custom extensions: GA "Beginning in early December 2026" (previously early November), complete by mid-December 2026 (previously mid-November).** Tenants that have the protection on keep the Microsoft-recommended list by default. Admins can add or remove extensions, or reset to that list. [MC1509801](https://mc.merill.net/message/MC1509801).
- **MC1470410, Teams QR code protection for external messages: GA "expected to complete by end of November 2026 (previously late October)".** "Images containing QR codes sent by external users will be blurred by default in Teams messages." Users can reveal the image. "No administrator configuration or policy changes are required"; brief the helpdesk. [MC1470410](https://mc.merill.net/message/MC1470410).
- **MC1459141, Teams policy to block identified external meeting bots: GA completes by "end of November 2026 (previously late October)".** "Default state: Off." It is a new option in the "Manage bots" meeting protection settings in the Teams admin center, assigned through meeting policies. Pilot it with one group first. [MC1459141](https://mc.merill.net/message/MC1459141).
- **MC1539002, Copilot Chat Planner Agent: the post carries "Act by Dec 4, 2026" but no required action.** The changes are "enabled by default for users with access to Planner Agent". Not re-read today. [MC1539002](https://mc.merill.net/message/MC1539002).
- **MC1245222, new Outlook for Windows local file sharing: worldwide rollout now "mid-January 2027" (previously early November 2026), complete by mid-February 2027 (previously early December 2026).** Users can attach locally stored Word, Excel and PowerPoint files in the new Outlook for Windows. The feature is on by default, and "No admin action is required"; existing Outlook and Exchange policies still apply. [MC1245222](https://mc.merill.net/message/MC1245222).
- **Update, MC1530615, Teams report guest invitations: GA begins "mid-November 2026 (previously early November)".** Setting: Teams admin center > Messaging policies > Report a security concern. [MC1530615](https://mc.merill.net/message/MC1530615).

Related guides: [Exchange Online SMTP AUTH basic auth checklist](../../guides/exchange-online-smtp-auth-basic-auth-checklist.md) · [EOP preset policies and DMARC](../../guides/exchange-online-protection-preset-policies-dmarc.md).

More: [all Email & collaboration news](../topic/email-collaboration/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 11 November 2026. Runbook Lab is not affiliated with Microsoft.
