---
date:
  created: 2026-10-31 12:00:00
slug: cisa-kev-cisco-asa-gitlab-ivanti-php
categories:
  - Threats & vulnerabilities
description: "CISA KEV, 26 to 30 October 2026: exploited Cisco ASA/FTD, GitLab, Ivanti Connect Secure and PHP flaws, incl. PAN-OS. What to patch and read-only checks."
rl_type: news
rl_kits: []
rl_controls: []
---

# CISA KEV this week: Cisco ASA, GitLab, Ivanti, PHP

Between 26 and 30 October 2026 CISA added actively exploited flaws in Cisco Secure Firewall ASA and FTD, GitLab CE/EE, Ivanti Connect Secure and PHP to its Known Exploited Vulnerabilities (KEV) catalog, with federal due dates from 29 October to 13 November. Network, VPN, DevOps and web server owners should patch now, whatever sector they are in.

<!-- more -->

!!! info "Updated 1 November 2026"
    Palo Alto Networks says the PHP flaws are being exploited against PAN-OS firewalls and Panorama: "Active exploitation has been observed targeting the Palo Alto Networks management interface exposed to the internet." Palo Alto lists fixed hotfixes for every supported branch. See the new section [PAN-OS and Panorama](#pan-os-and-panorama-php2shell). We also added CISA's note on other Ruby-based products to the GitLab section.

!!! note "Runbook card"
    **What changes:** eight CVEs are now listed as exploited in the wild (catalog version 2026.10.30).<br>
    **Who:** owners of Cisco ASA/FTD remote access VPN, self-managed GitLab, Ivanti Connect Secure, PHP web servers, VMware ESX and Linux hosts.<br>
    **By when:** the KEV due dates are binding only on US federal civilian agencies, but they are a fair "patch by" date for everyone: 29 October (PHP), 31 October (Linux kernel), 1 November (Cisco, GitLab), 2 November and 13 November (Ivanti), 11 November (VMware ESX).<br>
    **Do this:** 1. Find which of these products you run and where they face the internet. 2. Apply the vendor fix from the vendor advisory. 3. Check for signs of exploitation before and after patching.<br>
    **Check:** the per-product commands below (read-only).<br>
    **Source:** [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog), read as JSON on 31 October 2026.

| CVE | Product | Added | Due | Jump to |
|---|---|---|---|---|
| CVE-2026-76418 | Cisco Secure Firewall ASA and FTD | 29 Oct | 1 Nov | [Cisco](#cisco-asa-ftd-cve-2026-76418) |
| CVE-2026-97229 | GitLab CE/EE | 29 Oct | 1 Nov | [GitLab](#gitlab-cve-2026-97229) |
| CVE-2026-111357, CVE-2026-118527 | Ivanti Connect Secure | 30 Oct | 2 Nov, 13 Nov | [Ivanti](#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527) |
| CVE-2026-109618, CVE-2026-109619 | PHP | 26 Oct | 29 Oct | [PHP](#php-cve-2026-109618-and-cve-2026-109619), [PAN-OS](#pan-os-and-panorama-php2shell) |
| CVE-2026-41709, CVE-2026-46300 | VMware ESX, Linux kernel | 28 Oct | 11 Nov, 31 Oct | [Also added](#also-added-vmware-esx-and-linux-kernel) |

CISA lists "Known ransomware campaign use" as "Unknown" for all of them.

## Cisco ASA / FTD: CVE-2026-76418 {#cisco-asa-ftd-cve-2026-76418}

CISA: an "unchecked return value to NULL pointer dereference vulnerability that could allow an unauthenticated, remote attacker to cause the device to reload unexpectedly, resulting in a denial of service (DoS) condition."

Cisco's advisory (first published 28 October 2026, CVSS 8.6) says the flaw is in the Remote Access SSL VPN service and is due to "logic errors when secondary authentication is configured on a tunnel group". A device is affected when it runs a vulnerable release, the SSL remote access VPN login service is reachable, and secondary authentication is configured in the tunnel group scope. Cisco says it "became aware of active exploitation of this vulnerability" in October 2026 and that "There are no workarounds".

Check (read-only, ASA CLI):

```text
show version
show running-config webvpn
show running-config tunnel-group | include tunnel-group|secondary-authentication-server-group
show running-config webvpn | include tunnel-group-list
```

If `webvpn` is enabled on an interface and any tunnel group, including `DefaultWEBVPNGroup`, has `secondary-authentication-server-group`, the device is in scope. Cisco notes that disabling the group list does not remove exposure if the default group uses secondary authentication. On FTD, review the deployed remote access VPN policy in Secure Firewall Management Center or Device Manager.

Fix: use the Fixed Software section of the [Cisco advisory](https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-asaftd-tunnel-dos-s6mgkb75) to find the first fixed release for your train. Watch for unexpected reloads (`show crashinfo`): each one drops every remote access VPN session.

## GitLab: CVE-2026-97229 {#gitlab-cve-2026-97229}

CISA: an integer overflow "that could allow an unauthenticated user to execute arbitrary code on the GitLab server via a specially crafted regular expression in a CI/CD configuration, due to insufficient regular expression validation."

GitLab's critical patch release of 12 October 2026 rates it CVSS 10.0 and lists impacted versions as "all versions from 19.2 before 19.2.8, 19.3 before 19.3.5, and 19.4 before 19.4.2". GitLab.com and GitLab Dedicated are already patched; this is for self-managed instances. CISA notes that other products "can potentially be affected by the same underlying Ruby/Onigmo Integer Overflow issue" and points to a [Ruby advisory of 23 October 2026](https://www.ruby-lang.org/en/news/2026/10/23/regexp-fixes-for-gitlab-cves). If you run other self-hosted Ruby applications that compile regular expressions from untrusted input, read that advisory and update the Ruby runtime as it says. We have not read the Ruby advisory, so we don't list Ruby versions here.

Check: Admin area > Dashboard shows the version, or open `/help` on your instance. On the server: `sudo gitlab-rake gitlab:env:info`.

Fix: upgrade to 19.4.2, 19.3.5 or 19.2.8 or later. If you run a release older than 19.2, GitLab's notice doesn't say whether it is affected; move to a supported, patched release. GitLab published threat detections for exploitation attempts in the same release note. Review CI/CD configuration changes from untrusted contributors, and rotate runner and deploy tokens if you find signs of exploitation.

## Ivanti Connect Secure: CVE-2026-111357 and CVE-2026-118527 {#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527}

Both were added on 30 October 2026. CISA's descriptions:

- **CVE-2026-111357** (due 2 November): a "missing authentication for critical function vulnerability that could allow a local authenticated attacker to escalate their privileges."
- **CVE-2026-118527** (due 13 November): a "generation of predictable numbers or identifiers vulnerability that allows a remote authenticated attacker to upload files with attacker-controlled content to a known location on disk."

CISA says each "can be chained" with the other and with CVE-2026-104935. CISA links Ivanti's [security advisory](https://hub.ivanti.com/s/article/Security-Advisory-Ivanti-Connect-Secure-CVE-2026-104935?language=en_US); we have not read it yet, so we don't list fixed versions here.

Do this: confirm your Connect Secure version in the admin console, apply the fixed release named in Ivanti's advisory, and run Ivanti's integrity checker if your version supports it. Treat the appliance as a likely target: review admin logins and any files that appeared on it recently.

## PHP: CVE-2026-109618 and CVE-2026-109619 {#php-cve-2026-109618-and-cve-2026-109619}

Added on 26 October 2026, due 29 October. CISA: CVE-2026-109618 "allows for unauthenticated remote code execution" through memory corruption; CVE-2026-109619 is a "stale internal request-state vulnerability that allows for unauthenticated remote code execution." CISA published an alert on 21 October, "Critical Vulnerabilities in PHP Require Immediate Patching".

Check: `php -v` on each web host, and the PHP version in every container base image you build from.

Fix: install the latest patch release of your PHP branch from php.net or your distribution. Take PHP versions that no longer receive security fixes off the internet.

`php -v` does not cover appliances that embed PHP. Network appliances need the vendor's own fix: see Palo Alto Networks below.

## PAN-OS and Panorama: PHP2Shell exploited {#pan-os-and-panorama-php2shell}

Palo Alto Networks' advisory for CVE-2026-109618 (published 21 October 2026, updated 30 October 2026) rates the PHP flaws "Severity 9.2 · CRITICAL" with "Urgency HIGHEST" and "Exploit Maturity ATTACKED". Its exploitation status: "Active exploitation has been observed targeting the Palo Alto Networks management interface exposed to the internet."

- **Affected:** "PAN-OS software on PA-Series and VM-Series firewalls and on Panorama (virtual and M-Series)". The advisory lists Cloud NGFW and GlobalProtect App as not affected.
- **Risk:** "The risk is highest on PAN-OS when you allow access to the management interface from external IP addresses on the internet." Palo Alto says you can reduce it "by restricting access to a jump box that is the only system allowed to access the management interface."
- **Fixed (unaffected at or above):** 12.2.4-h1 · 12.1.4-h13, 12.1.7-h11, 12.1.10-h3 · 11.2.4-h23, 11.2.7-h23, 11.2.10-h16, 11.2.13-h4, 11.2.16-h1 · 11.1.4-h38, 11.1.6-h40, 11.1.7-h12, 11.1.10-h36, 11.1.13-h16, 11.1.16-h4 · 10.2.7-h39, 10.2.10-h42, 10.2.13-h27, 10.2.16-h12, 10.2.18-h13.
- **One exception:** "11.2.10-h16 which only includes the fix for PHP vulnerabilities; 11.2.10-h17 includes fixes for both" (PHP and the Node.js brotli flaw). On 11.2.10, go to h17.

Check (read-only, PAN-OS CLI):

```text
show system info | match sw-version
show interface management
```

Then in the web interface, **Device > Setup > Interfaces > Management**: the Permitted IP Addresses list should hold only internal admin addresses or a jump host. Under **Network > Network Profiles > Interface Mgmt**, check that no management profile is attached to an internet-facing interface.

Do this: 1. Move management access off the internet (jump host only). 2. Install the hotfix for your branch from the list above. 3. If the management interface was reachable from the internet before you patched, treat the device as possibly compromised: review admin and configuration logs and follow Palo Alto's guidance in the advisory. Customers with a Threat Prevention subscription can turn on the Threat IDs the advisory lists, but those only protect management traffic that passes through a dataplane port with decryption, as the advisory explains.

## Also added: VMware ESX and Linux kernel {#also-added-vmware-esx-and-linux-kernel}

Added on 28 October 2026:

- **CVE-2026-41709, Broadcom VMware ESX** (due 11 November): "an insufficient logging vulnerability that could allow a malicious actor with admin access to perform certain operations without being logged." Check who holds ESX admin access, and patch per Broadcom's advisory.
- **CVE-2026-46300, Linux kernel** (due 31 October): a missing initialisation flaw in socket buffer coalescing during ESP (IPsec) input processing that allows "unintended modification of page-cache-backed data". Install your distribution's kernel update and reboot. Check with `uname -r`.

## Why it matters

Edge devices and developer platforms keep showing up together in KEV for a reason: a VPN concentrator or a CI server is reachable from the internet and holds the keys to everything behind it. No Microsoft product was added to KEV in this period.

Related: all dated actions we track are on [Microsoft 365 security deadlines](../../guides/deadlines.md). For the Microsoft side of the estate, start with the [M365 Hardening Kit](../../kits/m365-hardening.md). More [Threats & vulnerabilities news](../topic/threats-vulnerabilities/).

## Sources

- [CISA Known Exploited Vulnerabilities catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog), JSON feed via the [cisagov/kev-data mirror](https://github.com/cisagov/kev-data), catalog version 2026.10.30, read 31 October 2026
- [Cisco Security Advisory cisco-sa-asaftd-tunnel-dos-s6mgkb75](https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-asaftd-tunnel-dos-s6mgkb75) (version 1.0, 28 October 2026, read 31 October 2026)
- [GitLab Critical Patch Release: 19.4.2, 19.3.5, 19.2.8](https://docs.gitlab.com/releases/patches/patch-release-gitlab-19-4-2-released/) (12 October 2026, read 31 October 2026)
- [Palo Alto Networks security advisory CVE-2026-109618](https://security.paloaltonetworks.com/CVE-2026-109618) (published 21 October 2026, updated 30 October 2026, read 1 November 2026)
- [CISA alert: Critical Vulnerabilities in PHP Require Immediate Patching](https://www.cisa.gov/news-events/alerts/2026/10/21/critical-vulnerabilities-php-require-immediate-patching) (21 October 2026, as linked from the KEV entry)

Last reviewed: 1 November 2026. Runbook Lab is not affiliated with Microsoft, Cisco, GitLab, Ivanti or Palo Alto Networks.
