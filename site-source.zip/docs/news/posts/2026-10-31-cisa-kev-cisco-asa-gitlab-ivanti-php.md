---
date:
  created: 2026-10-31 12:00:00
slug: cisa-kev-cisco-asa-gitlab-ivanti-php
categories:
  - Threats & vulnerabilities
description: "CISA KEV, 26 to 30 October 2026: exploited Cisco ASA/FTD, GitLab, Ivanti Connect Secure and PHP flaws, incl. PAN-OS. What to patch and read-only checks."
rl_type: news
rl_kits: []
rl_controls: []
rl_tickets:
- summary: Patch Cisco ASA/FTD CVE-2026-76418 (CISA KEV)
  priority: Highest
  due: '2026-11-01'
  due_note: CISA's KEV due date (1 November 2026; https://www.cisa.gov/known-exploited-vulnerabilities-catalog). It binds only US federal civilian agencies; we use it as a fair patch-by date.
  steps:
  - Find ASA/FTD devices with the SSL remote access VPN enabled and secondary authentication configured in a tunnel group (show running-config webvpn; show running-config tunnel-group).
  - Install the first fixed release for your train from the Fixed Software section of Cisco advisory cisco-sa-asaftd-tunnel-dos-s6mgkb75. Cisco says there are no workarounds.
  - On FTD, review the deployed remote access VPN policy in Secure Firewall Management Center or Device Manager.
  - Watch for unexpected reloads (show crashinfo).
  source: https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-asaftd-tunnel-dos-s6mgkb75
- summary: Upgrade self-managed GitLab for CVE-2026-97229 (CISA KEV)
  priority: Highest
  due: '2026-11-01'
  due_note: CISA's KEV due date (1 November 2026; https://www.cisa.gov/known-exploited-vulnerabilities-catalog). It binds only US federal civilian agencies; we use it as a fair patch-by date.
  steps:
  - Check the version (Admin area > Dashboard, /help, or sudo gitlab-rake gitlab:env:info).
  - Upgrade to 19.4.2, 19.3.5 or 19.2.8 or later.
  - 'If you run GitLab on your own Ruby (from source or your own container image), also update Ruby: Alpine Linux says 3.3.13, 3.4.12, 4.0.9 or later (check with ruby -v inside the GitLab container or host).'
  - On a release older than 19.2, move to a supported, patched release.
  - Review CI/CD configuration changes from untrusted contributors; rotate runner and deploy tokens if you find signs of exploitation.
  source: https://docs.gitlab.com/releases/patches/patch-release-gitlab-19-4-2-released/
- summary: Upgrade Ivanti Connect Secure for CVE-2026-111357 and CVE-2026-118527 (CISA KEV)
  priority: Highest
  due: '2026-11-02'
  due_note: CISA's KEV due date (2 November 2026 for CVE-2026-111357; 13 November 2026 for CVE-2026-118527; https://www.cisa.gov/known-exploited-vulnerabilities-catalog). It binds only US federal civilian agencies; we use it as a fair patch-by date.
  steps:
  - Confirm your Connect Secure version in the admin console.
  - Upgrade to 25.1.1.3, 25.1.3.1 or 22.8R2.6 or later, whichever matches your branch; confirm the fixed build in Ivanti's advisory.
  - Run Ivanti's Integrity Checker Tool before and after the upgrade, but a clean result does not rule out compromise (Volexity).
  - Check web logs for welcome.cgi requests with an X-DSCGI-PATH header that does not match the URL, check /tmp/, and use memory and network forensics if you suspect compromise.
  - Review admin logins and any files that appeared on the appliance recently. Patching does not remove an implant that is already there.
  - If the appliance may have been compromised, rotate LAPS passwords and any Active Directory credentials the appliance uses or could reach, and review who read BitLocker recovery keys in Active Directory or Entra ID as far back as your logs go (our advice, not Volexity's).
  source: https://cyber.gc.ca/en/alerts-advisories/ivanti-security-advisory-av26-1035
- summary: Update PHP for CVE-2026-109618 and CVE-2026-109619 (CISA KEV)
  priority: Highest
  due: '2026-10-29'
  due_note: CISA's KEV due date (29 October 2026; https://www.cisa.gov/known-exploited-vulnerabilities-catalog). It binds only US federal civilian agencies; we use it as a fair patch-by date.
  steps:
  - Run php -v on each web host and check the PHP version in every container base image you build from.
  - Install the latest patch release of your PHP branch from php.net or your distribution.
  - Take PHP versions that no longer receive security fixes off the internet. Appliances that embed PHP need the vendor's fix (see the PAN-OS ticket).
  source: https://www.cisa.gov/known-exploited-vulnerabilities-catalog
- summary: Patch PAN-OS and Panorama for PHP2Shell (CVE-2026-109618)
  priority: Highest
  steps:
  - 'Move management interface access off the internet (jump host only): Device > Setup > Interfaces > Management.'
  - Install the hotfix for your branch from Palo Alto's advisory (on 11.2.10, go to h17).
  - 'If the management interface was reachable from the internet before you patched, treat the device as possibly compromised: review admin and configuration logs and follow Palo Alto''s guidance.'
  source: https://security.paloaltonetworks.com/CVE-2026-109618
- summary: Patch VMware ESX CVE-2026-41709 (CISA KEV)
  priority: High
  due: '2026-11-11'
  due_note: CISA's KEV due date (11 November 2026; https://www.cisa.gov/known-exploited-vulnerabilities-catalog). It binds only US federal civilian agencies; we use it as a fair patch-by date.
  steps:
  - Check who holds ESX admin access.
  - Patch per Broadcom's advisory.
  source: https://www.cisa.gov/known-exploited-vulnerabilities-catalog
- summary: Update the Linux kernel for CVE-2026-46300 (CISA KEV)
  priority: High
  due: '2026-10-31'
  due_note: CISA's KEV due date (31 October 2026; https://www.cisa.gov/known-exploited-vulnerabilities-catalog). It binds only US federal civilian agencies; we use it as a fair patch-by date.
  steps:
  - Check the running kernel with uname -r.
  - Install your distribution's kernel update and reboot.
  source: https://www.cisa.gov/known-exploited-vulnerabilities-catalog
---

# CISA KEV this week: Cisco ASA, GitLab, Ivanti, PHP

Between 26 and 30 October 2026 CISA added actively exploited flaws in Cisco Secure Firewall ASA and FTD, GitLab CE/EE, Ivanti Connect Secure and PHP to its Known Exploited Vulnerabilities (KEV) catalog, with federal due dates from 29 October to 13 November. Network, VPN, DevOps and web server owners should patch now, whatever sector they are in.

<!-- more -->

!!! info "Updated 8 November 2026"
    Upgraded GitLab and still exposed? Alpine Linux says that if you run GitLab on your own Ruby (built from source or in your own container image) rather than GitLab's packages, upgrading GitLab is not enough: you also need Ruby 3.3.13, 3.4.12, 4.0.9 or later. Alpine saw exploitation attempts against its own GitLab on 20 and 21 October 2026. See [GitLab](#gitlab-cve-2026-97229).

!!! info "Updated 3 November 2026: correction"
    Our Ivanti step told you to run Ivanti's Integrity Checker Tool with no caveat. Volexity, which found this exploit chain, says that because the chain changes code in memory only and restores configuration data, "the tool does not detect any modifications", so a clean result does not rule out compromise. We added the web log, /tmp/ and forensics checks Volexity recommends, and a note that the attackers went after LAPS passwords and BitLocker recovery keys. See [Ivanti Connect Secure](#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527).

!!! info "Updated 2 November 2026"
    The Canadian Centre for Cyber Security lists the Ivanti Connect Secure versions that are affected: anything before 25.1.1.3, 25.1.3.1 or 22.8R2.6, depending on your branch. It also cites open-source reporting that CVE-2026-111357 is being exploited in the wild. CISA marks CVE-2026-111357 for forensic triage; its federal due date is 2 November 2026. See [Ivanti Connect Secure](#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527).

!!! info "Updated 1 November 2026"
    Palo Alto Networks says the PHP flaws are being exploited against PAN-OS firewalls and Panorama: "Active exploitation has been observed targeting the Palo Alto Networks management interface exposed to the internet." Palo Alto lists fixed hotfixes for every supported branch. See the new section [PAN-OS and Panorama](#pan-os-and-panorama-php2shell). We also added CISA's note on other Ruby-based products to the GitLab section.

!!! note "Runbook card"
    **What changes:** eight CVEs are now listed as exploited in the wild (catalog version 2026.10.30).<br>
    **Who:** owners of Cisco ASA/FTD remote access VPN, self-managed GitLab, Ivanti Connect Secure, PHP web servers, VMware ESX and Linux hosts.<br>
    **By when:** the KEV due dates are binding only on US federal civilian agencies, but they are a fair "patch by" date for everyone: 29 October (PHP), 31 October (Linux kernel), 1 November (Cisco, GitLab), 2 November and 13 November (Ivanti), 11 November (VMware ESX). Most of these dates have passed: patch now.<br>
    **Do this:** 1. Find which of these products you run and where they face the internet. 2. Apply the vendor fix from the vendor advisory. 3. Check for signs of exploitation before and after patching.<br>
    **Check:** the per-product commands below (read-only).<br>
    **Source:** [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog), read as JSON on 31 October and 2 November 2026.

<p class="rl-jira" markdown>[Add to Jira (CSV)](../../tickets/cisa-kev-cisco-asa-gitlab-ivanti-php.csv){ .rl-jira__link download } <span class="rl-jira__help">One Jira task per action in this brief. To import: as a Jira admin, Settings > System > External system import > CSV; date format yyyy-MM-dd; map Issue ID to Issue Id, and Summary, Issue Type, Priority, Due date, Labels and Description.</span></p>

| CVE | Product | Added | Due | Jump to |
|---|---|---|---|---|
| CVE-2026-76418 | Cisco Secure Firewall ASA and FTD | 29 Oct | 1 Nov | [Cisco](#cisco-asa-ftd-cve-2026-76418) |
| CVE-2026-97229 | GitLab CE/EE | 29 Oct | 1 Nov | [GitLab](#gitlab-cve-2026-97229) |
| CVE-2026-111357, CVE-2026-118527 | Ivanti Connect Secure | 30 Oct | 2 Nov, 13 Nov | [Ivanti](#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527) |
| CVE-2026-109618, CVE-2026-109619 | PHP | 26 Oct | 29 Oct | [PHP](#php-cve-2026-109618-and-cve-2026-109619), [PAN-OS](#pan-os-and-panorama-php2shell) |
| CVE-2026-41709, CVE-2026-46300 | VMware ESX, Linux kernel | 28 Oct | 11 Nov, 31 Oct | [Also added](#also-added-vmware-esx-and-linux-kernel) |

CISA lists "Known ransomware campaign use" as "Unknown" for all of them.

## Cisco ASA / FTD: CVE-2026-76418 {#cisco-asa-ftd-cve-2026-76418}

CISA: an "unchecked return value to NULL pointer dereference vulnerability that could allow an unauthenticated, remote attacker to cause the device to reload unexpectedly, resulting in a denial of service (DoS) condition."

Cisco's advisory (first published 28 October 2026, CVSS 8.6) says the flaw is in the Remote Access SSL VPN service and is due to "logic errors when secondary authentication is configured on a tunnel group". A device is affected when it runs a vulnerable release, the SSL remote access VPN login service is reachable, and secondary authentication is configured in the tunnel group scope. Cisco says it "became aware of active exploitation of this vulnerability" in October 2026 and that "There are no workarounds".

Check (read-only, ASA CLI):

```text
show version
show running-config webvpn
show running-config tunnel-group | include tunnel-group|secondary-authentication-server-group
show running-config webvpn | include tunnel-group-list
```

If `webvpn` is enabled on an interface and any tunnel group, including `DefaultWEBVPNGroup`, has `secondary-authentication-server-group`, the device is in scope. Cisco notes that disabling the group list does not remove exposure if the default group uses secondary authentication. On FTD, review the deployed remote access VPN policy in Secure Firewall Management Center or Device Manager.

Fix: use the Fixed Software section of the [Cisco advisory](https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-asaftd-tunnel-dos-s6mgkb75) to find the first fixed release for your train. Watch for unexpected reloads (`show crashinfo`): each one drops every remote access VPN session.

## GitLab: CVE-2026-97229 {#gitlab-cve-2026-97229}

CISA: an integer overflow "that could allow an unauthenticated user to execute arbitrary code on the GitLab server via a specially crafted regular expression in a CI/CD configuration, due to insufficient regular expression validation."

GitLab's Critical Patch Release of 12 October 2026 rates it CVSS 10.0 and lists impacted versions as "all versions from 19.2 before 19.2.8, 19.3 before 19.3.5, and 19.4 before 19.4.2". GitLab.com and GitLab Dedicated are already patched; this is for self-managed instances. CISA notes that other products "can potentially be affected by the same underlying Ruby/Onigmo Integer Overflow issue" and points to a [Ruby advisory of 23 October 2026](https://www.ruby-lang.org/en/news/2026/10/23/regexp-fixes-for-gitlab-cves). If you run other self-hosted Ruby applications that compile regular expressions from untrusted input, read that advisory and update the Ruby runtime as it says. We have not read the Ruby advisory; the Ruby versions below are Alpine Linux's.

**Upgraded but still vulnerable?** Alpine Linux runs GitLab in its own container image. According to BleepingComputer, the fix "required a patch to Ruby", which GitLab bundled with its official packages but Alpine's custom image did not include. Alpine's own advice: upgrading GitLab is not enough if you run GitLab with your own Ruby (from source or in your own container image); you also need Ruby 3.3.13, 3.4.12, 4.0.9 or later. Alpine's fixed image, alpinelinux/gitlab:19.3.6, contains Ruby 3.3.13 (BleepingComputer). Attackers submitted malicious CI configurations against Alpine's GitLab on 20 and 21 October 2026; Alpine found no evidence of code execution but could not rule it out, and rebuilt the instance. Check the runtime with `ruby -v` inside the GitLab container or host.

Check: Admin area > Dashboard shows the version, or open `/help` on your instance. On the server: `sudo gitlab-rake gitlab:env:info`.

Fix: upgrade to 19.4.2, 19.3.5 or 19.2.8 or later. If you run a release older than 19.2, GitLab's notice doesn't say whether it is affected; move to a supported, patched release. GitLab published threat detections for exploitation attempts in the same release note. Review CI/CD configuration changes from untrusted contributors, and rotate runner and deploy tokens if you find signs of exploitation.

## Ivanti Connect Secure: CVE-2026-111357 and CVE-2026-118527 {#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527}

Both were added on 30 October 2026. CISA's descriptions:

- **CVE-2026-111357** (due 2 November): a "missing authentication for critical function vulnerability that could allow a local authenticated attacker to escalate their privileges."
- **CVE-2026-118527** (due 13 November): a "generation of predictable numbers or identifiers vulnerability that allows a remote authenticated attacker to upload files with attacker-controlled content to a known location on disk."

CISA says each "can be chained" with the other and with CVE-2026-104935. CISA links Ivanti's [security advisory](https://hub.ivanti.com/s/article/Security-Advisory-Ivanti-Connect-Secure-CVE-2026-104935?language=en_US), which we could not open.

**Affected versions.** The Canadian Centre for Cyber Security advisory [AV26-1035](https://cyber.gc.ca/en/alerts-advisories/ivanti-security-advisory-av26-1035) (modified 30 October 2026) lists Ivanti Connect Secure "Versions prior to 25.1.1.3", "Versions prior to 25.1.3.1" and "Versions prior to 22.8R2.6". It also says: "Open-source reporting indicates that CVE-2026-111357 is being exploited in the wild." Confirm the exact fixed build for your branch in Ivanti's advisory before you schedule the upgrade.

**Forensic triage.** CISA's catalog entry for CVE-2026-111357 has forensic triage set to "Yes": check the appliance for compromise, not only patch it.

Do this: 1. Confirm your Connect Secure version in the admin console. 2. Upgrade to 25.1.1.3, 25.1.3.1 or 22.8R2.6 or later (the first versions the Canadian Centre lists as not affected), whichever matches your branch. 3. Run Ivanti's Integrity Checker Tool before and after the upgrade, but do not treat a clean result as proof (see below). 4. Review admin logins and any files that appeared on the appliance recently. Patching does not remove an implant that is already there.

**A clean Integrity Checker result does not rule out compromise.** Volexity, which found the exploit chain (published 13 October 2026; an update note says Ivanti's 29 October patch addresses the privilege escalation flaw, tracked as CVE-2026-111357, and that the rest of the post has not been updated), says that "because this exploit chain patches library code in memory only and restores configuration store data, the tool does not detect any modifications. As such, forensic investigation is required to identify evidence of exploitation." Volexity tracks the activity as UTA0576. What Volexity recommends checking:

- **Web logs:** large numbers of requests for `/dana-na/auth/url_default/welcome.cgi` with a header like `X-DSCGI-PATH: /home/webserver/htdocs/dana/fb/smb/wu.cgi` or `X-DSCGI-PATH: /home/runtime/tmp/<MD5(filename)>`. Volexity expects attackers to use other paths too, so these values are examples, not a complete list. If you can, alert on any request where the URL path and the X-DSCGI-PATH header do not match.
- **The appliance:** check the `/tmp/` directory for signs of post-exploitation activity.
- **If you suspect compromise:** network and memory forensics, not only a disk check.

**Your Windows estate.** Volexity saw the attackers go after "Active Directory credentials and secrets, including Local Administrator Password Solution (LAPS) passwords and BitLocker recovery keys". Our advice, not Volexity's: if your appliance may have been compromised, rotate LAPS passwords and any Active Directory credentials the appliance uses or could reach, and review who read BitLocker recovery keys in Active Directory or Entra ID as far back as your logs go (Volexity found the activity in the first week of October 2026, on an appliance that was already compromised).

## PHP: CVE-2026-109618 and CVE-2026-109619 {#php-cve-2026-109618-and-cve-2026-109619}

Added on 26 October 2026, due 29 October. CISA: CVE-2026-109618 "allows for unauthenticated remote code execution" through memory corruption; CVE-2026-109619 is a "stale internal request-state vulnerability that allows for unauthenticated remote code execution." CISA published an alert on 21 October, "Critical Vulnerabilities in PHP Require Immediate Patching".

Check: `php -v` on each web host, and the PHP version in every container base image you build from.

Fix: install the latest patch release of your PHP branch from php.net or your distribution. Take PHP versions that no longer receive security fixes off the internet.

`php -v` does not cover appliances that embed PHP. Network appliances need the vendor's own fix: see Palo Alto Networks below.

## PAN-OS and Panorama: PHP2Shell exploited {#pan-os-and-panorama-php2shell}

Palo Alto Networks' advisory for CVE-2026-109618 (published 21 October 2026, updated 30 October 2026) rates the PHP flaws "Severity 9.2 · CRITICAL" with "Urgency HIGHEST" and "Exploit Maturity ATTACKED". Its exploitation status: "Active exploitation has been observed targeting the Palo Alto Networks management interface exposed to the internet."

- **Affected:** "PAN-OS software on PA-Series and VM-Series firewalls and on Panorama (virtual and M-Series)". The advisory lists Cloud NGFW and GlobalProtect App as not affected.
- **Risk:** "The risk is highest on PAN-OS when you allow access to the management interface from external IP addresses on the internet." Palo Alto says you can reduce it "by restricting access to a jump box that is the only system allowed to access the management interface."
- **Fixed (unaffected at or above):** 12.2.4-h1 · 12.1.4-h13, 12.1.7-h11, 12.1.10-h3 · 11.2.4-h23, 11.2.7-h23, 11.2.10-h16, 11.2.13-h4, 11.2.16-h1 · 11.1.4-h38, 11.1.6-h40, 11.1.7-h12, 11.1.10-h36, 11.1.13-h16, 11.1.16-h4 · 10.2.7-h39, 10.2.10-h42, 10.2.13-h27, 10.2.16-h12, 10.2.18-h13.
- **One exception:** "11.2.10-h16 which only includes the fix for PHP vulnerabilities; 11.2.10-h17 includes fixes for both" (PHP and the Node.js brotli flaw). On 11.2.10, go to h17.

Check (read-only, PAN-OS CLI):

```text
show system info | match sw-version
show interface management
```

Then in the web interface, **Device > Setup > Interfaces > Management**: the Permitted IP Addresses list should hold only internal admin addresses or a jump host. Under **Network > Network Profiles > Interface Mgmt**, check that no management profile is attached to an internet-facing interface.

Do this: 1. Move management access off the internet (jump host only). 2. Install the hotfix for your branch from the list above. 3. If the management interface was reachable from the internet before you patched, treat the device as possibly compromised: review admin and configuration logs and follow Palo Alto's guidance in the advisory. Customers with a Threat Prevention subscription can turn on the Threat IDs the advisory lists, but those only protect management traffic that passes through a dataplane port with decryption, as the advisory explains.

## Also added: VMware ESX and Linux kernel {#also-added-vmware-esx-and-linux-kernel}

Added on 28 October 2026:

- **CVE-2026-41709, Broadcom VMware ESX** (due 11 November): "an insufficient logging vulnerability that could allow a malicious actor with admin access to perform certain operations without being logged." Check who holds ESX admin access, and patch per Broadcom's advisory.
- **CVE-2026-46300, Linux kernel** (due 31 October): a missing initialisation flaw in socket buffer coalescing during ESP (IPsec) input processing that allows "unintended modification of page-cache-backed data". Install your distribution's kernel update and reboot. Check with `uname -r`.

## Why it matters

Edge devices and developer platforms keep showing up together in KEV for a reason: a VPN concentrator or a CI server is reachable from the internet and holds the keys to everything behind it. No Microsoft product was added to KEV in this period.

Related: all dated actions we track are on [Microsoft 365 security deadlines](../../guides/deadlines.md). For the Microsoft side of the estate, start with the [M365 Hardening Kit](../../kits/m365-hardening.md). More [Threats & vulnerabilities news](../topic/threats-vulnerabilities/).

## Sources

- [CISA Known Exploited Vulnerabilities catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog), JSON feed via the [cisagov/kev-data mirror](https://github.com/cisagov/kev-data), catalog version 2026.10.30, read 31 October and 2 November 2026
- [Cisco Security Advisory cisco-sa-asaftd-tunnel-dos-s6mgkb75](https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-asaftd-tunnel-dos-s6mgkb75) (version 1.0, 28 October 2026, read 31 October 2026)
- [GitLab Critical Patch Release: 19.4.2, 19.3.5, 19.2.8](https://docs.gitlab.com/releases/patches/patch-release-gitlab-19-4-2-released/) (12 October 2026, read 31 October 2026)
- [Alpine Linux: GitLab security incident (CVE-2026-97229)](https://alpinelinux.org/posts/GitLab-security-incident-CVE-2026-97229.html) (28 October 2026; Ruby versions as read by our news desk on 1 November 2026) and [BleepingComputer: Alpine Linux rebuilds GitLab after attempted RCE attack](https://www.bleepingcomputer.com/news/security/alpine-linux-rebuilds-gitlab-after-attempted-rce-attack/) (1 November 2026, read 8 November 2026)
- [Palo Alto Networks security advisory CVE-2026-109618](https://security.paloaltonetworks.com/CVE-2026-109618) (published 21 October 2026, updated 30 October 2026, read 1 November 2026)
- [Volexity: A Series of Unauthenticated Events: Chained Exploitation of Ivanti Connect Secure Zero-Days](https://www.volexity.com/blog/2026/10/13/a-series-of-unauthenticated-events-chained-exploitation-of-ivanti-connect-secure-zero-days/) (13 October 2026, update note after Ivanti's 29 October patch, read 3 November 2026)
- [Canadian Centre for Cyber Security: Ivanti security advisory (AV26-1035)](https://cyber.gc.ca/en/alerts-advisories/ivanti-security-advisory-av26-1035) (13 October 2026, modified 30 October 2026, read 2 November 2026)
- [CISA alert: Critical Vulnerabilities in PHP Require Immediate Patching](https://www.cisa.gov/news-events/alerts/2026/10/21/critical-vulnerabilities-php-require-immediate-patching) (21 October 2026, as linked from the KEV entry)

Last reviewed: 8 November 2026. Runbook Lab is not affiliated with Microsoft, Cisco, GitLab, Ivanti, Palo Alto Networks, Volexity or Alpine Linux.
