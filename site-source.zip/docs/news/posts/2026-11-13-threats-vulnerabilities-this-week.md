---
date:
  created: 2026-11-13 12:50:00
slug: threats-vulnerabilities-this-week-2026-11-13
categories:
  - Threats & vulnerabilities
description: "Threats to 13 November 2026: remove ScreenConnect RMM+ 1.0.31/1.0.32, close the N-central Legacy API, patch FortiOS, NetScaler, Xen Orchestra, Apache, Chrome."
rl_type: news
rl_area: detection-response
rl_service: [other, defender, entra]
rl_kits: [mde]
rl_controls: []
---

# Threats & vulnerabilities this week: 22 changes (13 November 2026)

Twenty-two confirmed threat and vulnerability items from the week to 13 November 2026: four already have their own briefs, twelve are new here and six are logged. The first action is for MSPs on ScreenConnect: remove the third-party RMM+ extension versions 1.0.31 and 1.0.32, which Huntress links to a worm on at least 288 endpoints in 48 organisations.

<!-- more -->

This is our weekly Threats & vulnerabilities roundup. The CISA KEV entries (Chromium, Cisco BroadWorks, Openwave, FreeSwitch) were re-read on 13 November 2026 from CISA's KEV data: CISA had no catalogue release on 11 or 12 November (catalog version 2026.11.10, 1,779 entries, read 13 November 2026). All other items rest on the facts Research read at each primary source between 7 and 13 November 2026.

One addition to last week's roundup: the same catalogue lists Barracuda CVE-2026-116606 and CVE-2026-111560, added 10 November 2026 with a due date of 13 November 2026. See [last week's Barracuda item](2026-11-06-threats-vulnerabilities-this-week.md#barracuda-esg-cve-2026-116606-chains-to-root-2-november-2026).

## Already briefed

1. **SonicWall SonicOS SSL-VPN CVE-2026-19868, in KEV since 6 November 2026.** Who acts: owners of Gen 7 and Gen 8 firewalls with SAML for SSL-VPN logins. Check: firmware 7.3.4-7013 or higher (Gen 7) or 8.2.3-8015 or higher (Gen 8). CISA due date: 20 November 2026. Brief: [SonicWall SSL-VPN SAML and MFA bypass](2026-11-07-sonicwall-sslvpn-saml-mfa-bypass-cve-2026-19868.md). Source: [SNWLID-2026-0014](https://psirt.global.sonicwall.com/vuln-detail/SNWLID-2026-0014).
2. **GPUStack CVE-2026-102895, in KEV since 9 November 2026 (filed under AI security).** Who acts: teams that self-host GPUStack. Check: `pip show gpustack` must show 2.2.0 or later. CISA due date: 12 November 2026. Brief: [GPUStack admin bypass in CISA KEV](2026-11-09-gpustack-auth-bypass-cve-2026-102895-kev.md). Source: [GHSA-gj9m-f8ph-pmhr](https://github.com/gpustack/gpustack/security/advisories/GHSA-gj9m-f8ph-pmhr).
3. **IBM Aspera Faspex CVE-2026-123218, in KEV since 9 November 2026.** Who acts: teams that run Faspex 5.0.0 to 5.0.19. Check: the faspex-core image must read "5.0.19 (1ce4b13, Fix Pack: 1)". CISA due date: 12 November 2026. Brief: [IBM Aspera Faspex flaw in CISA KEV](2026-11-10-ibm-aspera-faspex-cve-2026-123218-kev.md). Source: [IBM security bulletin](https://www.ibm.com/support/pages/node/7295921).
4. **Outlook zero-day CVE-2026-124194, November Patch Tuesday.** Who acts: every tenant with Outlook desktop, plus Exchange SE and Windows server admins. Check: Office build (Office LTSC 2021 16.0.14334.21048, Office LTSC 2024 16.0.17932.21140), ExSetup 15.02.2562.057. CISA due date: 24 November 2026. Brief: [Outlook zero-day CVE-2026-124194](2026-11-10-outlook-zero-day-cve-2026-124194-november-patch-tuesday.md). Source: [MSRC November 2026 Security Updates](https://api.msrc.microsoft.com/cvrf/v3.0/cvrf/2026-Nov).

## New this week

### ScreenConnect "SCKit" worm through the third-party RMM+ extension (11 November 2026)

Huntress (11 November, updated 11/11/26 11:34pm ET) counts "at least 288" endpoints across "48 organizations". Entry was through the third-party RMM+ extension, versions 1.0.31 and 1.0.32, which accepted a blank access key when it had never been configured. ScreenConnect 26.6.6.9747 and 26.7.6.9783 were seen. ConnectWise, as quoted by SecurityWeek and The Record, disabled five RMM+-family extensions in "more than 400" environments and said "Their presence alone does not establish compromise." The malware adds Microsoft Defender exclusions.

- **Who acts:** MSPs running ScreenConnect with third-party extensions.
- **Check:** ScreenConnect Administration > Extensions: list installed extensions and their versions. Look for ScreenConnect clients you did not deploy. In Defender XDR Advanced hunting: `DeviceRegistryEvents | where Timestamp > ago(30d) | where RegistryKey has @"Windows Defender\Exclusions"`.
- **Do this:** remove RMM+ 1.0.31 and 1.0.32.
- **Source:** [Huntress: SCKit worm](https://www.huntress.com/blog/sckit-worm-rogue-screenconnect). Related: [Defender for Endpoint ASR kit](../../kits/defender-endpoint-asr.md), [KEV catch-up: SharePoint, ScreenConnect, PAN-OS](2026-11-05-kev-catch-up-sharepoint-screenconnect-pan-os.md).

### N-able N-central "Able2Shell": HF2 fixed seven CVEs, new exploits target HF2 (8 to 12 November 2026)

After 33 alleged zero-days were published on 8 November, N-able took hosted N-central offline. N-central 2026.4 HF2 (build 2026.4.1.26, 10 November) fixes CVE-2026-125878 to CVE-2026-125883 and CVE-2026-91000. Late on 11 November two new exploits, "4EverAble2Shell" and "Agent2Shell", were published against HF2. Per Huntress's live blog (12 November, 6:30 AM ET), N-able says 4EverAble2Shell needs the non-default Legacy API enabled and internet-exposed, and is "not advising customers to take N-central offline"; Agent2Shell's dependence on it is "unconfirmed". No fix yet. Not in CISA KEV.

- **Who acts:** MSPs on on-premises N-central.
- **Check:** build 2026.4.1.26 (Huntress warns the version string may not change); Legacy API state and internet exposure; new admin accounts, new local admins and unexpected JSP files in the web root.
- **Do this:** upgrade to HF2, then Agents before Probes; disable the Legacy API or keep it off the internet.
- **Source:** [N-able: N-central 2026.4 HF2 release notes](https://status.n-able.com/2026/11/10/n-central-2026-4-hf2-release-notes/) and [Huntress](https://www.huntress.com/blog/n-able-disables-cloud-services-following-disclosure-of-able2shell-exploit-chains).

### Fortinet November PSIRT: FortiOS and FortiManager/FortiAnalyzer critical flaws (10 November 2026)

FortiGuard's monthly release marks every item below "Known Exploited: No". FortiOS/FortiSASE OSPF CVE-2026-126253 (FG-IR-26-267, CVSS 9.3) and FortiOS CVE-2026-126254 (FG-IR-26-268, "Numeric truncation error", 9.6) are fixed in 8.0.2, 7.6.8, 7.4.13 and 7.2.14. FortiManager/FortiAnalyzer: FGFM CVE-2026-126261 (FG-IR-26-275, 9.0; fixed 8.0.1 and 7.6.8, 7.4 and 7.2 "Migrate to a fixed release"), dmserver CVE-2026-126229 (FG-IR-26-244, 9.1; fixed 8.0.2, 7.6.8, 7.4.12, 7.2 migrate), "JSON Injection in JRPC API" CVE-2026-126170 (FG-IR-26-219, 9.8; affects 8.0.0 to 8.0.2 and 7.6.0 to 7.6.7; workaround `rpc-permit none` in the admin profile) and SQL injection CVE-2026-126262 (FG-IR-26-276, 9.3). FG-IR-26-269 CVE-2026-126255 (sshd) applies to 7.4 only with "GPC OS Login".

- **Who acts:** firewall and Fortinet management admins, often MSPs.
- **Check:** `get system status` on each FortiGate, FortiManager and FortiAnalyzer (read-only) against the fixed builds; confirm FGFM (TCP 541) and management interfaces are reachable only from trusted networks.
- **Source:** [FortiGuard PSIRT](https://www.fortiguard.com/psirt) and [FG-IR-26-219](https://fortiguard.fortinet.com/psirt/FG-IR-26-219).

### Citrix NetScaler: 28 CVEs in ADC and Gateway, Console authentication bypass (12 November 2026)

CTX697305 (updated 11-12-2026) fixes 28 CVEs in NetScaler ADC and Gateway: fixed in "14.1-73.57 and later", "13.1-64.39 and later releases of 13.1", 14.1-FIPS 14.1-73.58 and 13.1-FIPS/13.1-NDcPP 13.1-37.293. CTX697320, severity "Critical", covers NetScaler Console CVE-2026-120869 (CVSS 4.0 9.4): "An unauthenticated attacker can bypass authentication controls to access restricted resources on the appliance", given "Access to Citrix NetScaler Console IP". Fixed: "Citrix NetScaler Console 14.1-74.34 and later releases". Citrix credits its product security team "using advanced AI-assisted analysis". Citrix is "not aware of any exploits", as quoted by The Hacker News.

- **Who acts:** NetScaler ADC, Gateway and Console admins.
- **Check:** `show ns version` on each appliance (read-only); Console version against 14.1-74.34; Console management IPs not reachable from the internet.
- **Source:** [CTX697305](https://support.citrix.com/external/article/CTX697305) and [CTX697320](https://support.citrix.com/external/article/CTX697320).

### Xen Orchestra VSA-2026-062: exploited authentication bypass, no CVE (10 November 2026)

Vates' advisory (published and updated 10 November 2026, severity "Critical", no CVE) says: "This vulnerability is actively exploited by a threat actor." It is an "Empty-object login token" bypass affecting "Xen Orchestra before 6.9.2 (stable) and 6.10.1 (latest)" and XOA. Fixed: XO 6.9.2 and 6.10.1 (xo-server 5.211.2 and 5.213.1). Some press reports give other version numbers; these are Vates' own. Without a CVE it cannot appear in CISA KEV.

- **Who acts:** virtualisation admins and MSPs running Xen Orchestra or XOA.
- **Check:** the xo-server version (5.211.2 or 5.213.1 or later); whether XO is reachable from the internet; WAF or proxy logs for `authenticationToken=j:{}` or `authenticationToken=j:%7B%7D`.
- **Do this:** update and keep XO off the internet. On a confirmed compromise, rotate the pool secret, backup-remote, root and OTP secrets and reinstall.
- **Source:** [Vates VSA-2026-062](https://docs.vates.tech/security-advisories/advisories/2026/vates-sa-2026-062/).

### Apache HTTP Server 2.4.71 fixes critical mod_http2 RCE CVE-2026-119618 (11 November 2026)

Apache lists "CVE-2026-119618 (critical): mod_http2: heap corruption and RCE in assign_headers", affecting 2.4.55 through 2.4.70 (mod_h2 2.0.8 to 2.0.42). Version 2.4.71, released 11 November 2026, fixes it with CVE-2026-106023 (Important) and CVE-2026-109163 (Low). Credit goes to Anthropic's OSS Scanner and Google. No exploitation is stated.

- **Who acts:** anyone running Apache httpd, including appliances and reverse proxies built on it.
- **Check:** `apachectl -v` for the version and `apachectl -M | grep http2` to see if mod_http2 is loaded (both read-only).
- **Do this:** upgrade to 2.4.71 or your vendor's fixed package. If you can't yet, turn off HTTP/2 on exposed servers (`Protocols http/1.1`).
- **Source:** [Apache httpd 2.4 vulnerabilities](https://httpd.apache.org/security/vulnerabilities_24.html).

### Chromium CVE-2026-125350 in CISA KEV, due 24 November 2026

CISA added "Google Chromium Use-After-Free Vulnerability" on 10 November 2026. The entry says a use-after-free in the XML component "could allow a remote attacker to execute arbitrary code inside the sandbox via a specially crafted webpage", and that it "could affect multiple web browsers that utilize Chromium, including, but not limited to, Google Chrome, Microsoft Edge, and Opera". Use in ransomware campaigns: "Unknown". CISA points to Google's Chrome stable channel update for the fix; we have not read that post, so we don't give a build number here.

- **Who acts:** endpoint admins for Chrome and Edge.
- **Check:** Intune admin center > Apps > Monitor > Discovered apps, search "Chrome" and "Edge", and compare versions with Google's and Microsoft's release notes for this CVE; on one device, `chrome://version` or `edge://version`.
- **Source:** [CISA KEV catalog, CVE-2026-125350](https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext=CVE-2026-125350) (catalog version 2026.11.10, read 13 November 2026). Guide: [Microsoft 365 security deadlines](../../guides/deadlines.md).

### ESET: Turla "Cereal" toolset on on-premises Exchange (10 November 2026)

ESET attributes a modular .NET toolset, found in late 2025, to Turla "with high confidence". Victims were government bodies in Kazakhstan and Romania. CerealNeuron is a passive backdoor on Exchange-like paths such as /owa/; CerealHermit is a fallback that reads command files; CerealBox is injected into EdgeTransport.exe and collects mails with .doc, .docx and .pdf attachments without registering a transport agent. The compromised server acts as its own C2. ESET names no CVE and no initial access.

- **Who acts:** admins of on-premises Exchange servers.
- **Check:** `Get-Process EdgeTransport | Select-Object -ExpandProperty Modules | Select-Object ModuleName, FileName` and explain unfamiliar DLLs; review IIS logs for unusual request paths under /owa/. `Get-TransportAgent` will not show CerealBox.
- **Source:** [ESET release](https://www.globenewswire.com/news-release/2026/11/10/3399227/0/en/eset-research-russia-aligned-turla-group-uses-novel-exchange-tool-to-spy-on-eu-nato-emails.html). Related: [Exchange Server 2016 and 2019 end of updates](2026-11-03-exchange-server-2016-2019-esu-end-no-more-updates.md).

### Wiz: Qubole cross-account AWS access abused, stolen Entra ID secrets tested (9 November 2026)

Wiz reports that credentials from Qubole's AWS account 805246085872 were used to AssumeRole into customer accounts from 14 to 26 October. The attacker harvested Lambda environment variables, Secrets Manager and SSM, and bulk-copied S3. TruffleHog was used to validate stolen Entra ID client secrets, Okta and AWS keys. Separately, customer-owned access keys set up for Qubole were used from 8 to 11 October. Wiz cites no Qubole or Idera statement.

- **Who acts:** Qubole customers, and Entra admins whose app secrets live in AWS.
- **Check:** `aws iam list-roles --query "Roles[?contains(to_string(AssumeRolePolicyDocument), '805246085872')].RoleName"` (read-only); Entra admin center > Entra ID > Monitoring & health > Sign-in logs > Service principal sign-ins since 8 October.
- **Do this:** remove or limit the Qubole role trust and rotate the keys; rotate Entra app secrets stored in Lambda, Secrets Manager or SSM.
- **Source:** [Wiz](https://www.wiz.io/blog/qubole-cross-account-access-abused-in-the-wild). Related: [Conditional Access Baseline Kit](../../kits/conditional-access.md).

### Zoom Workplace for Windows ZSB-26023, CVE-2026-108186, CVSS 9.6 (10 November 2026)

Zoom's bulletin (published 11/10/2026, "Critical") says the flaw "may allow an unauthenticated user to conduct an escalation of privilege via network access"; the vector includes user interaction. Affected: "starting on version 7.1.0 and before version 7.1.8". No exploitation is stated.

- **Who acts:** endpoint admins with Zoom Workplace on Windows.
- **Check:** Intune admin center > Apps > Monitor > Discovered apps, search "Zoom", and list versions 7.1.0 to 7.1.7.
- **Do this:** push 7.1.8 or later through your app deployment.
- **Source:** [Zoom ZSB-26023](https://www.zoom.com/en/trust/security-bulletin/zsb-26023/).

### SonicWall GMS 9.5.2 and earlier: two flaws that will not be fixed (3 November 2026)

SonicWall advisory SNWLID-2026-0019 (3 November) covers CVE-2026-109593, an unauthenticated file read, and CVE-2026-109594, SQL injection, in GMS 9.5.2 and earlier. GMS reached end of support on 30 September 2026. As quoted by BleepingComputer, SonicWall says "no remediation or security update will be released for these vulnerabilities" and customers "are strongly encouraged to upgrade to the SonicWall Network Security Manager (NSM)". SOCRadar gives CVSS 9.1 and 6.8 and reports no exploitation and no public PoC. Neither CVE is in CISA KEV (read 13 November 2026).

- **Who acts:** MSPs and firewall teams still on GMS.
- **Check:** list every GMS host and whether it is reachable from the internet.
- **Do this:** treat GMS as unpatchable: take it off the internet, then migrate to NSM.
- **Source:** [SonicWall SNWLID-2026-0019](https://psirt.global.sonicwall.com/vuln-detail/SNWLID-2026-0019) (as quoted by [BleepingComputer](https://www.bleepingcomputer.com/)).

### Cisco BroadWorks XXE CVE-2026-20320 in CISA KEV, due 24 November 2026

CISA added "Cisco BroadWorks Improper Restriction of XML External Entity Reference Vulnerability" on 10 November 2026. Per the entry, it "could allow an unauthenticated, remote attacker to read sensitive configuration information on an affected system". Use in ransomware campaigns: "Unknown". CISA links Cisco advisory cisco-sa-bworks-xxe-uwUd7CEt for the fix.

- **Who acts:** service providers and UC teams running Cisco BroadWorks.
- **Check:** BroadWorks release and patch level against the fixed releases in Cisco's advisory.
- **Source:** [Cisco advisory](https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-bworks-xxe-uwUd7CEt) and the [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext=CVE-2026-20320) (read 13 November 2026).

## Also logged

- **OpsShield cPGuard update channel compromised.** OpsShield (3 November): versions 5.88.12 to 5.88.19 affected, fixed 5.88.25 and later; the update CDN was accessed on 2 November at 02:06 UTC, with about 32 confirmed data pulls ("a preliminary estimate"). Who acts: cPanel hosts. Source: [OpsShield](https://opsshield.com/).
- **Drupal Commerce Core SA-CONTRIB-2026-254, CVE-2026-118539.** "Highly critical" access bypass: "This vulnerability is being actively exploited in the wild." Fixed in 3.3.13 and 8.x-2.41; not in CISA KEV. Who acts: MSPs hosting Drupal shops. Source: [drupal.org](https://www.drupal.org/sa-contrib-2026-254).
- **SignalWire FreeSWITCH CVE-2026-116779 in KEV.** Added 9 November 2026, due 12 November 2026: a code injection flaw "that permits configuration and credential disclosure, arbitrary call control, and command execution". Who acts: VoIP teams on FreeSWITCH. Source: [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext=CVE-2026-116779) and [GHSA-mg63-h38w-8p9p](https://github.com/signalwire/freeswitch/security/advisories/GHSA-mg63-h38w-8p9p).
- **Openwave Webtop Media Transcoder CVE-2026-111793 in KEV.** Added 10 November 2026, due 24 November 2026: it "may allow an authenticated user to process and convert unintended document types if bypassing the Webmail experience". Who acts: mail providers on Openwave. Source: [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext=CVE-2026-111793).
- **GitLab 19.5.4, 19.4.6 and 19.3.8 (10 November).** Critical CVE-2026-105437, a Git heap overflow leading to command execution in Gitaly; no exploitation stated. Who acts: self-managed GitLab admins; self-compiled installs need Git 2.56.1 or later. Source: [GitLab patch release](https://docs.gitlab.com/releases/patches/patch-release-gitlab-19-5-4-released/).
- **Microsoft Threat Intelligence: GSocket used for stealthy C2 on Linux (11 November).** Blog post "The global socket: how threat actors are weaponizing GSocket for stealthy C2"; we have read the listing, not the full post. Who acts: Linux server and Defender teams. Source: [Microsoft Security blog](https://www.microsoft.com/en-us/security/blog/).

More: [all Threats & vulnerabilities news](../topic/threats-vulnerabilities/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 13 November 2026. Runbook Lab is not affiliated with Microsoft.
