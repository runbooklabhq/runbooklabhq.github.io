---
date:
  created: 2026-11-04 10:36:00
slug: microsoft-365-changes-november-2026
categories:
  - Email & collaboration
description: "Microsoft 365 changes in November 2026: SharePoint OTP guest links stop working, Exchange Online -Migration properties go, a risk CA policy turns On."
rl_type: news
rl_kits: [ca, exo]
rl_controls: []
---

# Microsoft 365 changes landing in November 2026

Three Microsoft 365 changes are landing now: SharePoint and OneDrive finish retiring one-time passcode (SPO OTP) sign-in for guests "by end of November 2026", Exchange Online stops returning some properties from `Get-Mailbox -Migration` from 15 November, and a Microsoft-managed Conditional Access policy for high-risk users should already have switched itself On in tenants that received that message (seen so far only in Education tenants). SharePoint, Exchange and identity admins should check each one this week.

<!-- more -->

!!! note "Runbook card"
    **What changes:** external users who reach old SharePoint and OneDrive links through SPO OTP get "access denied" until they have an Entra B2B guest account; selected properties disappear from Exchange Online `-Migration` cmdlet output from 15 November; the Microsoft-managed policy "Require risk remediation for high-risk users" moved from Report-only to On in the week of 28 October unless you set it.<br>
    **Who:** SharePoint and Entra admins in every commercial tenant (GCC, GCC High and DoD excluded for now); Exchange admins and migration tool owners; Entra ID P2 tenants for the risk policy (message seen so far only in Education tenants).<br>
    **By when:** SPO OTP retirement "expected to complete by end of November 2026"; Exchange Online "Act by Nov 15, 2026" (its own example says properties go from 10 November); the risk policy has already reached its switch date.<br>
    **Do this:** 1. Keep email one-time passcode for B2B guests turned on and check guest Conditional Access. 2. Find external users without a guest account and create one, or reshare. 3. Search scripts and tools for `-Migration` and test them. 4. Open the Microsoft-managed risk policy, confirm its state and exclude your emergency access accounts.<br>
    **Check:** Entra admin center, External Identities, All identity providers, Email one-time passcode; Conditional Access, Policies, filter for Microsoft-managed.<br>
    **Source:** [MC1243549](https://mc.merill.net/message/MC1243549), [MC1511071](https://mc.merill.net/message/MC1511071) and [MC1507808](https://mc.merill.net/message/MC1507808).

## SharePoint and OneDrive: one-time passcode sign-in retires (MC1243549)

Microsoft updated MC1243549 on 1 October 2026: Phase 2, "the retirement of SharePoint Online OTP, has been rescheduled to begin in mid-October 2026 and is expected to complete by end of November 2026 for Production environments". Both phases "exclude GCC, GCCH & DoD"; Microsoft will announce new dates for those clouds.

What breaks: external users who signed in to "specific people" links with SPO OTP, and who have no Entra B2B guest account, "will receive access denied until a matching B2B guest account exists". Links shared since Phase 1 (May and June 2026) already create a guest account automatically.

How access comes back, in Microsoft's words: "Admins can manually create a guest account for the external user at any time. Alternatively, an internal user with permissions needs to share or re-share at least one file, folder, or site, which will automatically create the guest account and restore access to all previously shared content."

The security side: once they are B2B guests, external users "become fully subject to Microsoft Entra Conditional Access, Identity Protection, and guest governance policies". Microsoft: "Authentication events and guest lifecycle actions will be logged through Entra audit logs rather than SPO OTP logs". Our reading: a guest policy that requires MFA or a compliant device now applies to people who used to sign in with a code alone, so expect some helpdesk calls.

Microsoft's preparation list, shortened:

1. Review external sharing settings and Conditional Access for guests in the SharePoint and Entra admin centers.
2. Make sure the right people can invite guests (for example the Guest Inviter role).
3. Tell users that some external contacts may see "access denied" on older links, and that resharing one file fixes it.
4. "If your organization relies on email OTP authentication via Entra, ensure it is not disabled in Entra External ID settings."
5. Optionally use external sharing reports to find external collaborators without a guest account and create the accounts in advance.

Also in the post: the `EnableAzureADB2BIntegration` setting no longer controls external sharing, and "The option to disable Entra B2B integration will be removed."

## Exchange Online: properties removed from -Migration cmdlets (MC1511071)

MC1511071 (published 16 October 2026, "Act by Nov 15, 2026") deprecates "selected properties returned or used with" `Get-Mailbox -Migration` and `New-Mailbox -Migration`, in two steps:

- "Beginning November 15, 2026: Selected properties will no longer be returned in applicable Get-Mailbox -Migration and New-Mailbox -Migration responses."
- "Beginning December 15, 2026: The affected properties will be blocked from being configured through applicable New-Mailbox -Migration scenarios."

The same post's example says a script "will no longer receive the affected properties in the returned object beginning November 10, 2026", so test before 10 November to be safe. Microsoft lists the properties on the Learn page "Changes to Get-Mailbox and New-Mailbox specifically with the Migration parameter", linked from the post. It asks you to review scripts that use `Get-Mailbox -Migration`, `New-Mailbox -Migration` or `Set-Mailbox -Migration`. "If your workflows don't use any of the affected properties, no action is required." If you cannot remove a dependency, Microsoft asks you to contact Support with the property name, cmdlet, scenario and impact.

Our reading of who this hits: migration scripts, tenant-to-tenant and hybrid tooling, and third-party migration products. Ask your migration vendor whether their tool reads these properties.

## Entra: the Microsoft-managed risk remediation policy should now be On (MC1507808)

MC1507808 (published 14 October 2026) says Microsoft created a Microsoft-managed Conditional Access policy, "Require risk remediation for high-risk users", in report-only mode for organisations with Entra ID P2, and gives the date as "The week of October 28, 2026: End of evaluation period", when the policy is "automatically switched to On" unless you set it to On or Off yourself. The public mirror marks this message as seen only in Education tenants so far, so it may not have reached every P2 tenant.

When On, "users identified as High User Risk will be prompted to self‑remediate". Microsoft says "No existing Conditional Access settings or exclusions (such as break‑glass accounts) will be altered." Our reading: your emergency access accounts are not excluded from this new policy unless you add them.

Microsoft's list: review the policy, decide whether to keep it On or set it Off, customise it (for example "exclude emergency access accounts") or change the membership of the policy's security group, and "Ensure users are registered for multifactor authentication so they can complete self‑remediation when prompted."

## Moved out of November: Defender for Office 365 Security Operator access (MC1486293)

Microsoft updated MC1486293 on 3 November 2026. The change that drops "Authorization and settings\Security settings (All permissions)" from the default Unified RBAC mapping of the Entra Security Operator role for Defender for Office 365, so the role loses access to email threat policies and the Tenant Allow/Block List, now "begins in early December 2026 (previously early November) and is expected to complete by mid-January 2027 (previously early December 2026)". Only tenants with Unified RBAC enabled for Defender for Office 365 are affected. You now have until December to grant "Core security settings and Detection tuning", or a role such as Security Administrator, to operators who need that access.

## How to check (read-only)

SharePoint guests and email OTP: Entra admin center, External Identities, All identity providers, Email one-time passcode, and confirm it is enabled. Then Conditional Access, Policies, and read which policies target "Guest or external users".

Exchange Online scripts: search your script repositories for the switch, for example in PowerShell:

```powershell
Get-ChildItem -Path . -Recurse -Include *.ps1,*.psm1 | Select-String -Pattern '-Migration' -SimpleMatch
```

Risk policy: Entra admin center, Conditional Access, Policies, filter for Microsoft-managed policies, open "Require risk remediation for high-risk users" and read its state and its Exclude list.

## How to verify

External test users with old links can open them after a reshare; your migration scripts run cleanly against a test mailbox; the risk policy shows the state you chose and your emergency access accounts under Exclude; Sign-in logs, filtered on this policy, show no failures for accounts that must never be blocked.

Related: all dated actions on [Microsoft 365 security deadlines](../../guides/deadlines.md), the [Conditional Access Baseline kit](../../kits/conditional-access.md), the [Exchange Online Protection kit](../../kits/exchange-online-protection.md), and more [Email & collaboration news](../topic/email-collaboration/).

## Sources

- [MC1243549: Retirement of SharePoint One-Time Passcode (SPO OTP) and transition to Microsoft Entra B2B](https://mc.merill.net/message/MC1243549) (published 4 March 2026, last updated 1 October 2026; read 4 November 2026)
- [MC1511071: Action required: Review property changes for Exchange Online scenarios](https://mc.merill.net/message/MC1511071) (published 16 October 2026; read 4 November 2026)
- [MC1507808: Microsoft-managed CA policy will be enforced soon, Require risk remediation for high-risk users](https://mc.merill.net/message/MC1507808) (published 14 October 2026; read 4 November 2026)
- [MC1486293: Changes to Unified RBAC permission mapping for Microsoft Entra Security Operator role](https://mc.merill.net/message/MC1486293) (published 2 October 2026, last updated 3 November 2026; read 4 November 2026)

Last reviewed: 4 November 2026. Runbook Lab is not affiliated with Microsoft.
