---
date:
  created: 2026-11-13 12:00:00
slug: identity-access-this-week-2026-11-13
categories:
  - Identity & access
description: "Identity news to 13 November 2026: SSPR date corrected, list SSPR users without a method, move SMS-only users before 1 February 2027, Entra GA features."
rl_type: news
rl_area: identity
rl_service: [entra]
rl_kits: [sms, ca]
rl_controls: []
---

# Identity & access this week: 3 changes (13 November 2026)

Three confirmed Identity & access items logged in the week to 13 November 2026, each with who acts, the check and the source. The first action is a correction: Microsoft's two sources now disagree on when SSPR stops accepting unregistered methods, so identity admins and the helpdesk should list SSPR users without a registered method now.

<!-- more -->

This is our weekly Identity & access roundup. The SSPR correction rests on Microsoft Learn and MC1325414, both re-read on 13 November 2026 for the brief. We could not re-read MC1540327 or the Entra blog post today; the other items rest on the facts Research read at each primary source between 7 and 8 November 2026.

## Already briefed

1. **Correction, 13 November 2026: Microsoft's two sources disagree on the SSPR date.** Microsoft Learn (last updated 5 November 2026) now says "Starting February 2027, SSPR will only accept explicitly registered authentication methods". MC1325414 (last updated 4 August 2026) still says "November 7, 2026: Enforcement begins". Our brief said 7 November until today. The action is unchanged. Identity admins and the helpdesk. Check: list users enabled for SSPR without a registered method. Brief: [SSPR stops using the phone number in the directory](2026-10-29-entra-sspr-registered-methods-only.md). Source: [MC1325414](https://mc.merill.net/message/MC1325414), [Microsoft Learn](https://learn.microsoft.com/en-us/entra/identity/authentication/howto-sspr-authenticationdata). Listed on our [corrections page](../../about/corrections.md).

## New this week

### Entra MC1540327: prepare users who can't use passkeys for SMS and voice retirement, published 5 November 2026

MC1540327 ("Action required: Prepare users who can't use passkeys for SMS and voice retirement") is tagged Major change, User impact, Admin impact and Retirement. It has no Act-by field. It says: "Prepare your organization before February 1, 2027." The retirement is phased, "not a single cutoff": "February 1, 2027" for most users and "July 1, 2027" for Global Admins and external users. Move users who rely only on SMS or voice to Authenticator push, phone sign-in or TOTP, or use a customer-managed telephony provider. The post is consistent with the Learn page and MC1519855.

- **Who acts:** identity admins and the helpdesk, before 1 February 2027.
- **Check:** Entra admin center > Authentication methods > User registration details: filter users whose only methods are SMS or voice, and move them first (path from our kit).
- **Source:** [MC1540327](https://mc.merill.net/message/MC1540327). Related: [Entra SMS MFA Exit Kit](../../kits/sms-mfa-exit.md), [SMS and voice MFA retirement guide](../../guides/entra-sms-voice-mfa-retirement-passkeys.md), [SSPR loses SMS and voice (last week)](2026-11-06-identity-access-this-week.md).

## Also logged

- **What's new in Microsoft Entra, November 2026 (6 November).** Now GA: bring-your-own telephony, passkey-first MFA ("Rollout continues through February 2027"), Windows Hello for Business and Platform SSO as standalone MFA ("Rollout begins early November 2026"), and Universal CAE with device and risk signals. In preview: guest lifecycle policies, and a default inactivity policy for agent identities that notifies owners "after 60 days of inactivity" and then disables the identity. Source: [Microsoft Entra blog](https://techcommunity.microsoft.com/blog/microsoft-entra-blog/what%E2%80%99s-new-in-microsoft-entra-november-2026/4556457). Related: [Conditional Access Kit](../../kits/conditional-access.md).

More: [all Identity & access news](../topic/identity-access/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 13 November 2026. Runbook Lab is not affiliated with Microsoft.
