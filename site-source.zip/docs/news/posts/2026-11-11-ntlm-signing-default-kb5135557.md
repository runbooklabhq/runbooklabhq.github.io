---
date:
  created: 2026-11-11 10:30:00
slug: ntlm-signing-default-kb5135557
categories:
  - Endpoint & devices
description: "KB5135557: November 2026 Windows updates turn on NTLM signing for clients; servers require it from May 2027. Audit events 4022 and 4023 for unsigned clients."
rl_type: news
rl_kits: [m365]
rl_controls: []
---

# NTLM signing on by default: KB5135557, servers May 2027

Microsoft's KB5135557 (published 10 November 2026) says Windows updates released on and after 10 November 2026 make Windows clients offer NTLM signing on all connections by default, and that in May 2027 "Windows servers begin requiring NTLM signing by default". Windows and Active Directory admins should use the new audit events now to find clients and devices that don't sign, before servers start rejecting them.

<!-- more -->

!!! note "Runbook card"
    **What changes:** phase 1 (10 November 2026): Windows clients "begin offering NTLM signing on all connections by default" and servers still "accept both signed and unsigned clients". Phase 2 (May 2027): "Clients that do not offer signing will be rejected by secure servers." The updates address CVE-2026-118737.<br>
    **Who:** Windows and Active Directory admins and MSPs running Windows 11 (23H2 to 26H2), Windows 10 Enterprise LTSC 2021 or Windows Server 2016 to 2025, and anything on the network that still authenticates to them with NTLM.<br>
    **By when:** auditing works now; enforcement on servers starts in May 2027 (Microsoft gives the month only).<br>
    **Do this:** 1. Install the November 2026 Windows updates. 2. Turn on NTLM Enhanced auditing and collect events 4022 (client) and 4023 (server) from the Microsoft-Windows-NTLM/Operational log. 3. List connections without the SIGN flag (0x10), then fix, update or isolate those clients before May 2027. 4. When the audit stays clean, set `ServerRequireNtlmSign` to 1 on servers.<br>
    **Check:** the read-only PowerShell below, on Windows Server 2019 or later.<br>
    **Source:** [KB5135557: NTLM signing security improvements in Windows](https://support.microsoft.com/en-us/servicing/os/windows/docs/2026/11/kb5135557-ntlm-signing-security-improvements) (published 10 November 2026).

## What Microsoft says

KB5135557 opens: "Windows updates released on and after November 10, 2026, contain additional protections that address CVE-2026-118737. These updates represent the first phase of improvements to NTLM message signing."

The two phases, as Microsoft words them:

- "Phase 1 (November 10, 2026): Windows client devices begin offering NTLM signing on all connections by default. Servers accept both signed and unsigned clients. Auditing events identify clients not using signing."
- "Phase 2 (May 2027): Windows servers begin requiring NTLM signing by default. Clients that do not offer signing will be rejected by secure servers."

Microsoft adds: "All supported Windows Server versions are capable of NTLM signing." The KB's Applies to list is Windows 11 versions 26H2, 26H1, 25H2, 24H2 and 23H2, Windows 10 Enterprise LTSC 2021, and Windows Server 2025, 2022, 2019 and 2016.

What else the KB says:

- Kerberos is not affected: "These changes apply only to NTLM authentication."
- Anonymous connections are "explicitly exempt", and so are guest accounts.
- If an older server does not echo SIGN back, "the client automatically removes SIGN from the session and falls back to legacy ALWAYS_SIGN behavior."
- In phase 2, a rejected client gets SEC_E_UNSUPPORTED_FUNCTION (0x80090302) and the server logs Warning event 4023 with that status code.
- "Microsoft might remove the registry keys at a future date."

Not yet known: Microsoft hasn't published a day in May 2027 for phase 2. The KB names no devices or applications that are likely to break, and it does not describe CVE-2026-118737; we couldn't read the MSRC entry for its severity today.

## The two registry values

Both are REG_DWORD under `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0`:

| Value | 0 (default) | 1 |
|---|---|---|
| `ClientAllowUnsignedNtlm` | "Client offers SIGN on all non-anonymous connections." | "Client does NOT offer SIGN. Use only for temporary compatibility." |
| `ServerRequireNtlmSign` | "Server accepts both signed and unsigned clients for secure connections." | "Server rejects unsigned clients. Recommended once auditing confirms readiness." |

For `ServerRequireNtlmSign`, the KB says "No restart required" and to set it to 1 "once sufficient Event ID: 4023 auditing shows no unsigned connections". Microsoft also says you can set it early to enforce signing before May 2027.

## How to check

Events 4022 (client side) and 4023 (server side) are written to Microsoft-Windows-NTLM/Operational. Microsoft says they are "available on Windows Server 2019 and later" with NTLM Enhanced auditing; the steps to turn it on are in Microsoft's [NTLM auditing enhancements overview](https://support.microsoft.com/en-us/servicing/os/windows/2025/07/overview-of-ntlm-auditing-enhancements-in-windows-11-version-24h2-and-windows-server-2025). Windows Server 2016 is on the KB's Applies to list but does not get these events.

Each event has a Negotiated Flags field. A connection is signed when the SIGN bit (0x00000010) is set; Microsoft says "A connection is secure when both bits are set", meaning SIGN and KEY_EXCH (0x40000000), with the Session Key Status field reading Present. Microsoft's example of a ready connection is 0xE0888215; its example that needs attention is 0xA0888205.

Read-only, on a server or client with the November update and auditing on:

```powershell
# Read the current settings (no value = default 0)
Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' `
  -Name ClientAllowUnsignedNtlm, ServerRequireNtlmSign -ErrorAction SilentlyContinue

# List NTLM events 4022/4023 whose Negotiated Flags lack SIGN (0x10)
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-NTLM/Operational'; Id=4022,4023} -ErrorAction SilentlyContinue |
  ForEach-Object {
    if ($_.Message -match 'Negotiated Flags:\s*(0x[0-9A-Fa-f]+)') {
      $flags = [Convert]::ToUInt32($Matches[1].Substring(2), 16)
      if (-not ($flags -band 0x10)) {
        [pscustomobject]@{ Time = $_.TimeCreated; Id = $_.Id; Flags = $Matches[1]; Message = ($_.Message -split "`n")[0] }
      }
    }
  }
```

KB5135557 has its own script under "Find clients not sending SIGN" that also pulls the client IP, host, user and process from each event; use it for the full report. Microsoft's test: "If no results appear (no unsigned connections), you are ready." Both scripts check only the SIGN bit; look at Session Key Status too. Don't filter by event level: Microsoft logs 4022 and 4023 as Warning for signed and unsigned connections alike.

## How to verify

After you set `ServerRequireNtlmSign` to 1 on a server, run the event query again over the next days. Any client that still doesn't offer SIGN shows up as a 4023 Warning with status 0x80090302, which is the failure users will see in May 2027.

## Impact and rollback

Phase 1 changes only what clients offer; servers still accept unsigned clients, and Microsoft says the fallback for an older server happens without failing the connection, so nothing should break today. The risk sits with clients that never offer SIGN: legacy NAS boxes, printers and scanners, appliances and old applications that authenticate with NTLM are the usual places to look (our suggestion; the KB names none). If a client breaks after you enforce signing on a server, set `ServerRequireNtlmSign` back to 0 on that server. `ClientAllowUnsignedNtlm=1` turns signing off on a client and is meant "only for temporary compatibility": record it as an exception with an end date.

Related: the [Outlook zero-day CVE-2026-124194 and November Patch Tuesday](2026-11-10-outlook-zero-day-cve-2026-124194-november-patch-tuesday.md) (another NTLM hash leak fixed on the same day), [Windows blocks NTLMv1-derived SSO credentials](2026-11-06-endpoint-devices-this-week.md) in last week's Endpoint roundup, every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md), the [M365 Hardening Kit](../../kits/m365-hardening.md) and more [Endpoint & devices news](../topic/endpoint-devices/).

## Sources

- [KB5135557: NTLM signing security improvements in Windows](https://support.microsoft.com/en-us/servicing/os/windows/docs/2026/11/kb5135557-ntlm-signing-security-improvements) (published 10 November 2026; read 11 November 2026)
- [Overview of NTLM auditing enhancements in Windows 11 version 24H2 and Windows Server 2025](https://support.microsoft.com/en-us/servicing/os/windows/2025/07/overview-of-ntlm-auditing-enhancements-in-windows-11-version-24h2-and-windows-server-2025) (linked from KB5135557)
- [CVE-2026-118737](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-118737) (Microsoft Security Response Center)

Last reviewed: 11 November 2026. Runbook Lab is not affiliated with Microsoft.
