---
date:
  created: 2026-10-31 13:40:00
slug: ai-security-this-week-2026-10-31
categories:
  - AI security
description: "AI security to 31 October 2026: North Korean actors' AI tradecraft and blocking device code flow, Copilot Memory on by default, Claude Code 2.1.314 fixes."
rl_type: news
rl_kits: [copilot, agents, ca]
rl_controls: [AG01]
---

# AI security this week: 5 changes (31 October 2026)

Five confirmed AI security items from the week to 31 October 2026. The action most tenants can take today: block device code flow, which Microsoft recommends after tracking North Korean actors' use of AI.

<!-- more -->

This is our weekly AI security roundup. It was due on Friday 30 October and is published a day late. Every item comes from a primary source read on 31 October 2026.

## Already briefed

1. **Copilot Studio retires older models; agents are moved to replacements on 12 November 2026.** Makers and Power Platform admins. Brief: [Copilot Studio model retirement](2026-10-28-copilot-studio-model-retirement.md). Source: [MC1506318](https://mc.merill.net/message/MC1506318).
2. **LiteLLM 1.107.0 supply-chain compromise stole credentials through Python startup hooks.** Anyone running LiteLLM. Brief: [LiteLLM 1.107.0 compromise](2026-10-29-litellm-supply-chain-compromise.md).

## New this week

### Microsoft Threat Intelligence: North Korean actors' AI use, and "block device code flow"

Microsoft's 29 October post groups the actors it tracks by how far they have adopted AI. Microsoft names Onyx Sleet and Pearl Sleet as using "the open-source agentic AI penetration testing framework ARTEX", and Coral Sleet as trojanising private GitHub repositories. Its recommendations include: "Microsoft recommends blocking device code flow wherever possible", EDR in block mode, and zero-hour auto purge in Defender for Office 365.

- **Who acts:** identity and SecOps admins.
- **Check:** Entra admin center > Conditional Access > New policy > Conditions > Authentication flows > Device code flow > Block. Start in Report-only and exclude only documented device types.
- **Source:** [Microsoft Security blog, 29 October 2026](https://www.microsoft.com/en-us/security/blog/2026/10/29/tracking-ai-adoption-in-north-korean-threat-actor-tradecraft/) (attribution is Microsoft's). Related: [Conditional Access Baseline Kit](../../kits/conditional-access.md).

### Copilot Memory with work data: rollout to end of November 2026, Enhanced Personalization on by default

MC1492154: "expect to complete by end of November 2026 (previously late October)". Admins control it with `enhancedPersonalizationSetting`. MC1530959 (29 October) now states the default: the Enhanced Personalization control "is on by default and can be turned off for the entire tenant or for specific users through a Microsoft Entra group". Copilot Chat also starts showing which memories it used ("late October 2026").

- **Who acts:** Copilot admins and the privacy or data protection lead.
- **Check:** decide whether the tenant default stays on, and who may manage it (Global Administrators and People Administrators can). Pair it with the Copilot Memory retention item in our [Data & compliance roundup](2026-10-31-data-compliance-this-week.md).
- **Source:** [MC1492154](https://mc.merill.net/message/MC1492154) · [MC1530959](https://mc.merill.net/message/MC1530959). Related: [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md).

### Claude Code 2.1.314: a new write guard and four guardrail fixes

The changelog adds `permissions.blockWritesOutsideWorkingDirectories`: "Write, Edit and NotebookEdit refuse paths outside the working directories in every permission mode". It also fixes sandbox protections not applying to a worktree entered by `claude -p --resume` or `--continue`, Bash hooks not running on commands started by the Monitor tool, and `forceRemoteSettingsRefresh` no longer applying once the stored copy had expired, which "let sessions start without policy when the server could not be reached". The changelog gives no release date.

- **Who acts:** teams that rely on Claude Code hooks, the sandbox or managed settings as guardrails.
- **Check:** `claude --version` on developer machines and CI runners shows 2.1.314 or later. Consider setting `permissions.blockWritesOutsideWorkingDirectories: true` in managed settings.
- **Source:** [Claude Code CHANGELOG](https://github.com/anthropics/claude-code/blob/main/CHANGELOG.md). Related: [M365 AI Agent Hardening Kit](../../kits/ai-agent-hardening.md).

More: [all AI security news](../topic/ai-security/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 31 October 2026. Runbook Lab is not affiliated with Microsoft or Anthropic.
