---
date:
  created: 2026-10-31 13:10:00
slug: email-collaboration-this-week-2026-10-31
categories:
  - Email & collaboration
description: "Teams and Defender for Office 365 to 31 October 2026: phishing and QR detection in Teams, guest invite reports, meeting impersonation, move to quarantine."
rl_type: news
rl_kits: [exo, m365]
rl_controls: [EX01]
---

# Email & collaboration this week: 6 changes (31 October 2026)

Six confirmed Teams and Defender for Office 365 changes from the week to 31 October 2026. Most need no switch flipped, but the helpdesk and your user guidance need to know before they land.

<!-- more -->

!!! info "Updated 11 November 2026: correction"
    MC1526651, malicious QR code detection in Teams: Microsoft updated the timeline on 10 November 2026. General availability now begins in mid-November 2026 (previously early November) and should complete by late November 2026 (previously mid-November). This page still showed the old dates until today. See [the item](#teams-malicious-qr-detection).

!!! info "Updated 7 November 2026"
    MC1523084, moving email to quarantine as a Defender for Office 365 Plan 2 remediation action: general availability now begins in late November 2026 (previously early November) and should complete by mid-January 2027 (previously mid-December). See [the item](#defender-for-office-365-plan-2-move-email-to-quarantine-as-a-remediation-action).

!!! info "Updated 5 November 2026"
    MC1530615, reporting suspicious guest invitations in Teams: general availability now starts in mid-November 2026, previously early November. See [the item](#users-can-report-suspicious-guest-invitations-mid-november-2026).

This is our weekly Email & collaboration roundup. It was due on Friday 30 October and is published a day late. Every item was re-read on its primary source on 31 October 2026.

## Already briefed

1. **Teams chats with external organisations: file sharing turns on by default. Microsoft asks you to set the policy "by the first week of November".** Teams admins. Brief: [Teams external chat file sharing](2026-10-28-teams-external-chat-file-sharing.md). Source: [MC1479514](https://mc.merill.net/message/MC1479514).

## New this week

### Teams phishing detection in chats: Targeted Release early November, GA December 2026

Targeted Release "Beginning in early November 2026 and expected to complete by mid-November 2026"; General Availability "Beginning in early December 2026 and expected to complete by mid-December 2026".

- **Who acts:** Teams admins and the helpdesk. No admin configuration.
- **Check:** your user guidance says how to report a wrongly flagged message and how to treat unfamiliar external contacts.
- **Source:** [MC1519866](https://mc.merill.net/message/MC1519866).

### Teams malicious QR code detection, mid- to late November 2026, on by default { #teams-malicious-qr-detection }

Updated 11 November 2026: Microsoft moved the timeline on 10 November 2026. GA is now "Beginning in mid-November 2026 (previously early November) and expected to complete by late November 2026 (previously mid-November)". Previously this item said GA from early November, finishing mid-November 2026. "No admin action is required." The setting "is enabled by default" and follows the existing Malicious URL protection setting.

- **Who acts:** Teams admins.
- **Check:** Malicious URL protection is on in the Teams admin center. The QR setting follows it.
- **Source:** [MC1526651](https://mc.merill.net/message/MC1526651).

### Users can report suspicious guest invitations, mid-November 2026

Updated 5 November 2026: Microsoft moved the start. GA now begins "in mid-November 2026 (previously early November)" and is expected to complete by mid-November 2026. Users report an invitation when they decline it; reports reach admins in the User reported security submissions report in the Teams admin center. Managed at Teams admin center > Messaging policies > Report a security concern.

- **Who acts:** Teams admins; SecOps decides who triages the reports.
- **Check:** the messaging policy setting matches where your reported messages already go.
- **Source:** [MC1530615](https://mc.merill.net/message/MC1530615).

### Teams meeting impersonation protection, mid to late December 2026

GA "mid-December 2026" to "late December 2026". "No immediate admin action is required."

- **Who acts:** nobody yet. Tell the helpdesk before December so a new warning in a meeting isn't a surprise.
- **Source:** [MC1530613](https://mc.merill.net/message/MC1530613).

### Defender for Office 365 Plan 2: move email to quarantine as a remediation action

Updated 7 November 2026: Microsoft moved the timeline. GA now begins "in late November 2026 (previously early November)" and is "expected to complete by mid-January 2027 (previously mid-December)". Needs Defender for Office 365 Plan 2. "The Search and Purge role is required to approve remediation actions."

- **Who acts:** SecOps.
- **Check:** who holds Search and Purge, and which quarantine policy applies. If it lets users release messages, a quarantined phish can come back.
- **Source:** [MC1523084](https://mc.merill.net/message/MC1523084). Related: [Exchange Online Protection Kit](../../kits/exchange-online-protection.md).

More: [all Email & collaboration news](../topic/email-collaboration/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 11 November 2026. Runbook Lab is not affiliated with Microsoft.
