---
date:
  created: 2026-11-12 21:55:00
slug: signdrop-windows-clfs-zero-day-poc
categories:
  - Endpoint & devices
description: "SignDrop: public exploit code for an unpatched Windows CLFS privilege escalation. No CVE or patch yet. Check the CLFS Mode value and watch Defender alerts."
rl_type: news
rl_area: endpoint
rl_service: [windows, defender]
rl_kits: [mde]
rl_controls: [DE03, DE01]
---

# SignDrop: unpatched Windows CLFS zero-day PoC, no fix yet

On 10 November 2026 a researcher published "SignDrop", source code and a proof of concept for what they call a Windows Common Log File System (CLFS) "0day Local Privilege Escalation". Microsoft has not confirmed it and there is no CVE or patch, so Windows endpoint and server admins should size their exposure, keep the CLFS mitigation on and watch for a Microsoft advisory.

<!-- more -->

!!! note "Runbook card"
    **What changes:** public exploit code now exists for a Windows local privilege escalation that, according to the researcher, turns a standard user into SYSTEM by abusing the CLFS log-file authentication mitigation. The researcher also claims it "can be used to turn off any antivirus/EDR".<br>
    **Who:** Windows endpoint and server admins, SOC teams and MSPs. The researcher says it was tested on "windows 11 26H2, Windows 11 26H2 Experimental, Windows Server 2025 Experimental".<br>
    **By when:** now, to size exposure; the fix arrives when Microsoft ships one (no date, no CVE).<br>
    **Do this:** 1. Read the CLFS authentication Mode value across your fleet (read-only check below) to see how many devices the researcher would call vulnerable. 2. Do not turn the CLFS authentication mitigation off: the researcher warns that this exposes machines to CLFS memory-corruption bugs. 3. Keep Defender tamper protection on and alert on SYSTEM shells started from standard-user sessions and on tamper-protection or antivirus changes. 4. Watch the MSRC Security Update Guide for a CVE or advisory and patch when it lands.<br>
    **Check:** `Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\CLFS\Authentication' -Name Mode` (read-only).<br>
    **Source:** [MSNightmare/SignDrop on GitHub](https://github.com/MSNightmare/SignDrop) (researcher's README, published 10 November 2026).

## What the researcher says

The README describes the flaw as a "Windows Common Log FileSystem Authentication 0day Local Privilege Escalation Vulnerability". In short, as the researcher explains it: a standard user prepares a CLFS log file, then coerces a privileged process (Windows Defender, in the published chain) into opening it. CLFS then creates the log's authentication file as SYSTEM, and with path redirection the attacker controls where that file is written.

Claims that only the researcher makes, with no data or vendor statement behind them so far:

- "if it spawns a SYSTEM shell, you're vulnerable"
- an estimate that "80% of the world's windows installations are vulnerable"
- that it "can be used to turn off any antivirus/EDR", because the file is created from the security product's own process and so passes its self-defence (tamper protection) checks

The README's own test for exposure: "if it's in learning mode or enforcement mode then you're vulnerable". Under `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\CLFS\Authentication\Mode`, "If it's set to 0 or 1 then you're vulnerable. If it's set to 2 or 3 then you're not vulnerable." The researcher adds that disabling the mitigation "will expose your machine to memory corruption vulnerabilities" and that "there is no solution to this except waiting for a patch".

## What is not known

- Microsoft has not confirmed the flaw (The Hacker News), which also reports "No CVE, advisory, or patch for SignDrop appeared in the November security updates".
- It is not in CISA's Known Exploited Vulnerabilities catalog, and The Hacker News says "no attacks using the exploit have been reported".
- Nobody independent has published a test of the EDR-bypass claim or the 80% estimate.
- The researcher tested only Windows 11 26H2, Windows 11 26H2 Experimental and Windows Server 2025 Experimental. Other versions were not named, so their status is unknown.

Context: CLFS has been a frequent target for privilege escalation; The Hacker News counts 10 CLFS flaws in CISA's KEV catalog. Public exploit code for a local privilege escalation is most useful to an attacker who already runs code as a standard user, for example after a phishing payload, which is why the detection steps matter more than the registry count. The Hacker News also notes that "Three of the researcher's earlier Defender flaws have been exploited in attacks."

## How to check

Read-only. Run on a device, or through your management tool as a script that only reads:

```powershell
# CLFS authentication mode (the value the researcher's README uses)
Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\CLFS\Authentication' `
  -Name Mode -ErrorAction SilentlyContinue | Select-Object Mode

# Defender state on the same device
Get-MpComputerStatus | Select-Object AMRunningMode, RealTimeProtectionEnabled, IsTamperProtected
```

Do not run the public proof of concept on production devices. No output means the Mode value is not set on that device; record it separately rather than counting it as 0. Treat the Mode count as the size of your exposure, not as something to change: the researcher's "not vulnerable" values (2 or 3) appear to be the settings where the mitigation is not in learning or enforcement mode, which the researcher warns against.

## How to verify

When Microsoft publishes a CVE or advisory for this, we will add it here with an "Updated" note. After you install that update, the check is Microsoft's own: the KB or security update guide entry for the CVE, and your update compliance report.

## Impact and rollback

Nothing above changes a device. The one change to avoid is changing the CLFS authentication Mode to reach the "not vulnerable" values: according to the researcher, disabling the mitigation trades this bug for the older class of CLFS memory-corruption exploits.

Related: the [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md) (tamper protection and device health controls), the [November Patch Tuesday brief](2026-11-10-outlook-zero-day-cve-2026-124194-november-patch-tuesday.md), the [NTLM signing default (KB5135557)](2026-11-11-ntlm-signing-default-kb5135557.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md) and more [Endpoint & devices news](../topic/endpoint-devices/).

## Sources

- [MSNightmare/SignDrop](https://github.com/MSNightmare/SignDrop) (researcher's README; commits 10 November 2026; read 12 November 2026)
- [New SignDrop Zero-Day Exploit Turns Windows CLFS Security Feature Into SYSTEM Access](https://thehackernews.com/2026/11/new-signdrop-zero-day-exploit-turns.html) (The Hacker News, 12 November 2026; read 12 November 2026)
- [BleepingComputer report on SignDrop](https://www.bleepingcomputer.com/news/security/new-windows-signdrop-zero-day-gives-hackers-system-privileges/) (BleepingComputer, 12 November 2026; relayed by our Research desk, not re-read in this run)

Last reviewed: 12 November 2026. Runbook Lab is not affiliated with Microsoft.
