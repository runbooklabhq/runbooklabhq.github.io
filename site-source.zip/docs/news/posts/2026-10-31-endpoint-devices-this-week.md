---
date:
  created: 2026-10-31 13:20:00
slug: endpoint-devices-this-week-2026-10-31
categories:
  - Endpoint & devices
description: "Windows and Intune changes to 31 October 2026: eMudhra roots removed, Windows 11 23H2 Enterprise updates end 10 November, Intune Administrator protection."
rl_type: news
rl_area: endpoint
rl_service: [windows, intune, defender]
rl_kits: [mde]
rl_controls: [DE01]
---

# Endpoint & devices this week: 3 changes (31 October 2026)

Three confirmed Windows and Intune changes from the week to 31 October 2026. The nearest date: Windows 11 version 23H2 Enterprise and Education stop getting updates on 10 November 2026.

<!-- more -->

This is our weekly Endpoint & devices roundup. It was due on Friday 30 October and is published a day late. Every item comes from a primary source read on 31 October 2026.

## Already briefed

1. **Windows and Edge removed seven eMudhra root certificates on 26 and 27 October 2026.** Endpoint and PKI admins: make sure trust-list updates reach disconnected devices and replace certificates that chain to eMudhra. Brief: [Windows and Edge drop seven eMudhra roots](2026-10-31-emudhra-ca-keys-windows-edge-trust.md). Source: [MC1529467](https://mc.merill.net/message/MC1529467).

## New this week

### Windows 11 23H2 Enterprise and Education: end of updates on 10 November 2026

Microsoft's 30-day reminder: "Windows 11, version 23H2 Enterprise and Education editions reach end of updates on November 10, 2026". Windows Server 2016 and Windows 10 Enterprise LTSC 2021 reach end of updates on 12 January 2027.

- **Who acts:** endpoint admins.
- **Check:** Intune admin center > Devices > Windows, filter by OS version 10.0.22631. Those devices need a feature update ring to 24H2 or later before 10 November. List Server 2016 hosts now for January.
- **Source:** [Windows message center](https://learn.microsoft.com/windows/release-health/windows-message-center) (reminders of 9 and 14 October 2026).

### Intune 2610: Administrator protection settings and a GA template for Defender agent runtime protection

"Microsoft Intune now includes two Administrator protection settings in endpoint security Account protection policies." The "endpoint security template for Microsoft Defender for Endpoint agent runtime protection settings is now generally available." Windows message center (13 October): Administrator protection is turned on by default in the Windows 11 security baseline.

- **Who acts:** endpoint admins.
- **Check:** Intune admin center > Endpoint security > Account protection. Pilot Administrator protection on a small group first, because elevation prompts change.
- **Source:** [What's new in Microsoft Intune](https://learn.microsoft.com/intune/intune-service/fundamentals/whats-new) (week of 26 October 2026). Related: [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md).

More: [all Endpoint & devices news](../topic/endpoint-devices/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 31 October 2026. Runbook Lab is not affiliated with Microsoft.
