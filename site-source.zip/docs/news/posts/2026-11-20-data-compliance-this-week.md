---
date:
  created: 2026-11-20 11:35:00
slug: data-compliance-this-week-2026-11-20
categories:
  - Data & compliance
description: "Data & compliance news to 20 November 2026: Purview DLP for Copilot and local agents in January 2027, label limits on security groups, SharePoint DAG reviews."
rl_type: news
rl_area: data-compliance
rl_service: [purview, sharepoint-onedrive, microsoft-365]
rl_kits: [copilot]
rl_controls: []
---

# Data & compliance this week: 5 changes (20 November 2026)

Five confirmed Purview, SharePoint and Microsoft 365 Backup items from the week to 20 November 2026. The one to plan for: in January 2027 Purview DLP can stop Copilot and local AI agents from processing sensitive files, and Microsoft's enhanced built-in sensitive information types change what your existing DLP and auto-labeling policies detect.

<!-- more -->

This is our weekly Data & compliance roundup. Items rest on the facts our Research desk read at each primary source between 14 and 19 November 2026. On 19 November we corrected the 6 November roundup: Purview DLP and auto-labeling for non-Microsoft apps (MC1449180) now begins "in mid-March 2027 (previously late December 2026)" and should complete by late March 2027; see [corrections](../../about/corrections.md).

## New this week

### Purview at Ignite: DLP for Copilot on unlabelled files and for local agents, public preview January 2027 (17 November 2026)

"Protect the sensitive data that Copilot uses (public preview January 2027): Apply DLP policies that prevent Copilot from processing files with sensitive data, even when those files aren't labeled." "Protect the sensitive data local agents use (public preview January 2027)", naming Claude Code, GitHub CLI, the GitHub Copilot app, Claude Desktop, and the Claude Code and GitHub Copilot extensions for VS Code. Also: "auto-labeling scalability improvements (generally available): Now label up to 500,000 files per day", and "enhanced built-in sensitive information types (SITs) (available starting January 2027)".

- **Who acts:** DLP and compliance admins.
- **Check:** list the DLP and auto-labeling policies that rely on built-in sensitive information types (Purview portal > Data loss prevention > Policies). When the enhanced types arrive in January 2027, run those policies in simulation again before you trust their numbers.
- **Source:** [Secure the data that fuels AI with Microsoft Purview](https://techcommunity.microsoft.com/blog/microsoft-security-blog/secure-the-data-that-fuels-ai-with-microsoft-purview/4573266) (Microsoft Security Blog, 17 November 2026). Related: [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md).

### MC1508238: sensitivity labels for Entra security groups, GA mid-January 2027

"General Availability (Worldwide): Beginning in mid-January 2027 (previously mid-November 2026) and expected to complete in mid-January 2027 (previously late November 2026)". One limit to know before you start: "Once a sensitivity label is applied to a security group, the label cannot currently be changed or removed." Licensing is "such as Microsoft 365 E3 or Microsoft 365 E5, which includes Microsoft Entra ID P1", and admins must turn it on in tenant settings.

- **Who acts:** compliance and Entra admins.
- **Check:** nothing to change now. When it arrives, test on a pilot group first, because a label on a group cannot be removed.
- **Source:** [MC1508238](https://mc.merill.net/message/MC1508238) (updated 14 November 2026).

## Also logged

- **MC1556106, SharePoint data access governance reports and site access reviews are enhanced "starting late November 2026"; "No action is required before rollout".** Useful for oversharing reviews before Copilot. [MC1556106](https://mc.merill.net/message/MC1556106).
- **MC1489971, Purview DLP and inline collection for Edge for Business with Intune multi-admin approval: "Beginning in early January 2027 (previously late November 2026) and expected to complete by end of January 2027 (previously early December 2026)".** [MC1489971](https://mc.merill.net/message/MC1489971).
- **MC1387526, Microsoft 365 Backup full workload backup: "General Availability: We will begin rolling out in January 2027".** Informational. [MC1387526](https://mc.merill.net/message/MC1387526).

Related guides: [Microsoft 365 Copilot oversharing checklist](../../guides/microsoft-365-copilot-oversharing-checklist-jira.md).

More: [all Data & compliance news](../topic/data-compliance/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 20 November 2026. Runbook Lab is not affiliated with Microsoft.
