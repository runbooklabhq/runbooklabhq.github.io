---
date:
  created: 2026-11-27 10:22:00
slug: endpoint-devices-this-week-2026-11-27
categories:
  - Endpoint & devices
description: "Endpoint news to 27 November 2026: Windows hotpatch KB5132043 app errors and workaround, KB5138318 fixes 0x139 on Server 2025, 26H2 reaches unmanaged PCs."
rl_type: news
rl_area: endpoint
rl_service: [windows, intune]
rl_kits: [mde]
rl_controls: []
---

# Endpoint & devices this week: 6 changes (27 November 2026)

Six confirmed Windows and Intune items from the week to 27 November 2026. The first check is for anyone using Windows hotpatch on Windows 11 24H2 or later: after the November 2026 hotpatch (KB5132043) some apps fail to install, start or run with error 0xC0000099, and Microsoft gives a registry workaround.

<!-- more -->

This is our weekly Endpoint & devices roundup. Items rest on the facts our Research desk read at each primary source between 20 and 26 November 2026, and on the Message Center text as read on 27 November 2026.

## Already briefed

1. **NTLM signing (KB5135557): Microsoft added a known issue on 24 November.** Third-party authentication proxies, single sign-on and app-packaging tools that use NTLM may fail after the 10 November 2026 update. Brief with the workaround: [NTLM signing by default (KB5135557)](2026-11-11-ntlm-signing-default-kb5135557.md#known-issue-ntlm-proxies-sso-and-app-packaging).

## New this week

### Hotpatch KB5132043: some apps fail with 0xC0000099; registry workaround (19 November 2026)

Microsoft's alert sits in the Microsoft 365 admin center; we read it as quoted by BleepingComputer and The Register. Microsoft: "Devices which installed the November 2026 hotpatch update [KB5132043], might experience an error when installing, launching, or running some applications. Resulting from this issue, errors similar to 'ERROR_ALLOTTED_SPACE_EXCEEDED (0xC0000099)' are displayed". "Current investigation suggests this issue occurs for applications which load the 32-bit Windows Installer DLL, found as msi.dll." "Devices which installed the November 2026 Windows monthly security update are not expected to be affected by this issue". The workaround: set `HotPatchTableSize` under `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management` to 2000, then restart. The public KB5132043 page said "Microsoft is not currently aware of any issues with this update" when our desk read it on 21 November. No fix date.

- **Who acts:** endpoint admins with hotpatch on Windows 11 24H2 or later (Windows Autopatch or an Intune hotpatch policy).
- **Check:** Microsoft 365 admin center > Health > Windows release health, for the alert. Ask the help desk for 0xC0000099 tickets on hotpatched devices.
- **Do this:** apply the registry value only to the affected devices, confirm the value type in the alert before you script it, and restart. Keep the devices on hotpatch: the security fixes stay applied.
- **Source:** [BleepingComputer](https://www.bleepingcomputer.com/news/microsoft/microsoft-confirms-app-installation-launch-issues-after-hotpatch/) (19 November 2026); [The Register](https://www.theregister.com/os-platforms/2026/11/20/microsoft-suggests-registry-hack-to-work-around-hotpatch-woes/5311279) (20 November 2026).

### KB5138318: out-of-band hotpatch fixes stop error 0x139 on Windows Server 2025 (25 November 2026)

Microsoft: "Microsoft has released a new Windows out-of-band (OOB) update today, November 25, 2026, to address an issue affecting a limited number of Windows Servers with Router Advertisement (RA) enabled that receive time-bound IPv6 routes. Affected devices might stop unexpectedly with stop error 0x139 (KERNEL_SECURITY_CHECK_FAILURE) when a route timer expires." It "affects some Windows Server 2025 devices after installing the November 2026 Windows security hotpatch update." The update is non-security, comes through Windows Update for hotpatch-enrolled servers, "downloads and installs automatically and takes effect without requiring a restart".

- **Who acts:** server admins running Windows Server 2025 on hotpatch.
- **Check:** that KB5138318 is in the update history of each hotpatch server; Event Viewer > Windows Logs > System for unexpected restarts with bugcheck 0x139 since the November hotpatch.
- **Do this:** nothing to install by hand; if a server has not received it, check that it can reach Windows Update.
- **Source:** [MC1568439](https://mc.merill.net/message/MC1568439); [Windows message center](https://learn.microsoft.com/en-us/windows/release-health/windows-message-center) (25 November 2026).

### Windows 11 26H2 now installs automatically on PCs that IT does not manage (from 18 November 2026)

Microsoft: "Starting November 18, we are taking the next step in version 26H2's phased rollout to make it easier to get the update. We are gradually expanding automatic delivery, beginning with devices running Windows 11, versions 24H2 and 25H2, that are not managed by IT departments." "This process depends on Windows Update settings and is available for personal devices and non-managed business devices." Windows settings backup is on by default from 26H2 on eligible devices ([our 20 November item](2026-11-20-endpoint-devices-this-week.md)), so unmanaged business PCs that move now get that default too.

- **Who acts:** MSPs and admins of small sites with PCs that have no Intune or Windows Update for Business policy.
- **Check:** Intune admin center > Devices > Windows > Feature updates, or your RMM's patch report: list business PCs with no feature update policy.
- **Do this:** put those PCs under a feature update policy if you need to control when they move, and read the 26H2 known issues first.
- **Source:** [Windows 11, version 26H2 known issues and notifications](https://learn.microsoft.com/en-us/windows/release-health/status-windows-11-26h2) (status as of 18 November 2026).

## Also logged

- **PowerShell 7 comes to Windows: "Beginning with the next release of Windows, PowerShell 7 will be included as the upgrade for Windows PowerShell 5.1."** "Your existing automation needs no changes." Known gaps of the MSIX package: running as SYSTEM, DISM cmdlets, machine-wide settings. Test your SYSTEM-context scripts. [PowerShell Team blog](https://devblogs.microsoft.com/powershell/powershell-7-coming-to-windows/) (17 November 2026).
- **MC1567251, "Windows Server 2028 is now available in public preview".** Microsoft: "The release includes a hardened Server Core configuration by default, a new security baseline, and Trusted Launch for virtual machines." Lab only. [MC1567251](https://mc.merill.net/message/MC1567251).
- **MC1568568, tap indicator for security keys on display-based NFC readers in Windows 11**, from the November 2026 non-security update; set it with the Intune Policy CSP CredentialProviders or the Group Policy `EnableNFCTapLocationIndicator` (as read on 26 November). Useful where staff sign in with FIDO2 keys on NFC screens. [MC1568568](https://mc.merill.net/message/MC1568568).

Related: [Defender for Endpoint ASR Kit](../../kits/defender-endpoint-asr.md) · [Defender ASR rules: audit to block](../../guides/defender-asr-rules-audit-to-block.md).

More: [all Endpoint & devices news](../topic/endpoint-devices/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 27 November 2026. Runbook Lab is not affiliated with Microsoft.
