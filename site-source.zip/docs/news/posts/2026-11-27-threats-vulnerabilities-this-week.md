---
date:
  created: 2026-11-27 10:24:00
slug: threats-vulnerabilities-this-week-2026-11-27
categories:
  - Threats & vulnerabilities
description: "Threats to 27 November 2026: CISA KEV adds Mitel MiCollab, Xen Orchestra, Juniper SSR, Drupal Core, Cisco Expressway and N-able MailAssure flaws."
rl_type: news
rl_area: detection-response
rl_service: [other]
rl_kits: [mde]
rl_controls: []
---

# Threats & vulnerabilities this week: 18 changes (27 November 2026)

CISA added 19 vulnerabilities to its Known Exploited Vulnerabilities (KEV) catalogue between 20 and 25 November 2026, none in a Microsoft product; 18 are new here and the 19th, VMware vCenter, is already in our 20 November roundup. The first check is for anyone running Mitel MiCollab, Vates Xen Orchestra or Juniper Session Smart Router: CISA's due date for most of those flaws is 28 November 2026.

<!-- more -->

This is our weekly Threats & vulnerabilities roundup. Every entry below was re-read in the CISA KEV catalogue on 27 November 2026 (catalogue released 25 November 2026, 1,805 entries; no release since, over the US Thanksgiving holiday). Known ransomware use is "Unknown" for all 18 listed here. The due dates are CISA's for US federal agencies; treat them as the latest date for everyone. The vendor advisories were not opened for this roundup: take fixed versions from each vendor's advisory linked in the catalogue entry.

## Already briefed

1. **Azure API Management Classic: a management-plane flaw was exploited to read stored secrets; Microsoft mitigated it on 19 November 2026.** Customers rotate the secrets and investigate. Brief: [Azure API Management Classic flaw](2026-11-24-azure-api-management-classic-flaw-secrets-exploited.md).
2. **VMware vCenter CVE-2026-123890 was added to CISA KEV on 20 November 2026, due 23 November 2026.** Mandiant reports exploitation since early September 2026. Patch and rotate the vCenter SAML signing certificates. Item with the 21 November update: [Threats & vulnerabilities, 20 November](2026-11-20-threats-vulnerabilities-this-week.md).

## New this week

### Mitel MiCollab: five flaws in the AWV conferencing component, four due 28 November 2026 (KEV 25 November)

CISA lists CVE-2026-133324 ("could allow an unauthenticated attacker to bypass authentication controls"), CVE-2026-133275 ("could allow an unauthenticated attacker to upload arbitrary files"), CVE-2026-133303 ("execute arbitrary commands using pre-staged malicious content"), CVE-2026-133323 ("execute arbitrary system commands"), all due 28 November 2026, and CVE-2026-133311 ("access sensitive information using a specific system-generated random identifier"), due 9 December 2026. All five sit in "the Audio, Web and Video Conferencing (AWV) component".

- **Who acts:** owners of Mitel MiCollab, and MSPs that host it.
- **Check:** whether the MiCollab AWV web interface is reachable from the internet.
- **Do this:** apply Mitel's fix or take AWV off the internet before 28 November 2026; look for files uploaded to the server that you did not put there.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 27 November 2026).

### Vates Xen Orchestra CVE-2026-133469: authentication bypass with an empty JSON token, due 28 November 2026

CISA: the flaw "could allow an unauthenticated attacker to bypass authentication and perform actions with administrative privileges via a specially crafted authentication token containing an empty JSON object."

- **Who acts:** owners of Xen Orchestra (XCP-ng management).
- **Check:** Xen Orchestra version and whether its web interface is reachable from user networks or the internet.
- **Do this:** update as Vates' advisory says, restrict the management interface, and review recent admin actions in its logs.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 27 November 2026).

### HPE Juniper Session Smart Router and Conductor CVE-2026-103406: root through a crafted salt minion ID, due 28 November 2026

CISA: the products "contain an OS command injection vulnerability that could allow a remote attacker to execute arbitrary commands as root via a specially crafted salt minion ID." Added 25 November 2026.

- **Who acts:** owners of Juniper SSR and Conductor (SD-WAN), and MSPs.
- **Check:** your SSR and Conductor inventory and software versions.
- **Do this:** apply HPE Juniper's fix or mitigation, then follow the forensic triage steps CISA's entry points to.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 27 November 2026).

### Drupal Core CVE-2026-132165: site takeover through install.php, due today, 27 November 2026

CISA: "Drupal Core contains a not failing securely vulnerability that could allow an unauthenticated attacker to take over an existing site or execute arbitrary code via the Drupal installer. Under specific conditions, the attacker can use install.php to attempt to reinstall Drupal on the site." BleepingComputer and The Hacker News reported active exploitation and public exploit details on 25 November; Drupal's own advisory was not read for this roundup.

- **Who acts:** owners of Drupal sites, including marketing and intranet sites run by agencies.
- **Check:** web server logs for requests to `/core/install.php`.
- **Do this:** update Drupal core as the Drupal advisory says today, and block `install.php` at the web server.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 27 November 2026).

### Cisco Expressway CVE-2026-76466: hard-coded credentials, root on clustered devices (KEV 20 November, due 23 November 2026)

CISA: the flaw "allows an unauthenticated, remote attacker with persistent cookies and network access to execute commands as root on a clustered device via the database service." The due date has passed.

- **Who acts:** owners of Cisco Expressway clusters (Teams and Webex interop edges, MSPs).
- **Check:** whether your Expressway nodes are clustered and on the fixed release in Cisco's advisory.
- **Do this:** patch now and restrict cluster traffic to the cluster peers.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 27 November 2026).

### N-able MailAssure (SpamExperts) CVE-2026-134624: SSRF in the LDAP sync check, due 26 November 2026

CISA: the flaw "allows an authenticated API user to connect to arbitrary internal hosts and ports, determine which are reachable, and send crafted data to internal services." It follows the N-able Mail Assure and SpamExperts security incident in our [20 November Email & collaboration roundup](2026-11-20-email-collaboration-this-week.md).

- **Who acts:** MSPs and admins who use N-able MailAssure or SpamExperts in front of Exchange Online.
- **Check:** once portal and API access return (N-able disabled them during the incident), which API users exist on your MailAssure account and when they last connected.
- **Do this:** follow N-able's notice, remove API users you do not need and rotate API credentials.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 27 November 2026).

## Also logged (CISA KEV, read 27 November 2026)

- **Optimizely Web Experimentation CVE-2026-132224, due 27 November:** a flaw "in its account signup flow that could allow an attacker to impersonate existing customer users and modify Project JavaScript". Review recent changes to your project's JavaScript.
- **Idunno AntiCsrf CVE-2026-131914, due 27 November:** deserialisation that "allows an unauthenticated remote attacker to execute arbitrary code via object injection". CISA notes the product "could be end-of-life (EoL) and/or end-of-service (EoS)". Search .NET projects for the package and remove it.
- **Danfoss AK-SM 800A Series, three flaws:** CVE-2023-25914 (path traversal, read system files) and CVE-2023-25915 ("run arbitrary commands"), due 28 November; CVE-2025-41450 (web report "exposing sensitive information, including internal IP addresses, usernames, and store names"), due 9 December. Keep these controllers off the internet.
- **Project MONAI MONAI Label CVE-2026-133968, due 26 November:** path traversal that "allows an unauthenticated remote attacker to write arbitrary files outside the intended datastore directory, potentially resulting in remote code execution". BleepingComputer links MONAI Label to the Cairn item in our AI security roundup; Amazon does not name the application.
- **Apache Roller CVE-2026-129448, due 23 November:** code execution "via the XML-RPC endpoint, which accepts and deserializes vendor extension types before authentication"; it covers the same flaw as CVE-2026-82384 across more versions.
- **SAP NetWeaver Enterprise Portal CVE-2025-42884, due 23 November:** CISA: it "allows an unauthenticated attacker to disclose or modify server information via injected JNDI environment properties". Apply the SAP note.

Source for all six: [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog). Check in Defender: Defender Vulnerability Management > Weaknesses, search each CVE id.

Related: [Defender for Endpoint ASR Kit](../../kits/defender-endpoint-asr.md) · [Microsoft 365 Hardening Kit](../../kits/m365-hardening.md).

More: [all Threats & vulnerabilities news](../topic/threats-vulnerabilities/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 27 November 2026. Runbook Lab is not affiliated with Microsoft.
