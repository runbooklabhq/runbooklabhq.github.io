---
date:
  created: 2026-11-05 09:50:00
slug: defender-rbac-auto-enable-review-imported-roles
categories:
  - Endpoint & devices
description: "MC1537494: Microsoft Defender RBAC turns on automatically for Defender and Sentinel from early December 2026. Review imported roles by 2 December."
rl_type: news
rl_service: [defender]
rl_kits: []
rl_controls: []
---

# MC1537494: Defender RBAC auto-enables from December

MC1537494 (published 3 November 2026) says Microsoft Defender role-based access control (Defender RBAC) will be "enabled automatically" for Defender and Sentinel portal workloads, with the global rollout starting "early December 2026" and expected "to complete by late January 2027". Defender and Sentinel admins, and MSPs that manage tenants through GDAP, should review the auto-imported role assignments in the Defender portal before the "Act by" date of 2 December 2026.

<!-- more -->

!!! note "Runbook card"
    **What changes:** your existing Defender and Sentinel roles are imported into Defender RBAC; "approximately 30 days after the in-portal notification date" Defender RBAC is activated automatically for the in-scope workloads, and portal authorisation "defaults to the new RBAC roles".<br>
    **Who:** tenants using Microsoft Defender or Microsoft Sentinel portal experiences (the portal banner names the workloads affected); for Defender for Office 365 it applies to organisations with Plan 2 (separately or in a suite such as Microsoft 365 E5).<br>
    **By when:** Act by 2 December 2026. Rollout "early December 2026" to "late January 2027". Your own activation date is shown in the Defender portal; Microsoft hasn't published per-workload dates in the post.<br>
    **Do this:** 1. Open the imported roles and check that each user and group has the expected role and scope. 2. Fix assignments now (Microsoft says you can, "even if Defender RBAC is not yet activated for that workload"). 3. Move any script that sets roles through an API to the Defender RBAC API, and update SOC runbooks. 4. Review the imported assignments against your change-management and access-governance requirements before activation, as Microsoft recommends.<br>
    **Check:** Microsoft Defender portal > Permissions > Roles (the banner on the "Permissions and roles" page confirms activation).<br>
    **Source:** [MC1537494](https://mc.merill.net/message/MC1537494) (published 3 November 2026).

## What Microsoft says

MC1537494 is titled "Attention needed: Your tenant will be auto enabled for the new Microsoft Defender RBAC model" and tagged "Major change" and "Admin impact", service Microsoft Defender XDR. Microsoft describes Defender RBAC as "becoming the single access model for all Defender and Sentinel portal experiences", rolled out in phases.

The sequence, per the post:

1. A banner in the Defender portal says which workloads will move. "Legacy roles are automatically imported." The banner and the import start the notification period.
2. During that period the import has "no operational impact until activation". You can review and adjust the imported roles at any time, and you can re-run the import manually.
3. "Beginning approximately 30 days after the notification date", Defender RBAC is enabled automatically for the named workloads. A banner on the "Permissions and roles" page confirms activation.
4. After activation, "legacy role assignments are no longer required to operate those portal experiences".

"The portal will identify which workloads will be enabled automatically and their activation dates." The post does not list them, so check your own portal rather than assume.

## What does not change

- Permissions for Microsoft Purview, Exchange Online, Entra directory roles, Privileged Identity Management and Azure resources not related to Sentinel "remain unchanged". Azure RBAC still governs Logic Apps and Workbooks.
- PowerShell with Defender for Office 365 "will continue to work as is".
- Entra roles Global Administrator, Security Administrator, Security Operator and Security Reader "continue to grant access to the Microsoft Defender portal as they do today", now mapped to Defender RBAC permissions ([mapping on Microsoft Learn](https://learn.microsoft.com/en-us/defender-xdr/compare-rbac-roles)).
- Delegated access (B2B/GDAP) and multi-tenant management "remains unchanged", and roles assigned to B2B/GDAP users or groups are included in the import.

Two points that do move: Sentinel workspace roles (Sentinel Reader, Responder, Contributor) "do get enabled automatically to Defender RBAC", and Email and Collaboration and Exchange Online permissions "are no longer required to operate Microsoft Defender for Office 365 portal experiences once Defender RBAC is active". They still "continue to govern Exchange Online and Microsoft Purview scenarios", so don't remove them.

## Opt-out and rollback

"Self-service opt-out is available after activation." Microsoft says the "workload settings" control in Defender RBAC lets you "instantly revert to your legacy system if needed". The opt-out exists only after activation. Our advice: finish the review before 2 December, and keep the first day after activation quiet, because a missing role usually shows up first in the SOC queue.

## How to check (read-only)

In the portal: Microsoft Defender portal > Permissions > Roles. For each imported role, open the assignments and confirm the users, groups and scopes (device groups keep working; Defender RBAC also adds Cloud, Sentinel and Identity scopes).

To compare against who holds the Entra roles that keep portal access, our example in Microsoft Graph PowerShell (read-only, needs RoleManagement.Read.Directory; lists active assignments only, so check PIM eligible assignments separately; groups are listed as one entry, so check their members too):

```powershell
Connect-MgGraph -Scopes "RoleManagement.Read.Directory"
$roles = 'Global Administrator','Security Administrator','Security Operator','Security Reader'
Get-MgDirectoryRole -All | Where-Object DisplayName -in $roles | ForEach-Object {
  $r = $_
  Get-MgDirectoryRoleMember -DirectoryRoleId $r.Id -All |
    Select-Object @{n='Role';e={$r.DisplayName}}, Id, @{n='Name';e={$_.AdditionalProperties.displayName}}
}
```

## How to verify

Our suggested check: after activation, ask one analyst from each role you rely on (a SOC analyst, a Security Operator, a member of a GDAP partner group) to confirm they still see incidents, Advanced hunting and the threat policies they used before. The "Permissions and roles" page banner confirms that activation happened.

## Related changes

The Defender for Office 365 change to the Entra Security Operator role mapping (MC1486293) now runs "early December 2026" to "mid-January 2027", in the same window. Details in [Microsoft 365 changes landing in November](2026-11-04-microsoft-365-changes-november-2026.md).

Related: the [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md), the [privileged access (PIM) guide for Global Administrators](../../guides/entra-privileged-access-pim-global-admins.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [Endpoint & devices news](../topic/endpoint-devices/).

## Sources

- [MC1537494: Attention needed: Your tenant will be auto enabled for the new Microsoft Defender RBAC model](https://mc.merill.net/message/MC1537494) (published 3 November 2026; read 5 November 2026)
- [Microsoft Learn: Compare Microsoft Defender XDR RBAC roles](https://learn.microsoft.com/en-us/defender-xdr/compare-rbac-roles) (linked from MC1537494)
- [MC1486293: Changes to Unified RBAC permission mapping for Microsoft Entra Security Operator role](https://mc.merill.net/message/MC1486293) (last updated 3 November 2026)

Last reviewed: 5 November 2026. Runbook Lab is not affiliated with Microsoft.
