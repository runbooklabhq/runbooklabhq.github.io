---
date:
  created: 2026-11-21 22:00:00
slug: entra-connect-health-api-flaw-tenant-metadata-exposed
categories:
  - Identity & access
description: "Entra Connect Health API flaw exploited: admin emails and tenant metadata read, fixed 19 Nov 2026. Check Service Health, warn admins, phishing-resistant MFA."
rl_type: news
rl_area: identity
rl_service: [entra]
rl_kits: [ca, m365]
rl_controls: [CA05, E04]
---

# Entra Connect Health flaw exposed admin emails, tenant data

Microsoft is notifying tenants that a flaw in the Entra Connect Health API, introduced on 23 July 2026 and fixed server-side on 19 November 2026, was exploited for "unauthorized read-only access to tenant-level metadata", including administrator and technical-contact email addresses. Entra and identity admins, and MSPs for each customer tenant, should check Azure Service Health for the notice now and prepare the exposed admins for targeted phishing.

<!-- more -->

!!! note "Runbook card"
    **What changes:** attackers read tenant metadata through a Connect Health API flaw. Microsoft's notice: "We did not identify any unauthorized configuration changes." No passwords, password hashes, authentication tokens or valid cryptographic keys were exposed.<br>
    **Who:** tenants with Microsoft Entra Connect Health that received Microsoft's security notification in Azure Service Health. Some MSPs report notices for several customer tenants.<br>
    **By when:** now. Microsoft says no software update or customer remediation is required; the follow-up steps below are Microsoft's recommendations.<br>
    **Do this:** 1. Look for the notice in Azure Service Health, per tenant. 2. Tell your security team and the people behind the exposed admin and technical-contact addresses to expect targeted phishing. 3. Make sure every privileged account uses phishing-resistant MFA. 4. Review your Connect Health configuration and the Entra audit and sign-in logs for anything unusual.<br>
    **Check:** Azure portal > **Service Health** > **Security advisories** (read-only).<br>
    **Source:** Microsoft's notification to affected tenants and a Microsoft spokesperson, as reported by [BleepingComputer](https://www.bleepingcomputer.com/news/security/microsoft-entra-connect-health-flaw-exploited-to-steal-tenant-data/) (21 November 2026).

## What Microsoft says

Microsoft found the flaw in the Entra Connect Health API on 9 November 2026. It had been introduced on 23 July 2026. Microsoft deployed a server-side fix on 19 November 2026, finished its investigation on 20 November and began notifying affected organisations through Azure Service Health.

From the notice: "On 20 November 2026, we concluded our investigation and determined that unauthorized read-only access to tenant-level metadata associated with your organization had occurred. We did not identify any unauthorized configuration changes."

A Microsoft spokesperson told BleepingComputer: "We deployed a fix on November 19, 2026, and have notified impacted customers through Azure Service Health, providing guidance and support."

According to the notice, the exposed data was:

- email addresses of tenant technical contacts and administrator accounts;
- tenant IDs, display names, initial domain names, country codes and region;
- Entra licence tiers and directory synchronisation status, including the last sync timestamp;
- Connect Health onboarding status;
- an expired certificate once used to register Connect Health agents with a Microsoft internal service that was decommissioned in late 2024.

Not exposed, per the notice: user passwords, password hashes, authentication tokens, valid cryptographic keys, on-premises server and Active Directory topology details, or Azure subscription information.

## What is not known

- How many tenants were affected. Microsoft has not said.
- Who exploited the flaw and when the access began. Not disclosed.
- No CVE has been published; the fix was made in the service.
- We could not read the Service Health notice ourselves. The quotes above come from BleepingComputer and [SecurityOnline](https://securityonline.info/microsoft-entra-connect-health-exposure/), which both quote Microsoft's notice.

## How to check

1. **Did you get the notice?** Azure portal > **Service Health** > **Security advisories**. MSPs: repeat for every customer tenant; one admin reported that the notices arrived hours apart.
2. **Whose addresses were in scope?** List the technical-notification addresses and the members of your activated admin roles. Read-only, Microsoft Graph PowerShell; these commands are ours, not from Microsoft's notice:

```powershell
Connect-MgGraph -Scopes "Organization.Read.All","RoleManagement.Read.Directory" -NoWelcome

# Technical contact addresses on the tenant
(Get-MgOrganization).TechnicalNotificationMails

# Members of every activated directory role
Get-MgDirectoryRole -All | ForEach-Object {
  $role = $_.DisplayName
  Get-MgDirectoryRoleMember -DirectoryRoleId $_.Id -All |
    Select-Object @{n='Role';e={$role}},
      @{n='UPN';e={$_.AdditionalProperties.userPrincipalName}}
} | Sort-Object Role | Format-Table -AutoSize
```

3. **Do those accounts use phishing-resistant MFA?** The read-only checks for this are on the control [CA05: Require phishing-resistant MFA for administrators](../../controls/conditional-access/ca05-require-phishing-resistant-mfa-for-administrators.md) and, for emergency access accounts, on [Break-glass accounts and mandatory MFA: am I affected?](../../guides/break-glass-mandatory-mfa-am-i-affected.md).
4. **Optional:** Microsoft's read-only scripts at aka.ms/ConnectHealth/scripts show which types of tenant metadata the API returns. They show current values, not what was accessed.

<!--rl-checknext-->

## What to do

Steps 1, 2 and 4 follow Microsoft's recommendations in the notice; the portal paths and controls are ours.

1. Tell your security team and the admins whose addresses appear in step 2 to expect phishing and social engineering that uses your tenant name, domain and licence tier.
2. Require phishing-resistant MFA for every privileged role with a Conditional Access authentication strength (control [CA05](../../controls/conditional-access/ca05-require-phishing-resistant-mfa-for-administrators.md)). Create the policy in Report-only first and keep the break-glass accounts excluded.
3. Keep admin roles on few, cloud-only accounts (control E04 in the [Microsoft 365 Hardening Kit](../../kits/m365-hardening.md#controls)), so fewer addresses are worth targeting.
4. Review the Connect Health configuration in the Entra admin center and the Entra audit and sign-in logs for the period from 23 July 2026.

## Impact and rollback

The checks change nothing. A Conditional Access policy that requires phishing-resistant MFA blocks any admin without a passkey, FIDO2 key, Windows Hello for Business or certificate method: register those methods first and run the policy in Report-only before you turn it on. To roll back, set the policy back to Report-only or Off.

Related: the [Conditional Access Baseline Kit](../../kits/conditional-access.md), the [Microsoft 365 Hardening Kit](../../kits/m365-hardening.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md) and more [Identity & access news](../topic/identity-access/).

## Sources

- [Microsoft Entra Connect Health flaw exploited to steal tenant data](https://www.bleepingcomputer.com/news/security/microsoft-entra-connect-health-flaw-exploited-to-steal-tenant-data/) (BleepingComputer, 21 November 2026, quoting Microsoft's Service Health notification and a Microsoft spokesperson; read 21 November 2026)
- [Microsoft Entra Connect Health exposure](https://securityonline.info/microsoft-entra-connect-health-exposure/) (SecurityOnline, 21 November 2026, quoting the same notification; read by our Research desk on 21 November 2026)

Last reviewed: 21 November 2026. Runbook Lab is not affiliated with Microsoft.
