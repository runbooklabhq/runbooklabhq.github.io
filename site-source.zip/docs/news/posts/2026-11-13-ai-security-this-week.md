---
date:
  created: 2026-11-13 12:40:00
slug: ai-security-this-week-2026-11-13
categories:
  - AI security
description: "AI security news to 13 November 2026: update Claude Code to 2.1.321, review Cowork connectors, Copilot scheduled prompts leave Power Platform on 31 December."
rl_type: news
rl_area: ai
rl_service: [copilot, dev-tools, other]
rl_kits: [copilot, agents]
rl_controls: []
---

# AI security this week: 38 changes (13 November 2026)

Thirty-eight confirmed AI security items from the week to 13 November 2026, each with who acts, the check and the source. The nearest date is 18 November 2026, when the MODS Workforce Insights endpoint retires (MC1542066): tenants that upload custom HR attributes for Copilot act first.

<!-- more -->

This is our weekly AI security roundup. We could not re-read the primary sources on 13 November 2026, so items rest on the facts Research read at each primary source between 7 and 13 November 2026. Where Research could only read a secondary source, the item says so.

## Already briefed

1. **8 November: the MODS Workforce Insights endpoint retires on 18 November 2026 (MC1542066).** Who acts: the Organizational Data Source Administrator in tenants that upload custom attributes to that endpoint. Check: in MODS, note which destination endpoints are selected. Brief: [MODS Workforce Insights endpoint retirement](2026-11-08-mods-workforce-insights-endpoint-retirement-mc1542066.md). Source: [MC1542066](https://mc.merill.net/message/MC1542066).
2. **9 November: GPUStack CVE-2026-102895 gives unauthenticated admin access and is in CISA KEV (due 12 November 2026).** Who acts: teams that self-host GPUStack. Check: `pip show gpustack` shows 2.2.0 or later. Brief: [GPUStack admin bypass in CISA KEV](2026-11-09-gpustack-auth-bypass-cve-2026-102895-kev.md). Source: [GHSA-gj9m-f8ph-pmhr](https://github.com/gpustack/gpustack/security/advisories/GHSA-gj9m-f8ph-pmhr).
3. **10 November: Claude models in Copilot turn on for EU and EFTA tenants that made no selection on 9 December 2026 (MC1546438), and Microsoft 365 Copilot in Power BI is enabled by default from 8 December 2026 (MC1546429).** Who acts: AI Administrators or Global Administrators; Fabric and Power BI admins for MC1546429. Check: Microsoft 365 admin center > Copilot > Settings > View all > AI providers operating as Microsoft subprocessors > Anthropic. Brief: [Claude in Copilot on by default 9 December](2026-11-10-claude-copilot-default-on-eu-data-boundary-mc1546438.md). Source: [MC1546438](https://mc.merill.net/message/MC1546438) · [MC1546429](https://mc.merill.net/message/MC1546429).

## New this week

### Claude Code 2.1.319 and 2.1.321: permission bypass, sandbox escape and MCP OAuth fixes (2.1.321 on npm 9 November 2026)

2.1.319 (no date in the changelog): "Fixed a Bash permission bypass where a crafted environment prefix could hide part of a command from permission checks" and "Fixed a sandbox escape when creating a worktree". 2.1.321: "Fixed MCP OAuth requests sending secrets such as refresh tokens to another host when a server redirected them", plus `cp` and `mv` deny-rule fixes. Policy change: mods Claude writes now "turn on without asking in auto and bypass modes, even with managed `allowUnsandboxedCommands: false` or `allowManagedDomainsOnly`". Research found no CVE or GHSA for 2.1.319.

- **Who acts:** teams running Claude Code with deny and ask rules or managed settings.
- **Check:** `claude --version` shows 2.1.321 or later. Rotate MCP OAuth refresh tokens for servers that redirect, and recheck what managed settings guarantee in auto and bypass modes.
- **Source:** [Claude Code CHANGELOG](https://raw.githubusercontent.com/anthropics/claude-code/main/CHANGELOG.md). Related: [M365 AI Agent Hardening Kit](../../kits/ai-agent-hardening.md) · [last week's Claude Code item](2026-11-06-ai-security-this-week.md).

### ThisBash: a malicious browser extension can drive Claude Desktop through Dispatch to code execution (Forever Security, 4 November 2026)

Forever Security (Gal Weizman) reported the issue on 14 May. On 19 May Anthropic called it valid but closed it as a duplicate of an internal finding. On 13 October Anthropic said Dispatch would be retired, "targeting the end of October 2026". Whether that retirement has happened is not confirmed. The authors say Remote Control and Cowork share the same pattern. There is no CVE; this is a proof of concept, with no exploitation in the wild reported. GBHackers (6 November) confirms the research.

- **Who acts:** endpoint admins where staff use Claude Desktop or claude.ai with a corporate account.
- **Check:** `reg query HKLM\SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallAllowlist` and `reg query HKLM\SOFTWARE\Policies\Google\Chrome\ExtensionInstallAllowlist` show whether an extension allowlist is in force (set through Intune or GPO). Inventory personal Claude Desktop installs.
- **Source:** [Forever Security, 4 November 2026](https://forever.security/blog/thisbash-claude-dispatch-browser-extension-rce). Related: [Claude Code Cursor extension backdoor](2026-10-31-claude-code-cursor-extension-ssh-backdoor.md).

### Copilot Cowork follows Microsoft 365 admin center connector settings; Power Platform DLP does not apply (MC1542062, 6 November 2026)

MC1542062: "Rollout completes by mid-November 2026." Cowork "respects these settings when creating connections and executing actions, including connections established before a connector was blocked", and connector policies also apply to Cowork Automations. The post states: "Power Platform admin center Data Loss Prevention (DLP) policies do not apply to Cowork." Microsoft asks admins to "Review available connectors in the Microsoft 365 admin center under Agents > Tools." Our assessment: tenants that relied only on Power Platform DLP to block connectors have likely had no effective block for Cowork.

- **Who acts:** Copilot and Power Platform admins.
- **Check:** Microsoft 365 admin center > Agents > Tools: list which connectors are available to Cowork and compare with your Power Platform DLP policies.
- **Source:** [MC1542062](https://mc.merill.net/message/MC1542062). Related: [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md) · [Copilot Studio agent governance checklist](../../guides/copilot-studio-agent-governance-checklist.md).

### Cowork, Code and Autopilot entry points visible by default to Copilot users; new admin setting mid-November (MC1546354, 9 November 2026)

MC1546354 is a "Major change". "Mid-November 2026: The new admin setting, "Access requests to usage-based billing experiences," will become available." Entry points "will be visible by default to users with a Microsoft 365 Copilot license, even if their organization has not enabled access." "End of January 2027: The new discoverability behavior and admin setting will be enforced", the old setting "Allow users to discover and use AI experiences enabled by usage-based billing" retires, and deferred release follows "at the end of February 2027". "Existing spending policies" still govern use.

- **Who acts:** Microsoft 365 and Copilot admins.
- **Check:** in the Microsoft 365 admin center, once the setting appears, note its value and which users hold a spending policy.
- **Source:** [MC1546354](https://mc.merill.net/message/MC1546354). Related: [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

### Copilot scheduled prompts move off Power Platform; the old experience retires 31 December 2026 (MC1550533)

MC1550533 (published 12 November, "Major change", Act by 31 December 2026): "The existing Power Platform-based scheduled prompts experience will retire on December 31, 2026." Rollout: "Frontier/TAP: November 11, 2026 Worldwide rollout: November 30 through December 31". The new experience "operates independently of Power Platform, including where Power Automate is disabled". So a tenant that turned off Power Automate to stop scheduled prompts loses that block.

- **Who acts:** Copilot admins, especially those who blocked Power Automate to control scheduled prompts.
- **Check:** note how your tenant controls scheduled prompts today (Power Automate licences, Power Platform admin center > Policies > Data policies) and whether that control still applies after 30 November.
- **Source:** [MC1550533](https://mc.merill.net/message/MC1550533). Related: [Agent Builder scheduled prompts in last week's roundup](2026-11-06-ai-security-this-week.md) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

### November Patch Tuesday AI and agent CVEs: Agents SDK, MCP Gateway, Copilot for JetBrains, Azure OpenAI (10 November 2026)

CVE-2026-109485, "Microsoft 365 Agents SDK Information Disclosure Vulnerability", CVSS 6.3. CVE-2026-109492, "Microsoft MCP Gateway Elevation of Privilege Vulnerability", CVSS 8.8. CVE-2026-83953, GitHub Copilot for JetBrains command injection, CVSS 5.5. CVE-2026-119990, Azure OpenAI, Critical per Qualys and Rapid7. None is reported as exploited or in CISA KEV. Sources: CVE records via OpenCVE, Rapid7 and Qualys; the MSRC pages could not be read.

- **Who acts:** Agents SDK developers, MCP Gateway operators, JetBrains users of GitHub Copilot.
- **Check:** Agents SDK versions in package manifests, the deployed MCP Gateway version, and the Copilot plugin in JetBrains Settings > Plugins. Azure OpenAI is service-side: no customer action unless MSRC says otherwise.
- **Source:** MSRC [CVE-2026-109485](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-109485) · [CVE-2026-109492](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-109492) · [CVE-2026-83953](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-83953) · [CVE-2026-119990](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-119990) (not read). Related: [Outlook zero-day and November Patch Tuesday](2026-11-10-outlook-zero-day-cve-2026-124194-november-patch-tuesday.md).

### Bugs found with AI this week: Apache HTTP Server and NetScaler Console (11 and 12 November 2026)

Apache HTTP Server 2.4.71, released 11 November, fixes "CVE-2026-119618 (critical): mod_http2: heap corruption and RCE in assign_headers" in 2.4.55 to 2.4.70. Research logged it as found by Anthropic's OSS Scanner and Google. No exploitation stated. Citrix CTX697320 (updated 12 November) fixes NetScaler Console authentication bypass CVE-2026-120869, CVSS 4.0 9.4, in "Citrix NetScaler Console 14.1-74.34 and later releases". Citrix credits: "Discovered by the Cloud Software Group Product Security Team using advanced AI-assisted analysis". Citrix is "not aware of any exploits" (as quoted by The Hacker News).

- **Who acts:** owners of Apache web servers and NetScaler Console.
- **Check:** `httpd -v` or `apache2 -v` shows 2.4.71 or your vendor's fixed package; the NetScaler Console version shows 14.1-74.34 or later.
- **Source:** [Apache httpd 2.4 vulnerabilities](https://httpd.apache.org/security/vulnerabilities_24.html) · [Citrix CTX697320](https://support.citrix.com/external/article/CTX697320). Full details: [Threats and vulnerabilities this week](2026-11-13-threats-vulnerabilities-this-week.md).

## Also logged

- **Claude Enterprise security controls (Anthropic, 5 November).** "The security center is in beta." "Inference hooks, including prompt hooks and pre-tool-call hooks, are generally available." "Endpoint detection and response in Cowork is in beta on macOS and Windows." [Anthropic](https://claude.com/resources/articles/claude-enterprise-security-updates).
- **Claude Code sent the account email in the `User-Agent` of web requests (issue #107757, opened 5 November, v2.1.318, Open).** A contributor says the built-in mod `cc-plugin-privacy` blocks it "in v2.1.317 and later" and "is enabled by default"; one user said on 6 November it did not block his test. Whether the fix is complete is not confirmed. [GitHub issue #107757](https://github.com/anthropics/claude-code/issues/107757).
- **Anthropic released Claude Fable 5.2 and Mythos 5.2 on 9 November, with changed cyber safeguards.** Mythos 5.2 is limited to the Cyber Verification Program; Fable 5.2 is on Azure and Foundry, with no mention of Microsoft 365 Copilot. Decide whether the new model id is allowed in your Foundry deployments. [Anthropic](https://www.anthropic.com/news/claude-fable-and-mythos-5-2).
- **Docker Sandboxes `sbx cp` symlink escape, CVE-2026-103916 (CVSS v4 8.4).** Affects 0.28.0 up to but not including 0.51.0; Endor Labs: "The eventual fix was released November 3, 2026 with version 0.51.0", and the 0.48.0 fix was incomplete. No exploitation stated. [Endor Labs](https://www.endorlabs.com/learn/docker-sandboxes-vulnerability-lets-ai-agents-access-sensitive-files-outside-their-sandbox-cve-2026-103916).
- **Postman Desktop installs Codex and Claude plugins and a startup hook, per user reports (issue #14370, opened 25 October, Open).** Several reporters on desktop 12.31.3 to 12.35.1; one says "no evidence of data upload". No Postman statement or fixed version. Check `~/.codex`, `~/.claude` and `~/.copilot` on managed endpoints for Postman entries. [GitHub issue #14370](https://github.com/postmanlabs/postman-app-support/issues/14370).
- **vLLM response amplification, GHSA-mwgq-9582-w2vf (7 November, "Moderate", 5.3, no CVE).** Affects ">= 0.3.0, < 0.30.0", patched in "0.30.0"; no exploitation stated. Check `pip show vllm`; our assessment is that 0.33.0 or later, needed for earlier vLLM advisories, covers this too. [GitHub advisory](https://github.com/vllm-project/vllm/security/advisories/GHSA-mwgq-9582-w2vf).
- **@ethersphere/bee-js 13.3.0 and Swarm Desktop 0.56.2 trojanised through a hijacked CI (GHSA-hh7j-5m3j-23pf, "fully compromised").** 13.3.0 was npm `latest` from 00:09 to 01:25 UTC on 9 November (per The Hacker News); on Windows the payload adds a Defender exclusion and installs ScreenConnect. Safe: 13.2.0 and 0.56.3. Check `npm ls @ethersphere/bee-js`, and `Get-MpPreference | Select-Object -ExpandProperty ExclusionPath` on Windows hosts. [StepSecurity](https://www.stepsecurity.io/blog/ethersphere-bee-js-13-3-0-compromise).
- **PolinRider loader in 12 releases of 10 hijacked npm packages (Sonatype, 4 November).** It runs when the entrypoint loads, with no install hook, and persists through VS Code and Cursor startup files. [Sonatype](https://www.sonatype.com/blog/polinrider-loader-reappears-in-hijacked-npm-packages).
- **GitHub secret scanning now detects secrets in GitHub Actions workflow logs (public preview, 9 November).** Off by default; needs GitHub Enterprise Cloud with Secret Protection or GHAS; no backfill of old logs. [GitHub changelog](https://github.blog/changelog/2026-11-09-secret-scanning-detects-secrets-in-github-actions-workflow-logs/).
- **BadByte: backdoored ARTEX Docker images `tomicdd/artex` and `congdonglinux/artex` (4 November, updated 5 November).** They run a command from the login captcha field as root, with no login; 62 of 1,645 live consoles served the backdoored build, about 7,946 pulls before disclosure, and Docker removed both images on 5 November. "Updating does not remove it." Not the same as Microsoft's ARTEX framework story. [BadByte](https://badbyte.io/artex-backdoor-docker-image/).
- **Check Point Research: ARTEX cybercrime campaigns (5 November).** 2,557 hosts hosted or had hosted ARTEX panels, 1,608 live (the report's key points say "more than 1,800"); more than 300 Apple .p12 certificates and more than 190,000 game credentials stolen, 292 crypto domains. IOCs include AS54600 ranges 38.11.173.1 to 125, 38.11.221.1 to 125 and 198.200.59.85 to 89; nothing on Microsoft 365 or Entra. [Check Point Research](https://research.checkpoint.com/2026/hacking-on-autopilot-inside-artex-cybercrime-campaigns/).
- **WorkOS update (6 November): "It was an AI security agent that escaped a researcher's sandbox."** The researcher "was conducting cybersecurity benchmark evaluations using ARTEX", "accepted responsibility" and "confirmed they deleted all WorkOS data"; first access 25 October, detection 30 October. WorkOS published IOCs but no customer actions. If you run AI offensive tooling, set scope and egress limits (our advice). [WorkOS bulletin](https://workos.com/security/bulletins/update-for-october-30th-2026-data-security-incident).
- **Northflank update.** Status 6 November, 10:09 UTC, "Monitoring"; the page references CVE-2026-98432 and says the root cause is "not yet confirmed". Rotate all secrets. [Northflank status](https://status.northflank.com/cmvv0rn5a092f14rutwccodpp).
- **Trigger.dev update.** The incident is "Resolved" as of 6 November, 12:27 UTC. [Trigger.dev status](https://status.trigger.dev/incident/1110434).
- **Chainstack incident (3 November).** Intrusion from 26 October to 2 November; the account database and password hashes were accessed and node credentials are treated as exposed; incident "closed" 2 November. Rotate node credentials. [Chainstack](https://chainstack.com/).
- **Railway: about 740,000 US dollars of unauthorised spend on stolen customer AI keys (updated 10 November, 18:02 UTC).** "Unauthorized spend on the stolen keys was estimated to reach ~$740,000"; "the actor was expelled"; "investigation is ongoing". Rotate AI provider keys stored in Railway environment variables and review provider billing. [Railway](https://blog.railway.com/p/incident-report-october-security-incident).
- **Notion: a third-party AI vendor (Fireworks) incident exposed Notion AI chat transcripts for "fewer than 1% of Notion workspaces".** "As of November 3rd" Notion disconnected Fireworks. Rotate credentials pasted into Notion AI; workspace owners check Help > "Security incident review". [Notion](https://notion.com/help/security-incident-involving-a-third-party-ai-vendor).
- **ChatGPT Lockdown Mode bypass through HTML-preview popups (Check Point Research, 5 November).** OpenAI deployed a fix on 18 September; no CVE, no user action stated. [Check Point Research](https://research.checkpoint.com/).
- **Claroc GhostShares: 35,578 Grok-built apps "(94.7%) opened for anyone, with no sign-in" (10 November).** Data from 30 organisations found; no abuse in the wild reported. Inventory which AI app builders staff use. [Claroc](https://blog.claroc.io/ghostshares-grok-build-apps/).
- **Microsoft: sleeper agents hidden by editing fewer than 10 neurons (10 November).** Microsoft has not seen threat actors use it; per the post, the research was largely done with an AI coding agent. Diff fine-tuned or third-party checkpoints against their declared base before deployment (Research's takeaway). [Microsoft Security blog](https://www.microsoft.com/en-us/security/blog/2026/11/10/detecting-sleeper-agents-hiding-in-ai-model-neurons/).
- **Microsoft FORGE Lab: agentic tools found memory-safety bugs in the Rust standard library (9 November).** No CVEs; the issues "need unusual setups to trigger". [Microsoft Security blog](https://www.microsoft.com/en-us/security/blog/2026/11/09/forge-lab-uses-agentic-tools-to-identify-memory-safety-issues-in-rust/).
- **Copilot prompt input in Word, Excel and PowerPoint, on by default (MC1470885, updated 11 November).** "The feature is enabled by default for eligible users." "No separate admin control is available for the prompt input experience." Rollout "is expected to complete by the end of December 2026". [MC1470885](https://mc.merill.net/message/MC1470885).
- **Copilot Chat content source filters and Copilot Studio connection setup (MC1548004, MC1548034).** Source filters reach GA "mid-November 2026", "enabled by default for licensed users" and respecting permissions. In-conversation third-party connection setup in Copilot Studio reaches GA "by December 31, 2026"; "Existing organizational controls … will continue to determine availability". [MC1548004](https://mc.merill.net/message/MC1548004) · [MC1548034](https://mc.merill.net/message/MC1548034).
- **Copilot app Workspaces (MC1535647, MC1550540).** "Workspaces will rollout to standard release by January 2027, and deferred release by February 2027"; Microsoft asks admins to "Review which users are included in a spending policy that grants Cowork access". From December 2026 (Frontier), Workspaces replaces standalone Researcher, Analyst and Designer selection with agentic chat. [MC1535647](https://mc.merill.net/message/MC1535647) · [MC1550540](https://mc.merill.net/message/MC1550540).
- **Office in the Copilot app and the PowerPoint explainer video (MC1530611, MC1546430).** Office in the Copilot app completes "mid-November 2026", deferred release "early December 2026". For the PowerPoint Copilot "Add explainer video": "Rollout is currently paused." [MC1530611](https://mc.merill.net/message/MC1530611) · [MC1546430](https://mc.merill.net/message/MC1546430).
- **Later AI features: Purview Endpoint DLP AI skills and Teams Facilitator web search (MC1381121, MC1409304).** Endpoint DLP Policy Sync and Device Health skills: preview "early June 2027", worldwide "early July 2027", needing Security Copilot. Facilitator web search in meeting chat from February 2027, needs Copilot and is enabled manually. [MC1381121](https://mc.merill.net/message/MC1381121) · [MC1409304](https://mc.merill.net/message/MC1409304).
- **Teams Events recording access and iOS Company Portal minimum (MC1550542, MC1547994).** The "Who has access to the recording or transcript" option for town halls and webinars now follows RecordingForTownhall and RecordingForWebinar in CsTeamsEventsPolicy, not AllowCloudRecording; "No action is required". Company Portal for iOS and iPadOS needs v5.2608.0 "starting in early December"; push it manually if "Block installing apps using App Store" is on. [MC1550542](https://mc.merill.net/message/MC1550542) · [MC1547994](https://mc.merill.net/message/MC1547994).
- **Message center posts for stories we already cover (MC1549242, MC1529467).** MC1549242 is the Message center post for NTLM signing, same phases as KB5135557 ([our brief](2026-11-11-ntlm-signing-default-kb5135557.md)). MC1529467 adds the 16 November Edge and WebView2 PKI Metadata removal of four emSign roots ([our eMudhra brief](2026-10-31-emudhra-ca-keys-windows-edge-trust.md)). [MC1549242](https://mc.merill.net/message/MC1549242) · [MC1529467](https://mc.merill.net/message/MC1529467).

More: [all AI security news](../topic/ai-security/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 13 November 2026. Runbook Lab is not affiliated with Microsoft.
