---
date:
  created: 2026-10-28 12:00:00
slug: teams-external-chat-file-sharing-default
categories:
  - Email & collaboration
description: Microsoft will turn on file sharing in Teams chats with external organisations unless admins have turned it off. Microsoft asks for a decision by the first week of November 2026.
rl_type: news
rl_area: email-collab
rl_service: [teams]
rl_kits: [m365]
rl_controls: []
---

# Teams turns on file sharing in external chats unless you turn it off

Microsoft will let people attach files in Teams chats with users from other organisations, and it will be on by default. Tenants that haven't explicitly turned the setting off get it. There is no rollout date yet, but Microsoft asks admins to set their choice by the first week of November 2026.

<!-- more -->

## What changes

- Users can share files in 1:1, group and meeting chats with external users who reach you through Teams external access (federation).
- Microsoft Learn still describes file sharing in external chats as off by default. Message center post MC1479514 changes that default for every tenant that hasn't disabled it.
- A second setting, `AutoShareFilesInExternalChats` in the Teams messaging policy, gives the people in the chat access to the shared file automatically. It is on by default.
- The post doesn't mention guest access. It covers external access only.

## Who needs to act, and by when

Teams and security admins in any tenant with external access on and the default files policy. Microsoft says "the first week of November" and gives no exact day.

## What to do

1. Read the current values. This only reads:

    ```powershell
    Get-CsTeamsFilesPolicy | Select-Object Identity, FileSharingInChatsWithExternalUsers
    Get-CsTeamsMessagingPolicy | Select-Object Identity, AutoShareFilesInExternalChats
    ```

2. Decide with whoever owns data protection. If files should not go into external chats, turn it off explicitly. A value you set yourself is not switched on by the rollout:

    ```powershell
    Set-CsTeamsFilesPolicy -Identity Global -FileSharingInChatsWithExternalUsers Disabled
    ```

3. If you want attachments but not automatic access for everyone in the chat, set `AutoShareFilesInExternalChats` to `Disabled` in the messaging policy instead.
4. Write the decision down with a date, so the next admin knows it was deliberate.

## Why it matters for security

A file shared into an external chat leaves the team that owns it. With automatic sharing on, access follows the chat membership, not a choice the user makes for each file. Check that your sensitivity labels and DLP policies cover the files people are likely to share there.

## Sources

- [MC1479514 on the public message center mirror](https://mc.merill.net/message/MC1479514) (last updated 15 October 2026)
- [Microsoft Learn: Share files and Loop components in external (federated) chats](https://learn.microsoft.com/en-us/microsoftteams/share-files-loop-in-external-chats)
