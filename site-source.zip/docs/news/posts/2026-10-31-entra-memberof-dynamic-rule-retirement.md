---
date:
  created: 2026-10-31 11:00:00
slug: entra-memberof-dynamic-rule-retirement
categories:
  - Identity & access
description: "On 3 November 2026 Entra ID retires the MemberOf dynamic rule operator. Groups, admin units and access packages using it stop updating. Find and replace them."
rl_type: news
rl_area: identity
rl_service: [entra]
rl_kits: [ca, m365]
rl_controls: [CA03]
rl_tickets:
- summary: List every Entra dynamic rule that uses MemberOf
  priority: Highest
  due: '2026-11-03'
  due_note: 'Microsoft''s retirement date in MC1529463: from 3 November 2026 MemberOf rules stop updating.'
  steps:
  - Run the read-only Graph PowerShell in the brief for dynamic groups and dynamic administrative units.
  - Read the rule of every access package automatic assignment policy (Identity Governance > Entitlement management > Access packages > Policies).
  source: https://mc.merill.net/message/MC1529463
- summary: Check Conditional Access exclusions and includes that use MemberOf groups first
  priority: Highest
  due: '2026-11-03'
  due_note: Microsoft's retirement date in MC1529463.
  steps:
  - 'For every group the script returns, search each Conditional Access policy''s excluded and included groups (Entra admin center > Protection > Conditional Access). Start with exclusions: if a Conditional Access policy includes or excludes a MemberOf group, that policy''s scope stops tracking reality on 3 November.'
  - Check Billing > Licences for group-based licence assignments that use those groups.
  source: https://mc.merill.net/message/MC1529463
- summary: Rewrite or convert the MemberOf groups, admin units and access packages
  priority: High
  due: '2026-11-03'
  due_note: Microsoft's retirement date in MC1529463.
  steps:
  - Rewrite each rule with supported operators (use the parent group's attributes directly where it was attribute-based).
  - Where no attribute rule works, convert to assigned membership and give the group an owner.
  - For access packages with no equivalent rule, plan another assignment approach, as Microsoft advises.
  - Change rules outside business hours for groups that Conditional Access or licensing depend on, and keep the old rule text.
  source: https://learn.microsoft.com/entra/identity/users/groups-dynamic-rule-more-efficient
- summary: 'Verify: no MemberOf rules left and membership is correct'
  priority: High
  steps:
  - 'Re-run the script: both queries return nothing.'
  - Compare the new membership count with the old one, and spot-check one recent joiner and one recent leaver against each rewritten group.
  source: https://mc.merill.net/message/MC1529463
---

# Entra MemberOf dynamic rules stop updating on 3 November

Microsoft Entra ID retires the MemberOf rule operator on 3 November 2026 (MC1529463). From that day, dynamic groups, dynamic administrative units and entitlement management auto-assignment policies that use MemberOf stop processing changes, so identity admins must replace those rules before then.

<!-- more -->

!!! note "Runbook card"
    **What changes:** rules that use MemberOf stop updating. Membership freezes "in their last known state".<br>
    **Who:** any tenant with MemberOf in a dynamic group, a dynamic administrative unit or an access package auto-assignment policy.<br>
    **By when:** 3 November 2026 (worldwide retirement date and act-by date).<br>
    **Do this:** 1. List every rule that contains MemberOf. 2. Rewrite it with supported operators, or convert it to assigned membership. 3. Re-check the Conditional Access policies, licences and access packages that target those groups.<br>
    **Check:** the read-only Graph PowerShell below returns zero rows.<br>
    **Source:** [MC1529463](https://mc.merill.net/message/MC1529463), published 28 October 2026.

<p class="rl-jira" markdown>[Add to Jira (CSV)](../../tickets/entra-memberof-dynamic-rule-retirement.csv){ .rl-jira__link download } <span class="rl-jira__help">One Jira task per action in this brief. To import: as a Jira admin, Settings > System > External system import > CSV; date format yyyy-MM-dd; map Issue ID to Issue Id, and Summary, Issue Type, Priority, Due date, Labels and Description.</span></p>

## What Microsoft says

MemberOf was a public preview operator. Microsoft says it observed that "use of MemberOf can affect dynamic membership processing across a tenant, even when only a single MemberOf rule is present", so the preview is ending and is "not recommended for production use".

Beginning 3 November 2026, per the message:

- "Dynamic groups using MemberOf will stop processing membership changes."
- "Dynamic administrative units using MemberOf will stop updating membership and administrative scope."
- "Entitlement management auto-assignment policies using MemberOf will stop processing assignment updates."
- "Existing membership and assignment data will remain in their last known state."

The knock-on effects Microsoft lists: new users may not receive the access or licences they need, former users may keep access or licences, Conditional Access may rely on outdated membership, and Teams, SharePoint and other apps may get stale membership. Group-based licensing may no longer match who is eligible.

This was announced earlier in MC1448379 (5 August 2026) and MC1488834 (5 October 2026). MC1529463 is the final reminder.

## Why it matters for security

A frozen group fails quietly. Nothing errors. A new joiner who should land in "All staff, MFA required" never does, and a leaver who should drop out of a privileged scope stays in it. If a Conditional Access policy includes or excludes a MemberOf group, that policy's scope stops tracking reality on 3 November.

## How to check (read-only)

Needs Microsoft Graph PowerShell and a reader role such as Global Reader.

```powershell
Connect-MgGraph -Scopes Group.Read.All, AdministrativeUnit.Read.All

# Dynamic groups whose rule uses memberOf
Get-MgGroup -All -Filter "groupTypes/any(c:c eq 'DynamicMembership')" `
  -Property Id,DisplayName,MembershipRule |
  Where-Object { $_.MembershipRule -match 'memberOf' } |
  Select-Object DisplayName, Id, MembershipRule

# Dynamic administrative units whose rule uses memberOf
Get-MgDirectoryAdministrativeUnit -All -Property Id,DisplayName,MembershipRule,MembershipType |
  Where-Object { $_.MembershipType -eq 'Dynamic' -and $_.MembershipRule -match 'memberOf' } |
  Select-Object DisplayName, Id, MembershipRule
```

For entitlement management, open each access package with an automatic assignment policy (Identity Governance > Entitlement management > Access packages > Policies) and read the rule. Microsoft's message says to use Graph PowerShell to find the policies that use MemberOf.

Then, for every group the script returns, find where it is used: Entra admin center > Protection > Conditional Access (search each policy's included and excluded groups), and Billing > Licences for group-based licence assignments.

## What to do

1. Rewrite the rule with supported operators. If the parent group itself was built from attributes (department, country, employeeType), use those attributes directly.
2. Where no attribute-based rule works, convert the group or administrative unit to assigned membership and give it an owner who maintains it.
3. For access packages, plan another assignment approach if no equivalent rule exists, as Microsoft advises.
4. Validate the new membership count against the old one before you rely on it.

## How to verify

Re-run the script above. Both queries should return nothing. Then spot-check one recent joiner and one recent leaver against each rewritten group.

## Rollback and impact

Changing a dynamic rule triggers re-evaluation, and members can drop out while it runs. Change the rule outside business hours for groups that Conditional Access or licensing depend on, and keep the old rule text so you can compare. Converting to assigned membership keeps the current members.

Related: our [Conditional Access baseline guide](../../guides/entra-conditional-access-baseline-report-only.md) (policies should target groups that stay current), the [Conditional Access Baseline Kit](../../kits/conditional-access.md), every date we track on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [Identity & access news](../topic/identity-access/).

## Sources

- [MC1529463 on the public message center mirror](https://mc.merill.net/message/MC1529463) (published 28 October 2026, read 31 October 2026)
- [Microsoft Learn: Create simpler, more efficient rules for dynamic membership groups](https://learn.microsoft.com/entra/identity/users/groups-dynamic-rule-more-efficient)
- [Microsoft Learn: Rules for dynamic membership groups in administrative units](https://learn.microsoft.com/entra/identity/role-based-access-control/admin-units-members-dynamic)
- [Microsoft Learn: Configure an automatic assignment policy for an access package](https://learn.microsoft.com/entra/id-governance/entitlement-management-access-package-auto-assignment-policy)

Last reviewed: 31 October 2026. Runbook Lab is not affiliated with Microsoft.
