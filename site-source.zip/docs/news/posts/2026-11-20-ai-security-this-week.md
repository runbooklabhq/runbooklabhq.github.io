---
date:
  created: 2026-11-20 10:35:00
slug: ai-security-this-week-2026-11-20
categories:
  - AI security
description: "AI security news to 20 November 2026: check for agent-framework 1.26.1 and 1.26.2, patch LiteLLM (CISA KEV), GitHub CI secret theft, Claude Code to 2.1.329."
rl_type: news
rl_area: ai
rl_service: [copilot, dev-tools, entra, other]
rl_kits: [agents, copilot]
rl_controls: []
---

# AI security this week: 15 changes (20 November 2026)

Fifteen confirmed AI security items from the week to 20 November 2026, plus one that already has its own brief. The first check is for teams that build agents in Python: Microsoft's agent-framework package on PyPI shipped two compromised versions, 1.26.1 and 1.26.2, on 17 November, and removing them from PyPI does not remove copies already installed.

<!-- more -->

This is our weekly AI security roundup. Items rest on the facts our Research desk read at each primary source between 12 and 20 November 2026.

## Already briefed

1. **MC1560922: the Microsoft Copilot desktop app opens websites inside the app by default from early January 2027; Act by 3 January 2027.** Endpoint and Microsoft 365 admins: set the BrowsingEnabled policy to Off, or configure the in-app browsing policies. Brief: [Copilot app in-app browsing on by default](2026-11-20-copilot-app-in-app-browsing-default-mc1560922.md).

## New this week

### Microsoft agent-framework on PyPI: versions 1.26.1 and 1.26.2 stole credentials (17 November 2026)

PyPI listed 1.26.1 and 1.26.2, both of 17 November 2026, as "RELEASE QUARANTINED"; on the evening of 18 November they no longer appeared in the release history, which now ends at 1.26.0 (12 November). Socket: "The Microsoft agent-framework PyPI package was compromised on November 17th, affecting versions 1.26.1 and 1.26.2." Socket describes a .pth start-up hook (agent_framework_meta.pth in 1.26.1, af_runtime_diag.pth in 1.26.2) that runs whenever Python starts, collects credential environment variables and Azure CLI files, requests Azure managed-identity tokens and, in 1.26.2, GitHub Actions OIDC tokens. "The reported payloads do not download or execute additional code." We found no Microsoft statement or advisory as of 18 November.

- **Who acts:** teams that installed agent-framework, or let CI resolve it, on 17 or 18 November.
- **Check:** `pip show agent-framework`, plus lockfiles, build logs and container layers, for 1.26.1 or 1.26.2. Look for agent_framework_meta.pth or af_runtime_diag.pth in site-packages.
- **Do this:** if found, rebuild from 1.26.0 pinned with hashes and rotate every secret that environment could reach (managed identity and service principal secrets, Azure DevOps and GitHub tokens, cloud keys). Review Entra sign-in logs for those service principals and managed identities, and outbound traffic to webhook.site, where Socket says the payload sends what it collects.
- **Source:** [agent-framework on PyPI](https://pypi.org/project/agent-framework/); [Socket](https://socket.dev/blog/agent-framework-pypi-package-compromised-with-credential-stealer) (17 November 2026); [The Hacker News](https://thehackernews.com/2026/11/attackers-compromise-microsofts-agent.html).

### LiteLLM CVE-2026-40217 in CISA KEV, due 2 December 2026

CISA added "BerriAI LiteLLM Unprotected Alternate Channel Vulnerability" on 18 November 2026 with a due date of 2 December 2026. Google's threat intelligence linked this CVE to LLMjacking earlier this month ([our 6 November item](2026-11-06-ai-security-this-week.md#google-gtig-and-mandiant-llmjacking-runs-up-ai-charges-on-stolen-cloud-identities-2-november-2026)). LiteLLM is often the gateway in front of Azure OpenAI and Foundry.

- **Who acts:** teams that run LiteLLM proxies.
- **Check:** `pip show litellm` on hosts and in images; container images with litellm in the tag. Update to the version BerriAI lists as fixed, then rotate the provider keys stored in the proxy. In the Azure activity log, review `Microsoft.CognitiveServices/accounts/deployments/write` by unexpected identities.
- **Source:** [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (read 19 November 2026).

### wfx-loot: hijacked GitHub accounts pushed a CI secret stealer (from 10 November 2026)

Aikido: "Starting on November 10, a threat actor used stolen GitHub credentials to push a malicious workflow payload into tens of thousands of repositories." "4,837 compromised accounts opened probe pull requests in 61,764 repositories." "At least 1,835 repositories ran the payload and have had credentials exfiltrated" (the same post also says "at least 1,806"). Signs: branch `wfx-docs`, pull request "docs: dependency audit notes", commits such as "ci: refresh build cache". In Azure it "exchanges OIDC tokens or client secrets for management tokens and lists subscriptions and Key Vaults". StepSecurity: "The attacker does not exploit a bug in GitHub Actions".

- **Who acts:** owners of GitHub organisations whose workflows hold cloud or AI keys.
- **Check:** search your organisation for pull requests titled "docs: dependency audit notes" and branches `wfx-docs` since 10 November, and for gaps in workflow run numbers. In Entra, review sign-ins of workload identities with federated GitHub credentials and Key Vault access since 10 November.
- **Source:** [Aikido](https://www.aikido.dev/blog/compromised-github-accounts-push-ci-secret-stealer-to-tens-of-thousands-of-repositories) (12 November 2026); [SecurityWeek](https://www.securityweek.com/attacker-targets-60000-github-repositories-in-credential-theft-campaign/).

### Device-code phishing can take over AI coding agents (Microsoft research, 17 November 2026)

Microsoft Security Research shows how a phished device-code sign-in could let an attacker take over a GitHub Copilot CLI session. "These are proof-of-concept results showing how existing features, working as designed, could be abused after a phished authorization; they are not attacks we have observed in the wild." Mitigations named: "enter a device code only for a sign-in you initiated yourself", Safe Links for email and Teams, and the GitHub Copilot CLI "'Store local sessions in the Cloud' policy… Choose the least permissive setting".

- **Who acts:** GitHub organisation admins and Entra admins.
- **Check:** GitHub organisation settings > Copilot > Policies, "Store local sessions in the Cloud". In Entra, check whether a Conditional Access policy blocks device code flow for users who do not need it.
- **Source:** [The risks of device code authentication for AI coding agents](https://www.microsoft.com/en-us/security/blog/2026/11/17/the-risks-of-device-code-authentication-for-ai-coding-agents/) (Microsoft Security Blog, 17 November 2026).

### FBI FLASH on the ARTEX attack framework: review ConnectWise apps by application ID (13 November 2026)

The FBI's FLASH-20261113-001 describes intrusions "progressing from initial targeting to privileged access in under three hours" and "over 1,600 publicly exposed ARTEX console instances". For the ConnectWise Cloud Backup compromise it names access to "more than 2,250 downstream tenants", and lists "Added credentials to existing OAuth applications" as a persistence technique. The FBI asks tenant owners to review every tenant where the affected ConnectWise apps are or were authorised, by application ID rather than display name, from at least 1 October 2026, and to keep those connections disabled until ConnectWise gives written restoration steps.

- **Who acts:** MSPs and tenant admins who ever authorised ConnectWise apps.
- **Check:** Entra admin center > Enterprise applications, filter by Application ID > Sign-in logs > Service principal sign-ins (successes and failures since 1 October 2026), and Audit logs for "Add service principal credentials", "Consent to application" and "Add app role assignment to service principal". Export before you change anything.
- **Source:** [FBI FLASH-20261113-001](https://www.ic3.gov/CSA/2026/261113.pdf); [The Record](https://therecord.media/artex-ai-tool-fbi-flash-alert). Brief: [ConnectWise cloud apps and Storm-0940](2026-11-03-connectwise-cloud-apps-storm-0940-m365-tenants.md).

### Cursor's incident report: a key exposed at Fireworks was the way in (13 November 2026)

Cursor's report on the malicious Claude Code extension copies served from its marketplace cache: "An attacker obtained an access key we had issued to Fireworks. The key was exposed by Fireworks". The attacker also accessed "limited customer support data and email conversations, product usage metrics and contact details, summaries of some coding agent conversations, and some credentials users had sent to the Cursor support team"; "less than 0.01% of customers had API credentials exposed". On the extension: "The marketplace source, Open VSX, never had the malware", "At most 5,000 users", and "Uninstalling the extension alone may not be enough." "We believe the incident is contained."

- **Who acts:** teams that use Cursor, and anyone who installed Claude Code extension 2.1.312 or 2.1.313 from Cursor on 29 October.
- **Check:** if Cursor emailed your admins a list of keys, rotate every key on it. Rotate any secret ever pasted into a Cursor support ticket. For hosts that got 2.1.312 or 2.1.313, follow our brief's hunt steps.
- **Source:** [Cursor security incident update](https://cursor.com/blog/security-incident-update) (13 November 2026); [BleepingComputer](https://www.bleepingcomputer.com/news/security/cursor-confirms-security-breach-led-to-malicious-claude-code-extension/). Brief: [Claude Code extension backdoor via Cursor](2026-10-31-claude-code-cursor-extension-ssh-backdoor.md).

### Claude Code 2.1.323 to 2.1.329: permission and sandbox fixes, auto mode on cloud gateways (12 to 19 November 2026)

From the changelog: 2.1.325 "Fixed a security issue in how zstd-compressed responses are decoded" and "Fixed a gap in Bash permission checks where some compound commands could run without asking", and "Changed sandboxed Bash commands to follow the normal permission flow by default". 2.1.323 "Fixed a case where the Bash sandbox could switch off during a session". 2.1.326 now warns when permission rules only looked saved. 2.1.327 added `claude mcp add-json <name> -` "so tokens can stay off the command line". 2.1.328 "Added auto mode for Claude Opus 4.6 and Sonnet 4.6 on Amazon Bedrock, Google Cloud's Agent Platform, Microsoft Foundry and Claude apps gateway; interactive sessions with no permission mode start in it". 2.1.329 "Added a warning … when hooks in managed settings fail to load". The 26 October advisory GHSA-5xjx-9qx6-jcrv (Edit tool race on macOS) is fixed from 2.1.251.

- **Who acts:** admins of Claude Code fleets.
- **Check:** `claude --version` on managed machines (latest 2.1.329; the stable channel was still 2.1.311 on 20 November). If you run Claude Code through Foundry, Bedrock or Agent Platform and do not want auto mode, set `permissions.defaultMode` in managed settings.
- **Source:** [Claude Code changelog](https://raw.githubusercontent.com/anthropics/claude-code/main/CHANGELOG.md); [GHSA-5xjx-9qx6-jcrv](https://github.com/anthropics/claude-code/security/advisories/GHSA-5xjx-9qx6-jcrv).

## Also logged

- **Microsoft Perception is generally available (17 November): "It orchestrates red, blue, and green team agents through playbooks".** Decide which high-impact actions need sign-off before you turn playbooks on. [Security for the agentic era](https://www.microsoft.com/en-us/security/blog/2026/11/17/security-for-the-agentic-era-powered-by-microsoft-perception/).
- **Microsoft FORGE Lab worked "with @github and the maintainers of six open-source projects to test whether AI-assisted vulnerability discovery can deliver verified, fixable reports instead of raw findings" (17 November).** No reader action. [@MsftSecIntel](https://x.com/MsftSecIntel).
- **Google Project Zero shortens disclosure: "On February 2, 2027, we will move to a "Full 60" policy", then "Full 30" from 3 January 2028, citing AI-assisted discovery.** Tighten your Patch Tuesday deployment times. [Project Zero disclosure policy](https://projectzero.google/2026/11/disclosure-policy.html).
- **Microsoft research on poisoned post-training data for coding agents (12 November): about "78% attack success on in-distribution harnesses".** For teams fine-tuning open-weight models: check checkpoint provenance and keep agent tool permissions minimal. [Trained to betray](https://www.microsoft.com/en-us/security/blog/2026/11/12/trained-to-betray-how-post-training-supply-chain-attacks-hijack-coding-agents/).
- **Corelight: a "pinned" MCP server "Over five weeks it ran with 15 different sets of dependencies".** Install MCP servers once from the lock file into a fixed environment instead of launching them with `uvx` or `npx`. [Corelight](https://corelight.com/blog/mcp-server-supply-chain-risk).
- **MC1558817, Dataverse data as knowledge in Agent Builder declarative agents, GA 17 November: "For new, production environments … this feature is automatically enabled".** Review the Work IQ setting on new production environments in the Power Platform admin center. [MC1558817](https://mc.merill.net/message/MC1558817).
- **MC796790, "Unified app and agent installation management is now generally available" across the Microsoft 365 admin center and Teams admin center (18 November).** Review which agents are available and installed after unification. [MC796790](https://mc.merill.net/message/MC796790).
- **Message Center, 20 November: MC1560924 Teams tenant policy for who can record and transcribe; MC1560996 Copilot Studio creates Dataverse agent users with the Entra agent's user account; MC1560916 GPT-6.2 Sol and Astra rolling out in Microsoft Copilot; MC1448373 Teams device management moves to the Teams Rooms Pro Management Portal (updated).** Informational. [MC1560924](https://mc.merill.net/message/MC1560924).

Related: [M365 AI Agent Hardening Kit](../../kits/ai-agent-hardening.md) · [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md).

More: [all AI security news](../topic/ai-security/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 20 November 2026. Runbook Lab is not affiliated with Microsoft.
