---
date:
  created: 2026-11-06 12:30:00
slug: threats-vulnerabilities-this-week-2026-11-06
categories:
  - Threats & vulnerabilities
description: "Threats to 6 November 2026: update WordPress (KEV due today), TeamViewer 15.83, SonicWall SMA1000, Barracuda ESG, Airbyte 2.2.0, Alpine OpenSSH; check SD-WAN."
rl_type: news
rl_service: [other]
rl_kits: []
rl_controls: []
---

# Threats & vulnerabilities this week: 17 changes (6 November 2026)

Seventeen confirmed threat and vulnerability items from the week to 6 November 2026: four already have their own briefs, seven are new here and six are logged. The nearest date is today: CISA's due date for WordPress core CVE-2026-119977 is 6 November 2026.

<!-- more -->

!!! warning "Updated 13 November 2026: Barracuda ESG flaws are in CISA KEV, due today"
    CISA added Barracuda CVE-2026-116606 and CVE-2026-111560 to its Known Exploited Vulnerabilities catalog on 10 November 2026, with a due date of 13 November 2026 (catalog version 2026.11.10, read 13 November 2026). Previously this page said neither CVE was in KEV, which was true of the catalogue released 9 November. Check the patch is installed and the admin interface is off the internet. See [the item](#barracuda-esg-cve-2026-116606-chains-to-root-2-november-2026).

!!! warning "Updated 10 November 2026: Barracuda ESG CVE-2026-116606 is now exploited"
    Barracuda updated its advisory on 9 November 2026 (9:00pm EST): "We have identified exploitation activity affecting a small number of organizations." Previously this page said the advisory did not mention exploitation. The chain gives root through the admin interface on Email Security Gateway. Check that the patch is installed and take the admin interface off the internet today. It was not in CISA KEV in the catalogue released 9 November 2026. See [the item](#barracuda-esg-cve-2026-116606-chains-to-root-2-november-2026).

!!! warning "Updated 10 November 2026: OpenSSH CVE-2026-123158 is now exploited and in CISA KEV"
    OpenSSH CVE-2026-123158 on Alpine: CISA added it to its Known Exploited Vulnerabilities catalog on 9 November 2026, due 12 November 2026. GreyNoise reports successful exploitation: its first observed successful attack was on 7 November 2026 at 00:46:51 UTC, and it lists confirmed post-exploitation activity from 6 attacker IPs. Previously this page said the flaw was not in KEV and that no successful attack had been shown. Update and restart sshd now. See [the item](#openssh-on-alpine-password-authentication-bypass-cve-2026-123158-5-november-2026).

!!! info "Updated 8 November 2026"
    OpenSSH CVE-2026-123158 on Alpine: Previdian now counts 17 exploitation attempts, from 11 attacker IPs in 8 countries (previously 8 attempts from one IP). Previdian says its telemetry does not show a successful attack. The flaw was still not in CISA's KEV catalog when our news desk checked the catalog on 8 November. See [the item](#openssh-on-alpine-password-authentication-bypass-cve-2026-123158-5-november-2026).

!!! info "Updated 7 November 2026"
    OpenSSH CVE-2026-123158 on Alpine: Previdian reported exploitation attempts in the wild on 6 November; the item previously said only that no attacks had been reported. See [the item](#openssh-on-alpine-password-authentication-bypass-cve-2026-123158-5-november-2026).

This is our weekly Threats & vulnerabilities roundup. The seven new items were re-read on their primary source on 6 November 2026; the CISA KEV entry for WordPress is as Research read it on 4 November. Of the six logged items, Node-RED was re-read today; the other five are as Research read them at the source earlier this week.

## Already briefed

1. **KEV catch-up: SharePoint Server CVE-2026-65660, ScreenConnect CVE-2026-84869, PAN-OS CVE-2026-0322, plus the Zyxel GS1900 update.** The GS1900 attacks used CVE-2026-107441, and the June firmware for CVE-2026-7273 does not stop them: install 2.90(xxxx.3)C0. Brief: [KEV catch-up: SharePoint, ScreenConnect, PAN-OS](2026-11-05-kev-catch-up-sharepoint-screenconnect-pan-os.md).
2. **KEV catch-up: FortiOS CVE-2025-61624, FortiMail CVE-2026-104286, NetScaler CVE-2026-88779, N-central CVE-2026-86218.** Network and MSP tooling admins. Brief: [KEV catch-up: FortiOS, FortiMail, NetScaler, N-central](2026-11-04-kev-catch-up-fortios-fortimail-netscaler-n-central.md).
3. **BeyondTrust Remote Support CVE-2026-102764, exploited since late August.** Patch, then hunt. Brief: [BeyondTrust Remote Support CVE-2026-102764](2026-11-03-beyondtrust-remote-support-cve-2026-102764-patch-hunt.md).
4. **Windows Shell CVE-2026-96951, the October zero-day.** Endpoint admins. Brief: [Windows Shell CVE-2026-96951](2026-11-04-windows-shell-cve-2026-96951-october-zero-day.md).

## New this week

### TeamViewer TV-2026-1010 and TV-2026-1011: update clients to 15.83 (27 October 2026)

Two bulletins, one action. TV-2026-1010 (29 September 2026, "Important", "Up to 8.8 (High)") fixed five CVEs in 15.82, including CVE-2026-92370 (8.8), improper access control during session establishment that lets a remote attacker bypass configured permissions. TV-2026-1011 (issued 27 October, updated 28 October 2026, "Up to 8.8 (High)") fixes three more in 15.83. One of them, CVE-2026-111585 (8.8), is an integer overflow in screen processing: a malicious remote host can, depending on the platform, run code with the privileges of the viewer process once a user connects to it. Version 15.82 does not fix it. Both bulletins: "TeamViewer is not aware of any active exploitation in the wild."

- **Who acts:** MSPs and helpdesks whose technicians connect out to customer machines with the TeamViewer Full Client, Portable or the Android Remote Control app.
- **Check:** Intune admin center > Apps > Monitor > Discovered apps, search "TeamViewer", and list anything below 15.83. On a single Windows machine: `Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object DisplayName -like 'TeamViewer*' | Select-Object DisplayName, DisplayVersion`. Legacy fixed builds for TV-2026-1011: 15.64.10 (Windows 7 and 8), 14.7.48868, 13.2.36231 (Windows), 13.2.154008 (Linux), 13.2.154007 (macOS). Until updated, technicians should not accept unsolicited session requests or open .tvs recordings from people they don't know.
- **Source:** [TeamViewer TV-2026-1011](https://www.teamviewer.com/en/resources/trust-center/security-bulletins/tv-2026-1011/) and [TV-2026-1010](https://www.teamviewer.com/de/resources/trust-center/security-bulletins/tv-2026-1010/). Related: [BeyondTrust Remote Support CVE-2026-102764](2026-11-03-beyondtrust-remote-support-cve-2026-102764-patch-hunt.md).

### Cisco Talos: UAT-11473 used Catalyst SD-WAN CVE-2026-20127 to plant KeyDrift (28 October 2026)

Cisco Talos reports that a group it tracks as UAT-11473 exploited "CVE-2026-20127, an authentication bypass vulnerability in Cisco SD-WAN Catalyst Controller instances" (in CISA KEV since February 2026) to install KeyDrift, malware that pulls IPsec data-plane keys out of the vdaemon process. Talos says the group's infrastructure "overlaps considerably" with the "Silent Train" covert network it links to Volt Typhoon, and that the group has targeted space and satellite services, defence and aerospace technology, and policy research. "Cisco has released patches for CVE-2026-20127."

- **Who acts:** anyone running Catalyst SD-WAN Controller, Manager or Validator.
- **Check:** confirm each control component is on a fixed release listed in Cisco advisory cisco-sa-sdwan-rpa-EHchtZk. On each, look for the Talos file paths: `ls -la /tmp/system-vdaemon /var/tmp/vdaemon.bin /var/tmp/vdaemon.conf /etc/sv/aaamgr/`, and review `grep "Accepted publickey for vmanage-admin" /var/log/auth.log` for unknown source addresses. An upgrade will not tell you whether something was planted before it. Snort SIDs: 65938 and 65958 (CVE), 67387 to 67416 (Snort 2) and 7:44 to 7:73 (Snort 3) for the artefacts. Run `request admin-tech` before you open a TAC case.
- **Source:** [Cisco Talos: Inside KeyDrift](https://blog.talosintelligence.com/uat-11473-keydrift/).

### SonicWall SMA1000 CVE-2026-102255: fixed builds out since 5 October 2026

SonicWall notice SNWLID-2026-0017 (published 5 October, updated 6 October 2026) lists a server-side request forgery, CVE-2026-102255 (CVSS 10.0), and three more CVEs in SMA 1000 models 6210, 7210 and 8200v. Affected: "12.4.3-03526 and older" and "12.5.0-02952 and older". There is no workaround. SonicWall says "There is no evidence that these vulnerabilities are being exploited in the wild"; Canada's Cyber Centre (AV26-1017 Update 1) cites open-source reporting of exploitation. It is not in CISA KEV as of Research's last catalogue read. SMA 100 and firewall SSL VPN are not affected.

- **Who acts:** owners of SMA 1000 appliances, physical or virtual.
- **Check:** the firmware version in the SMA 1000 Appliance Management Console must be 12.4.3-03670 or 12.5.0-03082 or later. Then review appliance logs for unauthenticated requests from addresses you don't recognise.
- **Source:** [SonicWall SNWLID-2026-0017](https://www.sonicwall.com/support/notices/product-notice-sma-1000-series-affected-by-multiple-vulnerabilities-snwlid-2026-0017/kA1VN000002QP3G0AW). Related: [KEV catch-up: FortiOS, FortiMail, NetScaler, N-central](2026-11-04-kev-catch-up-fortios-fortimail-netscaler-n-central.md).

### Barracuda ESG CVE-2026-116606 chains to root (2 November 2026)

Barracuda's advisory (published and updated 2 November 2026) pairs a pre-authentication authorisation bypass, CVE-2026-116606 (9.3), with command injection, CVE-2026-111560 (8.6). Chained, they give root on the Email Security Gateway; the command injection alone also affects Load Balancer ADC, WAF, Message Archiver, WAF Control Center and Web Security Gateway. Barracuda says successful exploitation requires an attacker to have access to the administrative interface; since 5 November the advisory lists CVE-2026-116606 as "No (Administrative UI Access Required)" for authentication.

Updated 10 November 2026: Barracuda's advisory, updated 9 November 2026 at 9:00pm EST, now says "We have identified exploitation activity affecting a small number of organizations." It does not name an attacker or give indicators. Previously this item said the advisory said nothing about exploitation. Neither CVE is in CISA KEV in the catalogue released 9 November 2026 (read 10 November 2026). Updated 13 November 2026: CISA added both on 10 November 2026, due 13 November 2026. Barracuda's guidance is unchanged: confirm the latest firmware and all patches are applied, and restrict admin interfaces to trusted internal networks; Barracuda Support helps with verification.

- **Who acts:** mail and network admins with Barracuda appliances, often MSPs for SMB customers.
- **Check:** confirm the patch is installed: ESG BNSF-40425 (9.4.017 and later) or BNSF-40430 (earlier); ADC and WAF BNADC-16586; Message Archiver BNMA-32468; WAF Control Center BNWF-60060; Web Security Gateway BNYF-24789. If automatic patching is off, turn it back on. Make sure the admin interface is reachable only from trusted internal networks.
- **Source:** [Barracuda advisory](https://trust.barracuda.com/security/pre-authentication-authorization-bypass-command-injection) (read 10 November 2026) and the [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog).

### WordPress core CVE-2026-119977 in CISA KEV, due 6 November 2026

CISA added "WordPress WordPress Core Time-of-check Time-of-use (TOCTOU) Race Condition Vulnerability" to KEV on 3 November 2026, with a due date of 6 November 2026 for US federal agencies. WordPress 7.1.4 (28 October 2026) fixes "A race condition during core updates that could lead to remote code execution", among 22 fixes, with backport releases from 7.0.8 down to 4.7.39. "WordPress 4.6 and earlier no longer receive security updates." 7.1.4 also updates the bundled root certificates after the eMudhra revocation.

- **Who acts:** anyone hosting WordPress sites, including the marketing sites MSPs run for customers.
- **Check:** `wp core version` on each site (WP-CLI, read-only) must show 7.1.4 or the fixed release for its branch. While you are there, list stray PHP files with `find wp-content/upgrade -name '*.php'` and review `wp user list --role=administrator` for accounts you don't recognise.
- **Source:** [WordPress 7.1.4](https://wordpress.org/documentation/wordpress-version/version-7-1-4/) and the CISA KEV catalogue. Guide: [Microsoft 365 security deadlines](../../guides/deadlines.md).

### Airbyte before 2.2.0: Connector Builder RCE exploited, JVN 4 November 2026

Airbyte's advisory GHSA-g35w-6r6v-h4r7 (17 October 2026, "No known CVE", CVSS 3.1 9.9) covers "Remote code execution via Connector Builder custom components when unsafe code is disabled" in "Airbyte < 2.2.0"; "Successful exploitation may expose data, credentials and secrets available to the affected container". JPCERT/CC's JVN#12040144 (4 November 2026) says "the vulnerability has been confirmed to be exploited in the wild"; its Japanese page lists 1.7.0 through 2.1.0 as affected. It is not in CISA KEV as of Research's last catalogue read.

- **Who acts:** anyone running self-managed Airbyte.
- **Check:** list the running image tags, for example `kubectl get pods -n <airbyte namespace> -o jsonpath='{..image}'`, and note anything below 2.2.0.
- **Do this:** upgrade to 2.2.0. Until then, Airbyte's workarounds: restrict network access to the Connector Builder / Manifest Server so only the Airbyte server can reach it, and limit Workspace Reader and Organization Reader access to trusted users. If the instance was reachable, rotate the source and destination credentials it held.
- **Source:** [GHSA-g35w-6r6v-h4r7](https://github.com/airbytehq/airbyte/security/advisories/GHSA-g35w-6r6v-h4r7) and [JVN#12040144](https://jvn.jp/en/jp/JVN12040144/index.html).

### OpenSSH on Alpine: password authentication bypass CVE-2026-123158 (5 November 2026)

OpenSSH 10.6p2 fixes a "password authentication bypass in sshd(8)" that is "exploitable through sshd on some Linux systems built and run with PAM support disabled". Alpine's advisory (5 November 2026) lists the conditions: sshd without PAM (or `UsePAM no`), `PasswordAuthentication` on (the default), an account with `*` in its password field, and at least one local account with a `$5$` or `$6$` hash. The CVE record (CVSS 3.1 8.1) came after Alpine's post. On 5 November OpenSSH's Damien Miller told The Hacker News "No attacks using the flaw have been reported."

Updated 8 November 2026: Previdian's page, as our news desk read it on the evening of 7 November, now counts "17 exploitation attempts, 11 unique attacker IPs, and 8 countries", seen by 4 sensors, last observed on 7 November; it still says its telemetry does not show a successful attack. Previously, on 6 November, Previdian reported 8 attempts from one IP address, seen by one sensor, the first at 00:05 UTC. Previdian notes that an observed attempt "does not mean the attempt succeeded". The flaw is not in CISA's KEV catalog. The steps below are unchanged.

Updated 10 November 2026: CISA added CVE-2026-123158 to its KEV catalog on 9 November 2026 as "OpenBSD OpenSSH Unexpected Status Code or Return Value Vulnerability", due 12 November 2026 (catalog version 2026.11.09, read 10 November 2026). GreyNoise's event page (last updated 10 November 2026, 08:10 UTC) says "Successful exploitation is being tracked as executing shell commands on the vulnerable system" and "CVE-2026-123158 is trivial to exploit and working exploits are publicly available." It dates the first successful exploitation of one of its sensors to 7 November 2026, 00:46:51 UTC, and lists confirmed post-exploitation activity from 6 attacker IPs. Previously this item said the flaw was not in KEV and, per Previdian, that no successful attack had been shown. If an affected host ran a vulnerable sshd with password authentication on, treat it as possibly compromised: CISA's entry asks for forensic triage, and GreyNoise lists the attacker IPs on its page.

- **Who acts:** admins of Alpine hosts, containers that run sshd, and musl-based appliances.
- **Check:** `sshd -T | grep -i -E 'passwordauthentication|usepam'` and `apk version openssh` (both read-only). Fixed packages: edge 10.6_p2-r0, 3.24 10.3_p1-r2, 3.23 10.2_p1-r1, 3.22 10.0_p1-r11, 3.21 9.9_p2-r1 (older branches are in the advisory).
- **By when:** now. CISA's due date for US federal agencies is 12 November 2026.
- **Do this:** after `apk upgrade`, restart sshd: "Upgrading the package alone does not replace the running daemon." If you can't update yet, Alpine's fallback is `PasswordAuthentication no`; confirm key login works first.
- **Source:** [Alpine security advisory](https://alpinelinux.org/posts/2026-11-05-openssh-password-authentication-bypass/), [OpenSSH 10.6p2 release notes](https://www.openssh.org/txt/release-10.6p2), [Previdian on CVE-2026-123158](https://previdian.com/CVE-2026-123158) (read 7 November 2026), [CISA KEV catalog, CVE-2026-123158](https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext=CVE-2026-123158) and [GreyNoise SSHole event page](https://sshole.events.greynoise.io/) (both read 10 November 2026).

## Also logged

- **Synology: C3RB3R ransomware uses a DSM flaw patched in December 2024.** Synology (29 October) says "threat actors exploiting a vulnerability patched in December 2024" and links Synology-SA-24:20; it does not say which CVE. Fixed DSM: 7.2.2-72806-1, 7.2.1-69057-6, 7.2-64570-4, 7.1.1-42962-7. Encrypted files end in ".L0CK3D". Who acts: NAS owners. Check: DSM > Control Panel > Update & Restore shows the version. Do this: turn on automatic updates and keep DSM off the internet. Source: [Synology](https://synology.com/en-global/company/news/article/C3RB3R).
- **Node-RED CVE-2026-58115 exploited from 30 October.** VulnCheck (2 November) saw instances without `adminAuth` exploited with a single `POST /flows`, dropping a Linux bot from 85.215.73.250:8080; "not in CISA's KEV at the time of writing". Siemens SSA-834709 lists V4.3.4.1 for SIMATIC IoT2050. Who acts: OT and automation teams. Check: `grep -n adminAuth settings.js` in the Node-RED user directory, confirm the editor is not reachable from outside, and review flows for unexpected `exec` nodes. Source: [VulnCheck](https://www.vulncheck.com/blog/exploitation-targeting-node-red).
- **Cisco's 4 November bundle.** UCS Central RCE CVE-2026-76506 (High, 7.6; Canada's Cyber Centre: fixed in 2.1(2c)), Unified CM XSS CVE-2026-76419 (6.1), ISE CVE-2026-20241 (5.3); no exploitation stated. Cisco's next bundled publication is "January 20, 2027". Who acts: Cisco data centre and collaboration admins. Check: UCS Central version against 2.1(2c). Source: [Cisco notice](https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-notice-I8z3n6lK).
- **DigiCert: a business system was accessed from 27 June to 2 July 2026.** DigiCert's report on Mozilla Bugzilla: self-registration accounts had read-only access to archived data; business contact data was exposed, and ID documents for a "small minority". "No certificate operations were impacted." Who acts: whoever holds your DigiCert account. Check: expect targeted phishing aimed at DigiCert account contacts and tell them. Source: [Bugzilla 2084460](https://bugzilla.mozilla.org/show_bug.cgi?id=2084460).
- **CWPdoor backdoor replaces Control Web Panel's cwpsrv.** XLab (5 November) found it in cwpsrv 1.15.10 and 1.24.0; "We do not yet know which vulnerability cwpdoor uses to spread." Who acts: hosting providers and MSPs running CWP. Check: `ss -axp | grep integrity` and `strings /usr/local/cwpsrv/bin/cwpsrv | grep X-Ngx-Integrity`; search logs for C2 136.0.141.71. Do this: block 136.0.141.71. Source: [XLab](https://blog.xlab.qianxin.com/cwpdoor-the-invisible-backdoor-living-inside-control-web-panel/).
- **Rails Active Storage with ImageMagick: arbitrary file write, GHSA-f3w6-w445-fwh9.** No CVE yet. Fixed in Rails 8.1.4.1 and 8.0.5.2, with mini_magick 5.1 or later. Who acts: Rails app owners using Active Storage variants. Check: `bundle exec rails -v` and `bundle list | grep mini_magick`. Source: [GHSA-f3w6-w445-fwh9](https://github.com/rails/rails/security/advisories/GHSA-f3w6-w445-fwh9).

More: [all Threats & vulnerabilities news](../topic/threats-vulnerabilities/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 10 November 2026. Runbook Lab is not affiliated with Microsoft.
