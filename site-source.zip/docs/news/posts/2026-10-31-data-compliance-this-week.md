---
date:
  created: 2026-10-31 13:30:00
slug: data-compliance-this-week-2026-10-31
categories:
  - Data & compliance
description: "Purview changes to 31 October 2026: DSPM classic retirement moves to March 2027, Teams retention stops covering Copilot, auto-labeling for .doc and .xls."
rl_type: news
rl_area: data-compliance
rl_service: [purview, copilot, teams]
rl_kits: [copilot]
rl_controls: [CR05]
---

# Data & compliance this week: 4 changes (31 October 2026)

Four confirmed Microsoft Purview changes from the week to 31 October 2026. One date moved again: the DSPM classic retirement now starts in mid-March 2027.

<!-- more -->

!!! info "Updated 25 November 2026: correction"
    MC1530948, Purview auto-labeling for legacy Office formats (.doc, .xls, .ppt): Microsoft updated the timeline on 24 November 2026. Public preview now runs from late November to early December 2026 and general availability from mid-December to late December 2026 (previously preview early to mid-November, GA late November). This page showed preview mid-November and GA late November until today. The Check line also said "old file shares"; MC1530948 covers SharePoint and OneDrive only, and the line now says so. Plan the re-save and re-run of existing auto-labeling policies for after GA, not for late November. See [the item](#auto-labeling-legacy-office-formats).

This is our weekly Data & compliance roundup. It was due on Friday 30 October and is published a day late. Every item was re-read on its primary source on 31 October 2026.

### DSPM classic and DSPM for AI classic retire in March 2027 (moved again)

Updated 30 October 2026: "Beginning in mid-March 2027 (previously late January) and expected to complete in late March 2027 (previously late January)". The first version of this message gave 30 November to 31 December 2026, so check any runbook or plan that still quotes those dates.

- **Who acts:** Purview, security and compliance admins who still use the classic DSPM or DSPM for AI views.
- **Check:** your reports, runbooks and bookmarks open the current DSPM experience in the Purview portal, not the classic pages.
- **Source:** [MC1481315](https://mc.merill.net/message/MC1481315).

### Legacy Teams retention policies stop covering Copilot, mid to end of January 2027

"Beginning in mid-January 2027 (previously late October 2026) and expected to complete by end of January 2027 (previously mid-November)". "Action is required if you currently rely on Teams retention policies to govern Copilot interactions."

- **Who acts:** compliance and records admins.
- **Check:** Purview > Data lifecycle management > Retention policies. Find policies on Teams chats that you assumed also cover Copilot, and create an explicit policy for the Microsoft Copilot experiences location.
- **Source:** [MC1481313](https://mc.merill.net/message/MC1481313) (updated 28 October 2026).

### Auto-labeling reaches legacy Office formats (.doc, .xls, .ppt): preview late November to early December, GA mid to late December 2026 {#auto-labeling-legacy-office-formats}

Updated 25 November 2026: MC1530948 (updated 24 November 2026) now says "Public Preview: Beginning in late November 2026 (previously early November)" "and expected to complete by early December 2026 (previously mid-November)", and "General Availability: Beginning in mid-December 2026 (previously late November)" "and expected to complete by late December 2026 (previously late November)". This item said preview mid-November and GA late November 2026 until today. Existing policies don't pick up the old formats on their own: "Make a small edit to each existing policy … and save the change", then "Run the policy again to restart the crawl".

- **Who acts:** information protection admins.
- **Check:** Information Protection > Policies > Auto-labeling policies. After GA (now mid to late December 2026), re-save and re-run each policy in simulation first, and expect new matches in older SharePoint libraries and OneDrive (MC1530948 covers files stored in SharePoint and OneDrive only). New policies pick up the legacy formats without the extra edit and run.
- **Source:** [MC1530948](https://mc.merill.net/message/MC1530948) (published 29 October 2026, updated 24 November 2026; re-read 25 November 2026).

### Retention for Copilot Memory: rollout completed

"Rollout completed October 2026." Purview can now retain Copilot memory items; retained versions are stored in the user's Exchange mailbox and are reachable through eDiscovery. "No immediate action is required."

- **Who acts:** compliance and records teams: decide the retention period and who may search it.
- **Check:** your Copilot retention policy covers memory, and eDiscovery role holders are the people you expect.
- **Source:** [MC1478965](https://mc.merill.net/message/MC1478965). Related: [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md).

More: [all Data & compliance news](../topic/data-compliance/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 25 November 2026 (MC1530948 item); 31 October 2026 (other items). Runbook Lab is not affiliated with Microsoft.
