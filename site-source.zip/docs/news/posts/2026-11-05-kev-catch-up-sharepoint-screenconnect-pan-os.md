---
date:
  created: 2026-11-05 10:50:00
slug: kev-catch-up-sharepoint-screenconnect-pan-os
categories:
  - Threats & vulnerabilities
description: "Exploited SharePoint Server CVE-2026-65660, ScreenConnect and PAN-OS flaws from CISA KEV, Sep to Oct 2026: fixed builds, checks and 31 more entries to review."
rl_type: news
rl_area: detection-response
rl_service: [sharepoint-onedrive, other]
rl_kits: []
rl_controls: []
---

# KEV catch-up: SharePoint, ScreenConnect, PAN-OS

Microsoft says that as of 25 September 2026 it "had reliable evidence of observed attacks" against SharePoint Server CVE-2026-65660, and CISA added it, ConnectWise ScreenConnect CVE-2026-84869 and Palo Alto PAN-OS CVE-2026-0322 to its Known Exploited Vulnerabilities catalog between 11 September and 14 October. On-premises SharePoint admins, MSPs running ScreenConnect and firewall owners should check their builds today; every federal due date has passed.

<!-- more -->

!!! note rl-today "Do this today"
    **What:** three exploited flaws in CISA's KEV catalog: SharePoint Server CVE-2026-65660, ScreenConnect CVE-2026-84869 and PAN-OS CVE-2026-0322.<br>
    **Who is exposed:** on-premises SharePoint Server 2016, 2019 and Subscription Edition farms, ScreenConnect users (cloud and on-premises) and PAN-OS firewalls or Panorama.<br>
    **The one action:** check each build against the fixed version below today: SharePoint `(Get-SPFarm).BuildVersion`, ScreenConnect Administration > Overview (26.6.5 or later), PAN-OS `show system info` (`sw-version`). CISA's due dates passed between 14 September and 17 October 2026.<br>
    For the Microsoft 365 side of the same estate, the [M365 Hardening Kit](../../kits/m365-hardening.md) has a free Top 10 with read-only checks.

!!! info "Updated 5 November 2026"
    Zyxel GS1900: the attacks blamed on KEV entry CVE-2026-7273 used a second flaw, CVE-2026-107441, and the June firmware that fixed CVE-2026-7273 does not stop them. Binarly (3 November 2026) says it was "Exploited in the Wild as a Zero-Day". Zyxel's fix for all ten models is firmware 2.90(xxxx.3)C0 (advisory of 3 November 2026; previously the June 2.90(xxxx.2)C0 build was the latest fix). See [Zyxel GS1900](#zyxel-gs1900-the-kev-fix-is-not-enough).

!!! note "Runbook card"
    **What changes:** nothing new this week. These are exploited flaws from September and October 2026 that we had not covered, with the vendors' fixed builds. At the end we list 31 more KEV entries added between 2 September and 27 October 2026: 26 in a table (edge devices, backup, collaboration and e-commerce) and 5 for developer and AI tools.<br>
    **Who:** admins of on-premises SharePoint Server 2016, 2019 and Subscription Edition; MSPs and IT teams using ScreenConnect (cloud and on-premises); owners of PAN-OS firewalls and Panorama.<br>
    **By when:** now. CISA's due dates were 14 September (ScreenConnect), 28 September (SharePoint) and 17 October 2026 (PAN-OS).<br>
    **Do this:** 1. SharePoint: install every update Microsoft lists for your version and confirm the farm build. 2. ScreenConnect: upgrade on-premises installs to 26.6.5 (25.4 or later is needed first; the flaw is in the client), then reinstall host clients and update access agents, also on cloud instances. 3. PAN-OS: upgrade to a fixed build and allow the management interface only from trusted internal IP addresses. 4. Work through the table of other KEV entries for anything you run.<br>
    **Check:** SharePoint `(Get-SPFarm).BuildVersion` against the table below; ScreenConnect Administration > Overview shows 26.6.5 or later; PAN-OS `show system info` shows a fixed `sw-version`.<br>
    **Source:** the vendor advisories linked in each section and the [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (catalog version 2026.11.04).

| CVE | Product | Added to KEV | Federal due date | What the vendor says about exploitation |
|---|---|---|---|---|
| CVE-2026-65660 | SharePoint Server 2016, 2019, Subscription Edition | 25 Sep 2026 | 28 Sep 2026 | "reliable evidence of observed attacks" (25 September) |
| CVE-2026-84869 | ConnectWise ScreenConnect client | 11 Sep 2026 | 14 Sep 2026 | Not confirmed by ConnectWise; priority "1 - High" ("either being targeted or have higher risk of being targeted"). The KEV listing is the exploitation signal |
| CVE-2026-0322 | PAN-OS (PA-Series, VM-Series, Panorama virtual and M-Series) | 14 Oct 2026 | 17 Oct 2026 | "Exploit Maturity ATTACKED" |

## SharePoint Server CVE-2026-65660: exploited, fixed in the August updates

Microsoft's Security Update Guide titles it "Microsoft SharePoint Server Remote Code Execution Vulnerability", CVSS 8.8, severity "Important", released 11 August 2026. Microsoft first published it as a spoofing flaw and later "Updated Impact in the Security Updates table, CVE Title, and FAQs". On 25 September it added: "As of 9/25/2026, Microsoft had reliable evidence of observed attacks against exploitation of this vulnerability."

On its own the flaw needs a signed-in attacker: Microsoft says it "allows an authorized attacker to execute code over a network". The Canadian Centre for Cyber Security (alert AL26-023, 24 September 2026) adds the reason to hurry: "Chained with other SharePoint vulnerabilities, this vulnerability can achieve pre-authentication remote code execution on SharePoint servers configured to permit anonymous access." The Cyber Centre adds that organisations that have not fully applied earlier SharePoint security updates "may therefore face an elevated risk of compromise."

| Product | Update (KB) | Fixed build |
|---|---|---|
| SharePoint Server Subscription Edition | KB5002893 | 16.0.19725.20522 |
| SharePoint Server 2019 | KB5002894 and KB5002896 | 16.0.10417.20198 |
| SharePoint Enterprise Server 2016 | KB5002905 and KB5002906 | 16.0.5565.1001 |

Microsoft's FAQ: "Customers should apply all updates offered for the software installed on their systems." Where two KBs are listed, install both; Microsoft says they "can be installed in any order". The Cyber Centre notes that SharePoint Enterprise Server 2016 and Server 2019 "are end of life as of July 15, 2026". Our advice: plan the move to Subscription Edition.

Check the build from the SharePoint Management Shell on any farm server (read-only):

```powershell
(Get-SPFarm).BuildVersion
```

Then open Central Administration > Upgrade and Migration > Check product and patch installation status to confirm every server shows the update, not only the one you checked.

What the Cyber Centre recommends beyond patching: keep SharePoint off the internet where you can, limit access to Central Administration, turn on AMSI integration for each web application with Request Body Scan Mode set to Full where you can, remove unused accounts, enforce MFA for administrators, and watch for web shells, unexpected web part changes and access to IIS machine keys.

Our advice: on any farm that was unpatched and reachable from the internet in September or October, look for new or changed `.aspx` files under the `LAYOUTS` folders and review Defender or AMSI detections for the SharePoint servers. If you find signs of compromise, rotate the ASP.NET machine keys after patching.

## ScreenConnect CVE-2026-84869: the client, so reinstall host clients

ConnectWise bulletin "ScreenConnect 26.6.5 Security Patch" (8 September 2026): a flaw "in the ScreenConnect client that may allow files to be transferred and executed through an active remote session without authorization or Host confirmation in certain circumstances". CVSS 9.9, severity "Important", priority "1 - High". ConnectWise: "ScreenConnect servers are not impacted", and "ScreenConnect version prior to 26.6.5 are impacted". CISA lists it as "ConnectWise ScreenConnect Improper Privilege Management and Missing Authorization Vulnerability", added 11 September 2026.

- **Cloud:** "No action is required" for the server, which ConnectWise has already moved to 26.6.5. ConnectWise still says: "After upgrading, make sure to reinstall your host clients and update your access agents."
- **On-premises:** upgrade to 26.6.5. "On‑premises partners must be running ScreenConnect version 25.4 or later to upgrade to version 26.6.5", and a licence out of maintenance must be upgraded first. Check "Latest Eligible Version" on Administration > Overview. Then reinstall host clients and update access agents.
- **Automate partners** with an integrated on-premises ScreenConnect get 26.6.5 from the Automate Product Updates page.
- **Temporary mitigation** until you can upgrade, from the bulletin: Administration > Security > Roles: edit a role, review each session group that has permissions assigned to it and deselect the TransferFiles permission (previously named TransferFilesInSession); repeat for each role. ConnectWise says this "is not a substitute for installing the security update".

After patching, ConnectWise recommends reviewing users and removing any you do not recognise, reviewing roles and permissions, changing passwords and turning on MFA. Our advice for MSPs: also review session logs since early September for file transfers and commands run in sessions you did not expect.

## PAN-OS CVE-2026-0322: management interface, no workaround

Palo Alto Networks advisory "CVE-2026-0322 PAN-OS: Authenticated Remote Code Execution (RCE) in the Management Interface" (published 14 October 2026, updated 15 October): it "enables an authenticated attacker with network access to execute arbitrary code with root privileges on the firewall". Severity "8.6 · HIGH", urgency "HIGHEST", exploit maturity "ATTACKED". Exploitation status: "Very limited exploitation has been observed targeting the Palo Alto Networks management interface." It affects PAN-OS on PA-Series and VM-Series firewalls and on Panorama. "Cloud NGFW and Prisma® Access are not impacted by this vulnerability."

This is a different bug from the PHP flaws in PAN-OS we covered in our [31 October KEV brief](2026-10-31-cisa-kev-cisco-asa-gitlab-ivanti-php.md#pan-os-and-panorama-php2shell). Both target the management interface.

| PAN-OS | Fixed builds |
|---|---|
| 12.2 | 12.2.4 or later |
| 12.1 | 12.1.4-h12, 12.1.7-h8 or 12.1.10-h2 or later |
| 11.2 | 11.2.4-h22, 11.2.7-h21, 11.2.10-h15, 11.2.13-h3 or 11.2.16 or later |
| 11.1 | 11.1.4-h37, 11.1.6-h39, 11.1.7-h11, 11.1.10-h35, 11.1.13-h15 or 11.1.16-h3 or later |
| 10.2 | 10.2.7-h38, 10.2.10-h41, 10.2.13-h26, 10.2.16-h11 or 10.2.18-h12 or later |
| Older, unsupported | "Upgrade to a supported fixed version." |

Pick the fixed build on your own maintenance line from the advisory's Solution table: for example, 11.2.5 through 11.2.7-h* goes to 11.2.7-h21 or 11.2.16 or later.

"No known workarounds exist for this issue." Palo Alto says the risk "is minimized by restricting access to the management interface to only trusted internal IP addresses" and is highest when the management interface is reachable from the internet. Threat Prevention Threat IDs 510046 and 510047 give "limited coverage" and only work with SSL decryption of management traffic routed through a data plane interface.

Indicators from the advisory, to search for in firewall and Panorama management logs: 66[.]42[.]72[.]14, 208[.]83[.]239[.]114 and 149[.]248[.]47[.]234.

Check the version from the CLI (read-only): `show system info` and read the `sw-version` line. Check which addresses are allowed to reach the management interface in its permitted IP addresses setting.

## Other KEV entries from September and October to review

These were added to the KEV catalog between 2 September and 27 October 2026 and we had not listed them. We list CISA's name and dates only. **We have not read each vendor's advisory, so we do not state fixed versions here:** check the vendor advisory linked from each CVE record before you patch. All federal due dates have passed except Adobe Commerce, due 10 November.

| Product | CVE | CISA's vulnerability name | Added to KEV |
|---|---|---|---|
| Citrix NetScaler | [CVE-2026-19490](https://nvd.nist.gov/vuln/detail/CVE-2026-19490) | Authentication Bypass Using an Alternate Path or Channel | 9 Sep 2026 |
| Citrix NetScaler | [CVE-2026-88771](https://nvd.nist.gov/vuln/detail/CVE-2026-88771) | Improper Input Validation | 27 Sep 2026 |
| Citrix NetScaler | [CVE-2026-88772](https://nvd.nist.gov/vuln/detail/CVE-2026-88772) | Improper Restriction of Operations within the Bounds of a Memory Buffer | 27 Sep 2026 |
| Fortinet Multiple Products | [CVE-2025-25249](https://nvd.nist.gov/vuln/detail/CVE-2025-25249) | Heap-based Buffer Overflow | 9 Sep 2026 |
| Cisco Secure Firewall Management Center and Security Cloud Control | [CVE-2026-20079](https://nvd.nist.gov/vuln/detail/CVE-2026-20079) | Authentication Bypass Using an Alternate Path or Channel | 9 Sep 2026 |
| Cisco Secure Email Gateway | [CVE-2026-76461](https://nvd.nist.gov/vuln/detail/CVE-2026-76461) | SQL Injection | 14 Sep 2026 |
| Cisco Secure Email Gateway | [CVE-2026-76519](https://nvd.nist.gov/vuln/detail/CVE-2026-76519) | Relative Path Traversal | 14 Oct 2026 |
| Cisco Identity Services Engine | [CVE-2026-76460](https://nvd.nist.gov/vuln/detail/CVE-2026-76460) | Incorrect Use of Privileged APIs | 16 Sep 2026 |
| Cisco Catalyst SD-WAN Manager | [CVE-2026-76504](https://nvd.nist.gov/vuln/detail/CVE-2026-76504) | Hex Encoding | 30 Sep 2026 |
| SonicWall SMA1000 | [CVE-2026-83548](https://nvd.nist.gov/vuln/detail/CVE-2026-83548) | Server-Side Request Forgery | 2 Sep 2026 |
| SonicWall SMA1000 | [CVE-2026-83549](https://nvd.nist.gov/vuln/detail/CVE-2026-83549) | OS Command Injection | 2 Sep 2026 |
| F5 BIG-IP APM | [CVE-2026-94127](https://nvd.nist.gov/vuln/detail/CVE-2026-94127) | Heap-based Buffer Overflow | 22 Sep 2026 |
| Check Point Multiple Products | [CVE-2026-93616](https://nvd.nist.gov/vuln/detail/CVE-2026-93616) | Path Traversal | 22 Sep 2026 |
| Check Point Multiple Products | [CVE-2026-85102](https://nvd.nist.gov/vuln/detail/CVE-2026-85102) | Improper Certificate Validation | 22 Sep 2026 |
| Arista VeloCloud Orchestrator | [CVE-2026-93952](https://nvd.nist.gov/vuln/detail/CVE-2026-93952) | Improper Input Validation | 22 Sep 2026 |
| MikroTik RouterOS | [CVE-2026-67277](https://nvd.nist.gov/vuln/detail/CVE-2026-67277) | Missing Authentication for Critical Function | 10 Sep 2026 |
| MikroTik RouterOS | [CVE-2026-86060](https://nvd.nist.gov/vuln/detail/CVE-2026-86060) | Improper Neutralization of Argument Delimiters in a Command | 10 Sep 2026 |
| MikroTik RouterOS | [CVE-2026-67279](https://nvd.nist.gov/vuln/detail/CVE-2026-67279) | Improper Enforcement of Behavioral Workflow | 25 Sep 2026 |
| Zyxel GS1900 Series Switches | [CVE-2026-7273](https://nvd.nist.gov/vuln/detail/CVE-2026-7273) | Stack-Based Buffer Overflow | 21 Sep 2026 (the fix is not enough: [see below](#zyxel-gs1900-the-kev-fix-is-not-enough)) |
| Ivanti Connect Secure | [CVE-2026-104935](https://nvd.nist.gov/vuln/detail/CVE-2026-104935) | Authentication Bypass by Spoofing | 13 Oct 2026 |
| Atlassian Multiple Products | [CVE-2026-21589](https://nvd.nist.gov/vuln/detail/CVE-2026-21589) | Files or Directories Accessible to External Parties | 15 Oct 2026 |
| GitLab CE and EE | [CVE-2026-85706](https://nvd.nist.gov/vuln/detail/CVE-2026-85706) | Path Traversal | 11 Sep 2026 |
| Acronis Backup | [CVE-2026-87886](https://nvd.nist.gov/vuln/detail/CVE-2026-87886) | Incorrect Default Permissions | 16 Sep 2026 |
| Ahsay AhsayCBS | [CVE-2026-105133](https://nvd.nist.gov/vuln/detail/CVE-2026-105133) | Improper Authentication | 14 Oct 2026 |
| Ahsay AhsayCBS | [CVE-2026-105134](https://nvd.nist.gov/vuln/detail/CVE-2026-105134) | Command Injection | 14 Oct 2026 |
| Adobe Commerce and Magento | [CVE-2026-48356](https://nvd.nist.gov/vuln/detail/CVE-2026-48356) | Unrestricted Upload of File with Dangerous Type | 27 Oct 2026 (due 10 Nov 2026) |

### Zyxel GS1900: the KEV fix is not enough

Added 5 November 2026. Binarly's research post of 3 November 2026 ("Pre-Auth RCE in Zyxel GS1900 Exploited in the Wild as a Zero-Day") analysed the exploit recovered from the attackers' server. It targets `/cgi-bin/dispatcher.cgi`, and its version table includes the June build that fixed CVE-2026-7273. Binarly: "the latest firmware version released as a fix to CVE-2026-7273 is vulnerable to the same exploit, which works without changes." Zyxel confirmed the separate flaw as CVE-2026-107441 on 11 October and released fixed firmware on 22 October, according to Binarly's timeline.

Zyxel's advisory (initial release 3 November 2026) calls it an out-of-bounds write that "could allow a LAN-based, unauthenticated attacker to exploit the flaw and potentially execute OS commands via a crafted HTTP request". Zyxel's advisory does not mention exploitation; the in-the-wild statement is Binarly's. CVE-2026-107441 is not in the KEV catalog (version 2026.11.04).

| Model | Affected | Fixed |
|---|---|---|
| GS1900-8 | 2.90(AAHH.2)C0 and earlier | 2.90(AAHH.3)C0 |
| GS1900-8HP | 2.90(AAHI.2)C0 and earlier | 2.90(AAHI.3)C0 |
| GS1900-10HP | 2.90(AAZI.2)C0 and earlier | 2.90(AAZI.3)C0 |
| GS1900-16 | 2.90(AAHJ.2)C0 and earlier | 2.90(AAHJ.3)C0 |
| GS1900-24 | 2.90(AAHL.2)C0 and earlier | 2.90(AAHL.3)C0 |
| GS1900-24E | 2.90(AAHK.2)C0 and earlier | 2.90(AAHK.3)C0 |
| GS1900-24EP | 2.90(ABTO.2)C0 and earlier | 2.90(ABTO.3)C0 |
| GS1900-24HPv2 | 2.90(ABTP.2)C0 and earlier | 2.90(ABTP.3)C0 |
| GS1900-48 | 2.90(AAHN.2)C0 and earlier | 2.90(AAHN.3)C0 |
| GS1900-48HPv2 | 2.90(ABTQ.2)C0 and earlier | 2.90(ABTQ.3)C0 |

**Do this:** read the firmware version on each GS1900 switch (web interface or the MSP inventory); any version ending `.2)C0` or earlier needs the `.3)C0` build. Keep the switch web interface off user and guest VLANs. Our advice: search DNS and proxy logs for the attackers' domain `981666[.]xyz`, which Binarly lists for this campaign's malware servers.

Ivanti Connect Secure CVE-2026-104935 is the flaw CISA says can be chained with the two Ivanti bugs in our [31 October KEV brief](2026-10-31-cisa-kev-cisco-asa-gitlab-ivanti-php.md#ivanti-connect-secure-cve-2026-111357-and-cve-2026-118527); the forensic checks there apply.

**Developer and AI tooling.** Five entries hit three tools that AI and platform teams often self-host: BerriAI LiteLLM [CVE-2026-59822](https://nvd.nist.gov/vuln/detail/CVE-2026-59822) (Improper Authentication, added 2 September, due 16 September), the Kludex Starlette web framework [CVE-2026-48710](https://nvd.nist.gov/vuln/detail/CVE-2026-48710) (HTTP Request/Response Smuggling, added 2 September, due 16 September), and JFrog Artifactory [CVE-2026-82329](https://nvd.nist.gov/vuln/detail/CVE-2026-82329) (Improper Authentication, added 2 September), [CVE-2026-42016](https://nvd.nist.gov/vuln/detail/CVE-2026-42016) (Incorrect Authorization) and [CVE-2026-42018](https://nvd.nist.gov/vuln/detail/CVE-2026-42018) (Improper Authentication, both added 11 September). Our advice: Starlette usually arrives as a Python dependency, so check your lock files and container images as well as the servers you know about.

## How to verify

Every SharePoint server shows the fixed build in "Check product and patch installation status"; ScreenConnect shows 26.6.5 or later and host clients have been reinstalled; each PAN-OS firewall and Panorama reports a fixed `sw-version`, and the management interface accepts connections only from your permitted internal addresses.

Related: the [first KEV catch-up on FortiOS, FortiMail, NetScaler and N-central](2026-11-04-kev-catch-up-fortios-fortimail-netscaler-n-central.md), the [BeyondTrust Remote Support exploit](2026-11-03-beyondtrust-remote-support-cve-2026-102764-patch-hunt.md), the [end of Exchange Server 2016 and 2019 security updates](2026-11-03-exchange-server-2016-2019-esu-end-no-more-updates.md), the [deadlines calendar](../../guides/deadlines.md) and more [Threats & vulnerabilities news](../topic/threats-vulnerabilities/).

## Sources

- [Microsoft Security Update Guide: CVE-2026-65660](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-65660) (released 11 August 2026, revised 25 September 2026; read 5 November 2026)
- [Canadian Centre for Cyber Security alert AL26-023](https://www.cyber.gc.ca/en/alerts-advisories/al26-023-vulnerability-impacting-microsoft-sharepoint-server-cve-2026-65660) (24 September 2026; read 5 November 2026)
- [ConnectWise: ScreenConnect 26.6.5 Security Patch](https://www.connectwise.com/company/trust/security-bulletins/2026-09-08-screenconnect-bulletin) (8 September 2026; read 5 November 2026)
- [Palo Alto Networks security advisory CVE-2026-0322](https://security.paloaltonetworks.com/CVE-2026-0322) (published 14 October 2026, updated 15 October 2026; read 5 November 2026)
- [Zyxel security advisory for out-of-bounds write vulnerability in GS1900 series switches (CVE-2026-107441)](https://www.zyxel.com/global/en/support/security-advisories/zyxel-security-advisory-for-out-of-bounds-write-vulnerability-in-gs1900-series-switches-11-03-2026) (initial release 3 November 2026; read 5 November 2026)
- [Binarly: Pre-Auth RCE in Zyxel GS1900 Exploited in the Wild as a Zero-Day](https://www.binarly.io/blog/zyxel-gs1900-rce-cve-2026-107441) (3 November 2026; read 5 November 2026)
- [CISA Known Exploited Vulnerabilities catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (catalog version 2026.11.04, read 5 November 2026)

Last reviewed: 5 November 2026. Runbook Lab is not affiliated with Microsoft, ConnectWise, Palo Alto Networks or Zyxel.
