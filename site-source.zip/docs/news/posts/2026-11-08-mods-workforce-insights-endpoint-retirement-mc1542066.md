---
date:
  created: 2026-11-08 09:55:00
slug: mods-workforce-insights-endpoint-retirement-mc1542066
categories:
  - AI security
description: "MC1542066: the Workforce Insights endpoint in MODS retires on 18 November 2026. Tenants that upload custom HR attributes must move to the M365 profile endpoint."
rl_type: news
rl_kits: [copilot]
rl_controls: []
---

# MC1542066: MODS Workforce Insights endpoint retires 18 Nov

MC1542066 (published 6 November 2026, "Act by: Nov 18, 2026") retires the Workforce Insights endpoint in Microsoft 365 Organizational Data Service (MODS): after 18 November it is no longer a destination for uploads, and custom organisational data goes through the Microsoft 365 profile endpoint instead. Only organisations that send custom attributes to the Workforce Insights endpoint, or plan to use custom attributes in Copilot or the Workforce Insights agent, must act; for everyone else Microsoft says "no immediate action is required".

<!-- more -->

!!! note "Runbook card"
    **What changes:** the Workforce Insights endpoint in MODS is retired. Custom organisational attributes reach the Workforce Insights agent and Copilot through the Microsoft 365 profile endpoint. Attributes already uploaded to the old endpoint stay as they are ("stale") and, per the post, become available to Microsoft 365 profile, Copilot experiences and the Workforce Insights agent.<br>
    **Who:** the test is one question: does your tenant upload custom attributes to the Workforce Insights endpoint in MODS, or plan to use custom attributes in Copilot or the agent? If no, nothing to do. If yes, the Organizational Data Source Administrator acts, with privacy and data governance owners for any non-public attribute (the post's example is job level).<br>
    **By when:** 18 November 2026 ("Act by: Nov 18, 2026").<br>
    **Do this:** 1. List the attributes you send to the Workforce Insights endpoint today. 2. Select the Microsoft 365 profile endpoint explicitly for public attributes; the current selection does not carry over. 3. For non-public attributes, agree an access policy with privacy and governance before you upload them; they need Microsoft's private preview, requested through the contact given in MC1542066. 4. Stop choosing the Workforce Insights endpoint for new uploads.<br>
    **Check:** in MODS (Microsoft 365 admin center, organisational data import), note which destination endpoints are selected and which attributes go to Workforce Insights. MC1542066 does not give a portal path.<br>
    **Source:** [MC1542066](https://mc.merill.net/message/MC1542066) (published 6 November 2026).

## What Microsoft says

MC1542066 is titled "Microsoft 365 Copilot: Changes to custom organizational data in MODS for Workforce Insights", tagged "Major change", "User impact" and "Admin impact". The facts in the post:

- "Microsoft 365 is retiring the Workforce Insights endpoint in MODS by November 18, 2026."
- "After November 18, 2026, the Workforce Insights endpoint will no longer be available as a destination in MODS." Public custom attributes go to the Microsoft 365 profile endpoint, which Microsoft says is already generally available for custom public attributes.
- The existing Workforce Insights endpoint selection does not carry over. You have to select the Microsoft 365 profile endpoint yourself.
- Data already uploaded to the Workforce Insights endpoint "will remain stale and continue to serve" the Workforce Insights agent and Copilot organisational queries, but new uploads through the retired endpoint are not possible.
- Non-public attributes reach Copilot experiences and the Workforce Insights agent only after the organisation joins a private preview. This applies to tenants already using the old endpoint and to tenants setting it up for the first time. To join, the post points to a contact address in MC1542066. Microsoft adds that these attributes will also become available to Copilot experiences beyond the agent as capabilities roll out.
- The Workforce Insights agent itself is in Frontier preview.
- The compliance section of the post answers "Yes" to both questions: the change alters how existing customer data is processed, stored or accessed, and it changes how custom attributes reach the Workforce Insights agent and Copilot experiences.

What the post does not say: which licence the Microsoft 365 profile endpoint needs, how long the stale data is kept, or whether uploaded attributes are covered by Copilot audit records. Microsoft hasn't published those details in MC1542066.

## Why it matters for data governance

HR attributes are often uploaded for one purpose, such as analytics in one agent. The post says data already uploaded to the Workforce Insights endpoint becomes available to Microsoft 365 profile and Copilot experiences as well. Our assessment: if your tenant uploaded HR attributes this way, treat this as a new audience for that data and check with HR and privacy owners that it is acceptable before 18 November. For a wider view of what Copilot can surface, use the [Copilot oversharing checklist](../../guides/microsoft-365-copilot-oversharing-checklist-jira.md).

## How to check

Read-only:

1. In MODS, open the organisational data import settings and note every destination endpoint that is selected.
2. For the Workforce Insights endpoint, list the attributes in the last upload file and mark each one public or non-public.
3. Note who holds the Organizational Data Source Administrator role, so the change has an owner.

Microsoft Learn explains imports and changes to uploaded data in [Import and manage your organizational data with a .csv file](https://learn.microsoft.com/microsoft-365-apps/org-data-service/import/import-orgdata#update-or-make-other-changes-to-your-data).

## How to verify

After the switch, the import settings show the Microsoft 365 profile endpoint selected, the next upload completes through it, and the Workforce Insights endpoint is no longer chosen for new uploads.

## Impact and rollback

If you do nothing and you upload custom attributes, your uploads to the Workforce Insights endpoint stop after 18 November and the agent keeps working from stale data. Non-public attributes reach Copilot experiences and the agent only once your organisation is in the private preview. MC1542066 offers no opt-out or extension.

Related: the [Copilot Readiness kit](../../kits/copilot-readiness.md), the [Work IQ agent memory brief (MC1539004)](2026-11-06-work-iq-agents-read-copilot-memory.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [AI security news](../topic/ai-security/).

## Sources

- [MC1542066: Microsoft 365 Copilot: Changes to custom organizational data in MODS for Workforce Insights](https://mc.merill.net/message/MC1542066) (published 6 November 2026; read 8 November 2026)
- [Microsoft Learn: Introduction to Microsoft 365 Organizational Data Service](https://learn.microsoft.com/microsoft-365-apps/org-data-service/organizational-data)
- [Microsoft Learn: Overview of Workforce Insights Agent](https://learn.microsoft.com/microsoft-365/copilot/workforce-insights-agent)

Message center posts are only visible inside a tenant's admin center; the links go to a public mirror (mc.merill.net). Last reviewed: 8 November 2026. Runbook Lab is not affiliated with Microsoft.
