---
date:
  created: 2026-10-31 13:00:00
slug: claude-code-cursor-extension-ssh-backdoor
categories:
  - AI security
description: "Trojanized Claude Code extension in the Cursor marketplace (29 October 2026) planted an SSH backdoor. Check for svc-telemetry, hunt with Defender XDR, clean up."
rl_type: news
rl_kits: []
rl_controls: []
---

# Claude Code extension in Cursor planted an SSH backdoor

On 29 October 2026 the Cursor extension marketplace served a tampered build of the Claude Code extension (`anthropic.claude-code` 2.1.312 and 2.1.313, Windows and macOS) for about eleven hours. Cursor says the malicious versions "were not developed by Anthropic". Anyone who installed or auto-updated the extension in Cursor that day should check for an attacker SSH key named `svc-telemetry` and for the persistence it set up.

<!-- more -->

!!! info "Updated 1 November 2026"
    Microsoft published its analysis on 30 October with Defender detection names and four advanced hunting queries: see [Hunt with Defender XDR](#hunt-with-defender-xdr) below. Microsoft writes that "all evidence suggests that the incident is limited to Cursor marketplace" and that Anthropic confirmed its systems "were not compromised". Anthropic's Felix Rieseberg, quoted by The Register, said "this only impacts Cursor users".

!!! note "Runbook card"
    **What changes:** nothing to configure. A one-day supply-chain compromise left an attacker SSH key, a reverse tunnel and a start-up task on some developer machines.<br>
    **Who:** people who use Cursor with the Claude Code extension and installed or updated it on 29 October 2026. No evidence that the VS Code Marketplace or Open VSX served the bad build.<br>
    **By when:** now. The key and the start-up task stay until someone removes them.<br>
    **Do this:** 1. Run the checks below. 2. Update the extension to 2.1.314. 3. If anything is found, isolate the machine, run Cursor's remediation script and rotate credentials from a clean machine.<br>
    **Check:** `findstr /C:"svc-telemetry" "%USERPROFILE%\.ssh\authorized_keys"` and `schtasks /query /tn SysMon` on Windows.<br>
    **Source:** [Cursor security notice](https://cursor.com/blog/claude-code-extension-security-notice) (29 October 2026, updated 30 October).

## What happened

- Cursor's notice gives the window as about 02:27 to 13:35 PT on 29 October 2026 (about 09:27 to 20:35 UTC). The Hacker News reports, citing Cursor, that up to 5,000 users installed the bad build. Cursor took its marketplace down to remove it, and version 2.1.314 replaced it.
- A loader was added in front of the legitimate code in the extension's main JavaScript file. It ran when the editor started and when the extension's panel opened.
- It added an attacker key with the comment `svc-telemetry` to `authorized_keys`, tried to turn on the local SSH service and opened a reverse SSH tunnel to `134.209.82.225`. Cursor says enabling SSH "would likely fail on most macOS and Windows hosts" because it needs admin rights, but the key and the persistence can still be in place.
- It set up persistence that retries about every 60 seconds: a scheduled task `SysMon` (with a Startup-folder fallback `sysmon.cmd`) on Windows, a LaunchAgent `com.apple.sysmond` on macOS, and a cron `@reboot` entry on Linux.
- It sent host details to `134.209.82.225:8099/beacon` over plain HTTP: public IP, hostname, user name, OS, home and working directories, Git email, and the names (not the values) of environment variables that look like secrets.
- Cursor says the attacker server has been taken offline. That does not remove anything already installed.

## Who is affected

You are in scope if Cursor on Windows or macOS installed or auto-updated `anthropic.claude-code` to 2.1.312 or 2.1.313 on 29 October 2026. People who installed the extension from the VS Code Marketplace or Open VSX are not known to be affected. The Claude Code command-line tool is not named in either report.

For teams: developer laptops often hold cloud, Git and AI tool credentials. Treat a hit as an endpoint incident, not as a plugin update.

## Check

These commands only read. Run them on each machine that uses Cursor.

```bat
:: Windows (Command Prompt)
findstr /C:"svc-telemetry" "%USERPROFILE%\.ssh\authorized_keys"
findstr /C:"svc-telemetry" "%ProgramData%\ssh\administrators_authorized_keys"
schtasks /query /tn SysMon
dir /a "%USERPROFILE%\.config\smt*"
dir /a "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\sysmon.cmd"
```

```bash
# macOS
grep svc-telemetry ~/.ssh/authorized_keys
ls -la ~/Library/LaunchAgents/com.apple.sysmond.plist ~/.config/.smt ~/.config/.smtk
ps aux | grep -E "ssh -N -R|autossh" | grep -v grep

# Which version is installed (if the cursor command is on your PATH)
cursor --list-extensions --show-versions | grep -i claude
```

No output (or "file not found" and "cannot find the task") means none of these indicators is present. On a network level, look for connections to `134.209.82.225` on TCP 22 or 8099 since 29 October.

## Hunt with Defender XDR {#hunt-with-defender-xdr}

If your developer machines are onboarded to Microsoft Defender for Endpoint, run these queries in the Defender portal under **Hunting > Advanced hunting**. They are Microsoft's own queries, copied from its blog post. Microsoft: "A result is an investigative lead, not proof of compromise."

Connections to the reported infrastructure:

```kusto
DeviceNetworkEvents
| where Timestamp > ago(30d)
| where RemoteIP == "134.209.82.225"
    or RemoteUrl has "134.209.82.225"
| project Timestamp,
          DeviceName,
          InitiatingProcessFileName,
          InitiatingProcessCommandLine,
          RemoteIP,
          RemotePort,
          RemoteUrl
```

Malicious file and persistence artifacts (Microsoft notes that "SHA-256 values might not be populated for every file event"):

```kusto
DeviceFileEvents
| where Timestamp > ago(30d)
| where SHA256 == "ecb58cb29078d9646ad1dcdbe51526f2d9cfea06be5fb2ab183e8ecc3ab6bf15"
    or FileName in~ (
        ".smt",
        ".smtk",
        "smt.cmd",
        "smtk",
        "sysmon.cmd",
        "com.apple.sysmond.plist"
    )
    or FileName startswith ".stk_"
| project Timestamp,
          DeviceName,
          ActionType,
          FolderPath,
          FileName,
          SHA256,
          InitiatingProcessFileName,
          InitiatingProcessCommandLine
```

Windows scheduled-task persistence:

```kusto
DeviceEvents
| where Timestamp > ago(30d)
| where ActionType == "ScheduledTaskCreated"
| where AdditionalFields has "SysMon"
    and AdditionalFields has "smt"
| project Timestamp,
          DeviceName,
          AccountName,
          AdditionalFields,
          InitiatingProcessFileName,
          InitiatingProcessCommandLine
```

macOS LaunchAgent persistence:

```kusto
DeviceEvents
| where ActionType == "PlistPropertyModified"
| where FolderPath has "com.apple.sysmond.plist"
```

Detections Microsoft lists:

- Microsoft Defender Antivirus: `Trojan:MacOS/SmtShellMal.A`, `Trojan:JS/CredTheft.MS!MTB`, `Trojan:MacOS/MalPlistSysmond.A`, `HackTool:MacOS/RevAnthShell.A`.
- Microsoft Defender for Endpoint alerts: "Suspicious activity originating from a code editor", "Suspicious addition of an SSH key", "Suspicious launchctl tool activity", "Suspicious scheduled task", "Suspicious Plist modifications", "Suspicious SSH tunneling activity".

Before you delete a key, Microsoft says to "Confirm the key against the fingerprint in Indicators of Compromise before removing the exact unauthorized entry" and to keep unrelated SSH keys. On Windows it says to check both `%USERPROFILE%\.ssh\authorized_keys` and `C:\ProgramData\ssh\administrators_authorized_keys`; both are in our check list above. Credentials: "Rotate credentials and revoke sessions from a known-clean device when telemetry indicates credential access or when device trust cannot be restored."

## What to do if you find something

1. Isolate the machine and keep evidence.
2. Remove the key, the persistence and any running tunnel. Uninstalling the extension alone is not enough, because the start-up scripts keep running. Cursor publishes `remediate-windows.ps1` (run from an elevated PowerShell) and `remediate-macos.sh` (run as the affected user); both exit non-zero if anything remains. Consider rebuilding the machine.
3. From a clean machine, rotate the credentials and sessions that machine could reach: Git and package registry tokens, cloud and SSH keys, AI provider keys and anything listed in its environment.
4. Update the extension to 2.1.314 and check where your editors get extensions from.

## Why it matters for security

AI coding tools run with your user's rights, your keys and your network. This build came through a trusted listing under the right publisher name, and auto-update did the rest. Pin or allow-list extension versions on developer machines where you can, alert on new entries in `authorized_keys` and on new scheduled tasks or LaunchAgents, and keep credentials on developer laptops short-lived.

Related: our weekly [AI security news](../topic/ai-security/) and the earlier [LiteLLM 1.107.0 supply-chain compromise](2026-10-29-litellm-supply-chain-compromise.md).

## Sources

- [Cursor: Security notice, malicious version of Anthropic.claude-code identified in the Cursor Extension Marketplace](https://cursor.com/blog/claude-code-extension-security-notice) (29 October 2026, updated 30 October 2026; read by our news desk 31 October 2026)
- [Microsoft Security blog: Inside a malicious Claude Code-branded extension and its persistent SSH backdoor](https://www.microsoft.com/en-us/security/blog/2026/10/30/inside-malicious-claude-code-branded-cursor-extension-persistent-ssh-backdoor/) (30 October 2026, read 1 November 2026)
- [The Register, quoting Anthropic's Felix Rieseberg](https://www.theregister.com/cyber-crime/2026/10/30/anthropic-that-claude-code-extension-compromise-couldnt-be-us/5306682) (30 October 2026)
- [The Hacker News: Official Claude Code extension on Cursor Marketplace trojanized with persistent SSH backdoor](https://thehackernews.com/2026/10/official-claude-code-vs-code-extension.html) (30 October 2026)
- [BleepingComputer: Malicious Claude Code extension on Cursor planted SSH backdoors](https://www.bleepingcomputer.com/news/security/malicious-claude-code-extension-on-cursor-planted-ssh-backdoors/)

Last reviewed: 1 November 2026.
