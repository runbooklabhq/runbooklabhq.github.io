---
date:
  created: 2026-11-06 12:50:00
slug: data-compliance-this-week-2026-11-06
categories:
  - Data & compliance
description: "Purview changes to 6 November 2026: auto-labeling scale moves to mid-November, DLP for non-Microsoft apps and eDiscovery diagnostics slip, plan your policies."
rl_type: news
rl_kits: [copilot, m365]
rl_controls: []
---

# Data & compliance this week: 4 changes (6 November 2026)

Four confirmed Microsoft Purview changes logged in the week to 6 November 2026: three dates moved and one feature was cancelled. The nearest date is mid-November 2026, when the larger auto-labeling simulation and site limits are now due.

<!-- more -->

This is our weekly Data & compliance roundup. All four Message center posts were re-read on 6 November 2026 and match Research's notes. None of them needs an admin action before rollout, so this week is about planning, not deadlines.

## Dates that moved

### Purview auto-labeling scale and reporting: now mid-November 2026 (previously late October)

MC1469958 v3 (updated 3 November): "Rollout will begin in mid-November 2026 (previously late October)" and "is expected to complete by mid-November 2026 (previously late October)". "Auto-labeling simulation capacity will increase from 4 million items to 20 million items." Policies can name "up to 1,000 individual SharePoint sites", and "Adaptive scopes will support up to 50,000 SharePoint sites per policy." "No action is required."

- **Who acts:** information protection admins who split auto-labeling policies to stay under the old limits.
- **Check:** in Security & Compliance PowerShell, `Get-AutoSensitivityLabelPolicy | Select-Object Name, Mode, Enabled` lists policies still in simulation (`TestWithoutNotifications`). Those are the ones the 20 million item limit helps. Or Purview portal > Information Protection > Policies > Auto-labeling policies.
- **Source:** [MC1469958](https://mc.merill.net/message/MC1469958). Related: [Microsoft 365 Copilot oversharing checklist](../../guides/microsoft-365-copilot-oversharing-checklist-jira.md).

### Purview DLP and auto-labeling for non-Microsoft apps: now late December 2026 (previously late October)

MC1449180 v3 (updated 30 October): "Beginning in late December 2026 (previously late October)". DLP policies will cover Google Workspace, Box, Dropbox, Salesforce, ServiceNow, AWS and Cisco Webex, and auto-labeling covers Google Workspace and Box, through Microsoft Defender for Cloud Apps connectors. Microsoft: "Ensure your organization has the required Enterprise tier Microsoft Purview licensing." "No action is required before rollout."

- **Who acts:** DLP and Defender for Cloud Apps admins in organisations that keep data in those apps.
- **Check:** Defender portal > Settings > Cloud Apps > Connected apps > App Connectors, and note which of the listed apps are connected. An app with no connector gets no Purview DLP policy when this arrives.
- **Source:** [MC1449180](https://mc.merill.net/message/MC1449180) · Learn: [DLP for non-Microsoft connected apps (preview)](https://learn.microsoft.com/purview/dlp-non-microsoft-connected-applications).

### Purview eDiscovery in-product diagnostics: GA now late December 2026 to early January 2027

MC1515937 v2 (updated 4 November). Public preview: "early December 2026 (previously late October)" to "mid-December 2026 (previously mid-November)". General availability: "late December 2026 (previously early December)" to "early January 2027 (previously mid-December 2026)". Admins get "three read-only diagnostic checks" for case access, search scoping and hold-policy distribution. "No admin action is required at this time."

- **Who acts:** eDiscovery managers and compliance admins.
- **Check:** until the diagnostics arrive, hold distribution is still a PowerShell job: `Get-CaseHoldPolicy -Identity "<policy name>" -DistributionDetail | Select-Object Name, DistributionStatus`. Holds always look fine until legal asks for them.
- **Source:** [MC1515937](https://mc.merill.net/message/MC1515937) · Learn: [Collect eDiscovery diagnostic information](https://learn.microsoft.com/en-us/microsoft-365/compliance/ediscovery-diagnostic-info).

## Also logged

### Content Explorer summary metrics cancelled

MC1217640 v6 (updated 4 November), Content Explorer "Unscanned data and Classification History summary metrics": "We have decided not to move forward with this change at this time." The planned counts of unscanned files and the classification history trend will not be added. "No action is required."

- **Who acts:** information protection admins who planned reports on these metrics.
- **Check:** Purview portal > Information Protection > Explorers > Content explorer still shows what it shows today. Remove any runbook step or report that expected the new metrics.
- **Source:** [MC1217640](https://mc.merill.net/message/MC1217640).

Related this week: Copilot memory is data governance too. Work IQ will let authorised agents read users' Copilot memory, see [Work IQ agents can read Copilot memory](2026-11-06-work-iq-agents-read-copilot-memory.md) and the [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md). Earlier Purview items: [Data & compliance roundup, 31 October](2026-10-31-data-compliance-this-week.md).

More: [all Data & compliance news](../topic/data-compliance/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 6 November 2026. Runbook Lab is not affiliated with Microsoft.
