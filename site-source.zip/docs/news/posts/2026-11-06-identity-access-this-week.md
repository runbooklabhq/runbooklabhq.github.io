---
date:
  created: 2026-11-06 12:00:00
slug: identity-access-this-week-2026-11-06
categories:
  - Identity & access
description: "Identity news to 6 November 2026: SSPR loses SMS and voice, Defender for Identity sensor v3 auto-enables, fix AD CS ESC1/ESC8, patch Authenticator, AuthPoint."
rl_type: news
rl_kits: [sms, ca, pim, agents]
rl_controls: []
---

# Identity & access this week: 11 changes (6 November 2026)

Eleven confirmed Identity & access items logged in the week to 6 November 2026, each with who acts, the check and the source. The nearest date is today: Microsoft says act on SSPR registered methods by 6 November, and enforcement begins on 7 November.

<!-- more -->

This is our weekly Identity & access roundup. Most items were re-read on their primary source on 6 November 2026. The two Microsoft blog posts (5 November and 30 October) and the MC1325414 and MC1506733 notices were not re-read today; for those we use the facts Research read at the primary source between 1 and 6 November. The WatchGuard item rests on SecurityWeek and the CVE records, not on WatchGuard's own advisories.

## Already briefed

1. **SSPR only accepts registered methods from 7 November 2026; Microsoft says "Act by Nov 6, 2026".** Identity admins and the helpdesk. Check: users with SSPR enabled but no registered method. Brief: [SSPR stops using the phone number in the directory](2026-10-29-entra-sspr-registered-methods-only.md). Source: [MC1325414](https://mc.merill.net/message/MC1325414).
2. **Microsoft Threat Intelligence (5 November) confirms leaked app secrets turned into tenant access.** Agentic AI tooling finds client secrets on GitHub; from 28 October Microsoft saw service principal sign-ins "on dozens of associated applications across multiple tenants", from the same IPs Todyl reported. The post names no actor. Entra admins and MSPs: hunt service principal sign-ins from 199.19.77[.]84 since 28 October and rotate any secret that was ever in a repo. Brief: [AI agents turn leaked app secrets into tenant access](2026-11-06-agentic-ai-leaked-app-secrets-service-principals.md). Related: [ConnectWise cloud apps and Microsoft 365 tenants](2026-11-03-connectwise-cloud-apps-storm-0940-m365-tenants.md).
3. **Default users can create Entra agent blueprints from 4 November 2026, rolling out to late November.** Identity admins. Check: Entra admin center > Entra ID > Users > User settings > "Users can create agent blueprints". Brief: [Entra agent blueprints and AgentIdentity.CreateAsManager](2026-11-04-entra-agent-blueprints-default-users-createasmanager.md). Source: [MC1506733](https://mc.merill.net/message/MC1506733).

## New this week

### SSPR loses Microsoft-provided SMS and voice from 1 February 2027

MC1536049 (published 3 November 2026, "Act by: Mar 22, 2027") retires Microsoft-provided SMS and voice for self-service password reset. Rollout starts "February 1, 2027" for "Users other than Global Administrators and external users" and "July 1, 2027" for "Global Administrators and external users"; in each case the SSPR transition ends "50 days after this rollout reaches your tenant". "These are phased rollout start dates, not a single SSPR cutoff for every organization." "Passkeys alone don't satisfy SSPR requirements", and "Microsoft will not automatically change your SSPR policy". Customer-managed telephony keeps working. Its rollout schedule section also says "We expect rollout to begin and complete in February 2027"; the phased dates above come from the post's table.

- **Who acts:** identity admins and the helpdesk, before 22 March 2027.
- **Check:** Entra admin center > Protection > Password reset > Authentication methods. Then list users whose only registered methods are phone methods (read-only): `Get-MgReportAuthenticationMethodUserRegistrationDetail -All | Where-Object { $_.IsSsprRegistered -and -not ($_.MethodsRegistered | Where-Object { $_ -notmatch 'Phone' }) } | Select-Object UserPrincipalName, MethodsRegistered`. Microsoft also recommends "Allow password change after secure sign-in" for passkey users.
- **Source:** [MC1536049](https://mc.merill.net/message/MC1536049). Related: [Entra SMS MFA Exit Kit](../../kits/sms-mfa-exit.md), [SMS and voice MFA retirement guide](../../guides/entra-sms-voice-mfa-retirement-passkeys.md).

### Fake help desk in Teams led to AD CS ESC1 and ESC8 abuse, Microsoft report of 30 October 2026

Microsoft describes two intrusions that began with help-desk impersonation in Teams and a user-approved Quick Assist session. In one, an ESC1 certificate template issued certificates for privileged accounts, followed by DCSync. In the other, coerced domain controller authentication was relayed to AD CS Web Enrollment (ESC8). "The activity did not exploit a vulnerability in Microsoft Teams." Microsoft's advice: "Require HTTPS and enforce Extended Protection for Authentication (EPA) on enrollment web endpoints" and "Disable NTLM on enrollment services where operationally feasible".

- **Who acts:** AD and identity admins in hybrid estates with AD CS; Teams admins for external access.
- **Check:** on a domain-joined admin host, list templates where the requester supplies the subject (read-only): `certutil -v -dstemplate | findstr /i "cn= ENROLLEE_SUPPLIES_SUBJECT"`. Then review who can enrol on each one, and whether `/certsrv` answers over HTTP. In the Teams admin center > Users > External access, check whether external chat is open to all domains.
- **Source:** [Microsoft Security blog, 30 October 2026](https://www.microsoft.com/en-us/security/blog/2026/10/30/help-desk-impersonation-ad-cs-abuse-investigating-esc1-esc8-intrusion-paths/). Related: [Conditional Access Kit](../../kits/conditional-access.md).

### Defender for Identity turns on sensor v3.x and Windows auditing 30 days after the banner, from October 2026

Licensed tenants with an active workspace see a banner on the Sensor management tab for 30 days. "After the 30-day notice period, Automatic sensor v3.x activation and Automatic Windows auditing configuration are enabled by default through a very gradual rollout, including settings currently set to Off." The date is tenant-specific: day 30 counts from when your banner appeared. The same update adds new Defender for Identity alerts for AD CS abuse, which pairs with the item above.

- **Who acts:** Defender and AD admins, before day 30 of the banner.
- **Check:** Defender portal > Settings > Identities > On-premises > Sensor management. Use **Go to Advanced features** to turn the settings on yourself, or **Opt out** to keep your current settings. Audit policy changes on domain controllers go through change control either way.
- **Source:** [What's new in Microsoft Defender for Identity](https://learn.microsoft.com/en-us/defender-for-identity/whats-new) (updated 28 October 2026).

### Huntress: token spray and replay reached 79 Microsoft 365 organisations, report of 22 October 2026

Huntress tracked a campaign from 14 July to 22 September 2026: at least 497 successful sign-ins at 79 organisations, against more than 200,000 failed attempts. Replay came from 193.26.115.0/24 (AS210558). The operator registered at least 48 Entra devices named "DESKTOP-" plus eight hex characters, and in 19 organisations wiped the existing MFA methods and registered a new one within three hours. Huntress: "Treat Conditional Access blocks (AADSTS53003) as a sign of a valid credential, not a save."

- **Who acts:** identity admins and MSP SOC teams.
- **Check:** Entra admin center > Monitoring & health > Sign-in logs, filter on the 193.26.115.x addresses, or in Log Analytics run `SigninLogs | where ipv4_is_in_range(IPAddress, "193.26.115.0/24")`, and look at failures as well. List recent devices (read-only): `Get-MgDevice -All -Property DisplayName,RegistrationDateTime,OperatingSystem | Where-Object DisplayName -like 'DESKTOP-*' | Sort-Object RegistrationDateTime -Descending`. Confirm before deleting anything. A password reset alone leaves the attacker's devices and MFA methods in place.
- **Source:** [Huntress](https://www.huntress.com/blog/token-replay-spray). Related: [Conditional Access baseline in report-only](../../guides/entra-conditional-access-baseline-report-only.md) (block device code flow).

### Storm-3119 resold hijacked Microsoft 365 Education tenants, Microsoft report updated 23 October 2026

Microsoft Threat Intelligence says Storm-3119 ("YAM Store") hijacks "Microsoft 365 and Azure for Education tenants and resells the stolen accounts". Its panels use stolen app credentials to reset passwords "silently (without forcing a change at next sign-in)", and in one stage it "signs in to a compromised Global Administrator account". Microsoft links the phishing kits it tracks as Storm-2990 to over one billion phishing emails and SMS messages since January 2026, and some downstream actors use device code phishing.

- **Who acts:** identity admins, education tenants and MSPs that manage them.
- **Check:** Entra admin center > Protection > Conditional Access > Policies: confirm a policy requires phishing-resistant MFA for admin roles, and one blocks device code flow (Conditions > Authentication flows). Review who holds Global Administrator.
- **Source:** [Microsoft Security blog, 14 October 2026](https://microsoft.com/en-us/security/blog/2026/10/14/the-hidden-network-inside-the-phishing-infrastructure-ecosystem-powering-global-cybercrime). Related: [PIM for Global Admins](../../guides/entra-privileged-access-pim-global-admins.md), [Privileged Access Kit](../../kits/privileged-access-pim.md).

### Microsoft Authenticator for Android CVE-2026-80097: versions before 6.2606.4246 affected, published 8 September 2026

MSRC rates this elevation of privilege flaw "Important", CVSS 8.6, exploited "No". It needs a malicious app on the phone and a user who completes an Authenticator flow; that app can then obtain tokens. Microsoft's CVE record lists Authenticator for Android from 6.0.0 up to, but not including, 6.2606.4246 as affected.

- **Who acts:** Intune and identity admins with Android users.
- **Check:** Intune admin center > Apps > Monitor > Discovered apps: Microsoft Authenticator versions on Android. Set a minimum app version in app protection or compliance. Updating does not revoke tokens already taken, so for devices you suspect, revoke sessions.
- **Source:** [CVE-2026-80097 at MSRC](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-80097). Related: [Conditional Access Kit](../../kits/conditional-access.md).

### WatchGuard AuthPoint Gateway: four CVEs fixed in 7.6.0, published 4 November 2026

AuthPoint Authentication Gateway versions before 7.6.0 have four flaws. CVE-2026-121637 (CVSS 8.9) lets an attacker "forge authentication results and bypass session security" through the LDAP callback. CVE-2026-121638, -121639 and -121640 cover certificate validation, a missing authentication check and request replay; we have not read WatchGuard's own advisories for those three, so we give no scores. WatchGuard and Cisco said they know of no exploitation in the wild (SecurityWeek, 5 November).

- **Who acts:** MSPs and admins who run AuthPoint for VPN, RADIUS or LDAP MFA. Treat the gateway as identity infrastructure.
- **Check:** on each gateway host (read-only): `Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object DisplayName -like '*AuthPoint*' | Select-Object DisplayName, DisplayVersion`. Anything below 7.6.0 needs the update.
- **Source:** [WatchGuard PSIRT, CVE-2026-121637](https://psirt.watchguard.com/CVE-2026-121637). Report: [SecurityWeek](https://www.securityweek.com/cisco-watchguard-release-patches-sonicwall-wont-fix-gms-flaws/).

## Also logged

- **Teams meetings get granular Conditional Access through authentication contexts.** Public preview "late November 2026", general availability from "early January 2027" to "late January 2027". Organisers can require extra verification for a specific meeting. It needs admin set-up: authentication contexts and their policies in Entra, published to Teams, then Teams meeting policies. Check: Entra admin center > Protection > Conditional Access > Authentication contexts. Source: [MC1532256](https://mc.merill.net/message/MC1532256). Related: [Conditional Access Kit](../../kits/conditional-access.md).

More: [all Identity & access news](../topic/identity-access/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 6 November 2026. Runbook Lab is not affiliated with Microsoft.
