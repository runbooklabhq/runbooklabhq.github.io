---
date:
  created: 2026-11-03 22:00:00
slug: outlook-blocks-msix-attachments-owa-mailbox-policy
categories:
  - Email & collaboration
description: "Outlook on the web and new Outlook block .msix and .msixbundle attachments from early November 2026. Check your OwaMailboxPolicy settings now, before rollout."
rl_type: news
rl_kits: [exo]
rl_controls: [EX05]
---

# Outlook web and new Outlook block MSIX attachments

Microsoft is adding .msix and .msixbundle to the blocked file types in every OWA mailbox policy, with rollout that "begins in early November 2026 and is expected to complete by mid-November 2026" (MC1488841). Exchange Online admins whose users legitimately send or receive MSIX packages by mail must allow them before the rollout reaches their tenant; everyone else needs no action.

<!-- more -->

!!! note "Runbook card"
    **What changes:** .msix and .msixbundle are added to the BlockedFileTypes list "in the default OWA Mailbox policy and any custom policies created in your tenant". Users of Outlook on the web and new Outlook for Windows "will no longer be able to open or download them".<br>
    **Who:** Exchange Online admins who manage OWA mailbox policies, and any team that sends MSIX app packages as mail attachments (our examples: packaging teams, software vendors, MSPs).<br>
    **By when:** rollout "begins in early November 2026" and is "expected to complete by mid-November 2026" (Worldwide, GCC, GCC High, DoD). Microsoft hasn't published exact dates.<br>
    **Do this:** 1. List your OWA mailbox policies and what they block and allow. 2. Ask whether anyone needs MSIX by mail; if no one does, take no action. 3. If someone does, add .msix and .msixbundle to AllowedFileTypes on the policies those users have, now, before the rollout reaches your tenant (Microsoft says "prior to rollout").<br>
    **Check:** `Get-OwaMailboxPolicy | Select-Object Name,IsDefault,@{n='MsixAllowed';e={$_.AllowedFileTypes -contains '.msix'}},@{n='MsixBlocked';e={$_.BlockedFileTypes -contains '.msix'}}` in Exchange Online PowerShell (read-only).<br>
    **Source:** [MC1488841: Microsoft Outlook: Update to default blocked file types in OwaMailboxPolicy](https://mc.merill.net/message/MC1488841) (published 5 October 2026).

## What Microsoft says

The Message Center post is tagged "Major change", "Feature update", "User impact" and "Admin impact". Microsoft gives security as the reason: the change helps "protect organizations from potentially unsafe file attachments". It also says "Most organizations are not expected to be affected by this update because these file types are infrequently used."

Platforms named in the post: Outlook for the web, new Outlook for Windows and Exchange Online. Classic Outlook for Windows is not mentioned in the post, so we make no claim about it either way.

The recommended action, in Microsoft's words: "No action is required if your organization does not rely on the .msix or .msixbundle file types. If your organization relies on these file types, we recommend that you add them to the AllowedFileTypes property of your users' OwaMailboxPolicy objects prior to rollout."

BleepingComputer reported the change on 7 October 2026, quoting the same Message Center post.

## How to check (read-only)

Connect to Exchange Online PowerShell and list every OWA mailbox policy with whether it allows or blocks .msix (the lists hold dozens of entries, so `Format-List` would cut them short):

```powershell
Get-OwaMailboxPolicy | Select-Object Name,IsDefault,@{n='MsixAllowed';e={$_.AllowedFileTypes -contains '.msix'}},@{n='MsixBlocked';e={$_.BlockedFileTypes -contains '.msix'}}
```

Once the rollout reaches your tenant, MsixBlocked shows True on each policy. Repeat with `'.msixbundle'` for the bundle type. To see which policy a user has (a blank value means the default policy):

```powershell
Get-CASMailbox -Identity user@yourdomain.example | Format-List OwaMailboxPolicy
```

## If you must keep MSIX by mail

Our example, based on the AllowedFileTypes parameter Microsoft links from the post (see [Set-OwaMailboxPolicy](https://learn.microsoft.com/powershell/module/exchange/set-owamailboxpolicy)). This changes the policy, so run it only on the policies that need it, after a change approval:

```powershell
Set-OwaMailboxPolicy -Identity "<policy name>" -AllowedFileTypes @{Add=".msix",".msixbundle"}
```

Our advice: allowing MSIX in mail reopens a path Microsoft is closing on purpose. Where you can, ship packages through Intune or a file share instead, and keep a malware filter in front of mail either way. The [common attachments filter](../../controls/exchange-online-protection/ex05-anti-malware-common-attachments-filter-on-with-reject.md) in Exchange Online Protection is a separate setting from the OWA policy.

## How to verify

Run the check command again. Once the rollout has reached your tenant, every policy shows MsixBlocked as True; the policies you allowed also show MsixAllowed as True. Microsoft Learn's Set-OwaMailboxPolicy page is not consistent on which list wins when a type is in both (the AllowedFileTypes section says the Block list overrides the Allow list; the BlockedFileTypes section says the opposite), so ask one affected user to open a test .msix attachment in Outlook on the web after the rollout. If it is still blocked, our advice is to also remove the type from BlockedFileTypes on that policy only.

## Impact

Users who rely on MSIX attachments in Outlook on the web or new Outlook for Windows lose the ability to open or download them when the change lands. Nothing else changes in the post. If you added an allow entry and want to undo it, remove it with the same parameter and `@{Remove=...}`.

Related: the [Exchange Online Protection kit](../../kits/exchange-online-protection.md) and its [preset policies and DMARC guide](../../guides/exchange-online-protection-preset-policies-dmarc.md), dated actions on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [Email & collaboration news](../topic/email-collaboration/).

## Sources

- [MC1488841: Microsoft Outlook: Update to default blocked file types in OwaMailboxPolicy](https://mc.merill.net/message/MC1488841) (published 5 October 2026; read 3 November 2026)
- [Microsoft Learn: Set-OwaMailboxPolicy](https://learn.microsoft.com/powershell/module/exchange/set-owamailboxpolicy) (AllowedFileTypes and BlockedFileTypes parameters)
- [BleepingComputer: Microsoft Outlook to block MSIX attachments used in attacks](https://www.bleepingcomputer.com/news/microsoft/microsoft-outlook-to-block-msix-attachments-used-in-attacks/) (7 October 2026)

Last reviewed: 3 November 2026. Runbook Lab is not affiliated with Microsoft.
