---
date:
  created: 2026-11-20 10:31:00
slug: identity-access-this-week-2026-11-20
categories:
  - Identity & access
description: "Identity news to 20 November 2026: audit new MFA and passkey registrations after COLD RELIC, test Baseline security mode 2026 in simulation, Entra at Ignite."
rl_type: news
rl_area: identity
rl_service: [entra, defender]
rl_kits: [ca, m365]
rl_controls: []
---

# Identity & access this week: 6 changes (20 November 2026)

Six confirmed Entra and Microsoft 365 identity items from the week to 20 November 2026. The first check is for every Entra admin: after Google's report on COLD RELIC, list the MFA methods and passkeys registered in the last 30 days and look for registrations that followed a risky sign-in.

<!-- more -->

This is our weekly Identity & access roundup. Items rest on the facts our Research desk read at each primary source between 17 and 20 November 2026. Our new "Am I affected?" page on [mandatory MFA for admin portals and break-glass accounts](../../guides/break-glass-mandatory-mfa-am-i-affected.md) went live on 19 November.

## Already briefed

1. **Defender for Identity retires the classic "Remote code execution attempt" and "Suspected identity theft (pass-the-hash)" alerts; act by 30 November 2026.** SOC teams and Defender admins: build the custom detection rule first. Brief: [Defender for Identity classic alerts retirement (MC1552387)](2026-11-14-defender-for-identity-classic-alerts-retirement-mc1552387.md).

## New this week

### COLD RELIC: Entra ID token phishing, then rogue MFA devices and passkeys (GTIG, 18 November 2026)

Google Threat Intelligence Group (GTIG) describes an operator who first contacted the victim through "a secure messaging app", posing as an employee of an already breached firm. The phishing links were "designed to steal credentials and authentication tokens for Entra ID". GTIG: "After gaining initial access to an organization, COLD RELIC registers rogue MFA devices, passkeys, and MFA backup codes to establish long-term persistence." In one case the victim organisation used Entra ID as the single sign-on provider for Google Workspace. GTIG recommends "Enforce Phishing-Resistant MFA (FIDO2 / WebAuthn)" and "Restrict and Audit Passkey Registrations". SecurityWeek links COLD RELIC to Star Blizzard; that attribution is theirs and GTIG's, not ours.

- **Who acts:** Entra admins. No deadline.
- **Check:** Entra admin center > Monitoring > Audit logs, Service "Authentication Methods", activities "User registered security info" and "User registered all required security info", last 30 days. Look for registrations from a new location shortly after a risky sign-in.
- **Do this:** require phishing-resistant MFA through an authentication strength in Conditional Access for admins and high-value users, and limit the user action "Register security information" to trusted locations or compliant devices with a Conditional Access policy.
- **Source:** [COLD RELIC: a case study in impersonation and compromise](https://cloud.google.com/blog/topics/threat-intelligence/cold-relic-a-case-study-in-impersonation-and-compromise) (GTIG, 18 November 2026); [SecurityWeek](https://www.securityweek.com/russian-apt-poses-as-employee-of-hacked-firm-to-breach-another-us-organization/) (18 November 2026). Related: [Conditional Access Baseline Kit](../../kits/conditional-access.md).

### Microsoft Baseline security mode 2026 is generally available (17 November 2026)

"Microsoft Baseline security mode (BSM) 2026 is now generally available, with a phased rollout across all supported Microsoft 365 cloud environments worldwide." It adds 24 settings that "Administrators can apply each setting or run them in simulation mode". New settings include "Require MFA (multi-factor-authentication) for guests and external users (Entra)", "Disable guest users from having eDiscovery roles (Purview)", "Block COM add-ins that aren't on the admin allow list (Office)", "Require a second admin to approve sensitive actions (Intune)" and "Don't allow Microsoft 365 trial tenants to federate with your organization (Teams)". Microsoft also says "BSM 2025 will become the default configuration for all new Microsoft 365 tenants"; it gives no date for that.

- **Who acts:** Global Administrators and identity admins of existing tenants (opt-in per setting).
- **Check:** Microsoft 365 admin center > Org Settings > Security & Privacy > Baseline security mode. Run the new settings in simulation mode and read the impact before you apply them.
- **Source:** [Announcing Microsoft Baseline security mode 2026 general availability](https://techcommunity.microsoft.com/blog/microsoft_365blog/ignite%E2%80%9926-spotlight-announcing-microsoft-baseline-security-mode-2026-general-ava/4572694) (Microsoft 365 Blog, 17 November 2026). Related: [Microsoft 365 Hardening Kit](../../kits/m365-hardening.md).

### Entra at Ignite: agent identity lifecycle GA, hard deletion protection preview, guest lifecycle GA (17 November 2026)

From Microsoft's Entra Ignite post: "Microsoft Entra hard deletion protection (preview). You can protect crucial tenant objects such as Agent IDs from permanent deletion." "Automated lifecycle management of agent identities (generally available)… An out-of-the-box policy disables agent identities that have been inactive for 60 days." The post does not say whether that policy is on without admin action. Also announced: "Microsoft Entra Conditional Access policy plans (preview)", "Entra ID Governance Guest lifecycle policies (generally available)", "Microsoft MCP Server for Enterprise (generally available)", "Microsoft Entra Agent ID for discovered local agents (preview)" covering "60 local agent types, including Claude Code, OpenAI Codex, and GitHub Copilot CLI", an "MCP firewall (preview)", and "passkeys, now the default for new accounts in Microsoft Entra".

- **Who acts:** identity admins who run agent identities or plan guest lifecycle policies.
- **Check:** Entra admin center > Agent ID: list agent identities with no sign-in in the last 60 days and give each a sponsor, so a lifecycle policy does not disable an agent that runs rarely.
- **Source:** [AI is changing access: see how Entra helps you stay ahead](https://techcommunity.microsoft.com/blog/microsoft-entra-blog/ai-is-changing-access-see-how-entra-helps-you-stay-ahead-/4556456) (Microsoft Entra Blog, 17 November 2026). Related: [M365 AI Agent Hardening Kit](../../kits/ai-agent-hardening.md).

### MC1479503: App Governance permissions move with Unified RBAC, early to late December 2026

"Updated November 19, 2026: We have updated the timeline." "We will begin rolling out in early December 2026 (previously mid-November) and expect to complete by late December 2026 (previously late November)." Microsoft's summary: "Cloud App Security Administrators gain policy management rights; Compliance Administrators and Compliance Data Administrators lose some permissions." The post has no Act by date.

- **Who acts:** Entra role admins and Defender for Cloud Apps admins.
- **Check:** Entra admin center > Roles & admins: list who holds Cloud App Security Administrator, Compliance Administrator and Compliance Data Administrator. Decide who should manage App Governance policies, then re-test compliance staff's access after the change (Defender portal > Permissions > Microsoft Defender XDR (Unified RBAC)).
- **Source:** [MC1479503](https://mc.merill.net/message/MC1479503) (published 25 September 2026, updated 19 November 2026).

## Also logged

- **MC1551151, risk-based CAPTCHA for SMS and voice MFA: "Worldwide: Beginning in mid-November 2026."** "Users with restrictive network or firewall settings may be unable to complete SMS or voice MFA if the verification experience cannot load." "This change is separate from the planned retirement of SMS and voice authentication and does not affect the retirement timeline." Tell the help desk, and check proxies and web filtering. [MC1551151](https://mc.merill.net/message/MC1551151).
- **MC1558114, App Governance supports Defender XDR unified RBAC: "Public Preview (Worldwide): We will begin rolling out in late November 2026 and expect to complete by mid-December 2026."** Read it with MC1479503 above. [MC1558114](https://mc.merill.net/message/MC1558114).

Related guides: [Break-glass accounts and mandatory MFA: am I affected?](../../guides/break-glass-mandatory-mfa-am-i-affected.md) · [Entra SMS and voice MFA retires 1 February 2027](../../guides/entra-sms-voice-mfa-retirement-passkeys.md).

More: [all Identity & access news](../topic/identity-access/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 20 November 2026. Runbook Lab is not affiliated with Microsoft.
