---
date:
  created: 2026-10-31 23:50:00
slug: dotnet-october-oob-brotli-security-update
categories:
  - Threats & vulnerabilities
description: "Brotli flaw CVE-2026-111497 in .NET 8, 9 and 10, PowerShell 7 and Visual Studio is in CISA KEV (due 10 Nov). Check versions, update and rebuild apps."
rl_type: news
rl_kits: []
rl_controls: []
---

# .NET 8, 9 and 10 out-of-band Brotli security update

On 25 October 2026 Microsoft released out-of-band security updates for .NET 8, 9 and 10 (8.0.33, 9.0.22 and 10.0.14) and .NET 11 RC3, fixing the Brotli decompression flaw CVE-2026-111497 and finishing two fixes from the 13 October release. Anyone running .NET apps on servers, in containers or as self-contained builds should update; Microsoft says "We recommend updating as soon as possible."

<!-- more -->

!!! info "Updated 4 November 2026: correction"
    We wrote "We do not call it exploited" and listed only .NET. Two facts were missing. CISA added CVE-2026-111497 ("Google Brotli Unchecked Return Value Vulnerability") to its Known Exploited Vulnerabilities catalog on 27 October 2026, with a federal due date of 10 November 2026. Microsoft's Security Update Guide rates it CVSS 8.1, "Critical", and lists PowerShell 7, Visual Studio and Azure Linux 3 as affected as well as .NET. Microsoft's record still says "Exploited: No"; CISA does not say which product was attacked, so we do not name one. We now treat it as exploited for patch priority, because CISA does. See [Exploited, says CISA](#exploited-says-cisa) and [Also affected: PowerShell 7 and Visual Studio](#also-affected-powershell-7-and-visual-studio).

!!! note "Runbook card"
    **What changes:** new .NET runtimes 8.0.33, 9.0.22 and 10.0.14 fix CVE-2026-111497 (Brotli buffer overflow), CVE-2026-114148 (Linux tarball ownership) and re-release the fixes for CVE-2026-70197 and CVE-2026-102870.<br>
    **Who:** admins and developers running .NET 8, 9 or 10 apps (Windows and Linux servers, line-of-business and RMM tools, containers, self-contained apps), PowerShell 7.4, 7.5 or 7.6, Visual Studio 2017 to 2026, or Azure Linux 3 brotli and nodejs packages. .NET Framework is not affected.<br>
    **By when:** before 10 November 2026, CISA's federal due date (Microsoft says "as soon as possible"). Install it even if you applied the 13 October update.<br>
    **Do this:** 1. Install the updated runtime on every host and restart the apps. 2. Rebuild and republish self-contained apps. 3. Rebuild and redeploy container images from updated .NET images. 4. On .NET 8 and 9 Linux tarball installs, take the refreshed ASP.NET Core tarball. 5. Update PowerShell 7 and Visual Studio to the fixed builds below.<br>
    **Check:** `dotnet --list-runtimes` shows Microsoft.NETCore.App and Microsoft.AspNetCore.App at 8.0.33, 9.0.22 or 10.0.14 or later; `$PSVersionTable.PSVersion` shows 7.4.22, 7.5.13 or 7.6.9 or later.<br>
    **Source:** [.NET Blog: .NET October 2026 Out-of-Band Security Updates](https://devblogs.microsoft.com/dotnet/dotnet-october-2026-oob-security-updates/) (25 October 2026), [MSRC CVE-2026-111497](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-111497) and the [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog).

## What Microsoft says

CVE-2026-111497, all platforms: "A buffer overflow vulnerability exists in .NET's use of the Brotli decompression algorithm. This vulnerability may allow an unauthenticated attacker to read or corrupt process memory. This could lead to information disclosure, denial of service, or elevation of privilege."

Apps are exposed if they handle Brotli-compressed data through ASP.NET Core request decompression, HttpClient automatic response decompression or the System.IO.Compression Brotli APIs. Microsoft: "Request decompression and automatic response decompression are not enabled by default. .NET Framework is not affected."

CVE-2026-114148, Linux only: "Unsafe ownership metadata in affected .NET tarballs could allow a local attacker to modify files and gain elevated privileges." On .NET 10 and 11 this affects source-build tarballs only. On .NET 8 and 9 it also affects ASP.NET Core tarballs, "including users who do not build .NET from source".

Microsoft is also re-releasing the advisories for CVE-2026-70197 (SocketAsyncEventArgs memory corruption) and CVE-2026-102870 (Blazor WebAssembly debugger) "because the October 13, 2026 release did not fully address these issues". If you patched on 13 October, you still need this update.

| .NET version | Fixed version |
|---|---|
| .NET 8 | 8.0.33 |
| .NET 9 | 9.0.22 |
| .NET 10 | 10.0.14 |
| .NET 11 | Release Candidate 3 (RC2 users should update) |

The .NET blog post itself gives no CVSS score and says nothing about exploitation. The Security Update Guide record, below, does both.

## Exploited, says CISA

CISA added CVE-2026-111497 to the Known Exploited Vulnerabilities catalog on 27 October 2026 as "Google Brotli Unchecked Return Value Vulnerability", with a due date of 10 November 2026 for US federal agencies. CISA notes that it "affects an open-source component, third-party library, protocol, or proprietary implementation that could be used by different products" and points to the Brotli 1.2.1 release. Known ransomware use: "Unknown".

Microsoft's Security Update Guide (latest revision 1 November 2026) titles it "Google: CVE-2026-111497 Buffer overflow vulnerability in the Brotli decoder", CVSS 8.1, severity "Critical", impact Elevation of Privilege, issued by Google as the CNA. It marks the flaw "Publicly disclosed: Yes" and "Exploited: No".

The two records disagree, and neither says who was attacked or through which product. We do not guess. For patch order, treat it as exploited: a KEV listing is the stronger signal, and the fix is a routine servicing update.

## Also affected: PowerShell 7 and Visual Studio

The Security Update Guide lists these products and fixed builds for CVE-2026-111497 (read 4 November 2026):

| Product | Fixed build |
|---|---|
| .NET 8.0 installed | 8.0.427 (KB5133964) |
| .NET 9.0 installed | 9.0.320 (KB5133965) |
| .NET 10.0 installed | 10.0.403 (KB5133966) |
| .NET 11 | 11.0.100-rc.3.26522.148 |
| PowerShell 7.4 / 7.5 / 7.6 | 7.4.22 / 7.5.13 / 7.6.9 |
| Visual Studio 2017 version 15.9 (15.0 to 15.8: update to 15.9) | 15.9.84 |
| Visual Studio 2019 version 16.11 | 16.11.61 |
| Visual Studio 2022 version 17.14 | 17.14.43 |
| Visual Studio 2026 version 18.11 / 18.12 Insiders | 18.11.2 / 18.12 Insiders 3 |
| Azure Linux 3 brotli / nodejs | 1.2.1-1 / 24.22.1-1 |

MSRC also lists the Azure Linux 3 qemu and p7zip packages as affected, with no fixed version yet. Our reading of the .NET numbers: MSRC gives the SDK builds (8.0.427, 9.0.320, 10.0.403), which carry the runtimes in the table above (8.0.33, 9.0.22, 10.0.14), so check SDKs on build machines and runtimes on hosts. PowerShell 7 runs on .NET, so servers and admin workstations with PowerShell 7 need the PowerShell update even where no other .NET app is installed. Windows PowerShell 5.1 runs on .NET Framework, which is not affected.

## The part that gets missed

Installing the new runtime on a host only fixes framework-dependent apps. Microsoft: "Installing a newer runtime on the host does not update the runtime bundled with your application." Self-contained apps and container images carry their own copy, so each one needs a rebuild and redeploy.

Azure App Service for Windows has finished rolling out the updated built-in runtimes (update of 27 October 2026), but the App Service team says the platform update "does not replace a .NET runtime bundled with your application or inside your custom image".

## How to check (read-only)

On each Windows or Linux host:

```
dotnet --list-runtimes
```

Look for `Microsoft.NETCore.App` and `Microsoft.AspNetCore.App` at 8.0.33, 9.0.22 or 10.0.14 or later for each line you run. Note that `dotnet --version` shows the SDK version, not the runtime your app uses. On build agents, `dotnet --list-sdks` should show 8.0.427, 9.0.320 or 10.0.403 or later.

PowerShell 7, in a `pwsh` session:

```powershell
$PSVersionTable.PSVersion
```

Visual Studio: open Visual Studio Installer and compare the installed version with the table above.

On Windows, a quick inventory across the folders the shared runtime uses:

```powershell
Get-ChildItem "$env:ProgramFiles\dotnet\shared\Microsoft.NETCore.App", "$env:ProgramFiles\dotnet\shared\Microsoft.AspNetCore.App" -Directory -ErrorAction SilentlyContinue |
  Select-Object @{n='Runtime';e={$_.Parent.Name}}, Name
```

For self-contained apps and containers, check the runtime the running process reports, for example by logging `System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription` at start-up, as the App Service team suggests.

## How to verify

After updating, `dotnet --list-runtimes` lists the fixed version, restarted apps report it at start-up, and rebuilt container images are built from the updated .NET base images. Keep older runtimes only where an app still targets them, and plan to move those apps.

## Impact and rollback

This is a servicing update within each release line, so framework-dependent apps roll forward to it after a restart. Test business-critical apps first where you can. If something breaks, Microsoft asks you to report it in the .NET release feedback issues rather than staying on a runtime with known flaws.

Related: the other October 2026 Windows out-of-band update in our [eMudhra CA keys brief](2026-10-31-emudhra-ca-keys-windows-edge-trust.md), the [Exchange OWA and mail flow known issue](2026-10-31-exchange-owa-mail-flow-october-windows-server-updates.md) from the October Windows Server updates, this week's [CISA KEV additions](2026-10-31-cisa-kev-cisco-asa-gitlab-ivanti-php.md), all dated actions on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [Threats & vulnerabilities news](../topic/threats-vulnerabilities/).

## Sources

- [.NET Blog: .NET October 2026 Out-of-Band Security Updates](https://devblogs.microsoft.com/dotnet/dotnet-october-2026-oob-security-updates/) (25 October 2026; read 31 October 2026)
- [Azure App Service: .NET Brotli Security Updates on Azure App Service for Windows](https://azure.github.io/AppService/2026/10/26/dotnet-brotli-security-update-app-service-windows.html) (26 October 2026, updated 27 October 2026; read 31 October 2026)
- [Microsoft Support KB5133966: .NET 10.0 Update, October 25, 2026](https://support.microsoft.com/help/5133966)
- [MSRC Security Update Guide: CVE-2026-111497](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-111497) (latest revision 1 November 2026; read 4 November 2026 through the public Security Update Guide API)
- [CISA Known Exploited Vulnerabilities catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (CVE-2026-111497 added 27 October 2026, due 10 November 2026; catalog version 2026.11.03, read 4 November 2026)

Last reviewed: 4 November 2026. Runbook Lab is not affiliated with Microsoft.
