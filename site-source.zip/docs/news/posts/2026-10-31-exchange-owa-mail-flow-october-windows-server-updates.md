---
date:
  created: 2026-10-31 20:15:00
slug: exchange-owa-mail-flow-october-windows-server-updates
categories:
  - Email & collaboration
description: "October 2026 Windows Server updates can stop Exchange Server OWA sign-in and mail delivery. Check Event ID 1006 and apply the EpmapSavedContextCap registry fix."
rl_type: news
rl_kits: []
rl_controls: []
---

# Exchange OWA and mail flow hit by October Windows updates

Microsoft confirmed on 16 October 2026 that the October 2026 Windows Server security updates can stop Exchange Server 2016, 2019 and Subscription Edition users signing in to Outlook on the web and leave sent mail stuck in the Outbox. Exchange admins who installed the October update should check for Event ID 1006 and apply Microsoft's registry mitigation; the status is "Mitigated" and no fix has been released.

<!-- more -->

!!! note "Runbook card"
    **What changes:** the October 2026 Windows update sets a default limit of 512 simultaneous Endpoint Mapper lookups. Under heavy load Exchange runs out, and OWA, mail delivery and mailbox replication fail.<br>
    **Who:** on-premises and hybrid Exchange Server 2016, 2019 and SE admins whose Exchange servers run Windows Server 2016, 2019, 2022 or 2025 with the October 2026 update.<br>
    **By when:** now, on any affected server. Microsoft hasn't published a date for a fix.<br>
    **Do this:** 1. Keep the October Windows update installed. 2. Set the registry value `EpmapSavedContextCap` to 65536 on each Exchange server. 3. Reboot and watch for the symptoms coming back.<br>
    **Check:** Application log for Event ID 1006 with `MapiExceptionMdbOffline` and `ec=1142`, and growing queues in `Get-Queue`.<br>
    **Source:** [Windows release health: Windows Server 2022 known issues](https://learn.microsoft.com/windows/release-health/status-windows-server-2022) (opened 16 October 2026) and the [Exchange Team blog](https://techcommunity.microsoft.com/blog/exchange/exchange-servers-may-become-unstable-after-installation-of-october-2026-windows-/4565382) (16 October, updated 20 October 2026).

## What Microsoft says

Windows release health lists the issue as "Users might be unable to sign in to OWA or send emails on Exchange Server", status "Mitigated", originating update KB5126655 (OS Build 20348.5761, 13 October 2026) for Windows Server 2022. Affected platforms: "Windows Server 2025; Windows Server 2022; Windows Server 2019; Windows Server 2016". No client versions are affected.

The symptoms, in Microsoft's words: "Users might be unable to sign in to Outlook on the web (OWA), or email messages sent from Outlook might remain in the Outbox and not be delivered. Additionally, Exchange might experience issues accessing mailboxes during mailbox replication." The Exchange Team adds growing mail queues, DAG members that cannot reach quorum, and that a reboot "might resolve the issues temporarily".

The cause: "The October 2026 update introduced a default limit on the amount of memory used by Endpoint Mapper when handling Endpoint Lookup calls. For workloads such as Exchange Server, the default limit of 512 simultaneous Endpoint Lookup calls might not be sufficient under heavy load."

The Exchange Team names the Windows updates involved:

| Windows Server | October 2026 update |
|---|---|
| 2025 | KB5126646 |
| 2022 | KB5126655 |
| 2019 | KB5126651 |
| 2016 | KB5126868 |

Two points that change what you do:

- It is not an Exchange update problem. "Issues reported are not related to installation of October 2026 security updates for Exchange Server." Do not roll back the Exchange security updates.
- Do not uninstall the Windows update either. Microsoft: the October updates "carry a significant security payload and installation of those updates should not be delayed".

Not every server is hit. Severity "varies based on Exchange server load. Some servers might never see a problem." A quiet lab server that looks fine says little about a busy production DAG.

## How to check (read-only)

On each Exchange server:

```powershell
# Is the October 2026 Windows update installed? (pick your version's KB)
Get-HotFix -Id KB5126655, KB5126646, KB5126651, KB5126868 -ErrorAction SilentlyContinue

# Event ID 1006 with MapiExceptionMdbOffline in the last 7 days
Get-WinEvent -FilterHashtable @{LogName='Application'; Id=1006; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue |
  Where-Object { $_.Message -match 'MapiExceptionMdbOffline' } |
  Select-Object TimeCreated, ProviderName -First 20

# Is the mitigation already in place?
Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Rpc' -Name EpmapSavedContextCap -ErrorAction SilentlyContinue
```

In the Exchange Management Shell, look for queues that keep growing:

```powershell
Get-Queue | Where-Object { $_.MessageCount -gt 0 } | Sort-Object MessageCount -Descending |
  Select-Object Identity, Status, MessageCount, NextHopDomain
```

## What to do

The Exchange Team's recommendation, from an elevated Command Prompt on each Exchange server:

```
reg add "HKLM\SOFTWARE\Microsoft\Rpc" /v EpmapSavedContextCap /t REG_DWORD /d 65536 /f
```

Then reboot the server. Do one DAG member at a time and move active databases off it first, as you would for patching.

You can set the value before installing the October update: Microsoft says the key "is read and used only once October 2026 Windows Server updates are installed" and survives the installation. Add it to your Exchange server build so new or rebuilt servers get it too.

Microsoft also says "an additional mitigation is available for affected devices through Microsoft Support" for business customers.

## How to verify

After the reboot, the `Get-ItemProperty` check returns `EpmapSavedContextCap : 65536`. Over the next days there should be no new Event ID 1006 with `MapiExceptionMdbOffline`, OWA sign-in works and queues drain. If the problem returns, the Exchange Team says to raise the limit, though it has "so far not seen any cases where this might be needed".

## Impact and rollback

The change raises how much memory Endpoint Mapper may use. Microsoft calls it a temporary mitigation and lists no side effects. To undo it, delete the `EpmapSavedContextCap` value and reboot. Microsoft says there is "no imminent follow-up release from either Windows or Exchange"; we will update this page when that changes.

Related: our brief on the [eMudhra CA keys out-of-band update](2026-10-31-emudhra-ca-keys-windows-edge-trust.md) (another October Windows Server update to plan around), the dated actions on [Microsoft 365 security deadlines](../../guides/deadlines.md), the [Exchange Online SMTP AUTH checklist](../../guides/exchange-online-smtp-auth-basic-auth-checklist.md) for hybrid estates, and more [Email & collaboration news](../topic/email-collaboration/).

## Sources

- [Windows release health: Windows Server 2022 known issues and notifications](https://learn.microsoft.com/windows/release-health/status-windows-server-2022), entry "Users might be unable to sign in to OWA or send emails on Exchange Server" (opened 16 October 2026, last updated 16 October 2026; read 31 October 2026)
- [Exchange Team blog: Exchange servers may become unstable after installation of October 2026 Windows updates](https://techcommunity.microsoft.com/blog/exchange/exchange-servers-may-become-unstable-after-installation-of-october-2026-windows-/4565382) (16 October 2026, FAQ added 20 October 2026; read 31 October 2026)
- [BleepingComputer: Microsoft October Windows Server updates cause Exchange issues](https://www.bleepingcomputer.com/news/microsoft/microsoft-october-windows-server-updates-cause-exchange-issues/) (19 October 2026)

Last reviewed: 31 October 2026. Runbook Lab is not affiliated with Microsoft.
