---
date:
  created: 2026-11-20 10:25:00
slug: copilot-app-in-app-browsing-default-mc1560922
categories:
  - AI security
description: "MC1560922: the Microsoft Copilot desktop app turns in-app browsing on by default from early January 2027. Decide on the BrowsingEnabled policy by 3 January."
rl_type: news
rl_area: ai
rl_service: [copilot, windows]
rl_kits: [copilot]
rl_controls: []
---

# Copilot app in-app browsing on by default (MC1560922)

Microsoft said on 20 November 2026 (MC1560922) that the Microsoft Copilot desktop app for Windows and Mac will open websites inside the app by default, with rollout beginning in early January 2027. Endpoint and Microsoft 365 admins who do not want a second browser on managed devices should set the BrowsingEnabled policy to Off, or configure the new in-app browsing policies, by Microsoft's Act by date of 3 January 2027.

<!-- more -->

!!! info "Updated 26 November 2026: the in-app browsing policies are available now (MC1568702)"
    Microsoft published [MC1568702](https://mc.merill.net/message/MC1568702) on 25 November 2026: enterprise policies for the Copilot desktop app's built-in browser on Windows and Mac, "across security, privacy, content access, authentication/network behavior, and download/permission management". Status: "General Availability (Worldwide): Available now." Microsoft adds: "These additional policies only apply if the built-in browser is enabled via the 'BrowsingEnabled' policy, which is off by default." Our reading: that is the default today; MC1560922 turns in-app browsing on by default from early January 2027, so the policies will matter on every device where you leave it on. MC1568702 does not list the policy names and links no documentation. MC1560922 is unchanged (re-read 26 November 2026): in-app browsing becomes the default from early January 2027, Act by 3 January 2027. If you plan to keep in-app browsing on, you can set and test these policies on a pilot group now, before the January rollout.

!!! note "Runbook card"
    **What changes:** "We are enabling in-app browsing by default in the Microsoft Copilot desktop app for Windows and Mac." Websites shared in Copilot chat "will open directly within the desktop app by default, side by side with the Copilot conversation". Until now this was opt-in (MC1474455).<br>
    **Who:** endpoint and Microsoft 365 admins of organisations whose users run the Microsoft Copilot desktop app on Windows or Mac.<br>
    **By when:** Act by 3 January 2027. Rollout "will begin in early January 2027 and is expected to complete by the end of January 2027".<br>
    **Do this:** 1. Find the devices that run the Copilot desktop app (check below). 2. Decide: off, or on with your own settings. 3. For off: "Set the BrowsingEnabled policy to Off through your device management system". 4. For on: "Configure the new in-app browsing policies as needed to manage security, privacy, access, authentication and network behavior, downloads, and permissions", to match what you allow in Microsoft Edge. These policies are available now (MC1568702, 25 November 2026) and apply only where BrowsingEnabled is on; test them with a pilot group. 5. Re-read MC1560922 for the documentation link Microsoft says it will add.<br>
    **Check:** `Test-Path "$env:LOCALAPPDATA\Microsoft\Copilot\User Data"` on a Windows device (read-only; `True` means the folder exists, and MC1474455 says in-app browsing data is stored there).<br>
    **Source:** [MC1560922](https://mc.merill.net/message/MC1560922) (Major change, published 20 November 2026); [MC1568702](https://mc.merill.net/message/MC1568702) (policies, published 25 November 2026).

## What Microsoft says

MC1560922 is tagged "Major change", "Feature update", "User impact" and "Admin impact", with "Act by Jan 3, 2027". The service is Microsoft Copilot (Microsoft 365). In Microsoft's words:

- "As we announced in MC1474455, this feature allows users to open websites shared in Copilot chat directly within the desktop app, side by side with their Copilot conversation. Previously optional, this experience will be enabled by default".
- "General Availability (Worldwide): Rollout will begin in early January 2027 and is expected to complete by the end of January 2027."
- "If no changes are made, in-app browsing will remain enabled by default."
- "We will update this message with updated documentation." Microsoft lists "No compliance considerations identified."

The earlier post, [MC1474455](https://mc.merill.net/message/MC1474455) (updated 21 September 2026), says the in-app browser stores data on the device: "Browsing history, cookies, autofill information are stored on the local device", in the user data profile directory "%localappdata%\Microsoft\Copilot\User Data", following "the same storage mechanisms as Microsoft Edge". Users can still open a link in an external browser: the "External browser" option in the three-dot menu on the link, "Copy the URL", or right-clicking a tab in the side pane and selecting "External browser".

## Why it matters for security

The in-app browser is a second place where users open web pages, sign in and download files, with its own set of policies. Microsoft names separate in-app browsing policies for downloads, authentication, network behaviour and permissions, so do not assume the settings you enforce for Edge also apply there until Microsoft's documentation says so. MC1560922 says only: "We will update this message with updated documentation." MC1474455 answered "Yes" to "Does the change store new customer data?" (local browsing history, cookies, autofill), while MC1560922 says "No compliance considerations identified": review the local data question yourself.

## How to check

Read-only. Nothing below changes a device. Run in a normal PowerShell window as the signed-in user.

```powershell
# 1. Is a Copilot app package installed for this user? (package name filter is ours)
Get-AppxPackage -Name "*Copilot*" | Select-Object Name, Version

# 2. Does the folder where MC1474455 says in-app browsing data is stored exist?
Test-Path "$env:LOCALAPPDATA\Microsoft\Copilot\User Data"
```

For a fleet view, Intune admin center > **Apps** > **Monitor** > **Discovered apps** lists installed apps per device (portal path is ours, not from MC1560922). In your MDM, look for an existing **BrowsingEnabled** policy for the Copilot app: if MC1474455's opt-in test turned it on for a pilot group, those devices already browse in the app. Our sources do not give the macOS path of the user data profile.

<!--rl-checknext-->

## How to verify

- After you set BrowsingEnabled to Off, a link shared in Copilot chat on a pilot device opens in the external browser, not in the side pane.
- If you keep it on, test a download and a sign-in in the side pane on a pilot device and compare the result with your Edge policy.
- Re-read MC1560922 before 3 January 2027 for the documentation link and any date change, and MC1568702 for the policy names, which it does not give yet. We will add an "Updated" note here when Microsoft changes the post.

## Impact and rollback

Microsoft: "If no changes are made, in-app browsing will remain enabled by default." Our reading, not from the sources: with BrowsingEnabled set to Off, links open in the user's usual browser as before, and you reverse either choice by changing the same policy in your device management system. Test both on a pilot device.

Related: the [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md), [Claude models on by default in Copilot for EU tenants (MC1546438)](2026-11-10-claude-copilot-default-on-eu-data-boundary-mc1546438.md), [Work IQ agents can read Copilot memory (MC1539004)](2026-11-06-work-iq-agents-read-copilot-memory.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md) and more [AI security news](../topic/ai-security/).

## Sources

- [MC1560922: Microsoft Copilot: In-app browsing will be enabled by default in the desktop app](https://mc.merill.net/message/MC1560922) (Message Center mirror, published 20 November 2026; read 20 November 2026, re-read 26 November 2026)
- [MC1568702: Adding in app browsing control policies](https://mc.merill.net/message/MC1568702) (Message Center mirror, published 25 November 2026; read 26 November 2026)
- [MC1474455: In-app browsing in Copilot app](https://mc.merill.net/message/MC1474455) (Message Center mirror, published 19 September 2026, updated 21 September 2026; read 20 November 2026)

Last reviewed: 26 November 2026. Runbook Lab is not affiliated with Microsoft.
