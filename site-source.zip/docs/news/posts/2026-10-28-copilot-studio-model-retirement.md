---
date:
  created: 2026-10-28 11:00:00
slug: copilot-studio-model-retirement-12-november
categories:
  - AI security
description: "MC1506318: on 12 November 2026 Copilot Studio moves agents on GPT-4.1, GPT-4.1 Mini, GPT-5 and some GitHub Copilot models to new models. Find and test them."
rl_type: news
rl_kits: [agents]
rl_controls: [AG01, AG04]
---

# MC1506318: Copilot Studio GPT-4.1, GPT-5 retire 12 November

On 12 November 2026 Copilot Studio ends support for several AI models and moves the agents that use them to a replacement model automatically. Nobody has to press a button, which is exactly why it needs a test: the agent keeps its instructions and tools, but the model that reads them changes.

<!-- more -->

!!! info "Updated 4 November 2026: correction"
    Microsoft changed two planned replacement models on the GitHub Copilot harness in an update to MC1506318 published by 3 November: GPT-5 Chat now moves to "GPT-6 Luna (previously GPT-5.6 Terra)" and GPT 5.6 Sol to "GPT-6.1 Sol (previously GPT-6 Sol)". Our table named the old models and is now corrected. Microsoft says "All other planned replacement models and migration dates remain unchanged", so the date is still 12 November 2026. If you already tested an agent against GPT-5.6 Terra or GPT-6 Sol, test it again on the new model.

## What changes

| Model today | Harness | Moves to |
|---|---|---|
| GPT-4.1, GPT-4.1 Mini | Standard | GPT Chat Latest |
| GPT-5 Chat, GPT-5 Auto, GPT-5 Reasoning | Standard | GPT Chat Latest |
| GPT-5 Chat | GitHub Copilot | GPT-6 Luna (previously GPT-5.6 Terra) |
| GPT 5.6 Sol | GitHub Copilot | GPT-6.1 Sol (previously GPT-6 Sol) |
| GPT 5.6 Luna | GitHub Copilot | GPT 6 Luna |

"GPT Chat Latest" follows the latest supported GPT chat model. Microsoft says a later move to a new version will be announced separately, with at least 30 days' notice.

One exception: in environments outside the United States where moving data across geographies is restricted, GPT-4.1 and GPT-5 stay supported and are not migrated.

## Who needs to act, and by when

Power Platform admins and the owners of Copilot Studio agents, before 12 November 2026.

## What to do

1. Find the affected agents: Power Platform admin center, Manage, Copilot Studio. Review them by harness and model. The model field is in preview and only shows published configurations.
2. Tell each agent owner which model their agent moves to.
3. Test the planned replacement, or another supported model, now: answer quality, the main conversations, every tool and action the agent calls, and the systems it connects to.
4. Adjust instructions or settings where the test shows a change in behaviour.
5. Check model, region and data-movement requirements if your organisation restricts where data is processed.

## Why it matters for security

A model change is a change to every agent that uses it. Guardrails written as instructions ("never share…", "only answer about…") can behave differently on a new model, and so can the way an agent decides to call a tool. Treat 12 November like a patch day: inventory, owner, test, sign-off.

## Sources

- [MC1506318 on the public message center mirror](https://mc.merill.net/message/MC1506318) (last updated 3 November 2026; read 4 November 2026)

Last reviewed: 4 November 2026. Runbook Lab is not affiliated with Microsoft.
