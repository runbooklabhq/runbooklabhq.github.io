---
date:
  created: 2026-11-14 10:15:00
slug: defender-for-identity-classic-alerts-retirement-mc1552387
categories:
  - Identity & access
description: "MC1552387: Defender for Identity retires its RCE attempt and pass-the-hash alerts in late November 2026. Build the RCE rule and check MDE coverage by 30 Nov."
rl_type: news
rl_area: detection-response
rl_service: [defender]
rl_kits: [mde]
rl_controls: [DE01]
---

# MC1552387: Defender for Identity retires 2 alerts by 30 Nov

MC1552387 (published 13 November 2026) says Microsoft Defender for Identity is "retiring two classic alerts at the end of November 2026": Remote code execution attempt and Suspected identity theft (pass-the-hash). SOC and Defender admins should rebuild RCE detection as an Advanced Hunting custom detection rule and confirm Defender for Endpoint covers pass-the-hash before the "Act by" date of 30 November 2026.

<!-- more -->

!!! note "Runbook card"
    **What changes:** the classic Defender for Identity alerts "Remote code execution attempt" and "Suspected identity theft (pass-the-hash)" "will no longer be available after rollout completes". Microsoft says RCE activity "can continue to be monitored with a custom detection rule in Advanced Hunting" and pass-the-hash monitoring "should continue through Microsoft Defender for Endpoint on onboarded devices".<br>
    **Who:** SOC teams and Defender admins whose alert rules, SIEM or SOAR playbooks, email notifications or tuning rules use these two alerts. All clouds: Worldwide, GCC, GCC High and DoD.<br>
    **By when:** "Act by" 30 November 2026. Rollout begins "in late November 2026" and is expected "to complete by late November 2026".<br>
    **Do this:** 1. Count how often the two alerts fired and list what consumes them (check below). 2. Create an Advanced Hunting custom detection rule from Microsoft's published [RCE custom detection query](https://github.com/microsoft/Microsoft-Defender-for-Identity/blob/main/AdvancedHunting/RemoteCodeExecution.md). 3. Confirm the devices that matter for pass-the-hash are onboarded to Defender for Endpoint. 4. Re-point playbooks, notifications and suppression rules that match the old alert titles.<br>
    **Check:** Defender portal > Investigation & response > Hunting > Advanced hunting, run the read-only `AlertInfo` query below.<br>
    **Source:** [MC1552387](https://mc.merill.net/message/MC1552387) (Microsoft Defender XDR, tag "Retirement").

## What Microsoft says

The message is tagged "Retirement" under Microsoft Defender XDR. Microsoft gives the reason as aligning "detection workflows with current Microsoft Defender XDR and endpoint monitoring capabilities". Who is affected, in Microsoft's words: "Security teams using classic MDI alert workflows for RCE and pass-the-hash scenarios."

The two alerts named in MC1552387 (Microsoft's [classic alerts list](https://learn.microsoft.com/en-us/defender-for-identity/alerts-mdi-classic) describes the classic alerts):

- **Remote code execution attempt** (external ID 2019). Learn describes it as detecting "PSexec, Remote WMI, and PowerShell connections". The similarly named "Remote code execution attempt over DNS" is a different alert and is not named in MC1552387.
- **Suspected identity theft (pass-the-hash)**. Pass-the-hash monitoring moves to Defender for Endpoint.

Microsoft's action list, "Before the end of November 2026": create an Advanced Hunting custom detection rule for RCE "using the published query", and "Confirm pass-the-hash detection coverage through Defender for Endpoint on onboarded devices."

## What is not known

- Microsoft has not given an exact day for the switch-off, only "late November 2026" and the "Act by" date of 30 November.
- The Learn classic alerts page (last updated 16 August 2026) does not yet mark either alert as retiring.
- MC1552387 does not say whether past alerts stay visible in the incident queue after rollout, and does not name a licence change.

## How to check

Read-only. Run in Advanced hunting. `AlertInfo` keeps 30 days of data there.

```kusto
// How often did the two retiring alerts fire in the last 30 days?
AlertInfo
| where Timestamp > ago(30d)
| where Title in~ ("Remote code execution attempt", "Suspected identity theft (pass-the-hash)")
| summarize Alerts = count(), LastSeen = max(Timestamp) by Title, ServiceSource
```

```kusto
// Onboarding state of devices seen by Defender for Endpoint (latest record per device)
DeviceInfo
| where Timestamp > ago(7d)
| summarize arg_max(Timestamp, OnboardingStatus, OSPlatform) by DeviceId, DeviceName
| summarize Devices = count() by OnboardingStatus, OSPlatform
```

Zero results from the first query does not mean nothing depends on the alerts: also search your SIEM rules, SOAR playbooks and email notification rules for the two titles.

In the portal: **Assets > Devices** lists devices and their onboarding status. Devices that show as "Can be onboarded" are not covered by Defender for Endpoint.

## Build the replacement RCE rule

Microsoft's [RCE custom detection query](https://github.com/microsoft/Microsoft-Defender-for-Identity/blob/main/AdvancedHunting/RemoteCodeExecution.md) watches three Defender for Identity activity types in `IdentityDirectoryEvents`: "WMI execution", "Task scheduling" and "Service creation". It reads the last day (`start_time = end_time - 1d`) and suppresses accounts or source devices that did the same thing on 3 or more distinct days in the previous 7, to cut routine admin noise.

1. Open Advanced hunting, paste the query from Microsoft's page and run it first as a plain query, to see what it returns in your tenant.
2. Choose **Create detection rule**, set the frequency and severity, and map the account and device columns as impacted entities.
3. Name the rule so playbooks can match it, and update the playbooks and notifications that matched the old alert.

We have not run this query in a tenant. Read it before you save it as a rule, and expect to tune it: the baseline will hide admin tools that run every day.

## How to verify

- The new rule appears under **Hunting > Custom detection rules** with a recent run and no errors.
- After the rollout completes, the first `AlertInfo` query above stops returning new rows for the two titles, and your custom rule's alerts appear instead.
- The `DeviceInfo` query shows the devices you care about as "Onboarded".

## Impact and rollback

Nothing in the checks changes your tenant. A new custom detection rule adds alerts; if it is too noisy, turn the rule off or narrow it, which does not affect other detections. The retirement itself cannot be rolled back on your side.

Related: the [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md) (control DE01: every device onboarded with a healthy sensor), [Defender RBAC auto-enable from December (MC1537494)](2026-11-05-defender-rbac-auto-enable-review-imported-roles.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md) and more [Identity & access news](../topic/identity-access/).

## Sources

- [MC1552387: Retired: Microsoft Defender for Identity classic alerts (Remote code execution attempt and pass-the-hash)](https://mc.merill.net/message/MC1552387) (Message Center archive, published 13 November 2026; read 14 November 2026)
- [Microsoft Defender for Identity classic security alerts](https://learn.microsoft.com/en-us/defender-for-identity/alerts-mdi-classic) (Microsoft Learn, last updated 16 August 2026; read 14 November 2026)
- [RemoteCodeExecution.md](https://github.com/microsoft/Microsoft-Defender-for-Identity/blob/main/AdvancedHunting/RemoteCodeExecution.md) (Microsoft's Defender for Identity GitHub repository, linked from MC1552387; read 14 November 2026)

Last reviewed: 14 November 2026. Runbook Lab is not affiliated with Microsoft.
