---
date:
  created: 2026-11-06 11:30:00
slug: project-usage-report-retirement-mc1539001
categories:
  - Email & collaboration
description: "MC1539001: the Project usage report in the Microsoft 365 admin center retires on 4 December 2026. Export the data you need before 20 November 2026."
rl_type: news
rl_service: [microsoft-365]
rl_kits: [m365]
rl_controls: []
---

# MC1539001: Export Project usage data by 20 November

MC1539001 (published 5 November 2026) says the Project usage report in the Microsoft 365 admin center "will be retired on December 4, 2026", and asks admins to "Export any Project usage data you want to keep before November 20, 2026". Microsoft 365 admins and MSPs who report on Project activity need to export it now and move to the Planner usage report.

<!-- more -->

!!! note "Runbook card"
    **What changes:** the Project usage report (Project activity) under Reports > Usage in the Microsoft 365 admin center is retired, and "its historical data will no longer be accessible there".<br>
    **Who:** admins who use the Project usage report, and anyone whose dashboards, licence reviews or scripts read it.<br>
    **By when:** export before 20 November 2026. The report is gone from 4 December 2026 ("Act by: Dec 4, 2026").<br>
    **Do this:** 1. Export the Project usage data you want to keep before 20 November. 2. Switch reviews and dashboards to the Planner usage report. 3. Update internal documentation that names the Project usage report.<br>
    **Check:** Microsoft 365 admin center > Reports > Usage > Project activity: note the periods you need and export them.<br>
    **Source:** [MC1539001](https://mc.merill.net/message/MC1539001) (published 5 November 2026).

## What Microsoft says

MC1539001 is titled "Microsoft 365 admin center: Project usage report retirement", tagged "Major change", "Admin impact" and "Retirement", service Project for the web. The facts in the post:

- "Starting December 4, 2026, the Project usage report will no longer be available in the Microsoft 365 admin center, and its historical data will no longer be accessible there."
- The reason: the report shows active users in the Project desktop client, Project Online and Project for the web, and "Because Project Online and Project for the web have been retired, the Project usage report is also being retired."
- The replacement: "Use the Planner usage report in the Microsoft 365 admin center to view Planner and Planner premium activity."
- Scope: "This change applies only to the Project usage report. The Project desktop client remains supported under its published lifecycle."
- Rollout for Worldwide and GCC "will begin in early December 2026 and is expected to complete by early December 2026".

The two dates are different on purpose: 20 November is Microsoft's export deadline, 4 December is when the report goes. Plan for 20 November.

## Why it matters for security and licensing work

The Project usage report is one of the few places that shows how many people still sign in to the Project desktop client. If you use it to justify Project licences, to find unused seats or as evidence in an access review, export that history before 20 November. After 4 December it is not available in the admin center.

## How to check

Read-only, in the portal:

1. Microsoft 365 admin center > Reports > Usage: open Project activity and note which periods you report on.
2. Export the report for each period you need and store it with your other licence and access review evidence.
3. In the same Reports > Usage area, open the Planner usage report and confirm it shows the Planner and Planner premium activity you need.

## How to verify

After the export, open the files and check they hold the user and activity columns your reviews use. Any script or Power BI report that reads Project usage data should be pointed at the Planner usage report before 4 December.

## Impact and rollback

There is no rollback: Microsoft removes the report and its history from the admin center on 4 December 2026. Data you have exported stays yours.

Related: every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md), the [Microsoft 365 hardening checklist](../../guides/microsoft-365-hardening-checklist-jira.md), the [M365 Hardening Kit](../../kits/m365-hardening.md) and more [Email & collaboration news](../topic/email-collaboration/).

## Sources

- [MC1539001: Microsoft 365 admin center: Project usage report retirement](https://mc.merill.net/message/MC1539001) (published 5 November 2026; read 6 November 2026)
- [Microsoft 365 Reports in the admin center: Planner activity](https://learn.microsoft.com/microsoft-365/admin/activity-reports/planner-activity) (linked from the post)

Message center posts are only visible inside a tenant's admin center; the links go to a public mirror (mc.merill.net). Last reviewed: 6 November 2026. Runbook Lab is not affiliated with Microsoft.
