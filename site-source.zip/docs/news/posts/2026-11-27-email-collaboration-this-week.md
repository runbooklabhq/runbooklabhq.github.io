---
date:
  created: 2026-11-27 10:21:00
slug: email-collaboration-this-week-2026-11-27
categories:
  - Email & collaboration
description: "Email & collaboration news to 27 November 2026: Teams mobile minimum versions by 31 March 2027, OneDrive 1 TB quota fix in January, Power Apps thumbnails."
rl_type: news
rl_area: email-collab
rl_service: [teams, sharepoint-onedrive, microsoft-365]
rl_kits: [m365]
rl_controls: []
---

# Email & collaboration this week: 9 changes (27 November 2026)

Nine confirmed Teams, SharePoint, OneDrive and Power Platform items from the week to 27 November 2026. The first check is for Teams and Intune admins: Teams for Android and iOS must be on a minimum version before 1 April 2027, or file access in Teams mobile can fail.

<!-- more -->

This is our weekly Email & collaboration roundup. Items rest on the Message Center text as read on 27 November 2026, except where an item says otherwise. The newest Exchange Team Blog post we found is from 16 November (listing read 26 November).

## New this week

### MC1567258: Teams for Android and iOS need a minimum version before 1 April 2027 (Act by 31 March 2027)

Microsoft: "we are retiring pre-authenticated URLs and transitioning file access to Microsoft Entra ID-based authentication." Users "must run a compatible version of Teams for Android (1416/1.0.0.2026151302 or later) or iOS (8.19.0 or later)". "Users running older, incompatible versions may experience failures in affected file scenarios after enforcement begins on April 1, 2027." Rollout: "General Availability (Worldwide, GCC, GCC High, DoD): Rollout will begin in mid-March 2027 and is expected to complete by early April 2027." Microsoft also warns: "Disabling pre-authenticated URLs (tempauth) through PowerShell before April 1, 2027, may disrupt file scenarios across Teams mobile, regardless of app version."

- **Who acts:** Teams admins and Intune admins, before 31 March 2027.
- **Check:** Intune admin center > Apps > Monitor > Discovered apps, search "Microsoft Teams", and list devices below the versions above.
- **Do this:** set a minimum app version in an Intune app protection policy (Conditional launch > Min app version) for Teams on Android and iOS, with a warning first. Do not turn off tempauth early.
- **Source:** [MC1567258](https://mc.merill.net/message/MC1567258) (read 27 November 2026). Deadline row: [Microsoft 365 security deadlines](../../guides/deadlines.md).

### MC1567261: OneDrive stops giving some users a wrong 1 TB quota in January 2027 (Act by 29 January 2027)

Microsoft: "Today, users assigned certain storage-providing plans in combination with certain non-storage plans can incorrectly receive a 1 TB OneDrive quota. After this change, these combinations will no longer result in a 1 TB quota. OneDrive will instead apply the quota associated with the user's storage plan, which may be lower than 1 TB." Rollout: "Global: We will begin rolling out in early January 2027 and expect to complete by late January 2027." Microsoft says organisations should "prepare for possible read-only states".

- **Who acts:** Microsoft 365 and SharePoint admins with mixed licence combinations, before 29 January 2027.
- **Check:** Microsoft 365 admin center > Reports > Usage > OneDrive: export storage used per user and compare it with the quota that user's licence really gives.
- **Do this:** fix the licences of users who would go over their real quota, or ask them to move files, before January.
- **Source:** [MC1567261](https://mc.merill.net/message/MC1567261) (read 27 November 2026).

### MC1567320: SharePoint thumbnails may not show in Power Apps after the tempauth changes (25 November 2026)

Microsoft (Power Apps, 25 November) says changes made "in relation to the retirement of SharePoint temporary authentication URLs communicated under MC1551122 may prevent thumbnails for SharePoint items from rendering in Power Apps". The fix it names: "republish the affected app" (as read by our Research desk on 25 November). The MC1551122 date is unchanged: "Starting April 1, 2027, SharePoint temporary authentication URLs will no longer be available."

- **Who acts:** Power Platform admins and app makers.
- **Check:** canvas apps that show SharePoint images or thumbnails; open each and look for blank images.
- **Do this:** republish the affected apps. For flows and apps that rely on tempauth URLs, follow MC1551122 before 1 April 2027.
- **Source:** [MC1567320](https://mc.merill.net/message/MC1567320); [MC1551122](https://mc.merill.net/message/MC1551122) (updated 20 November 2026, read 27 November 2026).

## Also logged

- **MC1567221, Power Platform admin center: Inventory data export (preview) stops on 1 December 2026.** Usage and environment exports are not affected and data already exported stays (as read on 25 November). If a report depends on the inventory export, find another source this week. [MC1567221](https://mc.merill.net/message/MC1567221).
- **MC1567253, Viva Engage on iOS and iPadOS: "Beginning in early January 2027, new app releases will require iOS or iPadOS 18 or later."** Older devices keep the current app but get no updates. "No admin action needed." [MC1567253](https://mc.merill.net/message/MC1567253).
- **MC1567262, Microsoft 365 Backup: recovery windows from 3 months up to 10 years for SharePoint and OneDrive** (previously 2 years, as read on 25 November). Review your backup policy's retention if you need longer recovery points. [MC1567262](https://mc.merill.net/message/MC1567262).
- **MC1562278, Teams Markdown in the compose box: "Beginning in mid-January 2027 (previously early December 2026) and expected to complete by late February 2027 (previously mid-December 2026)"** (updated 25 November). No admin action. [MC1562278](https://mc.merill.net/message/MC1562278).
- **MC1568699, Campaigns in SharePoint: "We will begin rolling out on mid August 2026 and expect to complete by end of November 2026"**, as Microsoft published it on 25 November. [MC1568699](https://mc.merill.net/message/MC1568699).
- **MC1566260, Clipchamp video from a prompt now sits in Video Hub, "with an upgraded experience coming"** (updated 25 November; upgrade by end of February 2027 per our 26 November read). No admin action. [MC1566260](https://mc.merill.net/message/MC1566260).

Related: [Microsoft 365 Hardening Kit](../../kits/m365-hardening.md) · [Exchange Online Protection Kit](../../kits/exchange-online-protection.md).

More: [all Email & collaboration news](../topic/email-collaboration/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 27 November 2026. Runbook Lab is not affiliated with Microsoft.
