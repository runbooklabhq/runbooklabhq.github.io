---
date:
  created: 2026-10-29 20:00:00
slug: entra-sspr-registered-methods-only
categories:
  - Identity & access
description: "Entra SSPR will only accept registered methods: Learn now says February 2027, MC1325414 still says 7 November 2026. List users without a registered method now."
rl_type: news
rl_area: identity
rl_service: [entra]
rl_kits: [sms, m365]
rl_controls: []
---

# SSPR stops using the phone number in the directory

Microsoft Entra self-service password reset (SSPR) will only accept methods a user registered; the mobile number, office phone and alternate email that sit in the directory stop counting. Microsoft Learn now says this starts in February 2027, while Message Center post MC1325414 still says 7 November 2026, so identity admins should finish the check below now.

<!-- more -->

!!! info "Updated 13 November 2026: correction"
    Microsoft Learn ([Prepopulate user authentication contact information for SSPR](https://learn.microsoft.com/en-us/entra/identity/authentication/howto-sspr-authenticationdata), last updated 5 November 2026) now says: "Starting February 2027, SSPR will only accept explicitly registered authentication methods." MC1325414 (last updated 4 August 2026) still says "November 7, 2026: Enforcement begins" and "Action is required before November 9, 2026". This page said enforcement starts on 7 November 2026 until today. The two Microsoft sources disagree; we show both, and we will update this page when Microsoft updates MC1325414. The action is unchanged: make sure every SSPR user has a registered method. Listed on our [corrections page](../../about/corrections.md).

## What changes

- SSPR verification uses only registered authentication methods. The directory attributes `mobilePhone`, `businessPhones` and `otherMails` "will no longer be valid unless registered" (MC1325414).
- It applies to all users in tenants with SSPR enabled, administrators included, in the public cloud and the US Government clouds.
- Users with no registered method can't finish a reset. They are prompted to register or to contact an administrator.
- Dates: MC1325414 says registration campaign from 5 October 2026, "November 7, 2026: Enforcement begins", "Act by: Nov 6, 2026", and in its summary "Starting November 9, 2026". Microsoft Learn (updated 5 November 2026) says "Starting February 2027". Until Microsoft aligns the two, treat enforcement as possible at any time and finish the check now.

Pre-filling those attributes, by Entra Connect sync from on-premises AD or with `Update-MgUser`, was the documented way to prepare SSPR for years. Tenants that did it have users who never registered anything themselves.

## Who needs to act, and by when

Identity admins and the helpdesk, now. The latest date Microsoft states is February 2027 (Learn); the Message Center dates (6 to 9 November 2026) have passed.

## What to do

1. List users who are allowed to use SSPR but aren't registered for it. This only reads (role such as Reports Reader or Global Reader; the report needs Entra ID P1 or P2):

    ```powershell
    Connect-MgGraph -Scopes AuditLog.Read.All
    $r = @(Get-MgReportAuthenticationMethodUserRegistrationDetail -All)
    $gap = @($r | Where-Object { $_.IsSsprEnabled -and -not $_.IsSsprRegistered })
    "Enabled but not registered: $($gap.Count) (admins: $(@($gap | Where-Object { $_.IsAdmin }).Count))"
    ```

2. Make sure those users are prompted to register: check "Require users to register when signing in" in the password reset settings, and plan helpdesk-assisted registration as the fallback.
3. Tell the helpdesk and users before enforcement: what changes, where to register (My Security Info), who to call.

## Check

Re-run step 1 every few days until the count is zero. The "Enabled but not registered" count should go down. If it doesn't, the campaign isn't reaching those users. Write today's number down: once enforcement reaches your tenant, it tells you whether a reset ticket was expected.

## Why it matters for security

A reset method nobody registered is a reset method nobody checks. Registered methods are the ones users can see and remove in My Security Info, and the ones your authentication methods policy controls. The same users often lean on SMS, which Microsoft retires as an MFA method on 1 February 2027.

The longer walk-through, with the join that shows who was relying on directory data, is on [dev.to](https://dev.to/runbooklab/sspr-stops-using-the-phone-number-in-the-directory-in-november-find-who-loses-self-service-reset-55m5). All the dates we track are on [Microsoft 365 security deadlines](../../guides/deadlines.md).

## Sources

- [MC1325414 on the public message center mirror](https://mc.merill.net/message/MC1325414) (version 6, last updated 4 August 2026; re-read 13 November 2026)
- [Microsoft Learn: Prepopulate user authentication contact information for SSPR](https://learn.microsoft.com/en-us/entra/identity/authentication/howto-sspr-authenticationdata) (last updated 5 November 2026; re-read 13 November 2026)
- [Microsoft Graph: List userRegistrationDetails](https://learn.microsoft.com/en-us/graph/api/authenticationmethodsroot-list-userregistrationdetails)

Last reviewed: 13 November 2026. Runbook Lab is not affiliated with Microsoft.
