---
date:
  created: 2026-11-20 09:50:00
slug: fastunlock-windows-lock-screen-bypass-narrator
categories:
  - Endpoint & devices
description: "FastUnlock: public proof of concept for an unpatched Windows 11 lock-screen bypass via Narrator. No fix yet. Check TPM-only BitLocker and Microsoft accounts."
rl_type: news
rl_area: endpoint
rl_service: [windows, intune]
rl_kits: []
rl_controls: []
---

# FastUnlock: Windows lock-screen bypass via Narrator, no fix

On 19 November 2026 a researcher published "FastUnlock", a proof of concept that uses Windows Narrator to get past the Windows 11 lock screen and run programs on a device someone has in their hands. There is no Microsoft fix or CVE yet, so Windows and Intune admins should find laptops that rely on TPM-only BitLocker and have a Microsoft account linked, and plan a pre-boot PIN for the devices that leave the office.

<!-- more -->

!!! note "Runbook card"
    **What changes:** public exploit code now exists for an unpatched lock-screen bypass. According to the researcher, "succesful exploitation results in bypassing bitlocker and executing code in the context of the lockscreen account "WsiAccount"". ThreatLocker reproduced it and says the bypass gives access to the "WSIAccount" user, "which is not an administrator account".<br>
    **Who:** Windows endpoint and Intune admins, especially for laptops that travel. The researcher tested on "Windows 11 26H2 November Patch installed"; other versions were not tested.<br>
    **By when:** now, to size exposure; the fix arrives when Microsoft ships one (no date, no CVE).<br>
    **Do this:** 1. Count devices whose OS drive is protected by TPM-only BitLocker (read-only check below). 2. Count devices with a local profile linked to a Microsoft account. 3. For laptops that leave the office, plan BitLocker with a startup PIN (TPM+PIN) in a pilot group first. 4. Once the PIN is in place, tell travelling users to shut down or hibernate rather than sleep. 5. Watch the MSRC Security Update Guide for a CVE or advisory and patch when it lands.<br>
    **Check:** `Get-BitLockerVolume -MountPoint $env:SystemDrive | Select-Object -ExpandProperty KeyProtector` (read-only; elevated prompt).<br>
    **Source:** [MSNightmare/FastUnlock on GitHub](https://github.com/MSNightmare/FastUnlock) (researcher's disclosure) and [ThreatLocker's test](https://www.threatlocker.com/blog/proof-of-concept-for-fastunlock-windows-lock-screen-bypass-from-nightmare-eclipse) (19 November 2026).

## What the sources say

The researcher calls it "FastUnlock : Windows Narrator LockScreen Bypass 0day Vulnerability". The stated conditions: "this needs physical access and at least one account in the machine to be linked to an online account".

ThreatLocker tested the proof of concept and lists the requirements as:

- "Physical access to the machine."
- "A Microsoft account available through the account recovery flow."
- "Narrator navigation using Caps Lock and the arrow keys."

On BitLocker, ThreatLocker says: "BitLocker preboot pin will help mitigate this if the device was just turned on." In other words, FastUnlock does not break BitLocker's keys. It works on a device whose drive BitLocker has already opened, which with TPM-only BitLocker happens at every start without any user input.

The Hacker News (20 November 2026): "There is no fix from Microsoft yet, and nothing shows the method has been used in a real attack." Cyber Kendra adds that "Microsoft has not listed a workaround".

## What is not known

- Microsoft has not confirmed the flaw, and there is no CVE or advisory as of 20 November 2026.
- It is not reported as exploited, and it is not in CISA's Known Exploited Vulnerabilities catalog.
- Whether a work (Entra ID) account counts as an "online account" for this bypass is not stated by the researcher or by ThreatLocker. Devices with only Entra ID or domain accounts may be out of scope, but nobody has said so; treat them as REVIEW, not as safe.
- Windows 10 and other Windows 11 versions were not tested. The researcher: "I have not checked other windows versions so I am not really sure if this might work on windows 10" (as quoted by Security Affairs).
- Cyber Kendra reports that the researcher suggested blocking Narrator with AppLocker or a custom access control list as a stopgap. Nobody we can cite has tested that, and it removes a screen reader that some of your users may depend on.

## How to check

Read-only. Run on a device in an elevated PowerShell prompt, or through your management tool as a script that only reads:

```powershell
# OS drive protectors: 'Tpm' without 'TpmPin' or 'TpmPinStartupKey' = TPM-only
Get-BitLockerVolume -MountPoint $env:SystemDrive |
  Select-Object MountPoint, ProtectionStatus,
    @{n='Protectors';e={($_.KeyProtector.KeyProtectorType) -join ','}}

# Local profiles linked to a Microsoft account (PrincipalSource = MicrosoftAccount)
Get-LocalUser | Where-Object Enabled |
  Select-Object Name, PrincipalSource
```

A device with `Tpm` in its OS-drive protector list (and no `TpmPin` or `TpmPinStartupKey`) plus at least one `MicrosoftAccount` user matches both conditions the sources name. A device with no BitLocker at all (ProtectionStatus `Off`) is exposed to anyone with the device in hand anyway; count it too. If you run the check as an Intune script, set "Run script in 64-bit PowerShell host" to Yes: `Get-LocalUser` is not available in 32-bit PowerShell. Do not run the public proof of concept on production devices.

<!--rl-checknext-->

## What you can do before a fix

These steps and portal paths are ours, not from the sources. Test them in a pilot group first.

1. **Startup PIN for travelling laptops.** Intune admin center > **Endpoint security** > **Disk encryption** > BitLocker policy: "Require additional authentication at startup" = Enabled, with "Configure TPM startup PIN" = "Require startup PIN with TPM". This is the TPM+PIN countermeasure that Microsoft describes on its [BitLocker countermeasures](https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/countermeasures) page. Intune cannot add a PIN silently: on a drive already encrypted TPM-only, the user or an admin adds the PIN (for example `manage-bde -protectors -add C: -TPMAndPIN` in an elevated prompt), and the policy reports an error on that device until then. Set "Configure TPM startup" so it does not conflict with the required PIN.
2. **Fewer Microsoft accounts on work devices.** Review the Settings catalog policies in the Accounts category that limit consumer Microsoft account sign-in on corporate devices. Check the exact setting name and its effect in Microsoft Learn before you assign it.
3. **Shut down or hibernate for travel, once the PIN is in place.** ThreatLocker's note is that the PIN helps "if the device was just turned on"; a sleeping laptop keeps its drive open and is not asked for the PIN again. Hibernation may be turned off on some models; check before you rely on it. Without a PIN, a shut-down laptop with TPM-only BitLocker opens its drive by itself at the next start.

## How to verify

- Re-run the check: the OS drive shows `TpmPin` on the devices in scope.
- When Microsoft publishes a CVE or advisory, we will add it here with an "Updated" note. After you install that update, the check is Microsoft's own: the KB or Security Update Guide entry and your update compliance report.

## Impact and rollback

The checks change nothing. A startup PIN changes the start-up experience: users type a PIN before Windows loads, remote restarts wait at the PIN prompt, and the helpdesk needs a process for forgotten PINs (BitLocker recovery). Roll out to a pilot group, then widen. To roll back, set "Configure TPM startup PIN" back to "Allow startup PIN with TPM" in the same policy; devices that already have a PIN keep it until an admin replaces the TpmPin protector with a Tpm protector.

Related: [SignDrop, an earlier Windows zero-day from the same GitHub account](2026-11-12-signdrop-windows-clfs-zero-day-poc.md), the [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md) for device health controls, every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md) and more [Endpoint & devices news](../topic/endpoint-devices/).

## Sources

- [MSNightmare/FastUnlock](https://github.com/MSNightmare/FastUnlock) (researcher's disclosure, 19 November 2026; quotes as read by our Research desk on 20 November 2026)
- [Proof of concept for FastUnlock: Windows lock-screen bypass](https://www.threatlocker.com/blog/proof-of-concept-for-fastunlock-windows-lock-screen-bypass-from-nightmare-eclipse) (ThreatLocker, 19 November 2026; quotes as read by our Research desk on 20 November 2026)
- [New unpatched Windows 0-day FastUnlock](https://thehackernews.com/2026/11/new-unpatched-windows-0-day-fastunlock.html) (The Hacker News, 20 November 2026)
- [Chaotic Eclipse releases FastUnlock](https://securityaffairs.com/203537/hacking/chaotic-eclipse-releases-fastunlock-a-new-windows-zero-day-vulnerability.html) (Security Affairs, 19 November 2026; read 20 November 2026)
- [FastUnlock uses Windows Narrator to bypass the lock screen](https://www.cyberkendra.com/2026/11/fastunlock-windows-narrator-lock-screen-bypass.html) (Cyber Kendra, 20 November 2026; read 20 November 2026)

Last reviewed: 20 November 2026. Runbook Lab is not affiliated with Microsoft.
