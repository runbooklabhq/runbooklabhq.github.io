---
date:
  created: 2026-11-03 11:00:00
slug: exchange-server-2016-2019-esu-end-no-more-updates
categories:
  - Email & collaboration
description: "Exchange 2016 and 2019 get no more security updates: the Period 2 ESU ended with October 2026. Confirm the October SU on every server and plan Exchange SE."
rl_type: news
rl_service: [exchange-online]
rl_kits: []
rl_controls: []
---

# Exchange 2016 and 2019 ESU ended: no more updates

Microsoft's Extended Security Update (ESU) programme for Exchange Server 2016 and 2019 ended with October 2026, and Microsoft says there will be "no further updates for Exchange 2016/2019, even if you currently have a Period 2 ESU". Admins who still run either version should confirm the October 2026 security update is installed and plan the move to Exchange Server Subscription Edition (SE).

<!-- more -->

!!! note "Runbook card"
    **What changes:** Microsoft: "Once October 2026 ends, there will be no further updates for Exchange 2016/2019". The latest release in our sources is the 13 October 2026 security update.<br>
    **Who:** anyone with an Exchange Server 2016 or 2019 server in production, with or without the Period 2 ESU. Our note: that includes servers kept only for hybrid management; Exchange Online itself is not on this timeline.<br>
    **By when:** now. Microsoft's ESU eligibility ran "until the end of October 2026".<br>
    **Do this:** 1. Find every Exchange 2016 and 2019 server. 2. Confirm each one has the October 2026 security update (for Exchange 2019 CU15 that is KB5128896; for other versions and CUs, use the matching 13 October 2026 SU from Microsoft's update list). 3. Plan the move to Exchange SE: Microsoft describes an in-place upgrade from Exchange 2019 CU14 or CU15 to Exchange SE RTM as "low risk".<br>
    **Check:** Exchange Server Health Checker on each server, or the ExSetup.exe file version on each server, which shows the installed SU build (read-only commands below).<br>
    **Source:** [Exchange Team blog, 20 July 2026](https://techcommunity.microsoft.com/blog/exchange/reminder-exchange-2016-and-2019-esu-program-ends-in-october-2026/4539033) (updated 14 August 2026) and [KB5128896](https://support.microsoft.com/en-gb/servicing/exchange/server/update/2026/5128896) (13 October 2026).

## What Microsoft says

The Exchange Team wrote on 20 July 2026: "There will be no further extension of Exchange 2016/2019 ESU program timeline. Once October 2026 ends, there will be no further updates for Exchange 2016/2019, even if you currently have a Period 2 ESU."

The October 2026 security update for Exchange 2019 CU15 ([KB5128896](https://support.microsoft.com/en-gb/servicing/exchange/server/update/2026/5128896), 13 October 2026) repeats it: "Microsoft Exchange Server 2016 and 2019 have reached end of support." and "Organizations that are enrolled in the Period 2 Extended Security Update (ESU) program are eligible to receive released security updates until the end of October 2026." Organisations not in the ESU programme "should migrate to Exchange Server Subscription Edition (SE)".

The October update for Exchange 2019 CU15 fixes six CVEs, so it matters that it is installed everywhere:

| CVE | Type (Microsoft's title) |
|---|---|
| CVE-2026-70571 | Remote Code Execution |
| CVE-2026-77910, CVE-2026-87692, CVE-2026-87695, CVE-2026-87696 | Elevation of Privilege |
| CVE-2026-70279 | Spoofing |

The KB also lists one resolved issue: published calendars (.ics) returning HTTP 500 to calendar apps.

## What this means in practice

Tuesday 10 November 2026 is the first Patch Tuesday after the ESU ended. If it, or any later release, fixes an Exchange flaw, Microsoft has said Exchange 2016 and 2019 will not get the fix, ESU or not.

Microsoft's links, from the same blog post, if you plan to keep Exchange on-premises:

- **Exchange 2019 CU14 or CU15:** an in-place upgrade to Exchange SE RTM, which Microsoft calls "not a significant technological change and is low risk" ([why, in Microsoft's words](https://techcommunity.microsoft.com/blog/exchange/why-%E2%80%9Cin-place-upgrade%E2%80%9D-from-exchange-2019-to-exchange-se-is-low-risk/4410173)).
- **Upgrade guide (all versions):** [Upgrading your organization from current versions to Exchange Server SE](https://techcommunity.microsoft.com/blog/exchange/upgrading-your-organization-from-current-versions-to-exchange-server-se/4241305), which "lays out the path for how to migrate to Exchange SE".
- **Licensing:** Microsoft says "Exchange 2019 and Exchange SE licensing requirements are the same"; check the [licensing FAQ](https://www.microsoft.com/en-us/microsoft-365/exchange/microsoft-exchange-licensing-faq-email-for-business) it links.

Our advice, not Microsoft's: until a server is upgraded or removed, do not publish it to the internet beyond what mail flow and hybrid need, and treat it as a priority for monitoring.

## How to check (read-only)

From an Exchange Management Shell run as administrator:

```powershell
# Which servers run which version (CU level only: AdminDisplayVersion does not show installed SUs)
Get-ExchangeServer | Select-Object Name, Edition, AdminDisplayVersion, ServerRole

# Installed build including the SU (run on each server)
Get-Command ExSetup.exe | ForEach-Object { $_.FileVersionInfo.ProductVersion }

# Full report per server, including missing security updates
Get-ExchangeServer | ?{$_.AdminDisplayVersion -Match "^Version 15"} | %{.\HealthChecker.ps1 -Server $_.Name}
.\HealthChecker.ps1 -BuildHtmlServersReport
```

The [Exchange Server Health Checker](https://microsoft.github.io/CSS-Exchange/Diagnostics/HealthChecker/) reads configuration and writes a report; it changes nothing. It compares each server's build with Microsoft's build list and flags a missing SU.

## How to verify

After the October SU, Health Checker no longer reports the server as missing a security update. After an upgrade to Exchange SE, the ExSetup.exe version shows the SE build.

## Impact

Our reading: the servers keep running; what stops is the fixes. A flaw found from now on stays open on these versions; for an example of what one Exchange flaw can expose, see the [September V2 update for CVE-2026-96940](2026-11-02-exchange-server-september-v2-security-update.md), which let a signed-in user read other people's mailboxes.

Related: the October Windows Server update issue that breaks [Exchange OWA and mail flow](2026-10-31-exchange-owa-mail-flow-october-windows-server-updates.md), dated actions on [Microsoft 365 security deadlines](../../guides/deadlines.md), the [Exchange Online SMTP AUTH checklist](../../guides/exchange-online-smtp-auth-basic-auth-checklist.md) for hybrid estates, and more [Email & collaboration news](../topic/email-collaboration/).

## Sources

- [Exchange Team blog: Reminder: Exchange 2016 and 2019 ESU Program Ends in October 2026](https://techcommunity.microsoft.com/blog/exchange/reminder-exchange-2016-and-2019-esu-program-ends-in-october-2026/4539033) (20 July 2026, updated 14 August 2026, version 3.0; read 3 November 2026)
- [KB5128896: Security update for Exchange Server 2019 CU15, 13 October 2026](https://support.microsoft.com/en-gb/servicing/exchange/server/update/2026/5128896) (read 3 November 2026)
- [Exchange Server Health Checker](https://microsoft.github.io/CSS-Exchange/Diagnostics/HealthChecker/) (Microsoft CSS-Exchange, read 3 November 2026)

Last reviewed: 3 November 2026. Runbook Lab is not affiliated with Microsoft.
