---
date:
  created: 2026-10-31 13:00:00
slug: identity-access-this-week-2026-10-31
categories:
  - Identity & access
description: "Entra changes to 31 October 2026: MemberOf rules freeze on 3 November, SMS sign-in auto-disable, WHfB and Platform SSO as MFA, a CAPTCHA before SMS codes."
rl_type: news
rl_service: [entra]
rl_kits: [sms, ca]
rl_controls: [S01, S02]
---

# Identity & access this week: 6 changes (31 October 2026)

Six confirmed Microsoft Entra changes from the week to 31 October 2026, each with who acts, the check and the source. Two have their own briefs; the nearest date is the MemberOf retirement on 3 November.

<!-- more -->

This is our weekly Identity & access roundup. It was due on Friday 30 October and is published a day late. Every item was re-read on its primary source on 31 October 2026.

## Already briefed

1. **MemberOf dynamic rules stop updating on 3 November 2026.** Identity admins. Check: list dynamic groups and administrative units whose rule contains `memberOf`. Brief: [Entra MemberOf dynamic rules stop updating on 3 November](2026-10-31-entra-memberof-dynamic-rule-retirement.md). Source: [MC1529463](https://mc.merill.net/message/MC1529463).
2. **SSPR only accepts registered methods from 7 November 2026; Microsoft says act by 6 November.** Identity admins and the helpdesk. Check: users with SSPR enabled but not registered. Brief: [SSPR stops using the phone number in the directory](2026-10-29-entra-sspr-registered-methods-only.md). Source: [MC1325414](https://mc.merill.net/message/MC1325414).
3. **Passkey as the first MFA method: phase 1 now early November 2026 to early January 2027.** Identity admins: review the Conditional Access policy that protects security info registration. Brief: [Entra passkey-first MFA registration](2026-10-28-entra-passkey-first-mfa.md). Source: [MC1450133](https://mc.merill.net/message/MC1450133).

## New this week

### Unused SMS sign-in gets switched off, now by end of November 2026

Microsoft disables SMS as a first-factor sign-in method in tenants where no SMS sign-in succeeded in the previous 30 days, or where every attempt failed. The rollout is "expected to complete by end of November 2026" (updated 28 October; previously late September). "SMS for MFA and self-service password reset are not affected."

- **Who acts:** identity admins in tenants with SMS sign-in on (shared devices, frontline staff).
- **Check:** Entra admin center > Authentication methods > Policies > SMS. If "Use for sign-in" is on and nobody needs it, clear it yourself. If people depend on it, plan their move to passkeys.
- **Source:** [MC1465763](https://mc.merill.net/message/MC1465763). Related: [Entra SMS MFA Exit Kit](../../kits/sms-mfa-exit.md).

### Windows Hello for Business and macOS Platform SSO count as standalone MFA, early November to late December 2026

The rollout now runs "Beginning in early November 2026 (previously early October) and expected to complete in late December 2026 (previously mid-December)". "No configuration changes are required." Microsoft recommends users also register a portable method, such as a synced passkey or a Microsoft Authenticator passkey.

- **Who acts:** identity admins.
- **Check:** custom Authentication Strength policies that list Windows Hello for Business, and users whose only strong method is device-bound. They lose MFA when they lose the device.
- **Source:** [MC1450134](https://mc.merill.net/message/MC1450134) (updated 27 October 2026).

### Risk-based verification before SMS and voice codes, rolling out now

Entra may show an anti-bot verification step before it sends an SMS or voice code. "Rollout began in mid-October 2026 and is ongoing", "not every user or sign-in attempt will be affected", and "SMS and voice authentication options are not being removed".

- **Who acts:** helpdesk and identity admins.
- **Check:** tell the helpdesk users may see a verification step before the code arrives, so the tickets are expected. It is one more reason to move SMS users to passkeys before 1 February 2027.
- **Source:** [MC1518029](https://mc.merill.net/message/MC1518029) (updated 29 October 2026). Guide: [SMS and voice MFA retirement](../../guides/entra-sms-voice-mfa-retirement-passkeys.md).

More: [all Identity & access news](../topic/identity-access/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 31 October 2026. Runbook Lab is not affiliated with Microsoft.
