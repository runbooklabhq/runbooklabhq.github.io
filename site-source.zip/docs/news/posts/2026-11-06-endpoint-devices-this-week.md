---
date:
  created: 2026-11-06 12:40:00
slug: endpoint-devices-this-week-2026-11-06
categories:
  - Endpoint & devices
description: "Endpoint changes to 6 November 2026: .NET 8 and 9 end support on 10 November, Windows blocks NTLMv1 SSO, Apple KEV due 18 November, set Intune minimum OS."
rl_type: news
rl_service: [windows, dev-tools, defender, other]
rl_kits: [asr, m365]
rl_controls: []
---

# Endpoint & devices this week: 10 changes (6 November 2026)

Ten confirmed Endpoint & devices items logged in the week to 6 November 2026, each with who acts, the check and the source. The nearest date is Tuesday 10 November, when .NET 8 and .NET 9 reach end of support and Windows 11 23H2 Enterprise and Education get their last update.

<!-- more -->

This is our weekly Endpoint & devices roundup. Most items were re-read on their primary source on 6 November 2026. The CISA KEV entry for the Apple item, Sekoia's own research post and Microsoft's KB5127936 page were not re-read today; for those we use the facts Research read between 3 and 6 November, and we say where a claim comes from a news outlet.

## Already briefed

1. **Defender tenants are auto-enabled for the new Defender RBAC model; Microsoft says act by 2 December 2026.** Security admins: review the imported roles in Defender portal > Permissions > Roles before activation. Brief: [Defender RBAC auto-enable: review imported roles](2026-11-05-defender-rbac-auto-enable-review-imported-roles.md). Source: [MC1537494](https://mc.merill.net/message/MC1537494).
2. **Windows Shell CVE-2026-96951, exploited, fixed in the October 2026 updates.** The KEV due date (16 October) has passed, so any device still without the October cumulative update is overdue. Brief: [Windows Shell CVE-2026-96951 October zero-day](2026-11-04-windows-shell-cve-2026-96951-october-zero-day.md).
3. **Date reminder: Windows 11, version 23H2 Enterprise and Education "reach end of updates on November 10, 2026".** Endpoint admins: find devices still on build 10.0.22631 in Intune admin center > Devices > Windows, and move them to a 24H2 or later ring. Earlier context: [last Endpoint & devices roundup](2026-10-31-endpoint-devices-this-week.md). Source: [Windows message center](https://learn.microsoft.com/en-us/windows/release-health/windows-message-center).

## New this week

### .NET 8 and .NET 9 reach end of support on 10 November 2026

Microsoft's .NET Blog (29 June 2026): .NET 8 and .NET 9 "will reach end of support on November 10, 2026". After that Microsoft will "no longer provide servicing updates, security fixes, or technical support", and "No new security updates will be issued for either version." The upgrade target is ".NET 10, which is an LTS release supported through November 2028." The October out-of-band Brotli fix is among the last security updates either version will get.

- **Who acts:** developers and app owners, plus endpoint and server admins who own the runtime on line-of-business machines.
- **Check:** `dotnet --list-runtimes` on servers, build agents and workstations. Any `Microsoft.NETCore.App 8.*` or `9.*` line is a runtime that stops getting fixes on Tuesday. Retarget projects to `net10.0`.
- **Source:** [.NET Blog: .NET 8 and .NET 9 end of support](https://devblogs.microsoft.com/dotnet/dotnet-8-9-end-of-support/). Related: [.NET October out-of-band Brotli update](2026-10-31-dotnet-october-oob-brotli-security-update.md).

### Windows blocks NTLMv1-derived SSO credentials by default since the October 2026 update

From the October 2026 update, Windows 11 26H2, 25H2 and 24H2 and Windows Server 2025 restrict "generating NTLMv1-derived credentials for Single Sign-On by default" on devices without Credential Guard. If the `BlockNtlmv1SSO` value is not set, "Windows uses Enforce mode as the internal default behavior instead of Audit mode." Wi-Fi, Ethernet or VPN connections that use MS-CHAPv2 may no longer connect automatically. Typing the credentials still works, but they can't be saved. The Windows IT Pro Blog (3 November) says organisations using MS-CHAPv2 should "move to certificate-based authentication". Before you blame November's updates for Wi-Fi tickets, check this first.

- **Who acts:** endpoint and network admins running PEAP-MSCHAPv2 or other MS-CHAPv2 Wi-Fi, 802.1X wired or VPN.
- **Check:** blocked requests log Event ID 4025 (Audit mode logs 4024) in Microsoft-Windows-NTLM/Operational: `Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-NTLM/Operational'; Id=4024,4025} -MaxEvents 50`. Read the current setting with `Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' -Name BlockNtlmv1SSO -ErrorAction SilentlyContinue` (no value means Enforce). Setting it to 0 (Audit) is a temporary compatibility option, not a fix; plan the move to EAP-TLS.
- **Source:** [MC1508562](https://mc.merill.net/message/MC1508562) (15 October 2026) · [Windows news you can use: October 2026](https://techcommunity.microsoft.com/blog/windows-itpro-blog/windows-news-you-can-use-october-2026/4552396) · [KB5066470](https://support.microsoft.com/help/5066470).

### Apple CVE-2024-27834 added to CISA KEV on 4 November, due 18 November 2026

CISA added "Apple Multiple Products Improper Authentication Vulnerability" to the KEV catalogue on 4 November with a due date of 18 November 2026. The WebKit flaw lets "an attacker with arbitrary read and write capability" bypass pointer authentication. Apple fixed it in May 2024: iOS and iPadOS 17.5 and 16.7.8, macOS Sonoma 14.5 and Safari 17.5.

Update, 6 November: Sekoia, as reported by SecurityWeek, links the exploitation to watering-hole sites in research it calls "Poisoned Source". Sekoia attributes the activity to APT29 at "moderate to high confidence", as reported; the attribution is Sekoia's. The chains pair CVE-2024-27834 with two other already-patched bugs, CVE-2026-3910 in Chrome (patched March 2026) and CVE-2025-27038 in Qualcomm components (August 2025 Android bulletin), and the payload steals browser cookies. We could not read Sekoia's own post today.

- **Who acts:** endpoint admins for iPhone, iPad and Mac fleets, plus the identity team.
- **Check:** Intune admin center > Devices > All devices, filter by platform and sort by OS version to list iOS and iPadOS below 17.5 (16.7.8 on devices that can't run 17) and macOS below 14.5. Then Devices > Compliance > Policies > your iOS/iPadOS and macOS policies > Device Properties > Minimum OS version, and confirm it is at least those versions; current releases are the better floor.
- **Do this:** set the Intune minimum OS version and a short grace period. Because the payload steals cookies, revoke Entra sessions for users whose devices were on vulnerable builds: `Revoke-MgUserSignInSession -UserId <user>` (this is a change, so run it deliberately, not as a check).
- **Source:** [NVD: CVE-2024-27834](https://nvd.nist.gov/vuln/detail/CVE-2024-27834) (KEV listing) · [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog). Coverage: [The Hacker News](https://thehackernews.com/2026/11/hackers-exploit-patched-apple-flaw-to.html). Related: [Microsoft 365 Hardening Kit](../../kits/m365-hardening.md).

## Also logged

- **Always On VPN failures after the September 2026 Windows 11 updates are fixed in the October preview KB5127936 (28 October; 25H2 and 26H2).** Microsoft: "This update fixes an issue that affects Always On VPN connections after installing September security update". Microsoft had earlier marked the issue as fixed in the October cumulative updates, which it was not. **Who acts:** endpoint admins running Always On VPN. **Check:** `Get-VpnConnection -AllUserConnection | Select-Object Name, TunnelType`; profiles on `Automatic` are the affected setup. Until the fix reaches your ring, the workaround is SSTP-only or IKEv2-only. **Source:** [KB5127936](https://support.microsoft.com/en-us/servicing/os/windows-11/2026/10/kb5127936-windows-11-25h2-26h2-update) (not re-read today; fix line confirmed via [BleepingComputer](https://bleepingcomputer.com/news/microsoft/microsoft-finally-fixes-vpn-issues-caused-by-september-updates)).
- **Microsoft: a fake-download campaign uses trojanized Inno Setup-style installers to drop proxyware (WorldProxyPool), compute monetisation (CharityEngine and BOINC) and adware-style utilities (3 November).** Detections include Trojan:Win64/OfferLoader.DA!MTB and Behavior:Win32/SuspInnoOffer.A!mapsi. Microsoft recommends cloud-delivered protection, tamper protection, SmartScreen and the ASR rule that blocks executables that don't meet prevalence, age or trusted-list criteria. **Who acts:** endpoint and SecOps admins. **Check:** `Get-MpPreference | Select-Object AttackSurfaceReductionRules_Ids, AttackSurfaceReductionRules_Actions` and look for rule `01443614-cd74-433a-b99e-2ecdc07bfc25` in Audit or Block; then run Microsoft's three hunting queries (DeviceProcessEvents, DeviceNetworkEvents) in Defender portal > Hunting > Advanced hunting. **Source:** [Microsoft Security blog, 3 November 2026](https://www.microsoft.com/en-us/security/blog/2026/11/03/fake-download-campaign-uses-trojanized-installers-deliver-monetization-payloads/). Related: [ASR rules from Audit to Block](../../guides/defender-asr-rules-audit-to-block.md) · [Defender for Endpoint ASR Kit](../../kits/defender-endpoint-asr.md).
- **Windows Update certificates "will expire in May and June 2027".** Microsoft: "Replacement certificates will reach most devices through monthly updates", but "some devices might require additional IT action." **Who acts:** endpoint admins with devices that miss monthly updates (offline images, frozen kiosks, long-deferred rings). **Check:** Intune admin center > Reports > Windows updates for devices behind on quality updates; `Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1` on a device outside management. Microsoft hasn't published the device list for "additional IT action" in the post we read. **Source:** [Windows news you can use: October 2026](https://techcommunity.microsoft.com/blog/windows-itpro-blog/windows-news-you-can-use-october-2026/4552396).
- **What's new in Microsoft Security, November 2026 (5 November): Microsoft Execution Containers (MXC) for local AI agents on Windows are "now generally available", and "Now generally available, Defender discovers more than 50 supported local AI agents and their configured model context protocols (MCPs) across Windows and macOS".** Intune, Entra and Agent 365 integration for MXC is described as "upcoming". **Who acts:** endpoint and SecOps admins with developers running local AI agents. **Check:** build a baseline to compare with Defender's inventory, for example `Get-ChildItem -Path C:\src -Recurse -Filter .mcp.json -ErrorAction SilentlyContinue` on a developer workstation. The post does not say where in the Defender portal the inventory appears. **Source:** [Microsoft Security blog, 5 November 2026](https://www.microsoft.com/en-us/security/blog/2026/11/05/whats-new-in-microsoft-security-november-2026/).

More: [all Endpoint & devices news](../topic/endpoint-devices/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 6 November 2026. Runbook Lab is not affiliated with Microsoft.
