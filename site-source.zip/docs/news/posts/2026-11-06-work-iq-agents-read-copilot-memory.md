---
date:
  created: 2026-11-06 10:05:00
slug: work-iq-agents-read-copilot-memory
categories:
  - AI security
description: "MC1539004: from early December 2026, agents using Work IQ MCP can read users' Copilot memory by default. Review the memory read policy before rollout."
rl_type: news
rl_area: ai
rl_service: [copilot]
rl_kits: [copilot, agents]
rl_controls: []
---

# MC1539004: Agents can read Copilot memory from December

MC1539004 (published 5 November 2026) adds a Work IQ MCP path that gives "authorized agents" read-only access to each user's Copilot memory profile, rolling out worldwide "Beginning in early December 2026 and expected to complete by late December 2026". The admin policy that controls it "is enabled by default", so Microsoft 365 Copilot and agent admins who don't want agents reading user memory need to review that policy before early December.

<!-- more -->

!!! note "Runbook card"
    **What changes:** a new Work IQ MCP path, `/memory/me/coreMemories`, returns the signed-in user's memory profile to agents that have access to the Work IQ MCP server: Custom Instructions, Saved Memories and memories derived from chat history. Read only; memory "cannot be written or modified through Work IQ MCP".<br>
    **Who:** Microsoft 365 Copilot tenants whose users run agents with access to the Work IQ MCP server. Admins who own Copilot, agents and AI governance decide; MSPs should raise it with each client.<br>
    **By when:** rollout starts early December 2026 and is expected to complete by late December 2026. The post has no "Act by" date.<br>
    **Do this:** 1. Decide whether agents may read user memory at all, and for which agents. 2. If not, turn off the memory read policy before early December. 3. List which agents and MCP clients have access to the Work IQ MCP server today. 4. Tell users that the Personalization settings in Copilot Chat decide what goes into the profile.<br>
    **Check:** Microsoft 365 admin center > Agents > Tools > Registry > Work IQ MCP > Policies (the memory read policy).<br>
    **Source:** [MC1539004](https://mc.merill.net/message/MC1539004) (published 5 November 2026).

## What Microsoft says

MC1539004 is titled "Work IQ expands memory capabilities to agents", tagged "Major change", "New feature", "User impact" and "Admin impact", service Microsoft Copilot (Microsoft 365). The facts in the post:

- The new path supports "only the fetch tool". Agents can read the profile; they cannot change it.
- "Only the authenticated user's memory profile is available. A user's memory profile is not shared with other users."
- At launch the profile holds Custom Instructions, Saved Memories and memories derived from chat history. Microsoft says the profile "will continue to evolve and improve over time", so what an agent can read may grow later.
- Work IQ MCP gets a new policy that controls memory access, at Microsoft 365 admin center > Agents > Tools > Registry > Work IQ MCP > Policies. "Like other read policies, this policy is enabled by default."
- "No admin action is required." That is Microsoft's wording for "it switches on by itself", not a statement that nothing needs reviewing.

## The controls that limit it

The post names one Enhanced personalization control and three user settings:

- **Enhanced personalization:** "If Enhanced personalization is disabled, Copilot Memory is disabled and is not available through the MCP path." This also turns Copilot Memory off for users in Copilot itself, so use it only if you want memory off everywhere. The post does not say where this control sits.
- **User settings** in Copilot Chat > Settings > Personalization: if Customize Copilot is off, Custom Instructions are left out; if Saved memories is off, saved memories are left out; if Chat history & work insights is off, insights from chat history and Microsoft 365 activity are left out.
- Changes to Enhanced personalization and to the user settings "may take up to 48 hours to take effect". Make the change a few days before early December, not on the day.

What the post does not say: which licence the policy needs, whether the policy can be scoped to some agents or users, and whether agent reads of memory are audited. Microsoft hasn't published those details in MC1539004.

## Related: Copilot connectors reach Work IQ APIs (MC1538999)

A second post the same day widens what agents can reach. MC1538999 says Work IQ APIs "will be able to use data and tools from connected enterprise systems through Copilot connectors", with rollout beginning "in late November 2026" and expected to complete "by late December 2026". "Data sources already connected by users in Copilot Chat will automatically become available through Work IQ APIs, subject to existing permissions and administrator controls." Again "No additional administrator action is required."

Existing permissions still apply and no separate connector setup is needed, so this changes reach, not permissions. Our advice: list the Copilot connectors in use before late November and decide which ones agents built on Work IQ should be able to use. Source: [MC1538999](https://mc.merill.net/message/MC1538999).

## How to check

Read-only, in the portal:

1. Microsoft 365 admin center > Agents > Tools > Registry > Work IQ MCP > Policies: note the state of the memory read policy (once it appears in your tenant).
2. In the same registry entry, note which agents and clients have access to the Work IQ MCP server.
3. On a test account, Copilot Chat > Settings > Personalization: note which of Customize Copilot, Saved memories and Chat history & work insights are on.

## How to verify

Our suggested test once the rollout reaches your tenant: with the memory read policy off, ask a test agent that uses Work IQ MCP for the user's memory profile and confirm it returns nothing. Allow up to 48 hours after a change to Enhanced personalization or the user settings before you test.

## Impact and rollback

Turning the memory read policy off removes agent access to memory through Work IQ MCP; agents that rely on it lose that personal context. Turning Enhanced personalization off goes further and disables Copilot Memory itself. Both can be turned back on; allow up to 48 hours for the personalization controls.

Related: the [Copilot Studio agent governance checklist](../../guides/copilot-studio-agent-governance-checklist.md), the [AI Agent Hardening kit](../../kits/ai-agent-hardening.md), the [Copilot Readiness kit](../../kits/copilot-readiness.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [AI security news](../topic/ai-security/).

## Sources

- [MC1539004: Work IQ expands memory capabilities to agents](https://mc.merill.net/message/MC1539004) (published 5 November 2026; read 6 November 2026)
- [MC1538999: Microsoft 365 Copilot: Copilot connectors in Work IQ APIs](https://mc.merill.net/message/MC1538999) (published 5 November 2026; read 6 November 2026)

Message center posts are only visible inside a tenant's admin center; the links go to a public mirror (mc.merill.net). Last reviewed: 6 November 2026. Runbook Lab is not affiliated with Microsoft.
