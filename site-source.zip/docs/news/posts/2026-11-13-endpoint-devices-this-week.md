---
date:
  created: 2026-11-13 12:20:00
slug: endpoint-devices-this-week-2026-11-13
categories:
  - Endpoint & devices
description: "Endpoint changes to 13 November 2026: find KB5132061 install failures, re-sign scripts as UTF-8 with BOM, fix NetApp LDAP signing, audit ReFS on USB drives."
rl_type: news
rl_area: endpoint
rl_service: [windows, intune, defender]
rl_kits: [mde]
rl_controls: []
---

# Endpoint & devices this week: 12 changes (13 November 2026)

Twelve confirmed Endpoint & devices items logged in the week to 13 November 2026, each with who acts, the check and the source. The most pressing action is for Windows admins: Microsoft says devices that fail to install KB5132061 "should be repaired in 24 to 48 hours starting from November 11, 2026, 10am PT", so list the devices still failing after that window.

<!-- more -->

This is our weekly Endpoint & devices roundup. Items rest on the facts Research read at each primary source between 11 and 13 November 2026. Where a claim comes from a news outlet, we say so.

## Already briefed

1. **November 2026 Patch Tuesday (10 November): the exploited Outlook flaw CVE-2026-124194 is fixed by the Office update, CISA due date 24 November 2026.** For Windows admins the step is to confirm the November Windows cumulative update on servers, domain controllers first; see the install issue below. Brief: [Outlook zero-day CVE-2026-124194: November Patch Tuesday](2026-11-10-outlook-zero-day-cve-2026-124194-november-patch-tuesday.md). Source: [MSRC November 2026 Security Updates](https://api.msrc.microsoft.com/cvrf/v3.0/cvrf/2026-Nov).
2. **NTLM signing on by default from the 10 November 2026 Windows updates; "Windows servers begin requiring NTLM signing by default" in May 2027.** Windows and Active Directory admins: turn on NTLM Enhanced auditing and list events 4022 and 4023 without the SIGN flag in Microsoft-Windows-NTLM/Operational. Brief: [NTLM signing on by default: KB5135557](2026-11-11-ntlm-signing-default-kb5135557.md). Source: [KB5135557](https://support.microsoft.com/en-us/servicing/os/windows/docs/2026/11/kb5135557-ntlm-signing-security-improvements).
3. **SignDrop: public exploit code for an unpatched Windows CLFS privilege escalation, published by a researcher on 10 November 2026; no CVE or patch yet.** Windows endpoint and server admins: read `Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\CLFS\Authentication' -Name Mode` to size exposure, keep the mitigation and tamper protection on (see the [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md)). Brief: [SignDrop: unpatched Windows CLFS zero-day PoC](2026-11-12-signdrop-windows-clfs-zero-day-poc.md). Source: [MSNightmare/SignDrop on GitHub](https://github.com/MSNightmare/SignDrop) (researcher's README).

## New this week

### KB5132061 may fail to install on Windows 11 24H2, 25H2 and 26H2; auto-repair from 11 November

KB5132061, the November security update, now lists a known issue: on devices that installed KB5127936, "some devices might be unable to complete the installation. Affected devices might repeatedly attempt to install the update or display error code 0x80070306, 0x800f0989, or 0x800f0993." The fix "is automatically running in affected devices connected to the internet and using Windows Update in Settings", and "All affected devices should be repaired in 24 to 48 hours starting from November 11, 2026, 10am PT." Devices patched through WSUS or the Catalog are not named in that statement.

- **Who acts:** Windows 11 24H2, 25H2 and 26H2 admins.
- **Check:** Intune admin center > Reports > Windows updates, and list devices with KB5132061 failed or pending. After Microsoft's 48-hour window, open a support case for any device still failing.
- **Source:** [KB5132061](https://support.microsoft.com/help/5132061). Confirmation: [BleepingComputer](https://www.bleepingcomputer.com/news/microsoft/microsoft-confirms-kb5132061-installation-issues-0x80070306-0x800f0989-0x800f0993-errors/). Related: [November Patch Tuesday brief](2026-11-10-outlook-zero-day-cve-2026-124194-november-patch-tuesday.md).

### Signed PowerShell scripts with invalid UTF-8 may fail validation after the November Windows updates

KB5132061 says "scripts containing invalid UTF-8 encoding might fail signature validation, even if they were previously accepted." Microsoft's fix: "review the affected scripts, save them using valid UTF-8 encoding with a byte order mark (BOM), and sign them again." Further guidance is in KB5135999. This hits anything that relies on signed scripts: the AllSigned execution policy, AppLocker or App Control rules, and Intune platform scripts and remediations. Test on a patched device before the update reaches your broad ring.

- **Who acts:** endpoint admins and script owners who sign PowerShell scripts.
- **Check:** on a patched test device, read-only: `Get-ChildItem -Path C:\Scripts -Recurse -Include *.ps1,*.psm1 | Get-AuthenticodeSignature | Where-Object Status -ne 'Valid' | Select-Object Path, Status`. Re-save failures as UTF-8 with BOM and sign them again.
- **Source:** [KB5132061](https://support.microsoft.com/en-us/servicing/os/windows-11/2026/11/kb5132061-windows-11-24h2-25h2-26h2-security-update) (guidance: KB5135999).

### Standalone PowerShell security update for hotpatch devices: KB5135385 and KB5135386 (10 November)

Microsoft released KB5135385 for Windows 11 26H2, 25H2 and 24H2 (OS Builds 26300.9911, 26200.9911 and 26100.9911). KB5135386 for Windows Server 2025 is named in the Windows message center. KB5135385 "provides additional Windows PowerShell security improvements for hotpatch-enrolled devices. It is offered only after the November 2026 hotpatch security update has been installed." It covers Desired State Configuration (DSC), Invoke-WebRequest and PowerShell Workflow: CVE-2026-124224, CVE-2026-124225 and CVE-2026-124226. No exploitation is stated. "Your device might require a restart if affected Windows PowerShell files are in use." Microsoft is "not currently aware of any issues with this update." Hotpatch devices may not be restart-free this month.

- **Who acts:** admins with hotpatch rings (Windows 11 Enterprise, Windows Server 2025 Azure Edition or Arc).
- **Check:** `Get-HotFix -Id KB5135385, KB5135386 -ErrorAction SilentlyContinue` on hotpatch devices, after the November hotpatch.
- **Source:** [KB5135385](https://support.microsoft.com/help/5135385).

### Domain controller LDAP Kerberos SPN check breaks NetApp SMB shares: MC1551001 (12 November)

MC1551001 says the October 13, 2026 Windows security updates added "additional security requirements for LDAP authentication on Active Directory domain controllers". Kerberos service tickets for LDAP must "match the LDAP service principal name SPN registered on the target domain controller." Affected: "Azure NetApp Files and NetApp ONTAP configurations that connect to Active Directory LDAP with LDAP client session security set to none". Symptoms: "Issues accessing SMB shares" and "Invalid credentials" errors. For self-managed ONTAP the fix is "configuring LDAP session security to use sign or seal". Azure NetApp Files: see KB5134907. Do not roll back the DC updates.

- **Who acts:** Active Directory and storage admins running NetApp ONTAP or Azure NetApp Files.
- **Check:** on ONTAP, `vserver cifs security show` and read the LDAP session security value for each SVM; "none" is the affected setting.
- **Source:** [MC1551001](https://mc.merill.net/message/MC1551001) (guidance: KB5134907). Related: [NTLM signing on by default](2026-11-11-ntlm-signing-default-kb5135557.md).

### ReFS on removable media: blocking becomes the default with the January 2027 security update

KB5130741 (published 13 October 2026): the October update turned on auditing, and "Blocking is not enabled by default." With the "January 2027 security update (Enforcement phase) Auditing and blocking are enabled by default. ReFS volumes that meet either configured external-media condition are blocked from mounting unless an administrator explicitly changes the applicable setting." Audit hits log System Event ID 524 (Source ReFS). The setting is `RefsRemovableDeviceMountPolicy` (0 Off, 1 Audit, the default, 2 Block); a restart is required. MC1550797 (12 November) is Microsoft's "60-day reminder". Microsoft gives no day.

- **Who acts:** endpoint admins with users who format USB or SD drives as ReFS.
- **Check:** `Get-WinEvent -FilterHashtable @{LogName='System'; Id=524} -ErrorAction SilentlyContinue | Where-Object ProviderName -match 'ReFS'`. Setting: `Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name RefsRemovableDeviceMountPolicy -ErrorAction SilentlyContinue`.
- **Source:** [KB5130741](https://support.microsoft.com/en-us/help/5130741) · [MC1550797](https://mc.merill.net/message/MC1550797). Related: [Microsoft 365 security deadlines](../../guides/deadlines.md).

### Intune: just-in-time registration auto-enabled for eligible iOS/iPadOS tenants with the 2611 release

Intune's in development page (updated 30 October): "Microsoft Intune will automatically enable just-in-time (JIT) registration for eligible iOS/iPadOS tenants with the 2611 release." "Beginning with the November 2026 release", renewing the Apple MDM push certificate shows an acknowledgment, ahead of "web-based enrollment becoming the default for user-owned iOS and iPadOS devices in early 2027". Microsoft gives no calendar date for 2611.

- **Who acts:** Intune admins who enrol iPhone and iPad, plus the identity team that owns Conditional Access.
- **Check:** Intune admin center > Devices > Enrollment > Apple, review the enrollment profiles; then Entra admin center > Protection > Conditional Access > Policies, and find the policies that cover device registration.
- **Source:** [Intune: in development](https://learn.microsoft.com/en-us/intune/whats-new/in-development).

## Also logged

- **The November Windows 11 update KB5132061 (MC1547648) expands Secure Boot certificate deployment with "additional high confidence device targeting data".** It also fixes the RDP certificate-mismatch failures from the October preview. At release it listed no known issues (the install issue above came later), and there is no December non-security preview. **Who acts:** endpoint admins. **Check:** Intune admin center > Reports > Windows updates. **Source:** [KB5132061](https://support.microsoft.com/en-us/servicing/os/windows-11/2026/11/kb5132061-windows-11-24h2-25h2-26h2-security-update).
- **Windows release health: SQL Server linked server connections might remain open after the October updates, status "Confirmed" on 11 November.** Not a security issue. **Who acts:** server and database admins on Windows 11 24H2. **Source:** [Windows 11, version 24H2 known issues](https://learn.microsoft.com/en-us/windows/release-health/status-windows-11-24h2).
- **MC1491832 (updated 12 November): RD Web Access fails to render when browsers disable XSLT; the November 2026 Windows Server update (KB5130994) fixes it.** **Who acts:** admins of RD Web Access hosts; customised portals need Microsoft's extra guidance. **Check:** `Get-HotFix -Id KB5130994 -ErrorAction SilentlyContinue` on each host. **Source:** [MC1491832](https://mc.merill.net/message/MC1491832).

More: [all Endpoint & devices news](../topic/endpoint-devices/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 13 November 2026. Runbook Lab is not affiliated with Microsoft.
