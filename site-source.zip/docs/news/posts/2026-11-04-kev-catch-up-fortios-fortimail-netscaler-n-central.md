---
date:
  created: 2026-11-04 10:35:00
slug: kev-catch-up-fortios-fortimail-netscaler-n-central
categories:
  - Threats & vulnerabilities
description: "Exploited FortiOS, FortiMail, NetScaler and N-central flaws added to CISA KEV in September and October: fixed versions, checks and IOCs in one list."
rl_type: news
rl_kits: []
rl_controls: []
---

# KEV catch-up: FortiOS, FortiMail, NetScaler, N-central

Between 8 September and 16 October 2026 CISA added three flaws in internet-facing appliances and one in an RMM server to its Known Exploited Vulnerabilities catalog that we had not covered: FortiOS CVE-2025-61624, FortiMail CVE-2026-104286, Citrix NetScaler CVE-2026-88779 and N-able N-central CVE-2026-86218. If you run any of them yourself, check the version today; every federal due date has passed.

<!-- more -->

!!! note rl-today "Do this today"
    **What:** four exploited flaws in CISA's KEV catalog: FortiOS CVE-2025-61624, FortiMail CVE-2026-104286, NetScaler CVE-2026-88779 and N-central CVE-2026-86218.<br>
    **Who is exposed:** anyone running on-premises FortiGate, FortiProxy, FortiPAM, FortiSwitchManager or FortiMail, customer-managed NetScaler ADC or Gateway used for SAML, or self-hosted N-central.<br>
    **The one action:** check each version against the fixed version below today. CISA's due dates passed between 11 September and 19 October 2026.<br>
    For the Microsoft 365 side of the same estate, the [M365 Hardening Kit](../../kits/m365-hardening.md) has a free Top 10 with read-only checks.

!!! info "Updated 5 November 2026"
    NetScaler CVE-2026-88779: we re-read Citrix bulletin CTX697174 (first published 3 October 2026). The fixed builds below are unchanged, and the impact is still denial of service, only on appliances configured as a SAML SP or SAML IdP. Three more NetScaler flaws from September (CVE-2026-19490, CVE-2026-88771, CVE-2026-88772) are listed in our [second KEV catch-up](2026-11-05-kev-catch-up-sharepoint-screenconnect-pan-os.md), with SharePoint, ScreenConnect and PAN-OS. See [NetScaler](#netscaler-cve-2026-88779-saml-appliances).

!!! note "Runbook card"
    **What changes:** nothing new this week. These are exploited flaws from September and October that are easy to have missed, with the vendors' fixed versions.<br>
    **Who:** owners of on-premises FortiGate (FortiOS), FortiProxy, FortiPAM, FortiSwitchManager and FortiMail appliances; customer-managed NetScaler ADC and Gateway used for SAML, including Secure Private Access hybrid deployments; MSPs and IT teams running self-hosted N-central.<br>
    **By when:** now. CISA's due dates ran from 11 September to 19 October 2026.<br>
    **Do this:** 1. Find every instance and its version. 2. Upgrade to the fixed version in each section below; on FortiMail 7.2, turn off IBE until 7.2.10 ships. 3. On FortiMail, search for the published indicators of compromise. 4. Keep management and webmail interfaces off the internet.<br>
    **Check:** the installed version against the tables below (FortiOS and FortiMail: `get system status`; NetScaler: `show ns version`; N-central: the build number shown in the N-central UI, which must be 2026.3.1.14 or later).<br>
    **Source:** the vendor advisories linked in each section and the [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (catalog version 2026.11.03).

| CVE | Product | Added to KEV | Federal due date | Vendor says exploited |
|---|---|---|---|---|
| CVE-2025-61624 | FortiOS, FortiProxy, FortiPAM, FortiSwitchManager | 16 Oct 2026 | 19 Oct 2026 | "Known Exploited: Yes" |
| CVE-2026-104286 | FortiMail | 1 Oct 2026 | 4 Oct 2026 | "Known Exploited: Yes" |
| CVE-2026-88779 | NetScaler ADC and Gateway | 4 Oct 2026 | 7 Oct 2026 | not stated in the bulletin |
| CVE-2026-86218 | N-able N-central | 8 Sep 2026 | 11 Sep 2026 | "no confirmations" (5 September) |

## FortiMail CVE-2026-104286: unauthenticated file write, IOCs published

Fortinet advisory FG-IR-26-175 (published 1 October 2026, updated 7 October): a path traversal and NULL byte flaw that "may allow an unauthenticated attacker to write arbitrary files on the underlying system via crafted HTTP or HTTPS requests". Severity "Critical", CVSSv3 9.8. Fortinet: "This has been reported to be exploited in the wild, customers are urged to apply the workaround below."

| FortiMail | Affected | Fix |
|---|---|---|
| 8.0 | 8.0.0 through 8.0.1 | Upgrade to 8.0.2 or above |
| 7.6 | 7.6.0 through 7.6.6 | Upgrade to 7.6.7 or above |
| 7.4 | 7.4.0 through 7.4.8 | Upgrade to 7.4.9 or above |
| 7.2 | 7.2.0 through 7.2.9 | "Upgrade to upcoming 7.2.10 or above" |
| 7.0 | all versions | Migrate to a fixed release |

FortiMail Cloud was fixed by Fortinet on 5 October; "FortiMail Cloud customers need not perform any action."

Workaround, which matters most on 7.2 where no fix has shipped: turn off IBE (Encryption, IBE, IBE Service off) or in the CLI:

```
config system encryption ibe
set status disable
end
```

Fortinet's alternatives: block webmail access from the internet or allow it only from a trusted private network, or have a web application firewall in front of FortiMail "block POST requests to /ibe that contain '../'".

Indicators of compromise from the advisory, to search for in FortiMail logs and firewall logs:

- Source IPs 79[.]141.169.187 and 45[.]129.0.192.
- A config event adding an archive account named `archive234` with remote destination 79.141.169.187.
- A cron entry in the system event log starting `/bin/sh -c 'O=/migadmin`.
- Encryption log errors containing `Invalid Base64 Encoding at pos 0. Character=0x2a`.

Our advice: if any of these match, treat the appliance as compromised. Preserve logs, rebuild it from clean firmware and rotate the admin and archive credentials it held.

## FortiOS CVE-2025-61624: authenticated CLI path traversal

Fortinet advisory FG-IR-26-122 (published 14 April 2026): a path traversal in the command line interpreter of FortiOS, FortiPAM, FortiProxy and FortiSwitchManager that "may allow a privileged attacker to achieve arbitrary write or delete files via specifically crafted arguments to existing commands". Severity "Medium", CVSSv3 6.0, attack type "Authenticated", "Known Exploited: Yes". CISA added it to KEV on 16 October 2026, six months after the advisory, and flags it for forensic triage, as it does the FortiMail and N-central entries.

The attacker needs an admin account first. CISA describes it as needing an "admin profile and at least read-write permissions". So the risk is an attacker who already holds, or has stolen, firewall admin access using it to dig in further.

| Product | Fix |
|---|---|
| FortiOS 7.6 | 7.6.5 or above |
| FortiOS 7.4 | 7.4.10 or above |
| FortiOS 7.2, 7.0, 6.4 | Migrate to a fixed release |
| FortiProxy 7.6 / 7.4 | 7.6.5 / 7.4.12 or above (7.2 and 7.0: migrate) |
| FortiPAM 1.7 | 1.7.1 or above (1.0 to 1.6: migrate; 1.8 not affected) |
| FortiSwitchManager 7.2 / 7.0 | 7.2.8 / 7.0.7 or above |

Fortinet gives no fixed release on the FortiOS 7.2, 7.0 and 6.4 branches, only "Migrate to a fixed release"; our reading is that means 7.4.10 or 7.6.5 and later. Fortinet lists a FortiGuard virtual patch, "FG-VD-59270.0day.", in FMWP database update 25.120.

Our advice: after upgrading, review the admin accounts on each device, remove any you do not recognise and rotate the passwords and API tokens of the rest.

## NetScaler CVE-2026-88779: SAML appliances

Citrix security bulletin CTX697174: a "Memory overflow vulnerability leading to Denial of Service", CVSS v4.0 8.7, severity "High". It only affects appliances configured as a SAML service provider or SAML identity provider. CISA added it to KEV on 4 October 2026. Citrix's bulletin does not describe exploitation; the KEV listing is the exploitation signal.

Fixed versions, from the bulletin:

- NetScaler ADC and NetScaler Gateway 14.1-73.41 and later releases
- NetScaler ADC and NetScaler Gateway 13.1-64.28 and later releases of 13.1
- NetScaler ADC 14.1-FIPS 14.1-73.41 FIPS and later releases of 14.1-FIPS
- NetScaler ADC 13.1-FIPS and 13.1-NDcPP 13.1-37.282 and later releases

Citrix adds that Secure Private Access hybrid deployments using NetScaler instances are affected too, and that the bulletin only applies to customer-managed appliances; Citrix updates its own cloud services.

To see whether an appliance meets the precondition, Citrix says to look in the configuration for `add authentication samlAction` (SAML SP) or `add authentication samlIdPProfile` (SAML IdP).

## N-able N-central CVE-2026-86218: pre-auth remote code execution

N-able status page "N-central 2026.3 Hotfix 4 – CVE-2026-86218" (last updated 5 September 2026): "a critical-CVSS-rated vulnerability that could allow for pre-authenticated remote code execution on the N-central server". Fixed build 2026.3.1.14 (2026.3 Hotfix 4), which "supersedes N-central 2026.3 Hotfix 3 (build 2026.3.1.13)", so Hotfix 3 is not enough. CISA lists it as "N-able N-central Static Code Injection Vulnerability", added 8 September 2026.

- **Self-hosted:** "Customers running on-premises N-central deployments should upgrade to N-central 2026.3 HF4 immediately". Direct upgrade paths to 2026.3.1.14 are from 2025.4, 2026.1, 2026.2, 2026.3 and 2026.3 Hotfix 1 and 2; older versions go to one of those first.
- **Hosted (NCOD):** "patches have already been applied to your environment".
- **Agents:** the hotfix does not need agents to be upgraded, though N-able recommends keeping them current.

The two sources disagree on exploitation. N-able wrote on 5 September: "we have no confirmations that this vulnerability has been exploited in production environments, but unpatched systems remain at risk." CISA added it to KEV three days later. We go with CISA for patch priority.

Our advice for MSPs: an RMM server pushes code to every managed device, so after patching review N-central admin accounts and the scripts and automation policies created or changed since early September.

## How to verify

Each appliance or server reports a version at or above the fixed version in its section; FortiMail 7.2 shows IBE as off until 7.2.10 is installed; your FortiMail, firewall and proxy logs show no matches for the indicators above.

Related: our earlier [CISA KEV brief on Cisco ASA, GitLab, Ivanti and PHP](2026-10-31-cisa-kev-cisco-asa-gitlab-ivanti-php.md), the [BeyondTrust Remote Support exploit](2026-11-03-beyondtrust-remote-support-cve-2026-102764-patch-hunt.md), the [Windows Shell zero-day CVE-2026-96951](2026-11-04-windows-shell-cve-2026-96951-october-zero-day.md), and more [Threats & vulnerabilities news](../topic/threats-vulnerabilities/).

## Sources

- [Fortinet PSIRT FG-IR-26-175: FortiMail](https://fortiguard.fortinet.com/psirt/FG-IR-26-175) (published 1 October 2026, updated 7 October 2026; read 4 November 2026)
- [Fortinet PSIRT FG-IR-26-122: FortiOS, FortiProxy, FortiPAM, FortiSwitchManager](https://fortiguard.fortinet.com/psirt/FG-IR-26-122) (published 14 April 2026; read 4 November 2026)
- [Citrix security bulletin CTX697174: CVE-2026-88779](https://support.citrix.com/support-home/kbsearch/article?articleNumber=CTX697174) (first published 3 October 2026; read 4 and 5 November 2026)
- [N-able: N-central 2026.3 Hotfix 4 – CVE-2026-86218](https://status.n-able.com/2026/09/06/n-central-2026-3-hotfix-4-cve-2026-86218/) (last updated 5 September 2026; read 4 November 2026)
- [CISA Known Exploited Vulnerabilities catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (catalog version 2026.11.03, read 4 November 2026)

Last reviewed: 5 November 2026.
