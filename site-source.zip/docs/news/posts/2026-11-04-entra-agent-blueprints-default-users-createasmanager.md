---
date:
  created: 2026-11-04 09:55:00
slug: entra-agent-blueprints-default-users-createasmanager
categories:
  - Identity & access
description: "From 4 November 2026 Entra lets default users create agent blueprints and stops auto-granting AgentIdentity.CreateAsManager. Check both settings now."
rl_type: news
rl_area: identity
rl_service: [entra]
rl_kits: [agents]
rl_controls: [AG01, AG04]
---

# Entra agent identities: two changes from 4 November

Microsoft Entra starts two agent identity changes on 4 November 2026: default users can create agent blueprints unless you turn the setting off (MC1506733), and agent blueprints no longer get the AgentIdentity.CreateAsManager permission automatically (MC1506728). Entra admins should decide on the blueprint setting today and find any agent that creates its own identities without a signed-in user before the rollout reaches their tenant.

<!-- more -->

!!! note "Runbook card"
    **What changes:** 1. "Starting November 4, 2026, default users in Microsoft Entra can create agent blueprints" unless an admin sets "Users can create agent blueprints" to No (MC1506733). 2. "Starting November 4, Microsoft Entra will stop automatically granting the AgentIdentity.CreateAsManager permission to agent blueprints"; an admin must grant it (MC1506728).<br>
    **Who:** Entra admins in every tenant (change 1); owners of agents that use app-only authentication to create their own agent identities (change 2).<br>
    **By when:** both roll out worldwide "Beginning in early November 2026 and expected to complete by late November 2026". Microsoft hasn't published per-tenant dates.<br>
    **Do this:** 1. If default users should not create agents, set Entra ID > Users > User settings > Default user role permissions > "Users can create agent blueprints" to No and save. 2. Find agents that create agent identities app-only (audit log check below). 3. For each one that relies on the automatic grant, grant the AgentIdentity.CreateAsManager Microsoft Graph application permission (tenant-wide admin consent or manual app-role creation) or move it to another supported authorisation model, then test.<br>
    **Check:** Entra admin center > Entra ID > Audit logs, Category "ApplicationManagement", Activity "Add Service Principal", Initiated by (actor) type Application, target an agent identity.<br>
    **Source:** [MC1506733](https://mc.merill.net/message/MC1506733) and [MC1506728](https://mc.merill.net/message/MC1506728) (both published 13 October 2026).

## Change 1: default users can create agent blueprints

MC1506733 is titled "Action may be required: Review who can create agents in Microsoft Entra" and tagged "User impact" and "Admin impact". Microsoft says that from 4 November "users without built-in or custom Entra roles will be able to create new agent blueprints in their organization", unless an administrator turns off "Users can create agent blueprints".

If you set the toggle to No, "default users will not be able to create new agents". Supported administrators and users with the Agent ID Developer role can still create them. Microsoft also says: "If you change this toggle now, your tenant won't change right away. Your setting takes effect when the rollout begins in early November."

What the setting does not do, per the post: it does not change or remove existing agent blueprints, does not change who can create agent identities from existing blueprints, does not block an app or an agent from creating identities, and does not change creation requirements in platforms such as Microsoft Foundry or Security Copilot (for example, licence and Azure subscription requirements).

The new setting "is independent of Users can register applications. Review both settings separately." A tenant that already blocks app registration by default users is not covered by that choice.

If default users should be allowed to create agents, Microsoft says no action is required.

## Change 2: no automatic AgentIdentity.CreateAsManager

MC1506728 is tagged "User impact", "Admin impact" and "Retirement". Today every agent blueprint principal gets AgentIdentity.CreateAsManager automatically, which lets it create agent identities without a tenant admin granting an app role. From 4 November an administrator must grant the Microsoft Graph application permission to agents that need it. Agents that create their own identities app-only must get that explicit grant or "move to another supported authorization model before enforcement reaches their tenant".

The change "Affects existing and future agents". It does not remove existing agent identities or blueprints, and it does not affect an agent that uses a directory role to authorise creation of agent identities.

The failure mode: "If an app-only request relies only on the automatic grant after enforcement reaches your tenant, the request will fail with a 403 authorization error."

Microsoft says the explicit permission could be granted from 16 October "through tenant-wide admin consent or manual app-role creation" ("Granting it earlier will cause an error."). A successful grant shows "An administrator" in the Granted By column of the blueprint's Granted permissions table.

If no agent in your organisation depends on the automatic grant, no action is required.

## How to check (read-only)

Blueprint setting: Entra admin center > Entra ID > Users > User settings > Default user role permissions > "Users can create agent blueprints". Note the current value next to "Users can register applications".

Agents that create identities app-only, as Microsoft describes: Entra ID > Audit logs, Category "ApplicationManagement", Activity "Add Service Principal", then events where Initiated by (actor) type is Application and the target is an agent identity. For each agent found, open Entra ID > Agent blueprints > your blueprint > Granted permissions and see whether any other granted permission allows creating agent identities. If none does, that agent relies on AgentIdentity.CreateAsManager.

Our example of the same audit search in Microsoft Graph PowerShell (read-only, needs AuditLog.Read.All; check the target in the results against your agent identity list from [AG01](../../controls/ai-agent-hardening/ag01-inventory-every-agent-in-the-tenant.md)):

```powershell
Connect-MgGraph -Scopes "AuditLog.Read.All"
Get-MgAuditLogDirectoryAudit -All -Filter "category eq 'ApplicationManagement' and activityDisplayName eq 'Add service principal'" |
  Where-Object { $_.InitiatedBy.App.ServicePrincipalId } |
  Select-Object ActivityDateTime,@{n='InitiatedByApp';e={$_.InitiatedBy.App.DisplayName}},@{n='Target';e={$_.TargetResources[0].DisplayName}}
```

## How to verify

Blueprint setting: sign in as a test user with no Entra role and confirm they can no longer create a new agent blueprint once the rollout reaches your tenant (if you chose No). Users with the Agent ID Developer role should still succeed.

CreateAsManager: the blueprint's Granted permissions table lists AgentIdentity.CreateAsManager with "An administrator" under Granted By. Microsoft recommends you "Test app-only agent identity creation before enforcement begins" and update operational guidance for failed requests, so a 403 from an agent later is recognised quickly.

## Impact

Setting the blueprint toggle to No stops default users creating new agents; makers then need the Agent ID Developer role or a supported admin role. Granting AgentIdentity.CreateAsManager lets that agent create identities without a signed-in user, so grant it only to agents that need it; Microsoft says the permission is revocable once consented. Our note: to undo the toggle, set it back to Yes; the post does not cover reverting.

Related: the [AI agent hardening kit](../../kits/ai-agent-hardening.md), [AG04: watch agent creation, publishing and sharing](../../controls/ai-agent-hardening/ag04-watch-agent-creation-publishing-sharing-and.md), the [Copilot Studio agent governance checklist](../../guides/copilot-studio-agent-governance-checklist.md), dated actions on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [Identity & access news](../topic/identity-access/).

## Sources

- [MC1506733: Action may be required: Review who can create agents in Microsoft Entra](https://mc.merill.net/message/MC1506733) (published 13 October 2026; read 4 November 2026)
- [MC1506728: Microsoft Entra: Changes to AgentIdentity.CreateAsManager permission for agent identities](https://mc.merill.net/message/MC1506728) (published 13 October 2026; read 4 November 2026)

Last reviewed: 4 November 2026. Runbook Lab is not affiliated with Microsoft.
