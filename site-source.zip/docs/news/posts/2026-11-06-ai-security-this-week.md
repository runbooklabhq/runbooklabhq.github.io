---
date:
  created: 2026-11-06 12:20:00
slug: ai-security-this-week-2026-11-06
categories:
  - AI security
description: "AI security to 6 November 2026: GitHub blocks pull_request_target, Power Platform prompt models retire, Claude Code, Langflow and MCP SDK fixes to install."
rl_type: news
rl_kits: [agents, copilot]
rl_controls: []
---

# AI security this week: 25 changes (6 November 2026)

Twenty-five confirmed AI security items from the week to 6 November 2026, each with who acts, the check and the source. The nearest date to act on is 9 November 2026, when GitHub runs its first two-hour brownout that blocks `pull_request_target` in public repositories.

<!-- more -->

This is our weekly AI security roundup. Most items were re-read on their primary source on 6 November 2026. Where we could not reach the primary today, the item says so and uses the status words Research read at the primary earlier this week.

## Already briefed

1. **Work IQ lets authorised agents read users' Copilot memory, with the read policy "enabled by default" from early December 2026 (MC1539004), and makes data sources users connected in Copilot Chat available through Work IQ APIs (MC1538999).** Copilot and AI admins, before early December. Brief: [Work IQ agents read Copilot memory](2026-11-06-work-iq-agents-read-copilot-memory.md).
2. **Entra lets default users create agent blueprints from 4 November 2026 (MC1506733) and stops auto-granting `AgentIdentity.CreateAsManager` to blueprints (MC1506728).** Identity admins and agent developers. Brief: [Entra agent blueprints and CreateAsManager](2026-11-04-entra-agent-blueprints-default-users-createasmanager.md).

## Agent and developer tools

### GitHub blocks pull_request_target by default on 2 December 2026, brownouts on 9 and 16 November

GitHub's changelog of 2 November: "Starting December 2, 2026, GitHub Actions will block `pull_request_target` events by default" in public repositories, unless an Actions event policy allows them. "Enforcement was previously scheduled for November 2, 2026." Two brownouts enforce the block from 16:00 to 18:00 UTC on 9 November and 16 November 2026, and blocked runs "create failed runs with an error annotation". The rule starts in evaluate mode, so you can see which runs it would block. Public repositories on GitHub Free, Team and Enterprise Cloud are in scope. "Private and internal repositories aren't affected", and neither is GitHub Enterprise Server.

- **Who acts:** owners of public repositories and organisations that use `pull_request_target` workflows, before 16:00 UTC on 9 November.
- **Check:** `grep -rln "pull_request_target" .github/workflows/` in each public repository, or `gh search code "pull_request_target" --owner <your-org>` for the whole organisation. Then either leave the block on, which is safer, or allow only the named workflows through an Actions event policy.
- **Source:** [GitHub changelog, 2 November 2026](https://github.blog/changelog/2026-11-02-pull_request_target-blocked-by-default-december-2). Related: [Microsoft 365 security deadlines](../../guides/deadlines.md).

### Claude Code 2.1.316 to 2.1.318: managed settings, fail-closed hooks and a wider MCP deny list (31 October to 4 November 2026)

Three releases in five days change how guardrails behave.

- **2.1.316**: "Fixed `--restricted` sessions uploading files from outside the working directories when a Read allow rule covered them" and "Fixed PowerShell hooks not blocking on exit code 2 when the command begins with a type cast, `param`, `using` or an attribute". It also changes server-managed settings for Team and Enterprise logins: "settings fetched from Anthropic's API now apply without an approval prompt, and a stored copy that doesn't verify is refused".
- **2.1.317** (npm, 2 November): "Added `onFailure: "block"` for Agent SDK hook callbacks, so a callback that fails blocks the action instead of letting it run"; "Added a check that asks before a web or shell tool call sends your account email address to the network"; "Added a warning to `/schedule` when a new cloud scheduled task gets connectors you did not ask for, with how to remove them".
- **2.1.318**: "Changed `deniedMcpServers` URL entries to also block Anthropic-provided servers whose upstream URL matches, and connectors in cloud sessions and on self-hosted runners"; "Changed Claude Code to no longer install or update the IDE extension when started in an IDE terminal"; "Fixed permission prompts being answered by keys typed just after sending a message, or before a slow prompt appeared".

- **Who acts:** teams that use Claude Code hooks, `--restricted`, managed settings or `deniedMcpServers` as guardrails; Team and Enterprise admins who push server-managed settings.
- **Check:** `claude --version` on developer machines and CI runners shows 2.1.318 or later. Re-test PowerShell PreToolUse hooks that exit 2 to block. Review server-managed settings before you change them, since they now land without a prompt. Read the `deniedMcpServers` URL entries in managed settings, because they now also match connectors. Install the IDE extension only from the editor's own extensions view (see our [Cursor extension backdoor brief](2026-10-31-claude-code-cursor-extension-ssh-backdoor.md)).
- **Source:** [Claude Code releases on GitHub](https://github.com/anthropics/claude-code/releases/tag/v2.1.318) and the [Claude Code CHANGELOG](https://github.com/anthropics/claude-code/blob/main/CHANGELOG.md). Related: [M365 AI Agent Hardening Kit](../../kits/ai-agent-hardening.md).

### MCP TypeScript SDK: tasks not tied to their session (CVE-2026-111767) and a memory exhaustion bug, fixed in sdk 1.32.0 (20 October 2026)

The advisory published on 20 October 2026: "MCP TypeScript SDK: Experimental tasks were not tied to the session that created them", CVSS 8.6 High, affecting `@modelcontextprotocol/sdk` "All versions starting from 1.24.0 before 1.32.0". CVE-2026-111768 (CVSS 7.5, validation heap out-of-memory) affects sdk 1.3.0 to 1.31.0 and server 2.0.0 to 2.2.0, fixed in sdk 1.32.0 and server 2.3.0. Corgea also lists CVE-2026-111769, CVE-2026-111770, CVE-2026-111771 and GHSA-f897-62hf-6gxq in the same batch. We are logging this two weeks late.

- **Who acts:** teams that build or host MCP servers or clients in TypeScript.
- **Check:** `npm ls @modelcontextprotocol/sdk` in each project shows 1.32.0 or later (v2 server and client packages 2.3.0 or later). Stop using experimental tasks until you have upgraded.
- **Source:** [GitLab advisory, CVE-2026-111767](https://advisories.gitlab.com/npm/@modelcontextprotocol/sdk/CVE-2026-111767/) · [Corgea write-up](https://corgea.com/research/cve-2026-111767-111770-111768-mcp-typescript-sdk-cross-session-leak-dos/).

### MCPhantom: AI coding agents install deprecated MCP reference servers that will not be patched (2 November 2026)

Glow Labs found coding agents setting up deprecated `@modelcontextprotocol/server-*` packages, in 98% of cases taking the name from training data rather than from the user. By Glow's count the deprecated packages have 17,352,267 downloads since 10 July 2025 (server-github alone 185,239 in the last week). Glow reports four high-severity bugs with no CVE, the worst a prompt-injection remote code execution bug in server-puppeteer, and no exploitation seen. The maintainers say the repository is unmaintained, so no fix will come. Glow saw this with Claude Code, Cursor, Codex CLI, Claude Cowork and Claude chat.

- **Who acts:** whoever approves MCP servers for developers and agent platforms.
- **Check:** `grep -rE "@modelcontextprotocol/server-(github|postgres|slack|puppeteer|brave-search|google-maps|gitlab|gdrive|redis|aws-kb-retrieval|everart)" ~/.mcp.json ~/.claude.json ~/.cursor/mcp.json .mcp.json 2>/dev/null` on developer machines, plus `claude_desktop_config.json`.
- **Do this:** replace each hit with the service's official server and add the deprecated names to `deniedMcpServers` in Claude Code managed settings (our advice).
- **Source:** [Glow Labs, MCPhantom](https://www.glow.io/blogs/mcphantom-ai-coding-agents-are-installing-vulnerable-deprecated-mcp-servers-from-training-data) (not re-read today; [Help Net Security](https://www.helpnetsecurity.com/2026/11/03/mcphantom-deprecated-mcp-servers/) re-read). Related: [Copilot Studio agent governance checklist](../../guides/copilot-studio-agent-governance-checklist.md).

### Langflow OSS 1.0.0 to 1.12.8: two unauthenticated 9.8 flaws, fix only in 1.13.0 (28 October 2026)

IBM's bulletin of 28 October (modified 29 October) covers CVE-2026-93680 (improper authentication, 9.8), CVE-2026-110186 (code generation, 9.8, no privileges or user interaction needed), CVE-2026-110193 (a low-privileged user can make "the Agentic Assistant" produce code "resulting in arbitrary operating system command execution", 8.8) and CVE-2026-110192 (credential exposure, 6.5). Affected: "1.0.0 - 1.12.8". The fix is "upgrading … to Langflow OSS 1.13.0", after you "back up the database, secret key, and uploaded files". "Workarounds and Mitigations: None." The CVE record for CVE-2026-110186 shows SSVC exploitation "none", and it is not in CISA KEV.

- **Who acts:** anyone self-hosting Langflow, internet-facing instances first.
- **Check:** `pip show langflow` on hosts, or `docker ps --format '{{.Image}}' | grep langflow` for containers. Anything below 1.13.0 needs the upgrade.
- **Do this:** upgrade to 1.13.0. Until then, take exposed instances off the internet (our assessment, since IBM gives no workaround). After upgrading, rotate credentials stored in flows.
- **Source:** [IBM Security Bulletin 7294467](https://www.ibm.com/support/pages/node/7294467) (not re-read today) · [CVE-2026-110186 record](https://raw.githubusercontent.com/CVEProject/cvelistV5/main/cves/2026/110xxx/CVE-2026-110186.json) (re-read).

## Found with AI

### Linux kernel CVE-2026-98432, found with Claude: RHEL 9 fix out, other vendors still working (27 October to 5 November 2026)

Anthropic's Frontier Red Team found the TCP use-after-free with "an unreleased, internal research model". Its 27 October post says the bug "was patched upstream and backported to all maintained stable kernel branches"; the demonstrated exploit targets servers with a multipath TCP (MPTCP) listener. AlmaLinux: "The Linux kernel CVE team scores it CVSS 9.8 (Critical)", "The bug goes back to Linux 4.4", and "systems without MPTCP still need the fix". Red Hat issued RHSA-2026:93412 for RHEL 9 (kernel 5.14.0-687.64.1.el9_8) on 1 November. Its bulletin RHSB-2026-016 (updated 3 November) still says "Red Hat is expediting the release of fixes", and says turning MPTCP off is "not a complete mitigation". WatchGuard says Fireware OS and its access points ship the vulnerable kernel but "are not affected by the RCE exploit chain", and Dimension patches are "not available yet" (SecurityWeek, 5 November). Not in CISA KEV.

- **Who acts:** owners of Linux servers, appliances and container hosts, internet-facing hosts first.
- **Check:** `uname -r` against your distribution's fixed build (RHEL 9: `rpm -q kernel` shows 5.14.0-687.64.1.el9_8 or later), then reboot into it. Until patched, `sysctl net.mptcp.enabled` and `ss -H -lMn` show whether MPTCP listeners exist; Red Hat's interim nftables rule drops IPv4 TCP packets with IP options and, in Red Hat's words, "cannot fully prevent the vulnerability".
- **Source:** [Anthropic research post](https://www.anthropic.com/research/discovering-vulnerabilities-with-claude) · [Red Hat RHSB-2026-016](https://access.redhat.com/security/vulnerabilities/RHSB-2026-016) · [RHSA-2026:93412](https://access.redhat.com/errata/RHSA-2026:93412) · [AlmaLinux](https://almalinux.org/blog/2026-10-30-cve-2026-98432/) · [SecurityWeek, 5 November](https://www.securityweek.com/cisco-watchguard-release-patches-sonicwall-wont-fix-gms-flaws/).

## Attacks run or built with AI

### CrowdStrike: VAPOR PANDA used the ARTEX AI framework against more than 200 organisations in 11 days (29 October 2026)

CrowdStrike says the actor it tracks as VAPOR PANDA, which it describes as China-nexus, ran one ARTEX controller from 17 October 2026 against "more than 200 distinct organizations worldwide" in at least 14 countries, mainly on DeepSeek models. CrowdStrike confirmed post-exploitation at nine organisations and password spraying or credential scanning against at least 12 more. Initial access used unsigned SAML assertions combined with an XXE flaw, an unauthenticated container orchestration service, a forged admin token from unrotated keys in a 2022 directory export, and leaked VPN configurations. ARTEX is the same open-source framework Microsoft tied to Storm-0940 (see our [ConnectWise brief](2026-11-03-connectwise-cloud-apps-storm-0940-m365-tenants.md)).

- **Who acts:** SecOps and identity teams running SAML apps and internet-facing appliances.
- **Check:** in Defender XDR Advanced Hunting, `DeviceProcessEvents | where Timestamp > ago(30d) | where ProcessCommandLine has_any ("artx", "artex") or FolderPath has @"ProgramData\artx5v"`. CrowdStrike also says to "Enforce SAML signature validation" and rotate signing keys, preauthentication keys and service credentials after any suspected exposure.
- **Source:** [CrowdStrike, 29 October 2026](https://www.crowdstrike.com/en-us/blog/vapor-panda-uses-artex-to-scale-global-campaign/) (attribution is CrowdStrike's).

### Cisco Talos: the VOLTA infostealer asks LLMs which victims are worth the effort, and takes Microsoft OAuth tokens (31 October 2026)

VOLTA is a self-deleting Windows stealer. It sends stolen data through OpenRouter to anthropic/claude-opus-4.6 and, when a reply looks like a refusal, falls back to moonshotai/kimi-k2 and then google/gemini-2.5-flash. It takes browser passwords and cookies, Microsoft OAuth tokens, SSH and cloud keys and wallets, and uses stolen sessions to enrich the profile. Talos thinks it is sold as a builder kit. Talos recommends application control on which processes may launch Chrome with `--headless`, and to "Revoke any potentially compromised tokens and change passwords".

- **Who acts:** endpoint and identity admins.
- **Check:** in Advanced Hunting, `DeviceProcessEvents | where Timestamp > ago(30d) | where FileName =~ "chrome.exe" and ProcessCommandLine has "--headless" | summarize count() by InitiatingProcessFileName, DeviceName`.
- **Do this:** for any infected user, revoke Entra sessions (Entra admin center > Users > select user > Revoke sessions) and reset the password.
- **Source:** [Cisco Talos, 31 October 2026](https://blog.talosintelligence.com/appraisal-by-ai-model-driven-victim-prioritization-in-the-volta-infostealer/).

### Sophos: Aur0ra ransomware operators used AI coding agents to reach domain admin (reported 2 November 2026)

Sophos says GOLD OGRE, which runs Aur0ra ransomware, ran intrusions through "Cursor's Composer agentic coding model" with "AI models provided by Anthropic, xAI, and Moonshot". Humans supplied VPN credentials, SOCKS access and targets. The agents did "password spraying, Kerberoasting, NTLM coercion and relay, and credential extraction from files and backups", and in some environments "achieved domain management access". Operators got past guardrails by calling the work "authorized red team activity" or "diagnostics testing".

- **Who acts:** Active Directory and SecOps teams.
- **Check:** on domain controllers, `Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4769} -MaxEvents 5000 | Where-Object { $_.Message -match 'Ticket Encryption Type:\s+0x17' }` lists RC4 service tickets, a Kerberoasting signal. Sophos also recommends phishing-resistant MFA, reviewing domain admin rights, PAM and isolated backups.
- **Source:** [Sophos](https://www.sophos.com/en-us/blog/ai-used-in-aur0ra-ransomware-testing-and-execution) (the page shows no date) · [Help Net Security, 2 November](https://www.helpnetsecurity.com/2026/11/02/aur0ra-ransomware-ai-agents/).

### Google GTIG and Mandiant: LLMjacking runs up AI charges on stolen cloud identities (2 November 2026)

GTIG and Mandiant report incidents where fraudulent charges exceeded 100,000 US dollars in a single day, with cumulative charges at some organisations reaching 1 million US dollars before access was revoked. The main way in is stolen cloud identity material: IAM credentials, service account keys, GitHub personal access tokens and session tokens. Attackers test harvested keys with `max_tokens=1`, and one actor abused LiteLLM CVE-2026-40217 in `/key/regenerate` to turn virtual keys into PROXY_ADMIN credentials. GTIG: treat any unauthorised enablement of LLM services as a "critical security event".

- **Who acts:** Azure, AWS and Google Cloud owners with AI services, and teams running LiteLLM gateways.
- **Check:** `az monitor activity-log list --offset 7d --query "[?operationName.value=='Microsoft.CognitiveServices/accounts/deployments/write']"` per subscription, and the same for `Microsoft.Insights/diagnosticSettings/write` and `/delete`.
- **Do this:** set budget alerts and per-model quotas, and patch LiteLLM (see our [LiteLLM 1.107.0 brief](2026-10-29-litellm-supply-chain-compromise.md)).
- **Source:** [Google Cloud threat intelligence blog, 2 November 2026](https://cloud.google.com/blog/topics/threat-intelligence/llmjacking-monetizing-compromised-cloud-models).

## Microsoft Copilot and Power Platform

### Power Platform prompt models retire on 2 December 2026, prompts moved automatically (MC1536101)

MC1536101 (3 November): "This update will be applied on December 2, 2026." and "The models listed below will be fully retired by December 2, 2026." Basic GPT-4.1 mini moves to GPT-6 Luna. Standard GPT-4.1, GPT-5 chat, GPT-5.3 chat, Claude Sonnet 4.6 and Grok 4.1 Fast reasoning move to ChatGPT-latest. Premium GPT-5 reasoning, GPT-5.2 reasoning and Claude Opus 4.6 move to GPT-6 Reasoning. Microsoft says "no action is required to trigger automatic migration" and recommends you "Review and test your affected prompts before December 2, 2026."

- **Who acts:** Power Platform admins and makers who own AI Builder or Copilot Studio prompts.
- **Check:** Power Apps maker portal > AI hub > Prompts, in each environment: note the model each prompt uses and test it on the replacement. Where a prompt moves from Anthropic or xAI to an OpenAI model, check that your data-handling review still holds (our advice).
- **Source:** [MC1536101](https://mc.merill.net/message/MC1536101). Related: [Copilot Studio model retirement on 12 November](2026-10-28-copilot-studio-model-retirement.md) · [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md).

## Also logged

- **Northflank: "Assume all environment variables have been decrypted."** On 30 October Northflank told users to disable and rotate all keys, and at 23:38 UTC that "Users have reported unauthorised use of AI API keys supplied to the Northflank platform." Its latest update (2 November, 11:09 UTC, "Monitoring") says to rotate every secret, starting with AI, cloud, payment, private key and database credentials, and to reconnect integrations it revoked. Check AI provider usage logs from 29 October. [Northflank status](https://status.northflank.com/cmvv0rn5a092f14rutwccodpp).
- **ChatGPT shared link could run code in the viewer's session.** Parameter reported it on 18 October; "OpenAI fixed the issue on October 26". No user action stated. [Parameter](https://www.parameter.ai/labs/we-found-a-gap-at-openai) (not re-read today).
- **Teams meeting AI controls slip to January 2027 (MC1532253 v2).** The Copilot meeting policy gives way to MeetingAI and TranscriptionWithMeetingAI. Targeted Release now begins "early December 2026 (previously mid-November)"; General Availability "early January 2027 (previously late November 2026)", completing "mid-January 2027 (previously early December 2026)". Once enabled, "the Copilot policy can no longer be updated directly", so update scripts that set it. [MC1532253](https://mc.merill.net/message/MC1532253).
- **Agent Builder scheduled prompts (MC1302906).** Rollout "expected to begin mid-November 2026 (previously end of October)" and complete "by mid-December 2026 (previously end of November)". "This feature is enabled by default and respects existing tenant and Copilot policies." Tell users that scheduled prompts run under their own access. [MC1302906](https://mc.merill.net/message/MC1302906).
- **Chainalysis breached by "an external actor using offensive agentic techniques".** The 30 October notice listed user IDs, names, emails and role labels. The 4 November update says "names, usernames, password hashes and live tokens for all Chainalysis users were exposed" and "every user will have to reset passwords and rotate API keys as appropriate". Customers: rotate keys once access returns, and sign in from the login page, not from reset emails. [Chainalysis](https://www.chainalysis.com/blog/security-incident-october-30/).
- **Trigger.dev: attacker read environment variables of "a subset of organizations".** Resolved 1 November, 22:50 UTC; affected owners were emailed. Users rotate every secret stored as an environment variable. [Trigger.dev status](https://status.trigger.dev/incident/1110434).
- **Symantec: relay scripts redirect Codex and Claude Code and turn the sandbox off.** They replace `base_url` in `~/.codex/config.toml` or `ANTHROPIC_BASE_URL` in `~/.claude/settings.json`, set `sandbox_mode` to "danger-full-access" and persist user-scope `OPENAI_BASE_URL`, `CODEX_API_KEY` or `ANTHROPIC_AUTH_TOKEN`. About a dozen organisations, most in mainland China. Check: `grep -E "base_url|sandbox_mode" ~/.codex/config.toml` and `grep ANTHROPIC_BASE_URL ~/.claude/settings.json`. [Symantec, 29 October](https://www.security.com/threat-intelligence/openai-claude-unauthorized-relays).
- **WorkOS: internal sales app accessed through an "AI-assisted offensive security framework" (detected 30 October).** Contact details, sales history, call summaries and support conversations; "no evidence that WorkOS application data was accessed". Customers: "verify unexpected requests before sharing sensitive information or taking action". [WorkOS bulletin](https://workos.com/security/bulletins/october-30th-2026-data-security-incident) (not re-read today).
- **Check Point: a Codex jailbreak bundle rewrites agent instruction files to show relay ads.** `haiou-666/haiou-codex` (more than 250 stars) edits `00-identity.md` and a leftover `CLAUDE.md` to advertise an LLM gateway; "There are no hints that the advertised gateway itself is malicious." Same hunt as the Symantec item: watch global agent instruction and config files for changes. [Check Point Research, 3 November](https://research.checkpoint.com/2026/free-the-model-sell-the-gateway-prompt-adware-hidden-in-jailbreak-bundles/).
- **Visual Studio Tools for Applications and SSMS: Copilot prompt-injection RCE, CVE-2026-103572.** CVSS 8.8, exploited "No" at release on 13 October; user interaction required. The CVE record (updated 21 October) lists fixes in Visual Studio 2022 17.14.42 and Visual Studio 2026 18.10.4. Check: Visual Studio Installer shows those builds or later. [CVE-2026-103572 record](https://raw.githubusercontent.com/CVEProject/cvelistV5/main/cves/2026/103xxx/CVE-2026-103572.json) · [MSRC](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-103572).
- **OpenAI GPT-6 Cyber (5 November, limited access).** The Register reports that researchers used it to find 81 previously unknown high-severity Firefox bugs, which Mozilla has started fixing, and to build working exploits for 948 Linux kernel bugs. Expect a large Mozilla security release: keep the Firefox and Thunderbird patch window short. [The Register, 5 November](https://www.theregister.com/security/2026/11/05/openai-releases-gpt-6-cyber-and-promises-this-one-stays-within-rules-of-engagement/5307855) (openai.com could not be read today).
- **Copilot Studio agent metrics and alerts in Power Platform Monitor (MC1538998).** "This feature will reach general availability by December 4, 2026." Adds agent session success rate and recent sessions; "For agents in Managed Environments, admins can also configure custom thresholds and optional email notifications." Awareness only. [MC1538998](https://mc.merill.net/message/MC1538998).

More: [all AI security news](../topic/ai-security/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 6 November 2026. Runbook Lab is not affiliated with Microsoft.
