---
date:
  created: 2026-11-13 12:30:00
slug: data-compliance-this-week-2026-11-13
categories:
  - Data & compliance
description: "Data & compliance news to 13 November 2026: Purview DSPM partner previews retire 7 December, review DLP and Audit after MO1550821, eight MC updates logged."
rl_type: news
rl_area: data-compliance
rl_service: [purview, copilot, microsoft-365, exchange-online]
rl_kits: [copilot]
rl_controls: []
---

# Data & compliance this week: 10 changes (13 November 2026)

Ten confirmed Data & compliance items in the week to 13 November 2026: one Purview preview retirement, eight Message center updates and the ongoing Microsoft 365 incident MO1550821, which lists Purview DLP and Audit impact. The nearest fixed date is 7 December 2026, when Microsoft retires four Purview DSPM partner integrations in preview, so data security admins who use them should export what they need first.

<!-- more -->

This is our weekly Data & compliance roundup. Items rest on the facts Research read at each primary source between 8 and 10 November 2026. A search on 13 November found the MC1545691 page but not its text, so we did not count it as a re-read. Only the DSPM retirement asks for a decision before a fixed date; the rest are planning.

## Already briefed

1. **13 November, Microsoft 365 incident MO1550821 lists Purview impact.** Microsoft's status page says "Data Loss Prevention (DLP) across Microsoft 365 services" and "auto-labeling" "are impacted", and "Audit searches" and eDiscovery search and export "may also be impacted". Status at 07:29 UTC on 13 November: ongoing. **Who acts:** compliance and DLP admins, with the SOC. **Check:** [status.cloud.microsoft](https://status.cloud.microsoft/) > Microsoft 365 (Business or Enterprise) > Show details; after resolution, compare DLP matches and Audit records for the incident window with a normal day. Brief: [Microsoft 365 outage MO1550821](2026-11-13-microsoft-365-outage-mo1550821.md). Source: Microsoft service health status page, read 13 November 2026.

## New this week

### Purview DSPM partner integrations (Varonis, BigID, Cyera, OneTrust) retire 7 December 2026

MC1545691 (published 9 November, tagged Major change and Retirement; Worldwide, GCC, GCC High and DoD): "Effective December 7, 2026, we will retire the public preview experience" for the Data Security Posture Management partner integrations: Varonis (Salesforce), BigID (Databricks), Cyera (Snowflake) and OneTrust (GCP). After that date, "Data from those sources will no longer be ingested, processed, or displayed." Microsoft says "No action is required." It is a preview feature, so tenants that never turned these connectors on lose nothing. Tenants that did lose that view of Salesforce, Databricks, Snowflake or GCP data on 7 December.

- **Who acts:** data security and compliance admins who connected any of the four partner sources in DSPM.
- **Check:** Microsoft Purview portal > Data Security Posture Management, and note which of the four partner sources show data. If any do, export what you need and plan another view of those data sources before 7 December.
- **Source:** [MC1545691](https://mc.merill.net/message/MC1545691). Related: [Microsoft 365 security deadlines](../../guides/deadlines.md).

## Also logged

- **Purview DLP for external emails in Copilot, GA later (MC1301714).** "Updated November 6, 2026": GA now "early June 2027 (previously late January)" to "late June 2027 (previously late February)". Off unless enabled. Source: [MC1301714](https://mc.merill.net/message/MC1301714).
- **Purview DLP and Intune multi-admin approval for Edge for Business (MC1489971 v2).** "Beginning in late November 2026 … expected to complete by early December 2026 (previously mid-November)". "No action is required before rollout." Source: [MC1489971](https://mc.merill.net/message/MC1489971).
- **Annotate sensitivity-label protected PDFs on the web (MC1545696).** Arrives late January 2027, with no admin action. Labelled PDFs can then be annotated in the browser. Source: [MC1545696](https://mc.merill.net/message/MC1545696).
- **Outlook for Windows report in the Exchange admin center (MC1230889).** Retirement now "early April 2027 (previously early November 2026)". If a report or runbook uses it, you have until then to replace it. Source: [MC1230889](https://mc.merill.net/message/MC1230889).
- **Rewrite with Copilot in Edge for Business (MC1146821 v10).** Now "late January 2027 (previously end of October 2026)". On by default; the policy is InlineComposeEnabled. Source: [MC1146821](https://mc.merill.net/message/MC1146821).
- **Copilot onboarding (MC1486291).** Off by default, now "by late November 2026 (previously early November)". Source: [MC1486291](https://mc.merill.net/message/MC1486291).
- **Agent 365 agents as connected agents in declarative agents (MC1478975 v4).** Rollout "expected to complete by end of December 2026". Source: [MC1478975](https://mc.merill.net/message/MC1478975). Related: [Copilot Studio agent governance checklist](../../guides/copilot-studio-agent-governance-checklist.md).
- **Viva Insights (personal) and Viva Learning usage reports (MC1546411).** "retired from the Microsoft 365 admin center by mid-November 2026". Export anything you still report on. Source: [MC1546411](https://mc.merill.net/message/MC1546411).

Related this week: four of these items touch Copilot defaults and data handling (MC1301714, MC1146821, MC1486291 and MC1478975); see the [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md) and the [Microsoft 365 Copilot oversharing checklist](../../guides/microsoft-365-copilot-oversharing-checklist-jira.md). Earlier Purview items: [Data & compliance roundup, 6 November](2026-11-06-data-compliance-this-week.md).

More: [all Data & compliance news](../topic/data-compliance/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 13 November 2026. Runbook Lab is not affiliated with Microsoft.
