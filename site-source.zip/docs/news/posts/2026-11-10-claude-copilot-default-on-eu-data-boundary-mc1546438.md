---
date:
  created: 2026-11-10 10:30:00
slug: claude-copilot-default-on-eu-data-boundary-mc1546438
categories:
  - AI security
description: "MC1546438: Microsoft turns on Claude models in Copilot for EU and EFTA tenants on 9 December 2026. Opt out or scope access in the admin center before then."
rl_type: news
rl_service: [copilot]
rl_kits: [copilot]
rl_controls: []
---

# MC1546438: Claude in Copilot on by default 9 December

MC1546438 (published 10 November 2026) says Claude models from Anthropic in Microsoft Copilot move into the EU Data Boundary in early December 2026, and that "On December 9, 2026, Microsoft will enable Claude models for tenants that haven't made a selection". AI Administrators or Global Administrators of EU and EFTA tenants who don't want Claude on for every user must choose No users or Specific users and groups before 9 December 2026; a second post, MC1546429, turns Microsoft 365 Copilot in Power BI on by default a day earlier, on 8 December.

<!-- more -->

!!! note "Runbook card"
    **What changes:** Claude models in Copilot are "currently disabled by default for tenants in the EU and EFTA". On 9 December 2026 they are enabled for all users in tenants that haven't made an Anthropic selection, and the option to allow Claude only in Copilot in Microsoft 365 apps is retired: tenants using it move to All users. Processing for Claude in Copilot moves into the EU Data Boundary in early December 2026.<br>
    **Who:** admins of EU Data Boundary-eligible tenants in the EU and EFTA who manage access to AI models in Microsoft Copilot. Users there get Claude "across Microsoft Copilot experiences and in Microsoft Copilot Studio". Our suggestion: MSPs with EU clients should check each tenant.<br>
    **By when:** act by 9 December 2026 (the post's "Act by" date).<br>
    **Do this:** 1. Decide who may use Claude models in Copilot: everyone, nobody or a named group. 2. If not everyone, set the Anthropic setting to No users or Specific users and groups before 9 December and save. 3. If you use the "only in Copilot in Microsoft 365 apps" option, pick a new setting now: it moves to All users on 9 December. 4. Tell your helpdesk and compliance teams (Microsoft's ask). Our suggestion: record the decision for your data protection records.<br>
    **Check:** Microsoft 365 admin center > Copilot > Settings > View all > AI providers operating as Microsoft subprocessors > Anthropic (needs the AI Administrator or Global Administrator role).<br>
    **Source:** [MC1546438](https://mc.merill.net/message/MC1546438) (published 10 November 2026).

## What Microsoft says

MC1546438 is titled "Action may be required: Claude models in Copilot are coming into the EU Data Boundary and will be enabled by default". It is tagged "Major change", "New feature", "User impact" and "Admin impact", service Microsoft 365 Copilot Chat, Act by 9 December 2026.

The rollout schedule in the post:

- "Early December 2026: Processing for Claude models in Copilot moves into the EU Data Boundary."
- "December 9, 2026: Microsoft enables Claude models for tenants that haven't made a selection, and the option to allow them only in Copilot in Microsoft 365 apps will be retired."

What happens to each existing selection:

| Your Anthropic selection today | On 9 December 2026 |
|---|---|
| No selection made | Claude models "enabled for all users" |
| Only in Copilot in Microsoft 365 apps | Option retired; "your selection will move to All users" |
| Enabled (All users, or Specific users and groups) | Assignments don't change; processing moves into the EU Data Boundary once available |
| Disabled (No users) | "Your selection will be respected" |

Three more points from the post:

- "Until early December 2026, Claude models aren't covered by the EU Data Boundary processing commitment." Anthropic "continues to operate as a Microsoft subprocessor".
- Claude models in Copilot "are covered by Microsoft's enterprise data protection, and the Microsoft Product Terms and Data Protection Addendum apply, except as otherwise disclosed in Microsoft Learn documentation."
- "Anthropic models with Data Retention are governed by a separate setting and aren't part of this change." Check that setting on its own.

After 9 December, Microsoft says admins "can also disable the use of Claude models at any time". The post does not say how quickly a change reaches users, and does not name a PowerShell or Graph method for the setting.

## Same day: Copilot in Power BI on by default from 8 December (MC1546429)

MC1546429 (published 10 November 2026, tag "Retirement", Act by 8 December 2026) says "Beginning December 8, 2026, Microsoft 365 Copilot in Power BI will be enabled by default". This one is worldwide, not only EU and EFTA. The same post retires the standalone Copilot (preview) in Power BI: from the Power BI Home page, the mobile apps, Microsoft Teams, app-scoped Copilot and within Power BI workspace apps. The post gives two retirement dates: the body says "early January 2027" and the rollout schedule says "mid-January 2027". Microsoft hasn't said which is right.

The post says the standalone Copilot tenant setting and the "Show Copilot in app navigation" setting will be removed. It does not name the setting that controls Microsoft 365 Copilot in Power BI. Microsoft asks admins to tell affected people about the retirement and to review "Microsoft 365 Copilot in Power BI and Microsoft Fabric (preview), including its availability and requirements for your organization, ahead of the December 8 default-on date".

Our suggestion, not Microsoft's wording: Fabric and Power BI admins should note the state of the Copilot tenant settings in the Fabric admin portal now, so they can see what changed on 8 December. Source: [MC1546429](https://mc.merill.net/message/MC1546429).

## How to check

Read-only, in the portal:

1. Microsoft 365 admin center > Copilot > Settings > View all > AI providers operating as Microsoft subprocessors > Anthropic: note the current selection (No users, Specific users and groups, All users, or the option for Copilot in Microsoft 365 apps only). If nothing has ever been chosen, your tenant is in the group that is turned on.
2. Find the separate setting for Anthropic models with Data Retention (the post does not say where it is) and note its state; MC1546438 does not change it.
3. Our suggestion: Fabric admin portal > Tenant settings, note the Copilot settings as they are today.

## How to verify

After you save No users or Specific users and groups, open the Anthropic setting again and confirm the selection stuck. On 9 December or later, check it once more: Microsoft says "Other selections (All users, No users, or Specific users and groups) are respected."

## Impact and rollback

Choosing No users removes Claude models from Copilot for everyone, including people who already use them. Specific users and groups limits Claude to the people you name. Both can be changed later: Microsoft says admins "can disable Claude models or limit access at any time".

Related: the [Copilot Readiness kit](../../kits/copilot-readiness.md), [agents can read Copilot memory from December (MC1539004)](2026-11-06-work-iq-agents-read-copilot-memory.md), the [Copilot Studio agent governance checklist](../../guides/copilot-studio-agent-governance-checklist.md), every dated action on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [AI security news](../topic/ai-security/).

## Sources

- [MC1546438: Action may be required: Claude models in Copilot are coming into the EU Data Boundary and will be enabled by default](https://mc.merill.net/message/MC1546438) (published 10 November 2026; read 10 November 2026)
- [MC1546429: Power BI retiring standalone Copilot experiences (preview)](https://mc.merill.net/message/MC1546429) (published 10 November 2026; read 10 November 2026)

Message center posts are only visible inside a tenant's admin center; the links go to a public mirror (mc.merill.net). Last reviewed: 10 November 2026. Runbook Lab is not affiliated with Microsoft.
