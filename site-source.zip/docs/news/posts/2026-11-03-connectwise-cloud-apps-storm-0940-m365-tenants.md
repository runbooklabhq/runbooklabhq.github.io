---
date:
  created: 2026-11-03 09:55:00
slug: connectwise-cloud-apps-storm-0940-m365-tenants
categories:
  - Identity & access
description: "Hijacked ConnectWise cloud app identities were used against Microsoft 365 tenants. Search Entra for three App IDs and review audit logs from 15 October 2026."
rl_type: news
rl_service: [entra, other]
rl_kits: []
rl_controls: []
rl_tickets:
- summary: Hunt for the three ConnectWise App IDs in Entra ID
  priority: Highest
  steps:
  - 'Entra admin center > Enterprise applications > All applications: clear the Application type filter and search by ID, not by name: 506e08f9-6e9a-4da4-942b-a099a03644ae, 24205314-2b89-4e07-a2a4-579e898a5640, 0de14c77-b9b0-4137-9360-34878a929827.'
  - Also check the apps on the ConnectWise Trust Center list (https://www.connectwise.com/company/trust/advisories#cloudbackup).
  - For each service principal found, list its credentials and directory role assignments (read-only Graph PowerShell in the brief).
  source: https://www.microsoft.com/en-us/security/blog/2026/10/21/storm-0940-uses-artex-agentic-ai-connectwise-supply-chain-compromise/
- summary: Review ConnectWise app sign-ins and audit logs from 15 October 2026
  priority: Highest
  steps:
  - 'Sign-in logs > Service principal sign-ins: filter by each App ID; Microsoft says extend the review to 1 October where records exist and look at failed authentications and volume anomalies.'
  - 'Audit logs from 15 October 2026: credential additions, new applications, service principals or owners, app-role assignments and consent grants, privileged role assignments, and changes to users and groups.'
  - If you have Defender XDR, run the advanced hunting queries in Microsoft's post. No results is not proof that no access occurred.
  source: https://www.microsoft.com/en-us/security/blog/2026/10/21/storm-0940-uses-artex-agentic-ai-connectwise-supply-chain-compromise/
- summary: Keep old ConnectWise connections disabled; re-authorise only via the new app
  priority: High
  steps:
  - 'Do not delete the enterprise apps first: preserve configuration and evidence.'
  - Keep the old ConnectWise application connections disabled.
  - Re-authorise each tenant only through the new ConnectWise Cloud Backup for M365 app, from ConnectWise's own instructions, never from an emailed link. Plan the backup gap with your MSP or customers.
  - If you find something, an authorised responder removes confirmed unauthorised credentials, grants, owners, assignments and identities, after preserving configuration and evidence.
  source: https://status.connectwise.com/pages/incident/619cf82551fec9053d612f09/6ad263692dc48705ab3da2cb
---

# ConnectWise cloud apps hijacked: check these three App IDs

On 21 October 2026 Microsoft said an actor it tracks as Storm-0940, which it assesses was behind the ConnectWise compromise, took control of several ConnectWise cloud application identities and used the trust those apps already had to authenticate into customer Microsoft 365 tenants. MSPs and every organisation that consented to a ConnectWise cloud app (Cloud Backup, formerly SkyKick) should search Entra ID for three App IDs and review app activity from at least 15 October.

<!-- more -->

!!! note "Runbook card"
    **What changes:** stolen ConnectWise app credentials were used to authenticate to Microsoft 365 tenants, followed in some tenants by "application credential modifications to establish persistence, and changes involving identities, groups, and privileged roles" (Microsoft).<br>
    **Who:** MSPs and tenants with any ConnectWise cloud app consented: ConnectWise Cloud Backup, ConnectWise - MS Teams, ConnectWise - MS Graph, and any app on the ConnectWise Trust Center list.<br>
    **By when:** now. ConnectWise's incident is still open ("IDENTIFIED", last update 28 October 2026).<br>
    **Do this:** 1. Search Enterprise applications for the three App IDs below, by ID, not by name. 2. Review service principal sign-ins and audit logs from at least 15 October 2026 for credential additions, new owners, consent grants and role assignments. 3. Keep the old ConnectWise connections disabled and re-authorise only through the new "ConnectWise Cloud Backup for M365" app. Do not delete the enterprise apps first: preserve the evidence.<br>
    **Check:** Entra admin center > Enterprise applications > All applications, clear the Application type filter, search each App ID.<br>
    **Source:** [Microsoft Security blog, 21 October 2026](https://www.microsoft.com/en-us/security/blog/2026/10/21/storm-0940-uses-artex-agentic-ai-connectwise-supply-chain-compromise/) and the [ConnectWise status page incident](https://status.connectwise.com/pages/incident/619cf82551fec9053d612f09/6ad263692dc48705ab3da2cb) (28 October 2026).

<p class="rl-jira" markdown>[Add to Jira (CSV)](../../tickets/connectwise-cloud-apps-storm-0940-m365-tenants.csv){ .rl-jira__link download } <span class="rl-jira__help">One Jira task per action in this brief. To import: as a Jira admin, Settings > System > External system import > CSV; date format yyyy-MM-dd; map Issue ID to Issue Id, and Summary, Issue Type, Priority, Due date, Labels and Description.</span></p>

## The three App IDs

Microsoft's hunting queries list these application IDs. Microsoft: "Search by application ID rather than display name."

| App ID | Name in Microsoft's query |
|---|---|
| `506e08f9-6e9a-4da4-942b-a099a03644ae` | ConnectWise Cloud Backup |
| `24205314-2b89-4e07-a2a4-579e898a5640` | ConnectWise - MS Teams |
| `0de14c77-b9b0-4137-9360-34878a929827` | ConnectWise - MS Graph |

Microsoft's guidance text says to inventory "all four application IDs listed in this profile", but the post lists three. ConnectWise says it "disabled the seven ConnectWise application identities posted on our Trust Center page" on 17 October 2026, so check the [ConnectWise Trust Center](https://www.connectwise.com/company/trust/advisories#cloudbackup) list as well.

## What Microsoft says

- Microsoft describes Storm-0940 as "a China-state aligned actor" and "assesses that Storm-0940 was responsible for the recently disclosed ConnectWise supply chain compromise of a multi-tenant application".
- After "acquiring control of the identities of multiple ConnectWise cloud applications", the actor's AI agents authenticated to customer environments, "effectively taking advantage of the already established trust by these apps within a tenant".
- Scale: "Storm-0940 used ARTEX to attempt to sign-in to more than 2,250 tenants." That is the number of tenants targeted with sign-in attempts, not the number compromised. Microsoft has not published a count of affected tenants.
- ARTEX is an agentic AI penetration testing framework; Microsoft says the actor used it to speed up "scanning and reconnaissance, password spraying, and OAuth application abuse at downstream victims".
- The activity "did not result from a compromise of or a vulnerability in Microsoft corporate systems, products, or services."

ConnectWise's status page says it "disabled the seven ConnectWise application identities" at 07:00 UTC on 17 October 2026 and "suspended Cloud Backup service by revoking certificates used for affected application connections". Its latest update (28 October 2026, headed "partner action required") says: "Partners must re-authorize each Microsoft 365 tenant using the new application, “ConnectWise Cloud Backup for M365,” to resume backup and restore operations." Affected components: Cloud Backup, Cloud Migration, Cloud Services Portal, SaaS Security & Cloud Automation.

## How to check (read-only)

With Microsoft Graph PowerShell (our commands; they only read):

```powershell
Connect-MgGraph -Scopes "Application.Read.All","RoleManagement.Read.Directory" -NoWelcome
$ids = "506e08f9-6e9a-4da4-942b-a099a03644ae","24205314-2b89-4e07-a2a4-579e898a5640","0de14c77-b9b0-4137-9360-34878a929827"
foreach ($id in $ids) {
  $sp = Get-MgServicePrincipal -Filter "appId eq '$id'" -Property Id,AppId,DisplayName,AccountEnabled,KeyCredentials,PasswordCredentials
  if (-not $sp) { "$id : not in this tenant"; continue }
  $sp | Select-Object DisplayName, AppId, Id, AccountEnabled | Format-Table
  "  Credentials on the service principal: keys $($sp.KeyCredentials.Count), secrets $($sp.PasswordCredentials.Count)"
  $sp.KeyCredentials + $sp.PasswordCredentials | Select-Object DisplayName, StartDateTime, EndDateTime | Format-Table
  Get-MgRoleManagementDirectoryRoleAssignment -Filter "principalId eq '$($sp.Id)'" | Select-Object RoleDefinitionId, DirectoryScopeId | Format-Table
}
```

A credential with a start date on or after 1 October 2026 that you did not add, or any directory role assignment you did not expect, needs investigating. Our note: this access uses the app's own credentials, not a user sign-in, so user sign-in logs and MFA prompts will not show it. Credentials added to the multi-tenant app itself are not visible here, which is why the logs matter.

In the portal:

1. Entra admin center > Monitoring & health > Sign-in logs > Service principal sign-ins: filter by each App ID. Microsoft says to extend this review "to October 1" where records exist and to investigate "failed authentications and volume anomalies".
2. Entra admin center > Monitoring & health > Audit logs, from 15 October 2026: look for what Microsoft lists, "application or service-principal credential additions; new applications, service principals, or owners; app-role assignments and consent grants; privileged role assignments; and changes to users" and groups.
3. If you have Defender XDR, run the advanced hunting queries in Microsoft's post. Microsoft warns that "the absence of results should not be treated as confirmation that no access occurred".

## If you find something

Microsoft's guidance: "Preserve configuration and evidence before making irreversible changes", "Do not delete enterprise applications as the first response", and "Keep affected ConnectWise application connections disabled until ConnectWise provides formal restoration instructions". Then an authorised responder removes "confirmed unauthorized credentials, grants, owners, assignments, and identities".

Impact: disabling the old apps stops ConnectWise Cloud Backup for that tenant until you re-authorise through the new app, so plan the backup gap with your MSP or customers. Re-authorise only from ConnectWise's own instructions, never from an emailed link.

Related: our [Conditional Access baseline guide](../../guides/entra-conditional-access-baseline-report-only.md), the [Microsoft 365 hardening checklist](../../guides/microsoft-365-hardening-checklist-jira.md) (control E05 restricts user consent to applications), the [PIM guide for Global Admins](../../guides/entra-privileged-access-pim-global-admins.md) for reviewing privileged role assignments, and more [Identity & access news](../topic/identity-access/).

## Sources

- [Microsoft Security blog: AI-driven, large-scale nation-state campaign using ARTEX enables supply chain compromise](https://www.microsoft.com/en-us/security/blog/2026/10/21/storm-0940-uses-artex-agentic-ai-connectwise-supply-chain-compromise/) (21 October 2026; read 3 November 2026)
- [ConnectWise status: ConnectWise Cloud Backup Issue Investigation](https://status.connectwise.com/pages/incident/619cf82551fec9053d612f09/6ad263692dc48705ab3da2cb) (16 to 28 October 2026; read 3 November 2026)

Last reviewed: 3 November 2026. Runbook Lab is not affiliated with Microsoft or ConnectWise.
