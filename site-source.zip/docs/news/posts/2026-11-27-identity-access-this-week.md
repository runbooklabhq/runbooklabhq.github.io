---
date:
  created: 2026-11-27 10:20:00
slug: identity-access-this-week-2026-11-27
categories:
  - Identity & access
description: "Identity news to 27 November 2026: Entra passkey registration in My Sign-ins changes in December, and MC1540327 on users who cannot use passkeys is updated."
rl_type: news
rl_area: identity
rl_service: [entra]
rl_kits: [sms, ca]
rl_controls: []
---

# Identity & access this week: 2 changes (27 November 2026)

Two confirmed Entra items from the week to 27 November 2026, both about the move away from SMS and voice MFA. The first one reaches every user who registers a passkey in Microsoft Authenticator: the screens in My Sign-ins change from early December 2026, so update your user guide before then.

<!-- more -->

This is our weekly Identity & access roundup. Items rest on the Message Center text as read on 27 November 2026. The week's identity P0, the Entra Connect Health API flaw, already has its own brief (below).

## Already briefed

1. **Entra Connect Health API flaw exposed tenant metadata, including admin and technical-contact email addresses; fixed by Microsoft on 19 November 2026.** No customer remediation is required; affected tenants were told through Azure Service Health. Warn admins about targeted phishing. Brief: [Entra Connect Health API flaw](2026-11-21-entra-connect-health-api-flaw-tenant-metadata-exposed.md).

## New this week

### MC1545694: new passkey registration screens in My Sign-ins, early to end of December 2026

Microsoft: "Microsoft Entra is updating the passkey registration in My Sign-ins for Microsoft Authenticator users, adding a checkbox, updated link text, and guided steps to start registration." The timeline moved on 20 November: "General Availability (Worldwide): Beginning in early December 2026 (previously mid-November) and expected to complete by end of December 2026". Microsoft asks organisations to "inform users and update guidance accordingly". Microsoft names no admin setting for this change.

- **Who acts:** identity admins and the help desk, before early December 2026.
- **Check:** your own passkey guide for users, and which screenshots show the My Sign-ins passkey steps.
- **Do this:** once the new screens appear, register a test passkey in Authenticator from My Sign-ins (Security info > Add sign-in method > Passkey) and replace old screenshots. Tell the help desk the screens change during December; keep both versions of the guide until the rollout ends.
- **Source:** [MC1545694](https://mc.merill.net/message/MC1545694) (published 9 November 2026, updated 20 November 2026, read 27 November 2026). Related: [SMS MFA Exit Kit](../../kits/sms-mfa-exit.md).

### MC1540327 updated: users who cannot use passkeys still need another method before 1 February 2027

Microsoft updated the content of MC1540327 on 20 November 2026; the dates did not change. Microsoft's summary: "Users relying solely on Microsoft-provided SMS/voice for MFA in sessions that don't support passkeys must register alternative methods or configure customer-managed telephony before SMS/voice retirement begins February 1, 2027 (July 1 for admins/external users)." If they do not, "these users may be blocked from completing MFA in those sessions". Our 13 November item on this post is still correct.

- **Who acts:** identity admins.
- **Check:** Entra admin center > Protection > Authentication methods > User registration details: filter for users whose only methods are SMS or voice call. Those users need another method if they sign in where passkeys are not supported.
- **Do this:** register Microsoft Authenticator or a FIDO2 key for them, or plan customer-managed telephony, before 1 February 2027 (1 July 2027 for Global Administrators and external users).
- **Source:** [MC1540327](https://mc.merill.net/message/MC1540327) (published 5 November 2026, updated 20 November 2026, read 27 November 2026). Guide: [Entra SMS and voice MFA retires 1 February 2027](../../guides/entra-sms-voice-mfa-retirement-passkeys.md).

Related guides: [Break-glass accounts and mandatory MFA: am I affected?](../../guides/break-glass-mandatory-mfa-am-i-affected.md) · [Conditional Access Baseline Kit](../../kits/conditional-access.md).

More: [all Identity & access news](../topic/identity-access/) · [Microsoft 365 security deadlines](../../guides/deadlines.md).

Last reviewed: 27 November 2026. Runbook Lab is not affiliated with Microsoft.
