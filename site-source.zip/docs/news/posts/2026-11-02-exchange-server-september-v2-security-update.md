---
date:
  created: 2026-11-02 23:15:00
slug: exchange-server-september-v2-security-update-cve-2026-96940
categories:
  - Email & collaboration
description: "Exchange Server September 2026 V2 security update fixes CVE-2026-96940. Servers with only the original September SU are still exposed: run Health Checker."
rl_type: news
rl_kits: []
rl_controls: []
---

# Exchange Server September V2 update fixes CVE-2026-96940

On 2 October 2026 Microsoft released a V2 of the September 2026 Exchange Server security updates, adding a fix for CVE-2026-96940, a flaw that lets a signed-in user read other people's mailboxes in the same organisation. On-premises and hybrid Exchange admins who installed only the original September update should install the V2 package on every Exchange server and Management Tools machine.

<!-- more -->

!!! note "Runbook card"
    **What changes:** the September 2026 V2 security update adds the fix for CVE-2026-96940 (Important, CVSS 8.8). The original September release does not include it.<br>
    **Who:** admins of Exchange Server SE RTM, Exchange 2019 CU14 and CU15, and Exchange 2016 CU23 (2016 and 2019 only with the Period 2 ESU), including hybrid management-only servers and Exchange Management Tools workstations. Exchange Online needs no action.<br>
    **By when:** now. Microsoft recommends applying it "at the earliest opportunity".<br>
    **Do this:** 1. Run the Exchange Health Checker on every Exchange server. 2. Install the September 2026 V2 SU for your version and CU wherever it is missing. 3. Reboot, confirm all Exchange services started, run Health Checker again.<br>
    **Check:** Health Checker output for each server (it reports servers that are behind on CUs or SUs).<br>
    **Source:** [Exchange Team blog: Released: September 2026 V2 Exchange Server Security Updates](https://techcommunity.microsoft.com/blog/exchange/released-september-2026-v2-exchange-server-security-updates/4561718) (2 October 2026) and the [Security Update Guide entry for CVE-2026-96940](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-96940) (2 October 2026).

## What Microsoft says

The Exchange Team: "The difference between the original September 2026 Security Update release and this V2 release is an addition of CVE-2026-96940." If your servers got the September update before 2 October, they do not have this fix.

The Security Update Guide lists CVE-2026-96940 as "Microsoft Exchange Server Elevation of Privilege Vulnerability", severity "Important", CVSS 3.1 base score 8.8, weakness CWE-1390 (weak authentication). Its FAQ explains the impact: "An authenticated attacker who successfully exploited this vulnerability could gain unauthorized access to other users' mailboxes within the same organization and read email messages and attachments. The vulnerability does not allow access across tenant boundaries."

Exploitation status, in Microsoft's words: "We identified the vulnerability internally and are not aware of active exploitation." The Security Update Guide marks it "Exploited: No", "Publicly disclosed: No" and "Exploitation More Likely". It is not in the CISA Known Exploited Vulnerabilities catalogue.

Microsoft also says the update "was published ahead of its intended schedule", which is why the release sequence looks unusual.

Affected builds that get the V2 SU:

| Version | CU | Access |
|---|---|---|
| Exchange Server SE | RTM | Standard |
| Exchange Server 2019 | CU14, CU15 | Period 2 ESU enrolment required |
| Exchange Server 2016 | CU23 | Period 2 ESU enrolment required |

Exchange Online: Microsoft "has already deployed a related service-side fix", so Exchange Online customers do not need to act. Hybrid organisations still need the SU on their on-premises servers, "even if they are used only for management purposes".

Microsoft has not published the KB numbers in the blog post; get the right package for your version and CU from the download KB linked there.

## Exchange 2016 and 2019: the ESU point

The blog states that "Only customers who enrolled in the Period 2 Extended Security Update (ESU) program are eligible to receive Exchange Server 2016 and 2019 security updates released between May and October 2026", and describes the Period 2 ESU program as "valid between May and October 2026". If you run 2016 or 2019 without the ESU, this fix is not available to you; Microsoft's advice is to "upgrade your organization to Exchange SE as soon as possible".

## How to check (read-only)

Run the [Exchange Server Health Checker](https://microsoft.github.io/CSS-Exchange/Diagnostics/HealthChecker/) from an Exchange Management Shell run as administrator. It reads configuration and writes a report; it changes nothing:

```powershell
# Every Exchange server in the organisation
Get-ExchangeServer | ?{$_.AdminDisplayVersion -Match "^Version 15"} | %{.\HealthChecker.ps1 -Server $_.Name}
.\HealthChecker.ps1 -BuildHtmlServersReport
```

To list the installed build on each server for your own records:

```powershell
Get-ExchangeServer | Select-Object Name, Edition, AdminDisplayVersion
Get-Command ExSetup.exe | ForEach-Object { $_.FileVersionInfo.ProductVersion }   # run on each server
```

Compare the build with Microsoft's Exchange build numbers list; Health Checker does this comparison for you and flags a missing SU.

## How to verify

After installing the V2 SU and rebooting, Health Checker no longer reports the server as behind on security updates, and all Exchange services are running:

```powershell
Get-Service MSExchange* | Where-Object { $_.StartType -ne 'Disabled' -and $_.Status -ne 'Running' } | Select-Object Name, Status
```

An empty result means every enabled Exchange service is running. If services are left disabled after setup, Microsoft says something interrupted the installation; see Workaround 1 in its "repair failed installations" article linked from the blog post.

## Impact and rollback

Microsoft lists two known issues with this release: published calendars (.ics) can return HTTP 500 to calendar apps, and a ContentEngine deadlock affects organisations with email in Korean. Both are "to be resolved in a future update". Microsoft does not recommend uninstalling security updates. SUs are cumulative, so a server on a supported CU needs only the latest SU, not every earlier one. If you change the Auth certificate after installing, re-run the Hybrid Configuration Wizard.

Related: the October Windows Server update issue that breaks [Exchange OWA and mail flow](2026-10-31-exchange-owa-mail-flow-october-windows-server-updates.md) (patch both, in a planned window), dated actions on [Microsoft 365 security deadlines](../../guides/deadlines.md), the [Exchange Online SMTP AUTH checklist](../../guides/exchange-online-smtp-auth-basic-auth-checklist.md) for hybrid estates, and more [Email & collaboration news](../topic/email-collaboration/).

## Sources

- [Exchange Team blog: Released: September 2026 V2 Exchange Server Security Updates](https://techcommunity.microsoft.com/blog/exchange/released-september-2026-v2-exchange-server-security-updates/4561718) (2 October 2026, version 3.0; read 2 November 2026)
- [Microsoft Security Update Guide: CVE-2026-96940](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2026-96940) (released 2 October 2026, revision 1; read 2 November 2026)
- [Help Net Security: Exchange Server vulnerability CVE-2026-96940](https://helpnetsecurity.com/2026/10/05/exchange-server-vulnerability-cve-2026-96940) (5 October 2026)

Last reviewed: 2 November 2026. Runbook Lab is not affiliated with Microsoft.
