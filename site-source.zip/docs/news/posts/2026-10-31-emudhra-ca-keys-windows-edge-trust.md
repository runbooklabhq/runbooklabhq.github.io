---
date:
  created: 2026-10-31 11:30:00
slug: emudhra-ca-keys-windows-edge-trust-lists
categories:
  - Endpoint & devices
description: "Windows and Edge remove the remaining 10 eMudhra (emSign) roots from 16 November 2026. Find certificates that chain to them and replace them before then."
rl_type: news
rl_area: endpoint
rl_service: [windows]
rl_kits: [mde]
rl_controls: []
---

# Windows and Edge drop all eMudhra roots from 16 Nov 2026

Microsoft released an out-of-band Windows update on 26 October 2026 and changed the Microsoft Edge trust list on 27 October to stop trusting seven eMudhra certificates, after eight eMudhra intermediate CA private keys were compromised. Endpoint and PKI admins must make sure these trust-list updates reach every device and replace any certificate that chains to the removed roots. Microsoft now removes the remaining 10 eMudhra roots as well, starting 16 November 2026.

<!-- more -->

!!! warning "Updated 11 November 2026: the remaining eMudhra roots go on 16 November"
    Microsoft added an "Update (November 10, 2026)" to its MSRC post: it "is removing the remaining eMudhra root certificates across its products and services, starting November 16, 2026", and "certificates that chain to these roots will no longer be trusted by default" once the change reaches devices. Previously this page said Microsoft was still evaluating these roots.

    - **Windows (16 Nov):** Microsoft "will remove the remaining 10 eMudhra roots from the Windows trusted root certificate list" through the automatic certificate trust update endpoint. Connected devices, "including those in Azure", get it automatically; disconnected devices need your own trust-list process.
    - **Edge and WebView2 (16 Nov):** a PKI Metadata component update removes default trust for "emSign Root CA - G1, emSign Root CA - C1, emSign ECC Root CA, and emSign Root TLS CA - G1". Devices check for it "every 10 hours and shortly after each new app launch".
    - **Azure Linux (16 Nov):** roots removed, VM and container images refreshed.
    - **Later, depending on upstream releases:** .NET container images (from 16 Nov), the .NET SDK (December 2026), the APIM self-hosted gateway image and the Microsoft Build of OpenJDK (after the Mozilla release on 16 November).
    - The seven certificates removed in October are also in the Windows security update of 10 November 2026.

    Microsoft says "Timing varies by product" and points to the Microsoft Trusted Root Program announcements for the full list of affected certificates. It does not name all 10 roots in the post; the four Edge names above are the ones it lists. **Do this before 16 November:** run the read-only checks below with the pattern `emSign|eMudhra`, find TLS and code-signing certificates on your own and your suppliers' endpoints that chain to an emSign root, and replace them.

!!! info "Updated 11 November 2026"
    The Exchange OWA and mail flow issue below is now "Resolved" in Windows release health by the Windows updates of 10 November 2026; install those on Exchange servers and the registry workaround is not needed. Details: [Exchange OWA and mail flow hit by October Windows updates](2026-10-31-exchange-owa-mail-flow-october-windows-server-updates.md).

!!! info "Updated 31 October 2026"
    Exchange Server admins: Microsoft lists a known issue where the October 2026 Windows Server updates can stop OWA sign-in and mail delivery on Exchange servers. Check and mitigate before you push further Windows Server updates to those hosts: [Exchange OWA and mail flow hit by October Windows updates](2026-10-31-exchange-owa-mail-flow-october-windows-server-updates.md).

!!! note "Runbook card"
    **What changes:** Windows and Edge no longer trust six eMudhra G3 roots and an AAA Certificate Services cross-sign (October). From 16 November 2026 Microsoft also removes the remaining 10 eMudhra roots, including emSign Root CA - G1, C1, ECC and TLS G1. Certificates that chain to them stop validating.<br>
    **Who:** every organisation with Windows, Edge or WebView2; most work for those with disconnected or WSUS-isolated devices, Azure VMs built from older images, or certificates that chain to eMudhra.<br>
    **By when:** the October removals apply now. The remaining roots go from 16 November 2026 (Windows, Edge, WebView2, Azure Linux); other products follow upstream releases.<br>
    **Do this:** 1. Confirm automatic certificate trust updates and Edge component updates reach devices. 2. Deliver the updated trust lists to disconnected devices. 3. Find and replace certificates that chain to eMudhra or emSign roots before 16 November.<br>
    **Check:** the `certutil` commands below on a sample of devices.<br>
    **Source:** [MSRC blog](https://www.microsoft.com/msrc/blog/2026/10/microsoft-response-to-compromised-emudhra-certificate-authority-keys) (26 October, updated 27 October and 10 November 2026) and [MC1529467](https://mc.merill.net/message/MC1529467).

## What Microsoft says

The issue involves "eight eMudhra intermediate certificate authority (CA) private keys, six associated with TLS and two with code signing". Because those keys could be recovered, Microsoft says they "could potentially be used to create certificates or sign content that appeared to come from a trusted CA". The issue "arose in eMudhra's certificate hierarchy and was not a compromise of Microsoft systems" (MC1529467).

The timeline, per the MSRC post:

- **20 October 2026:** Microsoft updated the Windows Disallowed Certificate Trust List to block the affected certificate authorities.
- **26 October 2026:** an out-of-band Windows update removed seven certificates from the Windows trust list: six eMudhra G3 roots and an AAA Certificate Services cross-sign.
- **27 October 2026:** Microsoft removed the same seven certificates from the Microsoft Edge trust list.
- A separate CRLSet update blocks affected TLS certificates in Edge and WebView2. It arrives through Edge's component updates, so "Customers do not need to install a new browser version" (MC1529467). Microsoft gives no date for it.

On 26 October Microsoft said it was "evaluating the remaining eMudhra roots separately". On 10 November it published the outcome: the remaining roots are removed from 16 November 2026 (see the update at the top of this page).

Eight keys and seven certificates are both correct: eight intermediate keys were compromised, and seven root or cross-sign certificates were removed.

## Who needs to act

Most connected Windows devices get these changes automatically. The ones that don't:

- devices that can't reach Windows Update for root and disallowed certificate updates (air-gapped networks, strict WSUS-only estates, proxies that block the certificate trust list download)
- Azure VMs and Virtual Machine Scale Sets that run disconnected or from old images. Microsoft says "Updated images are available in Azure Marketplace".
- any service or app whose TLS or code-signing certificate chains to one of the removed roots. It stops validating once the change reaches the client.

## How to check (read-only)

On a Windows device, from an elevated prompt:

```powershell
# Is any eMudhra certificate still in the trusted root store?
certutil -store Root | Select-String -Pattern "emSign|eMudhra" -Context 0,3

# When did this device last sync the disallowed list? (UTC)
$k = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\SystemCertificates\AuthRoot\AutoUpdate'
[DateTime]::FromFileTimeUtc([BitConverter]::ToInt64($k.DisallowedCertLastSyncTime, 0))

# Which machine certificates were issued by eMudhra?
Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Issuer -match 'emSign|eMudhra' } |
  Select-Object Subject, Issuer, NotAfter
```

For your own estate, search your certificate inventory (internal CA reports, load balancer and web server certificates, code-signing certificates from vendors) for issuers containing "eMudhra" or "emSign". Ask suppliers whose software is signed with eMudhra code-signing certificates whether they are re-signing.

## What to do

1. **Keep updates flowing.** Allow automatic Windows certificate trust updates and Edge component updates (Microsoft's first recommendation).
2. **Disconnected devices.** Distribute the updated Disallowed Certificate Trust List through your own process, as described in Microsoft Learn's [Configure trusted roots and disallowed certificates](https://learn.microsoft.com/windows-server/identity/ad-cs/configure-trusted-roots-disallowed-certificates).
3. **Azure.** Redeploy disconnected VMs and scale sets from the updated Marketplace images, and refresh your own golden images.
4. **Replace dependent certificates.** For anything that chains to the removed roots, get a replacement certificate or another trusted chain before the change reaches the clients that use it.

## How to verify

Re-run the `certutil -store Root` check: it should return no eMudhra G3 roots now, and no emSign or eMudhra roots once the 16 November change has reached the device. The disallowed sync time should be on or after 20 October 2026. A test connection to any service you re-issued should validate without warnings.

## Impact

A certificate that chains to a removed root fails validation: TLS warnings in Edge and apps that use the Windows store, and signature checks that fail for affected signed code. That is the intended result. Find those dependencies before your users do.

Related: our [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md) (keeping endpoint security updates current), every date we track on [Microsoft 365 security deadlines](../../guides/deadlines.md), and more [Endpoint & devices news](../topic/endpoint-devices/).

## Sources

- [MSRC blog: Microsoft's response to compromised eMudhra certificate authority keys](https://www.microsoft.com/msrc/blog/2026/10/microsoft-response-to-compromised-emudhra-certificate-authority-keys) (26 October 2026, "Update, October 27, 2026" and "Update (November 10, 2026)"; read by our news desk 31 October and 11 November 2026)
- [MC1529467 on the public message center mirror](https://mc.merill.net/message/MC1529467) (published 28 October 2026, read 31 October 2026)
- [Microsoft Learn: Configure trusted roots and disallowed certificates in Windows](https://learn.microsoft.com/windows-server/identity/ad-cs/configure-trusted-roots-disallowed-certificates)

Last reviewed: 11 November 2026. Runbook Lab is not affiliated with Microsoft.
