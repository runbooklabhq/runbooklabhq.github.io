---
title: Newsletter
description: One mail on Friday from Runbook Lab - what changed in Microsoft 365 security this week, whether it affects you and what to check. Free, no sales, unsubscribe link in every issue.
rl_type: about
rl_nl_place: newsletter-page
---

# Newsletter

<p class="rl-lead">One mail on Friday: what changed in Microsoft&nbsp;365 security this week, whether it affects you and what to check.</p>

<!--rl-newsletter-->

## What is in an issue

- **What changed**: the week's Microsoft&nbsp;365, Entra, Defender, Purview, Intune, Windows and Copilot changes that need someone to act, each with its date and its source.
- **Am I affected**: who has to act, and a read-only check where we have one.
- **What to do**: the first step, and a link to the full brief with impact and rollback.
- **Dates coming up**: deadlines in the coming weeks from the [deadlines guide](guides/deadlines.md).
- Nothing else. No sales mails, no sponsored items, and no open or click tracking.

## Urgent alerts

Tick "Urgent alerts" if you also want a short mail on the day a Microsoft&nbsp;365 change needs action now, for example an exploited vulnerability with a fix to deploy. Most weeks there is none.

## How it works

You get one mail asking you to confirm; nothing is sent until you do. Every issue has an unsubscribe link, and a reply reaches us at runbooklab@outlook.com. What we store, and where, is on the [Privacy](about/privacy.md) page.

Prefer a feed? Every brief is also on [RSS and our social accounts](about/follow.md).
