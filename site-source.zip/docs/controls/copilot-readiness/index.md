---
title: "Copilot readiness controls"
description: "The free Top 5 controls of the M365 Copilot Readiness Kit with steps, impact, rollback and read-only checks."
rl_type: controls
---

# Copilot readiness controls

<p class="rl-lead">Fix oversharing before Copilot finds it, then roll Copilot out with Purview guardrails.</p>

| ID | Control | Priority | Effort |
|---|---|---|---|
| CR01 | [Find the overshared sites before Copilot does](cr01-find-the-overshared-sites-before-copilot-does.md) | Highest | 2 h |
| CR02 | [Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery)](cr02-hide-the-riskiest-sites-from-copilot-while-you-fix-them.md) | Highest | 1 h |
| CR03 | [Make 'Specific people, view' the default sharing link and put an expiry on Anyone links](cr03-make-specific-people-view-the-default-sharing-link-and.md) | High | 1 h |
| CR04 | [Remove 'Everyone except external users' from sensitive sites and hide it in the people picker](cr04-remove-everyone-except-external-users-from-sensitive.md) | High | 2 h + site owner time |
| CR05 | [Confirm Copilot interactions are audited and searchable](cr05-confirm-copilot-interactions-are-audited-and-searchable.md) | High | 30 min |

These are the free Top 5. The [M365 Copilot Readiness Kit](../../kits/copilot-readiness.md) has all 24 controls, with the Jira import, Excel plan and read-only script.
