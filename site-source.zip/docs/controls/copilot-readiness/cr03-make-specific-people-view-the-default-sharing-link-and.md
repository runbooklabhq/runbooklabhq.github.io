---
title: "Make 'Specific people, view' the default sharing link and put an expiry on Anyone links"
description: "Make 'Specific people, view' the default sharing link and put an expiry on Anyone links. Every 'People in your organisation' link created today is\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Make 'Specific people, view' the default sharing link and put an expiry on Anyone links

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CR03</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Copilot readiness](../../kits/copilot-readiness.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Safer sharing defaults</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Any SharePoint Online plan. SharePoint Administrator role.

## Why it matters

Every 'People in your organisation' link created today is something Copilot can surface to the whole company tomorrow. Microsoft's guardrail step is to restrict company-wide and Anyone links at tenant level so new sharing is narrow by default.

## Steps

1. SharePoint admin center &gt; Policies &gt; Sharing: set 'File and folder links' default to 'Specific people (only the people the user specifies)' and the default permission to View.
2. Same page: if Anyone links stay allowed, set them to expire (for example 30 days) and limit them to View. If nobody needs them, lower the external sharing level for SharePoint and OneDrive to 'New and existing guests'.
3. For sites that must keep a different default, set it per site: Active sites &gt; site &gt; Sharing &gt; Default sharing link type.
4. Tell users in one short message: links now default to specific people; ask IT if you need a wider link.

## Impact on users

Changes only new links. Existing links keep working until they expire or are removed (CR01 finds them). Some users will need one extra click to share wider.

## Rollback

Set the defaults back on the same Sharing page. Changing the default affects new links only.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Online.SharePoint.PowerShell (SharePoint settings), ExchangeOnlineManagement (audit).
    Connect first:
    Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
    Connect-ExchangeOnline
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). CR05 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
Get-SPOTenant | Select-Object SharingCapability, OneDriveSharingCapability, DefaultSharingLinkType, DefaultLinkPermission, RequireAnonymousLinksExpireInDays | Format-List
```

## How to verify

Check output shows DefaultSharingLinkType = Direct, DefaultLinkPermission = View, and either Anyone links not allowed or RequireAnonymousLinksExpireInDays set to a value greater than 0.

## Sources

- [Change default sharing link (Microsoft Learn)](https://learn.microsoft.com/en-us/sharepoint/change-default-sharing-link)
- [Configure secure governed data foundation Microsoft 365 Copilot (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-365/copilot/configure-secure-governed-data-foundation-microsoft-365-copilot)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 Copilot Readiness Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 24 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=control-cr03){ .md-button .md-button--primary } [See the kit](../../kits/copilot-readiness.md){ .md-button }

</div>
