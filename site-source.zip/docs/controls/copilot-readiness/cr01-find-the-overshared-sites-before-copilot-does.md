---
title: "Find the overshared sites before Copilot does"
description: "Find the overshared sites before Copilot does. Copilot answers from everything a user can open."
rl_type: control
rl_reviewed: 2026-10-28
---

# Find the overshared sites before Copilot does

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CR01</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Copilot readiness](../../kits/copilot-readiness.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Find and fix oversharing</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Data access governance reports and EEEU insights are part of SharePoint Advanced Management, which Microsoft includes with Microsoft 365 Copilot licences. DSPM data risk assessments need Microsoft Purview (check your plan). SharePoint Administrator role.

## Why it matters

Copilot answers from everything a user can open. Sites shared with 'Everyone except external users', broken inheritance and old company-wide links are the usual source of 'how did Copilot find the salary sheet'. Microsoft's blueprint starts here: identify high-risk sites and content first.

## Steps

1. SharePoint admin center &gt; Reports &gt; Data access governance: run the permission state report for SharePoint sites and the 'Everyone except external users' (EEEU) insights. Export both.
2. If you have Microsoft Purview DSPM: run the data risk assessment for oversharing (overshared sites with sensitive data, risky sharing links, frequently accessed content).
3. Sort by sensitivity (HR, finance, legal, board, M&A first) and by audience size. Put the top 20 sites in the tracker with a named owner each.
4. Run the read-only check below to list sites that allow sharing with anyone or with guests, and add the sensitive ones to the same list.

## Impact on users

None. Reports and the check only read data. Report generation can take hours on large tenants.

## Rollback

Nothing to roll back.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Online.SharePoint.PowerShell (SharePoint settings), ExchangeOnlineManagement (audit).
    Connect first:
    Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
    Connect-ExchangeOnline
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). CR05 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
$s = Get-SPOSite -Limit All | Where-Object { $_.SharingCapability -ne 'Disabled' }
"Sites with external sharing on: $($s.Count)"
$s | Group-Object SharingCapability | ForEach-Object { "$($_.Name): $($_.Count)" }
$s | Where-Object { $_.SharingCapability -eq 'ExternalUserAndGuestSharing' } | Select-Object -First 50 | ForEach-Object { "Anyone links allowed: $($_.Url)" }
```

## How to verify

A list of high-risk sites with an owner for each exists in the tracker, and the DAG/EEEU reports are saved with the date they were run.

## Sources

- [Microsoft 365 Copilot blueprint oversharing (Microsoft Learn)](https://learn.microsoft.com/en-us/copilot/microsoft-365/microsoft-365-copilot-blueprint-oversharing)
- [Configure secure governed data foundation Microsoft 365 Copilot (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-365/copilot/configure-secure-governed-data-foundation-microsoft-365-copilot)
- [Advanced management (Microsoft Learn)](https://learn.microsoft.com/en-us/sharepoint/advanced-management)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 Copilot Readiness Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 24 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=control-cr01){ .md-button .md-button--primary } [See the kit](../../kits/copilot-readiness.md){ .md-button }

</div>
