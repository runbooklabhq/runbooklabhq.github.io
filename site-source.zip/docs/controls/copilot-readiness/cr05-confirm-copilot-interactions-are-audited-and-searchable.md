---
title: "Confirm Copilot interactions are audited and searchable"
description: "Confirm Copilot interactions are audited and searchable. When someone asks 'who saw this through Copilot?', the audit log is your only evidence."
rl_type: control
rl_reviewed: 2026-10-28
---

# Confirm Copilot interactions are audited and searchable

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CR05</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Copilot readiness](../../kits/copilot-readiness.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Copilot audit and evidence</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">30 min</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Audit (Standard), included in Microsoft 365 business and enterprise plans. Longer audit retention needs Audit (Premium) or a retention add-on. Audit Logs or View-Only Audit Logs role.

## Why it matters

When someone asks 'who saw this through Copilot?', the audit log is your only evidence. Copilot interactions are logged as part of Audit (Standard) under the CopilotInteraction record type, but only if auditing is on in your tenant. Check it before the pilot, not after the first incident.

## Steps

1. Run the read-only check: it confirms unified audit log ingestion is on and counts CopilotInteraction records in the last 7 days.
2. If ingestion is off, turn it on in Microsoft Purview &gt; Audit (a tenant change; allow up to 60 minutes).
3. Microsoft Purview &gt; Audit &gt; search Activities - operation names: CopilotInteraction for one pilot user and save the search as your evidence procedure.
4. Decide how long to keep Copilot audit records and Copilot interactions (audit log retention policy and Data Lifecycle Management retention for Copilot). Write the decision in the tracker.

## Impact on users

Checking changes nothing. Turning on auditing has no user impact.

## Rollback

Not needed for the check. Do not turn auditing off.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Online.SharePoint.PowerShell (SharePoint settings), ExchangeOnlineManagement (audit).
    Connect first:
    Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
    Connect-ExchangeOnline
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). CR05 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
Get-AdminAuditLogConfig | Select-Object UnifiedAuditLogIngestionEnabled | Format-List | Out-String
$r = Search-UnifiedAuditLog -StartDate (Get-Date).AddDays(-7) -EndDate (Get-Date) -RecordType CopilotInteraction -ResultSize 1000
"CopilotInteraction records (last 7 days, max 1000): $(@($r).Count)"
```

## How to verify

UnifiedAuditLogIngestionEnabled is True and a CopilotInteraction search for a pilot user returns results; the retention decision is recorded.

## Sources

- [Audit Copilot (Microsoft Learn)](https://learn.microsoft.com/en-us/purview/audit-copilot)
- [Configure secure governed data foundation Microsoft 365 Copilot (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-365/copilot/configure-secure-governed-data-foundation-microsoft-365-copilot)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 Copilot Readiness Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 24 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=control-cr05){ .md-button .md-button--primary } [See the kit](../../kits/copilot-readiness.md){ .md-button }

</div>
