---
title: "Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery)"
description: "Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery). Fixing permissions on a big site takes weeks."
rl_type: control
rl_reviewed: 2026-10-28
---

# Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery)

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CR02</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Copilot readiness](../../kits/copilot-readiness.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Find and fix oversharing</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft 365 Copilot licence (SharePoint Advanced Management included). SharePoint sites only, not OneDrive. SharePoint Administrator role.

## Why it matters

Fixing permissions on a big site takes weeks. Restricted Content Discovery keeps a site's content out of organisation-wide search and Copilot answers in the meantime. Microsoft calls it an interim protection: remove it once access is fixed.

## Steps

1. SharePoint admin center &gt; Sites &gt; Active sites &gt; select the site &gt; Settings &gt; turn on 'Restrict content from Microsoft Copilot' &gt; Save. Or: Set-SPOSite -Identity &lt;site-url&gt; -RestrictContentOrgWideSearch $true (this changes the site; run it yourself, it is not part of the read-only script).
2. Apply it only to the high-risk sites from CR01. Microsoft advises using it selectively: every restricted site makes Copilot answers less complete.
3. Allow time. Sites with more than 500,000 items can take over a week to reflect the change.
4. Test with a pilot user who has access: ask Copilot about the site's content and check the answer no longer cites it.
5. Record a removal date per site in the tracker (when CR01's owner has fixed access).

## Impact on users

Copilot and organisation-wide search stop surfacing the site's content. Permissions do not change: users with access can still open files directly, and searches from inside the site still work. AI entry points such as the Copilot button and agent creation are removed on that site.

## Rollback

Turn the setting off on the site (or Set-SPOSite -Identity &lt;site-url&gt; -RestrictContentOrgWideSearch $false). Allow the same propagation time.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Online.SharePoint.PowerShell (SharePoint settings), ExchangeOnlineManagement (audit).
    Connect first:
    Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
    Connect-ExchangeOnline
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). CR05 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
Get-SPOTenant | Select-Object DelegateRestrictedContentDiscoverabilityManagement | Format-List | Out-String
'Existing Restricted Content Discovery reports:'
Get-SPORestrictedContentDiscoverabilityReport
```

## How to verify

Every high-risk site from CR01 either has access fixed or has 'Restrict content from Microsoft Copilot' on, with a removal date in the tracker. A pilot user's Copilot answer no longer cites the restricted site.

## Sources

- [Restricted content discovery (Microsoft Learn)](https://learn.microsoft.com/en-us/sharepoint/restricted-content-discovery)
- [Configure secure governed data foundation Microsoft 365 Copilot (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-365/copilot/configure-secure-governed-data-foundation-microsoft-365-copilot)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 Copilot Readiness Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 24 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=control-cr02){ .md-button .md-button--primary } [See the kit](../../kits/copilot-readiness.md){ .md-button }

</div>
