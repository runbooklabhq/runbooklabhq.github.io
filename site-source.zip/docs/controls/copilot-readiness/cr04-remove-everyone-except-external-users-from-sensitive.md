---
title: "Remove 'Everyone except external users' from sensitive sites and hide it in the people picker"
description: "Remove 'Everyone except external users' from sensitive sites and hide it in the people picker. 'Everyone except external users' (EEEU) gives every\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Remove 'Everyone except external users' from sensitive sites and hide it in the people picker

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CR04</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Copilot readiness](../../kits/copilot-readiness.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Safer sharing defaults</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h + site owner time</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Site access reviews and EEEU insights: SharePoint Advanced Management (included with Microsoft 365 Copilot licences). People picker setting: any SharePoint Online plan.

## Why it matters

'Everyone except external users' (EEEU) gives every employee access in one click. On a sensitive site it means Copilot can use that content for anyone who asks. Microsoft's remediation step is to remove company-wide groups and links from overshared sites, starting with site access reviews.

## Steps

1. From the EEEU insights (CR01), start a site access review for each sensitive site so the site owner removes EEEU and company-wide links (SharePoint admin center &gt; Reports &gt; Data access governance &gt; select the report &gt; Initiate site access review).
2. Where owners do not respond within the deadline, remove EEEU from the site permissions yourself and record it in the tracker.
3. Hide the EEEU claim in the people picker so new grants are harder: Set-SPOTenant -ShowEveryoneExceptExternalUsersClaim $false (a tenant change; run it yourself after telling the helpdesk).
4. Re-run the EEEU insights report after 28 days and compare.

## Impact on users

People who relied on EEEU lose access to that site and may raise tickets. Hiding the claim does not remove existing EEEU grants; it only stops new ones from the people picker.

## Rollback

Re-add the group to the site if a business need is confirmed (prefer a named group). Show the claim again with -ShowEveryoneExceptExternalUsersClaim $true.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Online.SharePoint.PowerShell (SharePoint settings), ExchangeOnlineManagement (audit).
    Connect first:
    Connect-SPOService -Url https://<tenant>-admin.sharepoint.com
    Connect-ExchangeOnline
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). CR05 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
Get-SPOTenant | Select-Object ShowEveryoneExceptExternalUsersClaim, ShowAllUsersClaim, ShowEveryoneClaim | Format-List
```

## How to verify

Sensitive sites from CR01 no longer grant EEEU; the next EEEU insights report shows fewer items; ShowEveryoneExceptExternalUsersClaim is False.

## Sources

- [Advanced management (Microsoft Learn)](https://learn.microsoft.com/en-us/sharepoint/advanced-management)
- [Configure secure governed data foundation Microsoft 365 Copilot (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-365/copilot/configure-secure-governed-data-foundation-microsoft-365-copilot)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 Copilot Readiness Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 24 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/copilot-readiness-top5?utm_source=site&utm_campaign=control-cr04){ .md-button .md-button--primary } [See the kit](../../kits/copilot-readiness.md){ .md-button }

</div>
