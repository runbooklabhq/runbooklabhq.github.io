---
title: "Block high-risk agent identities with Conditional Access"
description: "Block high-risk agent identities with Conditional Access. Autonomous agents sign in with their own agent identity, not a user, so your user Conditional\u2026"
rl_type: control
rl_service: ["copilot", "entra"]
rl_reviewed: 2026-10-28
---

# Block high-risk agent identities with Conditional Access

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">AG05</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[AI agent hardening](../../kits/ai-agent-hardening.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Agent identities (Microsoft Entra Agent ID)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">30 min</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft Agent 365 + Entra ID P2 or Microsoft 365 E5 (risk-based), or Microsoft 365 E7. Agent risk is in preview.

## Why it matters

Autonomous agents sign in with their own agent identity, not a user, so your user Conditional Access policies don't cover them. Microsoft provides a policy that blocks agent identities that Entra ID Protection flags as high risk.

## Steps

1. Microsoft Entra admin center &gt; Entra ID &gt; Conditional Access &gt; Policies &gt; New policy.
2. Users, agents or workload identities &gt; What does this policy apply to? &gt; Agents &gt; Include: All agent identities.
3. Target resources &gt; Include: All resources.
4. Conditions &gt; Agent risk (Preview) &gt; Configure: Yes &gt; High.
5. Grant &gt; Block. Enable policy: Report-only. Review the impact, then switch to On.
6. Agents that act through a user account or an agent user need separate policies: a policy on agent identities does not cover agent users.

## Impact on users

Agent identities that ID Protection rates as high risk are blocked from signing in to all resources, including legitimate agents if the risk signal is a false positive. Agent users and agents acting on behalf of a user are not covered by this policy. Run it in Report-only first and check the sign-in logs for agents that would be blocked.

## Rollback

Set Enable policy back to Report-only or Off. Keep the policy so you can switch it on again after the review.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph (Conditional Access + agent identities), ExchangeOnlineManagement (audit search), Microsoft.PowerApps.Administration.PowerShell (data policies).
    Connect first:
    Connect-MgGraph -Scopes AgentIdentity.Read.All,Policy.Read.All
    Connect-ExchangeOnline
    Add-PowerAppsAccount
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). AG04 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
$p = Get-MgIdentityConditionalAccessPolicy -All | Where-Object { ($_ | ConvertTo-Json -Depth 10) -match 'agent' }
if (-not $p) { 'No Conditional Access policy references agents' } else { $p | ForEach-Object { "$($_.DisplayName) [state: $($_.State)]" } }
```

## How to verify

A policy targeting All agent identities with Agent risk = High and Block exists and is On (state: enabled) after the Report-only review.

## Sources

- [Policy agent block high risk (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/conditional-access/policy-agent-block-high-risk)
- [Agent ID (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/conditional-access/agent-id)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 AI Agent Hardening Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=control-ag05){ .md-button .md-button--primary } [See the kit](../../kits/ai-agent-hardening.md){ .md-button }

</div>
