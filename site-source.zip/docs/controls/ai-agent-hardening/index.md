---
title: "AI agent hardening controls"
description: "The free Top 5 controls of the M365 AI Agent Hardening Kit with steps, impact, rollback and read-only checks."
rl_type: controls
---

# AI agent hardening controls

<p class="rl-lead">Inventory, guardrails and accountable owners for Copilot Studio agents and Entra agent identities.</p>

| ID | Control | Priority | Effort |
|---|---|---|---|
| AG01 | [Inventory every agent in the tenant](ag01-inventory-every-agent-in-the-tenant.md) | Highest | 1 h |
| AG02 | [Require user authentication for Copilot Studio agents](ag02-require-user-authentication-for-copilot-studio-agents.md) | Highest | 30 min |
| AG03 | [Block HTTP requests and channels you don't use](ag03-block-http-requests-and-channels-you-don-t-use.md) | High | 1 h |
| AG04 | [Watch agent creation, publishing, sharing and authentication changes](ag04-watch-agent-creation-publishing-sharing-and.md) | High | 1 h |
| AG05 | [Block high-risk agent identities with Conditional Access](ag05-block-high-risk-agent-identities-with-conditional-access.md) | High | 30 min |

These are the free Top 5. The [M365 AI Agent Hardening Kit](../../kits/ai-agent-hardening.md) has all 20 controls, with the Jira import, Excel plan and read-only script.
