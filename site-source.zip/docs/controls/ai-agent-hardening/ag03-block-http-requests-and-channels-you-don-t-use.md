---
title: "Block HTTP requests and channels you don't use"
description: "Block HTTP requests and channels you don't use. The HTTP connector lets an agent call any endpoint, which is the easiest exfiltration path."
rl_type: control
rl_reviewed: 2026-10-24
---

# Block HTTP requests and channels you don't use

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">AG03</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[AI agent hardening](../../kits/ai-agent-hardening.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Copilot Studio guardrails</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-24">24 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Power Platform admin (included with Copilot Studio)

## Why it matters

The HTTP connector lets an agent call any endpoint, which is the easiest exfiltration path. Public channels (Direct Line websites, Facebook, WhatsApp) put agents in front of people outside your tenant. Block what you don't use; allow specific endpoints where you need them.

## Steps

1. List the channels and HTTP endpoints your approved agents actually use (AG01 inventory).
2. In the data policy for Copilot Studio environments, block 'HTTP', or keep it and use Configure connector &gt; Connector endpoints to allow only the endpoints you listed.
3. Block unused channels: 'Direct Line channels in Copilot Studio', 'Facebook channel in Copilot Studio', 'WhatsApp channel in Copilot Studio', 'Omnichannel in Copilot Studio', 'SharePoint channel in Copilot Studio'.
4. Block 'Skills with Copilot Studio' if no agent uses Azure Bot Service skills.
5. Keep connectors used together in the same data group (Business, Non-business or Blocked): mixing groups in one agent is a policy violation.

## Impact on users

Agents that call blocked endpoints or use blocked channels stop working on those channels and show a data policy error in Copilot Studio. Agents that mix connectors from different data groups are flagged as violations.

## Rollback

Move the connector or channel back to the Business or Non-business group in the same data policy and select Update policy.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph (Conditional Access + agent identities), ExchangeOnlineManagement (audit search), Microsoft.PowerApps.Administration.PowerShell (data policies).
    Connect first:
    Connect-MgGraph -Scopes AgentIdentity.Read.All,Policy.Read.All
    Connect-ExchangeOnline
    Add-PowerAppsAccount
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). AG04 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
$j = Get-DlpPolicy | ConvertTo-Json -Depth 30
foreach ($c in 'Direct Line channels in Copilot Studio','Facebook channel in Copilot Studio','WhatsApp channel in Copilot Studio','Omnichannel in Copilot Studio','SharePoint channel in Copilot Studio','Skills with Copilot Studio') { "$c referenced in a data policy: $($j -match [regex]::Escape($c))" }
"HTTP connector referenced: $($j -match '"HTTP"')"
```

## How to verify

In the data policy, HTTP is blocked or endpoint-filtered, and every channel not on your approved list is in the Blocked group.

## Sources

- [Admin data loss prevention (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-copilot-studio/admin-data-loss-prevention)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 AI Agent Hardening Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=control-ag03){ .md-button .md-button--primary } [See the kit](../../kits/ai-agent-hardening.md){ .md-button }

</div>
