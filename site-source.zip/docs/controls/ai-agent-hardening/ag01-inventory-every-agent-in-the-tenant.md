---
title: "Inventory every agent in the tenant"
description: "Inventory every agent in the tenant. You cannot govern agents you cannot see."
rl_type: control
rl_reviewed: 2026-10-24
---

# Inventory every agent in the tenant

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">AG01</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[AI agent hardening](../../kits/ai-agent-hardening.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Agent inventory & monitoring</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-24">24 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Any Microsoft 365 tenant. Inventory: Power Platform administrator, Global reader, or AI reader. Agent identities: AgentIdentity.Read.All (Agent ID Administrator for non-owners).

## Why it matters

You cannot govern agents you cannot see. Agents show up in two places: Copilot Studio agents in Power Platform environments, and Microsoft Entra agent identities, which act with their own permissions. Most tenants have never listed either.

## Steps

1. Power Platform admin center &gt; Manage &gt; Inventory (or Manage &gt; Copilot Studio). It lists agents built in Copilot Studio and in Microsoft 365 Copilot Agent Builder. Select Download to export the full list to CSV with owner, environment and created date.
2. Entra agent identities: Microsoft Entra admin center &gt; Agent ID, or run the read-only check below (Microsoft Graph, AgentIdentity.Read.All).
3. Record an owner and a business purpose for every agent in the tracker. An agent without a named owner goes on the review list.
4. Repeat monthly. New agents appear without any admin action.

## Impact on users

None. The inventory export and the Graph check only read data.

## Rollback

Nothing to roll back.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph (Conditional Access + agent identities), ExchangeOnlineManagement (audit search), Microsoft.PowerApps.Administration.PowerShell (data policies).
    Connect first:
    Connect-MgGraph -Scopes AgentIdentity.Read.All,Policy.Read.All
    Connect-ExchangeOnline
    Add-PowerAppsAccount
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). AG04 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
$u = 'https://graph.microsoft.com/v1.0/servicePrincipals/microsoft.graph.agentIdentity?$select=id,displayName,accountEnabled,agentIdentityBlueprintId,createdDateTime'
$all = @()
while ($u) { $r = Invoke-MgGraphRequest -Method GET -Uri $u; $all += $r.value; $u = $r.'@odata.nextLink' }
"Agent identities: $($all.Count)"
$all | ForEach-Object { "$($_.displayName) | enabled: $($_.accountEnabled) | created: $($_.createdDateTime)" }
```

## How to verify

Every Copilot Studio agent and every agent identity has an owner and a purpose recorded in the tracker.

## Sources

- [Power Platform inventory (Microsoft Learn)](https://learn.microsoft.com/en-us/power-platform/admin/power-platform-inventory)
- [Agentidentity list (Microsoft Learn)](https://learn.microsoft.com/en-us/graph/api/agentidentity-list?view=graph-rest-1.0)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 AI Agent Hardening Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=control-ag01){ .md-button .md-button--primary } [See the kit](../../kits/ai-agent-hardening.md){ .md-button }

</div>
