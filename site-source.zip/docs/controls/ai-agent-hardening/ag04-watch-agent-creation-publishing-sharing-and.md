---
title: "Watch agent creation, publishing, sharing and authentication changes"
description: "Watch agent creation, publishing, sharing and authentication changes. Copilot Studio logs maker activity to the Microsoft Purview audit log by default."
rl_type: control
rl_reviewed: 2026-10-24
---

# Watch agent creation, publishing, sharing and authentication changes

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">AG04</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[AI agent hardening](../../kits/ai-agent-hardening.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Agent inventory & monitoring</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-24">24 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft 365 audit (Standard). Users need an assigned Microsoft 365 licence for Copilot Studio events to be recorded.

## Why it matters

Copilot Studio logs maker activity to the Microsoft Purview audit log by default. The events that matter most are an agent being published, shared, or having its authentication changed. Reviewing them catches an agent that went public overnight.

## Steps

1. Microsoft Purview portal &gt; Solutions &gt; Audit. Filter Activities for Copilot Studio activities and save the search.
2. Review these operations weekly: BotCreate, BotUpdateOperation-BotPublish, BotUpdateOperation-BotShare, BotUpdateOperation-BotAuthUpdate, BotDelete.
3. If you use Microsoft Sentinel, send the audit events there and alert on BotUpdateOperation-BotAuthUpdate and BotUpdateOperation-BotShare.
4. For every unexpected event, confirm with the agent owner and record the outcome in the tracker.

## Impact on users

None. Searching the audit log and saving a search change nothing. A Sentinel connector only adds ingestion cost for the events you send.

## Rollback

Delete the saved search or disable the analytics rule.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph (Conditional Access + agent identities), ExchangeOnlineManagement (audit search), Microsoft.PowerApps.Administration.PowerShell (data policies).
    Connect first:
    Connect-MgGraph -Scopes AgentIdentity.Read.All,Policy.Read.All
    Connect-ExchangeOnline
    Add-PowerAppsAccount
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). AG04 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
$ops = 'BotCreate','BotUpdateOperation-BotPublish','BotUpdateOperation-BotShare','BotUpdateOperation-BotAuthUpdate','BotDelete'
$e = Search-UnifiedAuditLog -StartDate (Get-Date).AddDays(-30) -EndDate (Get-Date) -Operations $ops -ResultSize 5000
if (-not $e) { 'No Copilot Studio create/publish/share/auth/delete events in the last 30 days' } else { $e | Group-Object Operations | ForEach-Object { "$($_.Name): $($_.Count)" }; $e | Group-Object UserIds | ForEach-Object { "by $($_.Name): $($_.Count)" } }
```

## How to verify

A saved audit search (or SIEM rule) exists for the five operations, and last week's events were reviewed.

## Sources

- [Admin logging Copilot Studio (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-copilot-studio/admin-logging-copilot-studio)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 AI Agent Hardening Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=control-ag04){ .md-button .md-button--primary } [See the kit](../../kits/ai-agent-hardening.md){ .md-button }

</div>
