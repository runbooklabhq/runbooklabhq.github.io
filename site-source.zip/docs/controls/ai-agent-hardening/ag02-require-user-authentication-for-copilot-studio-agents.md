---
title: "Require user authentication for Copilot Studio agents"
description: "Require user authentication for Copilot Studio agents. An agent published with No authentication can be used by anyone who reaches its channel, and it\u2026"
rl_type: control
rl_service: ["copilot", "entra"]
rl_reviewed: 2026-10-28
---

# Require user authentication for Copilot Studio agents

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">AG02</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[AI agent hardening](../../kits/ai-agent-hardening.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Copilot Studio guardrails</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">30 min</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Power Platform admin (included with Copilot Studio)

## Why it matters

An agent published with No authentication can be used by anyone who reaches its channel, and it answers from whatever knowledge and tools the maker connected. Blocking one connector in a data policy makes authentication mandatory for publishing.

## Steps

1. Power Platform admin center &gt; Security &gt; Data and privacy &gt; Data policy.
2. Edit the policy that covers your Copilot Studio environments (or create one) and add the environments.
3. On Assign connectors, find 'Chat without Microsoft Entra ID authentication in Copilot Studio' and select Block.
4. Save, then open an agent in Copilot Studio: agents without authentication show an error banner and cannot be published until the maker selects Authenticate with Microsoft or Authenticate manually.
5. Tell makers before you switch it on. Use the downloadable violation list on the agent's Channels page to follow up.

## Impact on users

Makers can no longer publish agents set to No authentication: the Publish button is unavailable and an error banner appears until they choose Authenticate with Microsoft or Authenticate manually. Users must then sign in to chat with those agents. Microsoft Learn does not say whether agents already published without authentication keep working, so test on one environment first and tell makers before you switch it on.

## Rollback

Data policy &gt; Edit Policy: move the connector out of Blocked (or remove the environment from the policy) and select Update policy. Agent-level exemptions are no longer supported, so roll back per policy or environment.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph (Conditional Access + agent identities), ExchangeOnlineManagement (audit search), Microsoft.PowerApps.Administration.PowerShell (data policies).
    Connect first:
    Connect-MgGraph -Scopes AgentIdentity.Read.All,Policy.Read.All
    Connect-ExchangeOnline
    Add-PowerAppsAccount
    Note: Microsoft retires Search-UnifiedAuditLog on 15 Oct 2027 (MC1505599). AG04 will move to the Graph AuditLogQuery API before then.
    ```

```powershell
$j = Get-DlpPolicy | ConvertTo-Json -Depth 30
if ($j -match 'Chat without Microsoft Entra ID authentication') { 'Connector is referenced in at least one data policy: confirm it is in the Blocked group for every Copilot Studio environment' } else { 'Connector not referenced in any data policy: agents can be published without authentication' }
```

## How to verify

Trying to publish a test agent with No authentication fails with a data policy error.

## Sources

- [DLP example 3 (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-copilot-studio/dlp-example-3)
- [Admin data loss prevention (Microsoft Learn)](https://learn.microsoft.com/en-us/microsoft-copilot-studio/admin-data-loss-prevention)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the M365 AI Agent Hardening Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/ai-agent-hardening-top5?utm_source=site&utm_campaign=control-ag02){ .md-button .md-button--primary } [See the kit](../../kits/ai-agent-hardening.md){ .md-button }

</div>
