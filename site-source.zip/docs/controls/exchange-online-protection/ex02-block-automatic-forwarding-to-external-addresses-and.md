---
title: "Block automatic forwarding to external addresses and review the forwards that already exist"
description: "Block automatic forwarding to external addresses and review the forwards that already exist. Attackers who take over a mailbox add an inbox rule or\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Block automatic forwarding to external addresses and review the forwards that already exist

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">EX02</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Exchange Online protection](../../kits/exchange-online-protection.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Outbound mail and forwarding</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Any Exchange Online plan (EOP).

## Why it matters

Attackers who take over a mailbox add an inbox rule or mailbox forward to an outside address and read the mail quietly for months. Microsoft recommends AutoForwardingMode Off in the outbound spam policy for both Standard and Strict. The default Automatic value behaves differently from tenant to tenant, so Microsoft advises setting On or Off explicitly.

## Steps

1. List mailboxes that forward today (ForwardingSmtpAddress or ForwardingAddress set) and inbox rules that forward or redirect. Ask each owner whether the forward is still needed.
2. Defender portal &gt; Threat policies &gt; Anti-spam &gt; Anti-spam outbound policy (Default) &gt; Forwarding rules: set Automatic forwarding rules to Off - Forwarding is disabled.
3. For approved business forwards, create a custom outbound spam policy with forwarding On, scoped to those senders only, and limit the destination with a remote domain.
4. Tell the helpdesk about the NDR users will see: 5.7.520 Access denied, Your organization does not allow external forwarding.

## Impact on users

Users who forward mail to personal or partner mailboxes get an NDR. Internal forwarding is not affected.

## Rollback

Set the default outbound policy back to the previous value, or add the user to a custom outbound policy with forwarding On.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: ExchangeOnlineManagement module (3.x). DNS checks use Resolve-DnsName (Windows PowerShell 5.1 or PowerShell 7 on Windows).
    Connect first:
    Connect-ExchangeOnline
    Connect-IPPSSession   # only for the alert policy check (EX20)
    Role: Global Reader, Security Reader or View-Only Organization Management is enough for these reads.
    ```

```powershell
Get-HostedOutboundSpamFilterPolicy | ForEach-Object { "$($_.Name) | AutoForwardingMode: $($_.AutoForwardingMode)" }
$f = Get-Mailbox -ResultSize Unlimited | Where-Object { $_.ForwardingSmtpAddress -or $_.ForwardingAddress }
"Mailboxes with a forward: $(@($f).Count)"
$f | Select-Object -First 50 | ForEach-Object { "$($_.UserPrincipalName) -> $($_.ForwardingSmtpAddress)$($_.ForwardingAddress)" }
```

## How to verify

The Default outbound policy shows AutoForwardingMode Off; every remaining forward is in a named custom policy with an owner; a test inbox rule forwarding outside the tenant returns 5.7.520.

## Sources

- [Outbound spam policies external email forwarding (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-office-365/outbound-spam-policies-external-email-forwarding)
- [Recommended settings for EOP and office365 (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-office-365/recommended-settings-for-eop-and-office365)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Exchange Online Protection Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/exchange-online-protection-top5?utm_source=site&utm_campaign=control-ex02){ .md-button .md-button--primary } [See the kit](../../kits/exchange-online-protection.md){ .md-button }

</div>
