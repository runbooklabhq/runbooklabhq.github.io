---
title: "Turn on the Standard preset security policy for all users (Strict for priority accounts)"
description: "Turn on the Standard preset security policy for all users (Strict for priority accounts). Preset security policies apply Microsoft's recommended\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Turn on the Standard preset security policy for all users (Strict for priority accounts)

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">EX01</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Exchange Online protection](../../kits/exchange-online-protection.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Preset policies and baseline</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    EOP parts: any Exchange Online plan. Safe Links, Safe Attachments and impersonation in the presets: Defender for Office 365 Plan 1 or 2 (Business Premium, E5 or add-on).

## Why it matters

Preset security policies apply Microsoft's recommended anti-spam, anti-malware and anti-phishing settings (and, with Defender for Office 365, Safe Links, Safe Attachments and impersonation protection) without hand-tuning dozens of settings. Standard and Strict are assigned to nobody until you turn them on, and they take precedence over custom policies for the same recipients.

## Steps

1. Defender portal &gt; Email & collaboration &gt; Policies & rules &gt; Threat policies &gt; Preset security policies. Turn on Standard protection and assign it to all recipients (for example all accepted domains).
2. Turn on Strict protection for a group of priority accounts (executives, finance, admins). Strict wins over Standard for users in both.
3. In the Defender for Office 365 step, add up to 350 users and 50 custom domains to impersonation protection and list trusted senders that must never be flagged.
4. Write down any custom anti-spam or anti-phishing policies that target the same users: presets override them, so either retire them or exclude those users from the preset on purpose.

## Impact on users

Spam goes to Junk under Standard and to quarantine under Strict; high confidence phishing and malware go to quarantine that only admins can release. Expect a few legitimate bulk senders to move to Junk in the first week.

## Rollback

Turn the preset off (the recipient conditions are kept) or add the affected users as exceptions. The default policies still protect everyone in the meantime.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: ExchangeOnlineManagement module (3.x). DNS checks use Resolve-DnsName (Windows PowerShell 5.1 or PowerShell 7 on Windows).
    Connect first:
    Connect-ExchangeOnline
    Connect-IPPSSession   # only for the alert policy check (EX20)
    Role: Global Reader, Security Reader or View-Only Organization Management is enough for these reads.
    ```

```powershell
foreach ($n in 'Standard Preset Security Policy','Strict Preset Security Policy') { foreach ($r in @(Get-EOPProtectionPolicyRule -Identity $n -ErrorAction SilentlyContinue)) { "EOP | $n | State: $($r.State) | domains: $(@($r.RecipientDomainIs) -join ',') | groups: $(@($r.SentToMemberOf) -join ',')" }; foreach ($r in @(Get-ATPProtectionPolicyRule -Identity $n -ErrorAction SilentlyContinue)) { "MDO | $n | State: $($r.State)" } }
"Rules only exist after a preset was turned on once in the portal. No output above = presets never enabled."
```

## How to verify

Standard preset rule State is Enabled and covers all accepted domains; Strict covers the priority group; Configuration analyzer shows no policy weaker than Standard for those users.

## Sources

- [Preset security policies (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-office-365/preset-security-policies)
- [Recommended settings for EOP and office365 (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-office-365/recommended-settings-for-eop-and-office365)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Exchange Online Protection Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/exchange-online-protection-top5?utm_source=site&utm_campaign=control-ex01){ .md-button .md-button--primary } [See the kit](../../kits/exchange-online-protection.md){ .md-button }

</div>
