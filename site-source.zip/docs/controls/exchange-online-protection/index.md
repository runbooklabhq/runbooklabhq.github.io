---
title: "Exchange Online protection controls"
description: "The free Top 5 controls of the Exchange Online Protection Kit with steps, impact, rollback and read-only checks."
rl_type: controls
---

# Exchange Online protection controls

<p class="rl-lead">Preset policies, SPF, DKIM and DMARC to p=reject, no silent forwarding, and Defender for Office 365 set up properly.</p>

| ID | Control | Priority | Effort |
|---|---|---|---|
| EX01 | [Turn on the Standard preset security policy for all users (Strict for priority accounts)](ex01-turn-on-the-standard-preset-security-policy-for-all-users.md) | Highest | 2 h |
| EX02 | [Block automatic forwarding to external addresses and review the forwards that already exist](ex02-block-automatic-forwarding-to-external-addresses-and.md) | Highest | 2 h |
| EX03 | [Publish SPF and turn on DKIM signing for every domain that sends mail](ex03-publish-spf-and-turn-on-dkim-signing-for-every-domain.md) | Highest | 3 h |
| EX04 | [Publish DMARC for every domain and move it from p=none to p=reject](ex04-publish-dmarc-for-every-domain-and-move-it-from-p-none-to.md) | High | 1 h set-up + 4 to 8 weeks monitoring |
| EX05 | [Anti-malware: common attachments filter on with Reject, zero-hour auto purge on, admin-only quarantine](ex05-anti-malware-common-attachments-filter-on-with-reject.md) | High | 30 min |

These are the free Top 5. The [Exchange Online Protection Kit](../../kits/exchange-online-protection.md) has all 20 controls, with the Jira import, Excel plan and read-only script.
