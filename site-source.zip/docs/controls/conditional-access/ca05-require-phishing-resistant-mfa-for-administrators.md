---
title: "Require phishing-resistant MFA for administrators"
description: "Require phishing-resistant MFA for administrators. Administrators are the target of adversary-in-the-middle phishing, which defeats SMS, voice and push."
rl_type: control
rl_reviewed: 2026-10-28
---

# Require phishing-resistant MFA for administrators

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CA05</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Conditional Access](../../kits/conditional-access.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Strong authentication for everyone</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h + 7 days report-only</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft Entra ID P1 (included in Microsoft 365 Business Premium, E3 and E5). Passkeys (FIDO2) are available in all editions.

## Why it matters

Administrators are the target of adversary-in-the-middle phishing, which defeats SMS, voice and push. Microsoft recommends the built-in Phishing-resistant MFA strength (passkeys/FIDO2, Windows Hello for Business or platform credential, multifactor certificate-based authentication) for at least 14 admin roles, including Global, Security, Exchange, SharePoint, User, Helpdesk and Conditional Access Administrator.

## Steps

1. Run the read-only check: it lists policies that apply the phishing-resistant strength to directory roles and shows the methods each admin has registered.
2. Make sure every admin has registered a passkey or Windows Hello for Business before you enforce (use a Temporary Access Pass to bootstrap).
3. New policy: Users = Directory roles (Global, Application, Authentication, Billing, Cloud Application, Conditional Access, Exchange, Helpdesk, Password, Privileged Authentication, Privileged Role, Security, SharePoint and User Administrator); exclude EmergencyAccess.
4. Target resources = All resources. Grant = Require authentication strength &gt; Phishing-resistant MFA. Enable policy = Report-only, then On after the review.

## Impact on users

Admins who have only SMS, voice or Authenticator push are blocked from admin sign-ins until they register a phishing-resistant method.

## Rollback

Set the policy to Report-only or Off; issue a Temporary Access Pass to an admin who lost their key.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.SignIns, .Reports, .Identity.DirectoryManagement).
    Connect first:
    Connect-MgGraph -Scopes Policy.Read.All,AuditLog.Read.All,UserAuthenticationMethod.Read.All,Directory.Read.All
    Role: Global Reader or Security Reader is enough for these reads.
    ```

```powershell
$p = Get-MgIdentityConditionalAccessPolicy -All
$a = $p | Where-Object { $_.Conditions.Users.IncludeRoles -and ($_.GrantControls.AuthenticationStrength.Id -eq '00000000-0000-0000-0000-000000000004' -or $_.GrantControls.AuthenticationStrength.DisplayName -like 'Phishing*') }
"Admin phishing-resistant policies: $(@($a).Count)"
$a | ForEach-Object { "$($_.DisplayName) | $($_.State) | roles: $(@($_.Conditions.Users.IncludeRoles).Count)" }
Get-MgReportAuthenticationMethodUserRegistrationDetail -All | Where-Object { $_.IsAdmin } | ForEach-Object { "Admin $($_.UserPrincipalName) | methods: $($_.MethodsRegistered -join ',')" }
```

## How to verify

A policy with the Phishing-resistant MFA strength covers at least the 14 recommended roles and is On; every admin shows a passkey, FIDO2 or Windows Hello method.

## Sources

- [Policy admin phish resistant MFA (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/conditional-access/policy-admin-phish-resistant-mfa)
- [Concept authentication strengths (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-authentication-strengths)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Conditional Access Baseline Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=control-ca05){ .md-button .md-button--primary } [See the kit](../../kits/conditional-access.md){ .md-button }

</div>
