---
title: "Conditional Access controls"
description: "The free Top 5 controls of the Conditional Access Baseline Kit with steps, impact, rollback and read-only checks."
rl_type: controls
---

# Conditional Access controls

<p class="rl-lead">A Conditional Access baseline with phishing-resistant MFA for admins and no legacy sign-in paths.</p>

| ID | Control | Priority | Effort |
|---|---|---|---|
| CA01 | [Create two emergency access accounts, exclude them from every policy and alert on their use](ca01-create-two-emergency-access-accounts-exclude-them-from.md) | Highest | 2 h |
| CA02 | [Name policies by persona and create every new policy in Report-only first](ca02-name-policies-by-persona-and-create-every-new-policy-in.md) | Highest | 1 h |
| CA03 | [Require MFA for all users on all resources with an authentication strength](ca03-require-mfa-for-all-users-on-all-resources-with-an.md) | Highest | 2 h + 7 days report-only |
| CA04 | [Block legacy authentication for all users](ca04-block-legacy-authentication-for-all-users.md) | Highest | 1 h + 7 days report-only |
| CA05 | [Require phishing-resistant MFA for administrators](ca05-require-phishing-resistant-mfa-for-administrators.md) | Highest | 2 h + 7 days report-only |

These are the free Top 5. The [Conditional Access Baseline Kit](../../kits/conditional-access.md) has all 20 controls, with the Jira import, Excel plan and read-only script.
