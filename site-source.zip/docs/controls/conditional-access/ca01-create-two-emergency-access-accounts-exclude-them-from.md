---
title: "Create two emergency access accounts, exclude them from every policy and alert on their use"
description: "Create two emergency access accounts, exclude them from every policy and alert on their use. A Conditional Access mistake can lock every administrator out\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Create two emergency access accounts, exclude them from every policy and alert on their use

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CA01</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Conditional Access](../../kits/conditional-access.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Foundation and emergency access</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Accounts: any edition. Alert rule: Azure Monitor / Log Analytics (pay-as-you-go ingestion, usually small).

## Why it matters

A Conditional Access mistake can lock every administrator out of the tenant. Microsoft recommends at least two cloud-only emergency access accounts, excluded from policies that block or restrict access, protected with a passkey (FIDO2) or certificate-based authentication, and monitored so every sign-in raises an alert.

## Steps

1. Create two cloud-only accounts on the \*.onmicrosoft.com domain with the Global Administrator role assigned permanently. Do not tie them to a person, phone or federated domain.
2. Register a passkey (FIDO2 security key) or certificate-based authentication for each account and store the keys in two separate safe places.
3. Create a group (for example EmergencyAccess) with both accounts and exclude that group from every Conditional Access policy that blocks or restricts access.
4. Send sign-in logs to Log Analytics and create an alert rule: SigninLogs where the UserId is one of the two accounts, severity 0, action group that emails and texts the security team.
5. Put a 90-day review in the calendar: sign in with each account, confirm the alert fires, and check the accounts are still excluded.

## Impact on users

None for users. Two privileged accounts exist that bypass policy, which is why they need strong keys and alerting.

## Rollback

Remove the accounts from the role and disable them if the organisation decides on another recovery process. Do not remove the exclusion while the accounts exist.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.SignIns, .Reports, .Identity.DirectoryManagement).
    Connect first:
    Connect-MgGraph -Scopes Policy.Read.All,AuditLog.Read.All,UserAuthenticationMethod.Read.All,Directory.Read.All
    Role: Global Reader or Security Reader is enough for these reads.
    ```

```powershell
$p = Get-MgIdentityConditionalAccessPolicy -All
$p | Where-Object { $_.State -ne 'disabled' } | ForEach-Object { "$($_.DisplayName) | $($_.State) | excluded users: $(@($_.Conditions.Users.ExcludeUsers).Count) | excluded groups: $(@($_.Conditions.Users.ExcludeGroups).Count)" }
"Active policies with NO user or group exclusion (break-glass not excluded?): $(@($p | Where-Object { $_.State -ne 'disabled' -and -not $_.Conditions.Users.ExcludeUsers -and -not $_.Conditions.Users.ExcludeGroups }).Count)"
```

## How to verify

Two emergency accounts exist with phishing-resistant credentials; every active policy that blocks or restricts excludes them; a test sign-in raised the alert within minutes.

## Sources

- [Security emergency access (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Conditional Access Baseline Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=control-ca01){ .md-button .md-button--primary } [See the kit](../../kits/conditional-access.md){ .md-button }

</div>
