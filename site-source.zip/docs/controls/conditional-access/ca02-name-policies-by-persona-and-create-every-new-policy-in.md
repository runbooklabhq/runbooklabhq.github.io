---
title: "Name policies by persona and create every new policy in Report-only first"
description: "Name policies by persona and create every new policy in Report-only first. Policies that are created straight to On are the usual cause of lockouts."
rl_type: control
rl_reviewed: 2026-10-28
---

# Name policies by persona and create every new policy in Report-only first

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CA02</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Conditional Access](../../kits/conditional-access.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Foundation and emergency access</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft Entra ID P1 (included in Microsoft 365 Business Premium, E3 and E5).

## Why it matters

Policies that are created straight to On are the usual cause of lockouts. Report-only mode evaluates a policy on every sign-in and logs the result without enforcing it, so you see who would be blocked before anyone is. A naming convention (number, persona, app, control) keeps 15+ policies readable.

## Steps

1. Agree a naming convention, for example CA001-AllUsers-AllApps-RequireMFA, CA010-Admins-AllApps-PhishingResistant, CA020-AllUsers-Legacy-Block.
2. Run the read-only check to list every policy with its state and last change. Rename existing policies to the convention.
3. Rule for the team: every new or edited policy goes to Report-only for at least 7 days, then On after the sign-in log review.
4. Use What If (Conditional Access &gt; Policies &gt; What If) for a test user before switching a policy to On.

## Impact on users

None. Renaming and report-only change nothing for users.

## Rollback

Nothing to roll back.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.SignIns, .Reports, .Identity.DirectoryManagement).
    Connect first:
    Connect-MgGraph -Scopes Policy.Read.All,AuditLog.Read.All,UserAuthenticationMethod.Read.All,Directory.Read.All
    Role: Global Reader or Security Reader is enough for these reads.
    ```

```powershell
$p = Get-MgIdentityConditionalAccessPolicy -All
$p | Sort-Object DisplayName | ForEach-Object { "$($_.DisplayName) | $($_.State) | modified: $($_.ModifiedDateTime)" }
$p | Group-Object State | ForEach-Object { "State $($_.Name): $($_.Count)" }
```

## How to verify

Every policy follows the naming convention; new policies show state 'enabledForReportingButNotEnforced' for at least 7 days before 'enabled'.

## Sources

- [Concept conditional access report only (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-report-only)
- [Howto conditional access insights reporting (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/conditional-access/howto-conditional-access-insights-reporting)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Conditional Access Baseline Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=control-ca02){ .md-button .md-button--primary } [See the kit](../../kits/conditional-access.md){ .md-button }

</div>
