---
title: "Block legacy authentication for all users"
description: "Block legacy authentication for all users. Legacy protocols (IMAP, POP, SMTP AUTH from old clients, Exchange ActiveSync with basic credentials) cannot do\u2026"
rl_type: control
rl_service: ["entra"]
rl_reviewed: 2026-10-28
---

# Block legacy authentication for all users

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CA04</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Conditional Access](../../kits/conditional-access.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Block weak sign-in paths</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h + 7 days report-only</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft Entra ID P1 (included in Microsoft 365 Business Premium, E3 and E5).

## Why it matters

Legacy protocols (IMAP, POP, SMTP AUTH from old clients, Exchange ActiveSync with basic credentials) cannot do MFA, so a stolen password is enough. A single Block policy on the legacy client app types closes that path.

## Steps

1. Run the read-only check: it lists block policies on legacy client types and groups the last 7 days of sign-ins by client app.
2. New policy: Users = All users, exclude EmergencyAccess and any service account you still have to migrate. Target resources = All resources.
3. Conditions &gt; Client apps &gt; Configure = Yes; select only Exchange ActiveSync clients and Other clients. Grant = Block access. Enable policy = Report-only.
4. Review report-only results for 7 days, move the remaining apps to modern authentication, then switch to On.

## Impact on users

Apps and devices that sign in with legacy protocols stop working (old mail clients, scanners using SMTP AUTH with basic credentials, scripts).

## Rollback

Set the policy to Report-only or Off; add a temporary exclusion for one account while it is migrated.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.SignIns, .Reports, .Identity.DirectoryManagement).
    Connect first:
    Connect-MgGraph -Scopes Policy.Read.All,AuditLog.Read.All,UserAuthenticationMethod.Read.All,Directory.Read.All
    Role: Global Reader or Security Reader is enough for these reads.
    ```

```powershell
$p = Get-MgIdentityConditionalAccessPolicy -All
$b = $p | Where-Object { $_.GrantControls.BuiltInControls -contains 'block' -and ($_.Conditions.ClientAppTypes -contains 'exchangeActiveSync' -or $_.Conditions.ClientAppTypes -contains 'other') }
"Legacy-auth block policies: $(@($b).Count)"
$b | ForEach-Object { "$($_.DisplayName) | $($_.State)" }
$since = (Get-Date).ToUniversalTime().AddDays(-7).ToString('yyyy-MM-ddTHH:mm:ssZ')
Get-MgAuditLogSignIn -Filter "createdDateTime ge $since" -Top 1000 | Group-Object ClientAppUsed | Sort-Object Count -Descending | ForEach-Object { "Client app '$($_.Name)': $($_.Count) sign-ins (last 7 days, first 1000)" }
```

## How to verify

A legacy-auth block policy is On; the sign-in logs show no successful sign-ins with Exchange ActiveSync or Other clients.

## Sources

- [Policy block legacy authentication (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/conditional-access/policy-block-legacy-authentication)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Conditional Access Baseline Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=control-ca04){ .md-button .md-button--primary } [See the kit](../../kits/conditional-access.md){ .md-button }

</div>
