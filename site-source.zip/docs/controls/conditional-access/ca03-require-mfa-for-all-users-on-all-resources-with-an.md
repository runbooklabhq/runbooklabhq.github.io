---
title: "Require MFA for all users on all resources with an authentication strength"
description: "Require MFA for all users on all resources with an authentication strength. Microsoft's baseline is one policy for all users and all resources, with no\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Require MFA for all users on all resources with an authentication strength

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">CA03</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Conditional Access](../../kits/conditional-access.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Strong authentication for everyone</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h + 7 days report-only</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft Entra ID P1 (included in Microsoft 365 Business Premium, E3 and E5). Authentication strengths need P1.

## Why it matters

Microsoft's baseline is one policy for all users and all resources, with no app exclusions, that requires multifactor authentication. Using the built-in 'Multifactor authentication' authentication strength (instead of the older 'Require MFA' checkbox) lets you raise the bar to passwordless or phishing-resistant later without rebuilding the policy.

## Steps

1. Run the read-only check: it lists policies that target All users + All resources with MFA or an authentication strength, and counts users who are not registered for MFA.
2. New policy: Users = All users; exclude the EmergencyAccess group and, in hybrid tenants, the Directory Synchronization Accounts role. Target resources = All resources, no exclusions.
3. Grant = Grant access &gt; Require authentication strength &gt; Multifactor authentication. Enable policy = Report-only.
4. After 7 days, open the sign-in logs (Conditional Access / Report-only tab) and the Insights workbook: fix the users who would fail, then switch to On.
5. If you use external authentication methods, use 'Require multifactor authentication' instead: Microsoft says they are not compatible with authentication strength yet.

## Impact on users

Every user is asked for MFA when the session is evaluated. Users with no MFA method registered are prompted to register.

## Rollback

Set the policy back to Report-only (this stops enforcement immediately) or Off.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.SignIns, .Reports, .Identity.DirectoryManagement).
    Connect first:
    Connect-MgGraph -Scopes Policy.Read.All,AuditLog.Read.All,UserAuthenticationMethod.Read.All,Directory.Read.All
    Role: Global Reader or Security Reader is enough for these reads.
    ```

```powershell
$p = Get-MgIdentityConditionalAccessPolicy -All
$m = $p | Where-Object { $_.Conditions.Users.IncludeUsers -contains 'All' -and $_.Conditions.Applications.IncludeApplications -contains 'All' -and ($_.GrantControls.BuiltInControls -contains 'mfa' -or $_.GrantControls.AuthenticationStrength.Id) }
"All users + all resources MFA policies: $(@($m).Count)"
$m | ForEach-Object { "$($_.DisplayName) | $($_.State) | strength: $($_.GrantControls.AuthenticationStrength.DisplayName) | built-in: $($_.GrantControls.BuiltInControls -join ',')" }
$r = Get-MgReportAuthenticationMethodUserRegistrationDetail -All
"Users not registered for MFA: $(@($r | Where-Object { -not $_.IsMfaRegistered }).Count) of $(@($r).Count)"
```

## How to verify

One policy with All users + All resources + an authentication strength is On; the sign-in logs show no unexpected failures for 7 days.

## Sources

- [Policy all users MFA strength (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/conditional-access/policy-all-users-mfa-strength)
- [Concept authentication strengths (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-authentication-strengths)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Conditional Access Baseline Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/entra-conditional-access-top5?utm_source=site&utm_campaign=control-ca03){ .md-button .md-button--primary } [See the kit](../../kits/conditional-access.md){ .md-button }

</div>
