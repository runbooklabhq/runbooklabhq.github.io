---
title: "Check every device is onboarded and its sensor is healthy"
description: "Check every device is onboarded and its sensor is healthy. A device that is not onboarded, or whose sensor stopped reporting, is invisible to Defender: no\u2026"
rl_type: control
rl_service: ["defender"]
rl_reviewed: 2026-10-28
---

# Check every device is onboarded and its sensor is healthy

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">DE01</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Defender for Endpoint and ASR](../../kits/defender-endpoint-asr.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Onboarding and antivirus baseline</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft Defender for Endpoint Plan 1 or Plan 2, or Defender for Business. Sensor health report: View Data permission under TVM.

## Why it matters

A device that is not onboarded, or whose sensor stopped reporting, is invisible to Defender: no alerts, no ASR reports, no response actions. Microsoft calls out impaired communications and missing sensor data as risks that warrant investigation.

## Steps

1. Microsoft Defender portal &gt; Reports &gt; Device health and compliance &gt; Sensor health & OS: filter on Inactive, Impaired communications and No sensor data. Export the list.
2. Compare the device count with Intune (or your CMDB): every Windows device you manage should appear in Defender.
3. On a sample device, run the read-only check: the Sense service should be Running and the onboarding status should be 1.
4. Fix each gap (re-run the onboarding package or Intune onboarding policy) and record it in the tracker.

## Impact on users

None. Reports and the check only read data.

## Rollback

Nothing to roll back.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Windows with Microsoft Defender Antivirus (Defender PowerShell module is built in). No tenant connection.
    Run on 3-5 sample devices per device type (laptops, kiosks, servers) as administrator.
    Tenant-wide views are in the Microsoft Defender portal (Reports > Device health; Advanced hunting) as described in each control.
    ```

```powershell
Get-Service -Name Sense | Select-Object Name, Status, StartType | Format-List | Out-String
$s = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status' -ErrorAction SilentlyContinue
"OnboardingState (1 = onboarded): $($s.OnboardingState)"
```

## How to verify

No managed Windows device is missing from Defender or shows Inactive / Impaired communications / No sensor data for more than 7 days.

## Sources

- [Device health sensor health os (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-endpoint/device-health-sensor-health-os)
- [Troubleshoot onboarding (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-endpoint/troubleshoot-onboarding)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Defender for Endpoint and ASR Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 15 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=control-de01){ .md-button .md-button--primary } [See the kit](../../kits/defender-endpoint-asr.md){ .md-button }

</div>
