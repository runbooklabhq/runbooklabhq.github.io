---
title: "Put all ASR rules in Audit and block the three standard protection rules"
description: "Put all ASR rules in Audit and block the three standard protection rules. Attack surface reduction rules stop Office macros, scripts and credential theft\u2026"
rl_type: control
rl_service: ["defender"]
rl_reviewed: 2026-10-28
---

# Put all ASR rules in Audit and block the three standard protection rules

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">DE04</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Defender for Endpoint and ASR](../../kits/defender-endpoint-asr.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Attack surface reduction</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h + 2-4 weeks audit</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Defender for Endpoint Plan 1/2 or Defender for Business. Advanced hunting for audit events: Plan 2 / E5.

## Why it matters

Attack surface reduction rules stop Office macros, scripts and credential theft before they run. Turned on in Block all at once they also stop legitimate tools. Microsoft groups three rules as standard protection; the rest should run in Audit first so you see what would break.

## Steps

1. Intune &gt; Endpoint security &gt; Attack surface reduction &gt; create an Attack Surface Reduction Rules policy: all rules on Audit, assigned to all Windows devices.
2. In the same policy set the three standard protection rules to Block: abuse of exploited vulnerable signed drivers (56a863a9-875e-4185-98a7-b882c64b5ce5), credential stealing from LSASS (9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2), persistence through WMI event subscription (e6db77e5-3df2-4cf1-b95a-636979351e5b). Audit them for a week first if you run unusual management tools.
3. Leave the rest in Audit for 2-4 weeks so month-end jobs show up too.
4. Run the read-only check on sample devices to confirm the policy arrived (actions: 0 off, 1 Block, 2 Audit, 6 Warn).

## Impact on users

Audit has no user impact. Block on the standard rules rarely affects business apps but can block old drivers or management tools that use WMI persistence. If LSA protection is on, the LSASS rule adds nothing extra.

## Rollback

Set the rule back to Audit or Not configured in the Intune policy.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Windows with Microsoft Defender Antivirus (Defender PowerShell module is built in). No tenant connection.
    Run on 3-5 sample devices per device type (laptops, kiosks, servers) as administrator.
    Tenant-wide views are in the Microsoft Defender portal (Reports > Device health; Advanced hunting) as described in each control.
    ```

```powershell
$p = Get-MpPreference
$ids = @($p.AttackSurfaceReductionRules_Ids)
$act = @($p.AttackSurfaceReductionRules_Actions)
"ASR rules configured: $($ids.Count)"
for ($i = 0; $i -lt $ids.Count; $i++) { "$($ids[$i]) = $($act[$i])" }
```

## How to verify

Every Windows device reports all ASR rules in Audit (2) and the three standard protection rules in Block (1).

## Sources

- [Attack surface reduction rules reference (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-endpoint/attack-surface-reduction-rules-reference)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Defender for Endpoint and ASR Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 15 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=control-de04){ .md-button .md-button--primary } [See the kit](../../kits/defender-endpoint-asr.md){ .md-button }

</div>
