---
title: "Defender for Endpoint and ASR controls"
description: "The free Top 5 controls of the Defender for Endpoint and ASR Kit with steps, impact, rollback and read-only checks."
rl_type: controls
---

# Defender for Endpoint and ASR controls

<p class="rl-lead">Every device onboarded, tamper protection on, and ASR rules moved from Audit to Block without outages.</p>

| ID | Control | Priority | Effort |
|---|---|---|---|
| DE01 | [Check every device is onboarded and its sensor is healthy](de01-check-every-device-is-onboarded-and-its-sensor-is-healthy.md) | Highest | 1 h |
| DE02 | [Make sure Defender Antivirus is active with cloud protection and block at first sight](de02-make-sure-defender-antivirus-is-active-with-cloud.md) | Highest | 1 h |
| DE03 | [Turn on tamper protection tenant-wide](de03-turn-on-tamper-protection-tenant-wide.md) | Highest | 30 min |
| DE04 | [Put all ASR rules in Audit and block the three standard protection rules](de04-put-all-asr-rules-in-audit-and-block-the-three-standard.md) | High | 2 h + 2-4 weeks audit |
| DE05 | [Turn on network protection (audit, then block)](de05-turn-on-network-protection-audit-then-block.md) | High | 1 h + 2 weeks audit |

These are the free Top 5. The [Defender for Endpoint and ASR Kit](../../kits/defender-endpoint-asr.md) has all 15 controls, with the Jira import, Excel plan and read-only script.
