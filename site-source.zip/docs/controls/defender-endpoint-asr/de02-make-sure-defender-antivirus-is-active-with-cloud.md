---
title: "Make sure Defender Antivirus is active with cloud protection and block at first sight"
description: "Make sure Defender Antivirus is active with cloud protection and block at first sight. ASR rules, network protection and indicators only work when\u2026"
rl_type: control
rl_service: ["defender"]
rl_reviewed: 2026-10-28
---

# Make sure Defender Antivirus is active with cloud protection and block at first sight

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">DE02</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Defender for Endpoint and ASR](../../kits/defender-endpoint-asr.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Onboarding and antivirus baseline</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Microsoft Defender Antivirus (Windows); management through Intune or another tool. Defender for Endpoint Plan 1/2 or Defender for Business for central reporting.

## Why it matters

ASR rules, network protection and indicators only work when Defender Antivirus runs in active mode. Block at first sight, which Microsoft says can cut the response time for new malware from hours to seconds, needs cloud protection on and samples sent automatically.

## Steps

1. Intune &gt; Endpoint security &gt; Antivirus &gt; Create policy &gt; Windows &gt; Microsoft Defender Antivirus: Allow cloud protection = Allowed; Submit samples consent = Send safe samples automatically (or all samples).
2. Keep real-time protection on and don't disable block at first sight.
3. Assign to all Windows devices.
4. Run the read-only check on sample devices: AMRunningMode should be Normal (active), MAPSReporting 2, SubmitSamplesConsent 1 or 3, DisableBlockAtFirstSeen False.

## Impact on users

Files new to Microsoft can be held for a cloud check before they run. Microsoft says 'Never send' for samples stops block at first sight from working.

## Rollback

Change the Antivirus policy settings back in Intune.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Windows with Microsoft Defender Antivirus (Defender PowerShell module is built in). No tenant connection.
    Run on 3-5 sample devices per device type (laptops, kiosks, servers) as administrator.
    Tenant-wide views are in the Microsoft Defender portal (Reports > Device health; Advanced hunting) as described in each control.
    ```

```powershell
Get-MpComputerStatus | Select-Object AMRunningMode, RealTimeProtectionEnabled, AMProductVersion, AntivirusSignatureLastUpdated | Format-List | Out-String
Get-MpPreference | Select-Object MAPSReporting, SubmitSamplesConsent, DisableBlockAtFirstSeen | Format-List | Out-String
```

## How to verify

Sample devices report active mode, real-time protection on, MAPSReporting 2, automatic sample submission and block at first sight not disabled.

## Sources

- [Configure block at first sight Microsoft Defender antivirus (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-endpoint/configure-block-at-first-sight-microsoft-defender-antivirus)
- [EDR in block mode (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-endpoint/edr-in-block-mode)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Defender for Endpoint and ASR Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 15 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=control-de02){ .md-button .md-button--primary } [See the kit](../../kits/defender-endpoint-asr.md){ .md-button }

</div>
