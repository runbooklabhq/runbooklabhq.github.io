---
title: "Turn on tamper protection tenant-wide"
description: "Turn on tamper protection tenant-wide. Attackers who reach admin rights try to switch off real-time protection or add exclusions first."
rl_type: control
rl_service: ["defender"]
rl_reviewed: 2026-10-28
---

# Turn on tamper protection tenant-wide

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">DE03</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Defender for Endpoint and ASR](../../kits/defender-endpoint-asr.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Onboarding and antivirus baseline</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">30 min</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Defender for Endpoint Plan 1/2, Defender for Business or Microsoft Defender Antivirus (per Learn 'Applies to').

## Why it matters

Attackers who reach admin rights try to switch off real-time protection or add exclusions first. With tamper protection on, those settings can't be changed on the device, and exclusions can't be added or modified locally.

## Steps

1. Microsoft Defender portal &gt; Settings &gt; Endpoints &gt; Advanced features: turn on Tamper protection for the tenant (or use Intune for selected devices).
2. Run the read-only check on sample devices: IsTamperProtected should be True.
3. Tell the desktop team: changes to protected settings may appear to succeed but are silently blocked; use troubleshooting mode for legitimate changes.
4. Note: Microsoft is renaming tamper protection to controlled configuration in management experiences, with no change in behaviour.

## Impact on users

Local and Group Policy changes to protected antivirus settings and exclusions are ignored. Changes must come from your management tool or troubleshooting mode.

## Rollback

Turn tamper protection off in the portal or exclude a device in Intune (this lowers protection; prefer troubleshooting mode).

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Windows with Microsoft Defender Antivirus (Defender PowerShell module is built in). No tenant connection.
    Run on 3-5 sample devices per device type (laptops, kiosks, servers) as administrator.
    Tenant-wide views are in the Microsoft Defender portal (Reports > Device health; Advanced hunting) as described in each control.
    ```

```powershell
Get-MpComputerStatus | Select-Object IsTamperProtected, RealTimeProtectionEnabled | Format-List
```

## How to verify

IsTamperProtected is True on sample devices of every type.

## Sources

- [Prevent changes to security settings with tamper protection (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-endpoint/prevent-changes-to-security-settings-with-tamper-protection)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Defender for Endpoint and ASR Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 15 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=control-de03){ .md-button .md-button--primary } [See the kit](../../kits/defender-endpoint-asr.md){ .md-button }

</div>
