---
title: "Turn on network protection (audit, then block)"
description: "Turn on network protection (audit, then block). Network protection stops apps, not just browsers, from connecting to domains that host phishing, exploits\u2026"
rl_type: control
rl_service: ["defender"]
rl_reviewed: 2026-10-28
---

# Turn on network protection (audit, then block)

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">DE05</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Defender for Endpoint and ASR](../../kits/defender-endpoint-asr.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Network and web protection</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">1 h + 2 weeks audit</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Defender for Endpoint Plan 1/2 (Defender Antivirus active mode with real-time, behaviour monitoring and cloud protection on). Windows 10 1709+ / Windows 11 Pro or Enterprise.

## Why it matters

Network protection stops apps, not just browsers, from connecting to domains that host phishing, exploits and malware. It is also a prerequisite for web content filtering and indicators in browsers other than Edge.

## Steps

1. Intune &gt; Endpoint security &gt; Antivirus &gt; Microsoft Defender Antivirus policy: Enable network protection = Enabled (audit mode) for two weeks.
2. Review blocked-in-audit connections with the security team.
3. Switch to Enabled (block mode).
4. Windows Server: network protection is opt-in (AllowNetworkProtectionOnWinServer); on DNS, file servers and domain controllers set AllowDatagramProcessingOnWinServer to false.

## Impact on users

Block mode stops connections to malicious or suspicious domains for every app on the device. Users see a notification.

## Rollback

Set Enable network protection back to audit mode or Disabled.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Windows with Microsoft Defender Antivirus (Defender PowerShell module is built in). No tenant connection.
    Run on 3-5 sample devices per device type (laptops, kiosks, servers) as administrator.
    Tenant-wide views are in the Microsoft Defender portal (Reports > Device health; Advanced hunting) as described in each control.
    ```

```powershell
Get-MpPreference | Select-Object EnableNetworkProtection | Format-List | Out-String
'0 = off, 1 = block, 2 = audit'
```

## How to verify

EnableNetworkProtection is 1 (block) on sample devices after the audit period.

## Sources

- [Enable network protection (Microsoft Learn)](https://learn.microsoft.com/en-us/defender-endpoint/enable-network-protection)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Defender for Endpoint and ASR Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 15 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/defender-asr-top5?utm_source=site&utm_campaign=control-de05){ .md-button .md-button--primary } [See the kit](../../kits/defender-endpoint-asr.md){ .md-button }

</div>
