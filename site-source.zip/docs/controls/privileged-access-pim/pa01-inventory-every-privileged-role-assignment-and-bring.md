---
title: "Inventory every privileged role assignment and bring Global Administrators below five"
description: "Inventory every privileged role assignment and bring Global Administrators below five. You cannot protect admin access you have not listed."
rl_type: control
rl_service: ["entra"]
rl_reviewed: 2026-10-28
---

# Inventory every privileged role assignment and bring Global Administrators below five

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">PA01</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Privileged access and PIM](../../kits/privileged-access-pim.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Inventory and least privilege</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">3 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Inventory and role changes: any Microsoft Entra ID edition. Eligible counts are only non-zero when PIM is in use (Entra ID P2 or ID Governance).

## Why it matters

You cannot protect admin access you have not listed. Microsoft recommends fewer than five Global Administrator assignments (an alert card appears on the Entra Overview page at 5 or more) and fewer than 10 privileged role assignments, plus two cloud-only emergency access accounts that keep Global Administrator permanently. Microsoft Entra ID has more than 65 built-in roles, and the admin center marks the high-risk ones with a PRIVILEGED label (preview).

## Steps

1. Run the read-only check (PA01) or open Entra admin center &gt; Roles & admins &gt; All roles, add the Privileged column and filter on it. Export who holds each privileged role, active and eligible.
2. For every Global Administrator, write down the tasks that person really does and find the least privileged role for each task (for example Exchange Administrator, User Administrator, Helpdesk Administrator). Keep the list in the tracker.
3. Agree the target with the IT lead: fewer than five Global Administrator assignments in total, the two emergency access accounts included (so two named people at most), and fewer than 10 privileged role assignments in total.
4. Add the replacement roles first, confirm each person can still do their work for a few days, then remove Global Administrator from them.
5. Record the final list (role, person, reason, owner) and repeat the count every quarter in PA05.

## Impact on users

Admins who lose Global Administrator may hit a missing permission on a task they rarely do. Plan a short fallback: they activate the role through PIM (PA02) or ask one of the remaining Global Administrators.

## Rollback

Re-add the removed role to the person while you find the right least privileged role. Keep the change in the tracker so the role does not stay by accident.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.Governance, .Users, .DirectoryObjects, .Authentication).
    Connect first:
    Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
    Role: Global Reader is normally enough. If a PIM read is denied, run it as Privileged Role Administrator: the script still only reads.
    ```

```powershell
$roles = 'Global Administrator','Privileged Role Administrator','Privileged Authentication Administrator','Security Administrator','Conditional Access Administrator','Exchange Administrator','SharePoint Administrator','User Administrator','Authentication Administrator','Application Administrator','Cloud Application Administrator','Hybrid Identity Administrator','Intune Administrator'
foreach ($n in $roles) { $d = Get-MgRoleManagementDirectoryRoleDefinition -Filter "displayName eq '$n'"; if ($d) { $a = @(Get-MgRoleManagementDirectoryRoleAssignment -All -Filter "roleDefinitionId eq '$($d.Id)'"); $e = @(Get-MgRoleManagementDirectoryRoleEligibilityScheduleInstance -All -Filter "roleDefinitionId eq '$($d.Id)'"); "$n | active now: $($a.Count) | eligible: $($e.Count)" } }
"Target: Global Administrator active below 5 (including the two emergency accounts); privileged assignments below 10 in total."
```

## How to verify

The PA01 output shows fewer than five Global Administrator assignments and the Entra Overview page shows no Global Administrator alert card. Every privileged assignment has a named owner and reason in the tracker.

## Sources

- [Best practices (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/best-practices)
- [Privileged roles permissions (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/privileged-roles-permissions)
- [Security emergency access (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Privileged Access and PIM Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=control-pa01){ .md-button .md-button--primary } [See the kit](../../kits/privileged-access-pim.md){ .md-button }

</div>
