---
title: "Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people"
description: "Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people. Eligible roles only help\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">PA03</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Privileged access and PIM](../../kits/privileged-access-pim.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Just-in-time access with PIM</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    PIM: Microsoft Entra ID P2 or Microsoft Entra ID Governance (P2 is in Microsoft 365 E5 and EMS E5). Without one of these licences PIM shows the alert 'The organization doesn't have Microsoft Entra ID P2 or Microsoft Entra ID Governance'. Authentication context needs Conditional Access (Entra ID P1, included in P2).

## Why it matters

Eligible roles only help if activation is hard to abuse. PIM role settings control how long an activation lasts (1 to 24 hours), whether activation needs MFA or a Conditional Access authentication context, a justification or ticket number, and approval. Microsoft recommends at least two approvers, and warns that approval with no approvers configured can lock you out.

## Steps

1. Open ID Governance &gt; Privileged Identity Management &gt; Microsoft Entra roles &gt; Settings and open Global Administrator. You need at least Privileged Role Administrator to change settings.
2. Activation: set the maximum duration short (we suggest 4 hours or less for Global Administrator, Privileged Role Administrator and Privileged Authentication Administrator); require MFA, or better a Conditional Access authentication context that asks for phishing-resistant MFA; require justification.
3. Require approval to activate and select two named approvers who are not the same people who activate (keep the emergency access accounts outside this flow).
4. Assignment: turn off 'Allow permanent active assignment' (set an end date), set eligible assignments to expire (for example after 12 months, renewed in the PA05 review), and require MFA and justification on active assignment.
5. Notifications: send role activation alerts and assignment alerts to a monitored security mailbox as well as the default recipients. Repeat for Privileged Role Administrator and Privileged Authentication Administrator, then decide the settings for the other privileged roles from PA01.

## Impact on users

Activating a Tier 0 role takes longer (approval) and expires sooner, so admins plan work in shorter windows. If both approvers are away, activation waits: name a backup approver.

## Rollback

In the role's PIM settings switch off 'Require approval to activate' or raise the maximum duration. Changes apply to new activations; current activations keep their end time.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.Governance, .Users, .DirectoryObjects, .Authentication).
    Connect first:
    Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
    Role: Global Reader is normally enough. If a PIM read is denied, run it as Privileged Role Administrator: the script still only reads.
    ```

```powershell
foreach ($n in 'Global Administrator','Privileged Role Administrator','Privileged Authentication Administrator') { $d = Get-MgRoleManagementDirectoryRoleDefinition -Filter "displayName eq '$n'"; $u = "/v1.0/policies/roleManagementPolicyAssignments?`$filter=scopeId eq '/' and scopeType eq 'DirectoryRole' and roleDefinitionId eq '$($d.Id)'"; $pa = @((Invoke-MgGraphRequest -Method GET -Uri $u).value) | Select-Object -First 1; if (-not $pa) { "$n | no PIM policy returned (PIM not in use or no access)"; continue }; $r = (Invoke-MgGraphRequest -Method GET -Uri "/v1.0/policies/roleManagementPolicies/$($pa.policyId)?`$expand=rules").rules; $x = $r | Where-Object { $_.id -eq 'Expiration_EndUser_Assignment' }; $en = $r | Where-Object { $_.id -eq 'Enablement_EndUser_Assignment' }; $ap = $r | Where-Object { $_.id -eq 'Approval_EndUser_Assignment' }; $aa = $r | Where-Object { $_.id -eq 'Expiration_Admin_Assignment' }; "$n | max activation: $($x.maximumDuration) | on activation: $(@($en.enabledRules) -join ',') | approval required: $($ap.setting.isApprovalRequired) | active assignments must expire: $($aa.isExpirationRequired) ($($aa.maximumDuration))" }
```

## How to verify

For the three Tier 0 roles PA03 shows a maximum activation of PT4H or less, MultiFactorAuthentication and Justification on activation (or an authentication context), approval required True and active assignments must expire True. A test activation by one admin reaches both approvers.

## Sources

- [PIM how to change default settings (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/pim-how-to-change-default-settings)
- [Identity governance PIM rules overview (Microsoft Learn)](https://learn.microsoft.com/en-us/graph/identity-governance-pim-rules-overview)
- [How to PIM update rules (Microsoft Learn)](https://learn.microsoft.com/en-us/graph/how-to-pim-update-rules)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Privileged Access and PIM Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=control-pa03){ .md-button .md-button--primary } [See the kit](../../kits/privileged-access-pim.md){ .md-button }

</div>
