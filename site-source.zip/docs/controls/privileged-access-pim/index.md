---
title: "Privileged access and PIM controls"
description: "The free Top 5 controls of the Privileged Access and PIM Kit with steps, impact, rollback and read-only checks."
rl_type: controls
---

# Privileged access and PIM controls

<p class="rl-lead">Fewer standing admins: eligible roles in PIM, strict Tier 0 settings and quarterly reviews.</p>

| ID | Control | Priority | Effort |
|---|---|---|---|
| PA01 | [Inventory every privileged role assignment and bring Global Administrators below five](pa01-inventory-every-privileged-role-assignment-and-bring.md) | Highest | 3 h |
| PA02 | [Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts](pa02-make-admin-roles-eligible-in-pim-no-permanent-active.md) | Highest | 4 h |
| PA03 | [Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people](pa03-set-pim-role-settings-for-tier-0-roles-short-activation.md) | Highest | 2 h |
| PA04 | [Give every admin a separate cloud-only admin account, not synced from on-premises](pa04-give-every-admin-a-separate-cloud-only-admin-account-not.md) | High | 3 h |
| PA05 | [Run a quarterly access review of privileged roles and alert on roles assigned outside PIM](pa05-run-a-quarterly-access-review-of-privileged-roles-and.md) | High | 2 h |

These are the free Top 5. The [Privileged Access and PIM Kit](../../kits/privileged-access-pim.md) has all 20 controls, with the Jira import, Excel plan and read-only script.
