---
title: "Run a quarterly access review of privileged roles and alert on roles assigned outside PIM"
description: "Run a quarterly access review of privileged roles and alert on roles assigned outside PIM. Admin roles pile up after projects end."
rl_type: control
rl_service: ["entra"]
rl_reviewed: 2026-10-28
---

# Run a quarterly access review of privileged roles and alert on roles assigned outside PIM

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">PA05</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Privileged access and PIM](../../kits/privileged-access-pim.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Admin accounts and reviews</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">2 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    PIM: Microsoft Entra ID P2 or Microsoft Entra ID Governance (P2 is in Microsoft 365 E5 and EMS E5). Without one of these licences PIM shows the alert 'The organization doesn't have Microsoft Entra ID P2 or Microsoft Entra ID Governance'. Access reviews of Microsoft Entra roles run in PIM; the wider access review features need ID Governance or the Microsoft Entra Suite.

## Why it matters

Admin roles pile up after projects end. PIM access reviews let you review Microsoft Entra role assignments one time or weekly, monthly, quarterly, semi-annually or annually, and remove access automatically when reviewers deny it or do not respond. The PIM security alert 'Roles are being assigned outside of Privileged Identity Management' has High severity and catches standing assignments added straight in the admin center.

## Steps

1. Open ID Governance &gt; Privileged Identity Management &gt; Microsoft Entra roles &gt; Access reviews &gt; New. Scope: the privileged roles from PA01; frequency Quarterly; duration 14 days.
2. Reviewers: Selected users (the IT lead and a second reviewer), not Members (self) for Tier 0 roles.
3. Upon completion: Auto apply results to resource = Enable; If reviewers don't respond = Remove access. Keep the two emergency access accounts out of scope or approve them every time.
4. In PIM &gt; Microsoft Entra roles &gt; Alerts &gt; Settings, confirm 'Roles are being assigned outside of Privileged Identity Management' is on with email, and set 'There are too many Global Administrators' and 'Potential stale accounts in a privileged role' to match the PA01 targets.
5. Put the review dates in the team calendar and track each quarter's result in the tracker.

## Impact on users

Reviewers spend a few minutes per quarter. Admins whose role is not approved lose it at the end of the review; they can request it again through PIM.

## Rollback

Stop or delete the review definition before it ends, or set Auto apply to Disable and apply results by hand. Removed eligible assignments can be added again in PIM.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.Governance, .Users, .DirectoryObjects, .Authentication).
    Connect first:
    Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
    Role: Global Reader is normally enough. If a PIM read is denied, run it as Privileged Role Administrator: the script still only reads.
    ```

```powershell
Get-MgIdentityGovernanceAccessReviewDefinition -All | ForEach-Object { "$($_.DisplayName) | status: $($_.Status) | recurrence: $($_.Settings.Recurrence.Pattern.Type) every $($_.Settings.Recurrence.Pattern.Interval) | auto-apply: $($_.Settings.AutoApplyDecisionsEnabled) | if no response: $($_.Settings.DefaultDecision)" }
"No output above = no access review definitions. PIM alert settings are portal-only (see Verify)."
```

## How to verify

PA05 lists a privileged-role review with recurrence absoluteMonthly every 3, auto-apply True and default decision Deny. In PIM &gt; Alerts the 'assigned outside of PIM' alert is on and its email reaches the security mailbox.

## Sources

- [PIM create roles and resource roles review (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/pim-create-roles-and-resource-roles-review)
- [PIM how to configure security alerts (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/pim-how-to-configure-security-alerts)
- [Best practices (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/best-practices)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Privileged Access and PIM Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=control-pa05){ .md-button .md-button--primary } [See the kit](../../kits/privileged-access-pim.md){ .md-button }

</div>
