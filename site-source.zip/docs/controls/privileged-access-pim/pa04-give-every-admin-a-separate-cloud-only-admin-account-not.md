---
title: "Give every admin a separate cloud-only admin account, not synced from on-premises"
description: "Give every admin a separate cloud-only admin account, not synced from on-premises. Microsoft recommends cloud-native accounts for Microsoft Entra roles:\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Give every admin a separate cloud-only admin account, not synced from on-premises

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">PA04</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Privileged access and PIM](../../kits/privileged-access-pim.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Admin accounts and reviews</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">High</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">3 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    Any Microsoft Entra ID edition. Admin accounts usually need no Microsoft 365 licence; phishing-resistant MFA methods have no extra licence cost.

## Why it matters

Microsoft recommends cloud-native accounts for Microsoft Entra roles: if an on-premises synced account is compromised, the Entra resources it administers can be compromised too. A separate admin account also keeps the role away from the account that reads email and browses the web every day.

## Steps

1. Use the PA04 output to list every account that holds or is eligible for a privileged role, with its sync status and number of licences.
2. For each person whose admin role sits on a synced or daily-use account, create a cloud-only admin account on the tenant domain (for example adm-firstname@contoso.onmicrosoft.com or a dedicated admin domain), with no mailbox licence unless a task needs one.
3. Register phishing-resistant MFA (passkey or Windows Hello for Business) for the new account and make it eligible for the same roles in PIM (PA02).
4. Remove the roles from the old daily account once the person has activated from the new one.
5. Add the admin accounts to the Conditional Access policy for administrators (Conditional Access Baseline Kit CA05) and to the PA05 access review.

## Impact on users

Admins sign in with a second account for admin work, usually in a separate browser profile. Admin accounts without a mailbox do not receive email notifications directly: point PIM notifications at the person's daily mailbox or a shared security mailbox.

## Rollback

Re-assign the role to the old account in PIM while the new account is fixed. Do not delete the new admin account until the cause is known.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.Governance, .Users, .DirectoryObjects, .Authentication).
    Connect first:
    Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
    Role: Global Reader is normally enough. If a PIM read is denied, run it as Privileged Role Administrator: the script still only reads.
    ```

```powershell
$ids = @()
foreach ($n in 'Global Administrator','Privileged Role Administrator','Privileged Authentication Administrator','Security Administrator','Conditional Access Administrator','Exchange Administrator','SharePoint Administrator','User Administrator','Authentication Administrator','Application Administrator','Cloud Application Administrator','Hybrid Identity Administrator','Intune Administrator') { $d = Get-MgRoleManagementDirectoryRoleDefinition -Filter "displayName eq '$n'"; if ($d) { $ids += @(Get-MgRoleManagementDirectoryRoleAssignment -All -Filter "roleDefinitionId eq '$($d.Id)'").PrincipalId; $ids += @(Get-MgRoleManagementDirectoryRoleEligibilityScheduleInstance -All -Filter "roleDefinitionId eq '$($d.Id)'").PrincipalId } }
$ids | Where-Object { $_ } | Sort-Object -Unique | ForEach-Object { $u = Get-MgUser -UserId $_ -Property userPrincipalName,onPremisesSyncEnabled,assignedLicenses -ErrorAction SilentlyContinue; if ($u) { "$($u.UserPrincipalName) | synced from on-premises: $([bool]$u.OnPremisesSyncEnabled) | licences: $(@($u.AssignedLicenses).Count)" } else { "$_ | not a user (group or service principal): review separately" } }
```

## How to verify

PA04 shows 'synced from on-premises: False' for every admin account, and the admin accounts are different from the accounts people use for email.

## Sources

- [Best practices (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/best-practices)
- [Security emergency access (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Privileged Access and PIM Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script.

[Download the free Top 5](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=control-pa04){ .md-button .md-button--primary } [See the kit](../../kits/privileged-access-pim.md){ .md-button }

</div>
