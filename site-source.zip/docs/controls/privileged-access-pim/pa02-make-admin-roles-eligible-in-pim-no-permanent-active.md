---
title: "Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts"
description: "Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts. A standing admin role is available to an attacker the\u2026"
rl_type: control
rl_reviewed: 2026-10-28
---

# Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts

<div class="rl-facts" markdown>
<div class="rl-fact" markdown><div class="rl-fact__k">Control</div><div class="rl-fact__v" markdown="span">PA02</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Kit</div><div class="rl-fact__v" markdown="span">[Privileged access and PIM](../../kits/privileged-access-pim.md)</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Area</div><div class="rl-fact__v" markdown="span">Just-in-time access with PIM</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Priority</div><div class="rl-fact__v" markdown="span">Highest</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Effort</div><div class="rl-fact__v" markdown="span">4 h</div></div>
<div class="rl-fact" markdown><div class="rl-fact__k">Last reviewed</div><div class="rl-fact__v" markdown="span"><time datetime="2026-10-28">28 October 2026</time></div></div>
</div>

!!! licence "Licence and role"
    PIM: Microsoft Entra ID P2 or Microsoft Entra ID Governance (P2 is in Microsoft 365 E5 and EMS E5). Without one of these licences PIM shows the alert 'The organization doesn't have Microsoft Entra ID P2 or Microsoft Entra ID Governance'.

## Why it matters

A standing admin role is available to an attacker the moment the account is taken over. With Privileged Identity Management users are made eligible and activate the role for a limited time; access is removed automatically when the time ends. PIM can also require approval and send notifications when a role is activated.

## Steps

1. Confirm the licence (Entra ID P2 or ID Governance) for every person who will hold an eligible role, and confirm the two emergency access accounts exist and are excluded from Conditional Access (Conditional Access Baseline Kit CA01).
2. Set the PIM role settings first (PA03), so the new eligible assignments are created under the right rules.
3. In ID Governance &gt; Privileged Identity Management &gt; Microsoft Entra roles &gt; Assignments, add each admin as Eligible for the roles agreed in PA01. Start with Global Administrator, Privileged Role Administrator and Privileged Authentication Administrator.
4. Ask each admin to activate once and confirm it works, then remove their Active assignment for that role. Keep only the two emergency access accounts as permanent Active Global Administrators.
5. Repeat for the other privileged roles, one role per day, and record each change in the tracker.

## Impact on users

Admins must activate a role before using it (a few seconds without approval, longer with approval). Scripts or service accounts that relied on a user holding a standing role stop working: list them before you start and move them to an app identity with the least permission.

## Rollback

Re-add the Active assignment for the person and role in PIM &gt; Assignments &gt; Add assignments &gt; Active. Leave the eligible assignment in place so you can try again.

## Read-only check

Reads settings only. It changes nothing in your tenant or on the device.

??? note "Modules, connection and role"

    ```text
    Requires: Microsoft.Graph PowerShell SDK (Microsoft.Graph.Identity.Governance, .Users, .DirectoryObjects, .Authentication).
    Connect first:
    Connect-MgGraph -Scopes RoleManagement.Read.Directory,RoleManagementPolicy.Read.Directory,AccessReview.Read.All,User.Read.All,Directory.Read.All
    Role: Global Reader is normally enough. If a PIM read is denied, run it as Privileged Role Administrator: the script still only reads.
    ```

```powershell
$rd = @{}
Get-MgRoleManagementDirectoryRoleDefinition -All | ForEach-Object { $rd[$_.Id] = $_.DisplayName }
$i = @(Get-MgRoleManagementDirectoryRoleAssignmentScheduleInstance -All)
"Active role assignments: $($i.Count) | activated through PIM right now: $(@($i | Where-Object { $_.AssignmentType -eq 'Activated' }).Count) | permanent (no end date): $(@($i | Where-Object { $_.AssignmentType -eq 'Assigned' -and -not $_.EndDateTime }).Count)"
$i | Where-Object { $_.AssignmentType -eq 'Assigned' -and -not $_.EndDateTime } | Select-Object -First 60 | ForEach-Object { $o = Get-MgDirectoryObject -DirectoryObjectId $_.PrincipalId -ErrorAction SilentlyContinue; $name = if ($o.AdditionalProperties['userPrincipalName']) { $o.AdditionalProperties['userPrincipalName'] } else { "$($o.AdditionalProperties['displayName']) ($($_.PrincipalId))" }; "  permanent: $name | $($rd[$_.RoleDefinitionId])" }
```

## How to verify

PA02 lists permanent active assignments only for the two emergency access accounts (and for service principals you have reviewed). Each admin has activated at least once from PIM.

## Sources

- [Best practices (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/best-practices)
- [Tutorial PIM (Microsoft Learn)](https://learn.microsoft.com/en-us/powershell/microsoftgraph/tutorial-pim)
- [Security emergency access (Microsoft Learn)](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/security-emergency-access)

<div class="rl-kitbox" markdown>

<p class="rl-kitbox__title">This control is in the Privileged Access and PIM Kit</p>

The free Top 5 has this control with its Jira import, Excel project plan, tracker CSV and the read-only PowerShell script. The Complete kit has all 20 controls.

[Download the free Top 5](https://runbooklab.gumroad.com/l/privileged-access-pim-top5?utm_source=site&utm_campaign=control-pa02){ .md-button .md-button--primary } [See the kit](../../kits/privileged-access-pim.md){ .md-button }

</div>
