---
title: "Controls"
description: "Microsoft 365 security controls with why, steps, impact, rollback, a read-only PowerShell check and the Microsoft Learn source."
rl_type: controls
---

# Controls

<p class="rl-lead">Every control page has the same parts: why it matters, the steps, what it does to users, how to roll it back, a read-only check, how to verify and the Microsoft Learn pages it is based on.</p>

30 controls are published here, the free Top 5 of each kit. The rest are listed on each kit's page.

## [Copilot readiness](copilot-readiness/index.md)

| ID | Control | Priority | Effort |
|---|---|---|---|
| CR01 | [Find the overshared sites before Copilot does](copilot-readiness/cr01-find-the-overshared-sites-before-copilot-does.md) | Highest | 2 h |
| CR02 | [Hide the riskiest sites from Copilot while you fix them (Restricted Content Discovery)](copilot-readiness/cr02-hide-the-riskiest-sites-from-copilot-while-you-fix-them.md) | Highest | 1 h |
| CR03 | [Make 'Specific people, view' the default sharing link and put an expiry on Anyone links](copilot-readiness/cr03-make-specific-people-view-the-default-sharing-link-and.md) | High | 1 h |
| CR04 | [Remove 'Everyone except external users' from sensitive sites and hide it in the people picker](copilot-readiness/cr04-remove-everyone-except-external-users-from-sensitive.md) | High | 2 h + site owner time |
| CR05 | [Confirm Copilot interactions are audited and searchable](copilot-readiness/cr05-confirm-copilot-interactions-are-audited-and-searchable.md) | High | 30 min |

## [AI agent hardening](ai-agent-hardening/index.md)

| ID | Control | Priority | Effort |
|---|---|---|---|
| AG01 | [Inventory every agent in the tenant](ai-agent-hardening/ag01-inventory-every-agent-in-the-tenant.md) | Highest | 1 h |
| AG02 | [Require user authentication for Copilot Studio agents](ai-agent-hardening/ag02-require-user-authentication-for-copilot-studio-agents.md) | Highest | 30 min |
| AG03 | [Block HTTP requests and channels you don't use](ai-agent-hardening/ag03-block-http-requests-and-channels-you-don-t-use.md) | High | 1 h |
| AG04 | [Watch agent creation, publishing, sharing and authentication changes](ai-agent-hardening/ag04-watch-agent-creation-publishing-sharing-and.md) | High | 1 h |
| AG05 | [Block high-risk agent identities with Conditional Access](ai-agent-hardening/ag05-block-high-risk-agent-identities-with-conditional-access.md) | High | 30 min |

## [Conditional Access](conditional-access/index.md)

| ID | Control | Priority | Effort |
|---|---|---|---|
| CA01 | [Create two emergency access accounts, exclude them from every policy and alert on their use](conditional-access/ca01-create-two-emergency-access-accounts-exclude-them-from.md) | Highest | 2 h |
| CA02 | [Name policies by persona and create every new policy in Report-only first](conditional-access/ca02-name-policies-by-persona-and-create-every-new-policy-in.md) | Highest | 1 h |
| CA03 | [Require MFA for all users on all resources with an authentication strength](conditional-access/ca03-require-mfa-for-all-users-on-all-resources-with-an.md) | Highest | 2 h + 7 days report-only |
| CA04 | [Block legacy authentication for all users](conditional-access/ca04-block-legacy-authentication-for-all-users.md) | Highest | 1 h + 7 days report-only |
| CA05 | [Require phishing-resistant MFA for administrators](conditional-access/ca05-require-phishing-resistant-mfa-for-administrators.md) | Highest | 2 h + 7 days report-only |

## [Privileged access and PIM](privileged-access-pim/index.md)

| ID | Control | Priority | Effort |
|---|---|---|---|
| PA01 | [Inventory every privileged role assignment and bring Global Administrators below five](privileged-access-pim/pa01-inventory-every-privileged-role-assignment-and-bring.md) | Highest | 3 h |
| PA02 | [Make admin roles eligible in PIM: no permanent active assignment except the two emergency accounts](privileged-access-pim/pa02-make-admin-roles-eligible-in-pim-no-permanent-active.md) | Highest | 4 h |
| PA03 | [Set PIM role settings for Tier 0 roles: short activation, MFA or authentication context, justification, approval by two people](privileged-access-pim/pa03-set-pim-role-settings-for-tier-0-roles-short-activation.md) | Highest | 2 h |
| PA04 | [Give every admin a separate cloud-only admin account, not synced from on-premises](privileged-access-pim/pa04-give-every-admin-a-separate-cloud-only-admin-account-not.md) | High | 3 h |
| PA05 | [Run a quarterly access review of privileged roles and alert on roles assigned outside PIM](privileged-access-pim/pa05-run-a-quarterly-access-review-of-privileged-roles-and.md) | High | 2 h |

## [Exchange Online protection](exchange-online-protection/index.md)

| ID | Control | Priority | Effort |
|---|---|---|---|
| EX01 | [Turn on the Standard preset security policy for all users (Strict for priority accounts)](exchange-online-protection/ex01-turn-on-the-standard-preset-security-policy-for-all-users.md) | Highest | 2 h |
| EX02 | [Block automatic forwarding to external addresses and review the forwards that already exist](exchange-online-protection/ex02-block-automatic-forwarding-to-external-addresses-and.md) | Highest | 2 h |
| EX03 | [Publish SPF and turn on DKIM signing for every domain that sends mail](exchange-online-protection/ex03-publish-spf-and-turn-on-dkim-signing-for-every-domain.md) | Highest | 3 h |
| EX04 | [Publish DMARC for every domain and move it from p=none to p=reject](exchange-online-protection/ex04-publish-dmarc-for-every-domain-and-move-it-from-p-none-to.md) | High | 1 h set-up + 4 to 8 weeks monitoring |
| EX05 | [Anti-malware: common attachments filter on with Reject, zero-hour auto purge on, admin-only quarantine](exchange-online-protection/ex05-anti-malware-common-attachments-filter-on-with-reject.md) | High | 30 min |

## [Defender for Endpoint and ASR](defender-endpoint-asr/index.md)

| ID | Control | Priority | Effort |
|---|---|---|---|
| DE01 | [Check every device is onboarded and its sensor is healthy](defender-endpoint-asr/de01-check-every-device-is-onboarded-and-its-sensor-is-healthy.md) | Highest | 1 h |
| DE02 | [Make sure Defender Antivirus is active with cloud protection and block at first sight](defender-endpoint-asr/de02-make-sure-defender-antivirus-is-active-with-cloud.md) | Highest | 1 h |
| DE03 | [Turn on tamper protection tenant-wide](defender-endpoint-asr/de03-turn-on-tamper-protection-tenant-wide.md) | Highest | 30 min |
| DE04 | [Put all ASR rules in Audit and block the three standard protection rules](defender-endpoint-asr/de04-put-all-asr-rules-in-audit-and-block-the-three-standard.md) | High | 2 h + 2-4 weeks audit |
| DE05 | [Turn on network protection (audit, then block)](defender-endpoint-asr/de05-turn-on-network-protection-audit-then-block.md) | High | 1 h + 2 weeks audit |
