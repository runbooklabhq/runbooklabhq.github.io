"""Builds docs/deadlines.ics from the table in docs/guides/deadlines.md (the single source of truth).

Rules
- Exact day ("3 Nov 2026", "7 Nov 2026 (act by 6 Nov)") -> one all-day event on that day.
- Month or window wording ("End of Dec 2026", "First week of Nov 2026", "Mid-Jan to end of Jan 2027",
  "Early Nov 2026 to early Jan 2027") -> one all-day event spanning the window, with conservative bounds:
  early = 1-10, first week = 1-7, mid = 11-20, late/end = 21-last day. The title keeps Microsoft's own
  wording first, so a window never looks like an exact date.
- A row whose date cannot be read is skipped and reported on stdout (the build log), never guessed.
- Windows longer than 14 days become one event on the first day of the window (no 2-month bars).
- Rows that end before today are dropped.
Output follows RFC 5545: CRLF line endings, lines folded at 75 octets, TEXT values escaped.
"""
import calendar
import datetime as dt
import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).parent
SITE = "https://runbooklabhq.com"
MONTHS = {m.lower(): i for i, m in enumerate(calendar.month_abbr) if m}
MONTH_RE = r"(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
PART = {"early": (1, 10), "first week of": (1, 7), "mid": (11, 20), "mid-": (11, 20), "late": (21, None), "end of": (21, None)}


def _last(y, m):
    return calendar.monthrange(y, m)[1]


def _part_bounds(word, y, m):
    lo, hi = PART[word]
    return dt.date(y, m, lo), dt.date(y, m, hi or _last(y, m))


def parse_when(when):
    """Return (start, end_inclusive, exact) or None. Never raises."""
    try:
        r = _parse_when(when)
    except (ValueError, KeyError):
        return None
    if r and r[1] < r[0]:
        return None
    return r


def _parse_when(when):
    s = re.sub(r"\(.*?\)", "", when).strip()
    s = s.replace("–", "-").replace("—", "-")
    m = re.fullmatch(r"(\d{1,2}) " + MONTH_RE + r" (\d{4})", s)
    if m:
        d = dt.date(int(m.group(3)), MONTHS[m.group(2)[:3].lower()], int(m.group(1)))
        return d, d, True
    # "<part> <Mon> [<YYYY>] to <part> <Mon> <YYYY>"
    side = r"(early|first week of|mid-?|late|end of)\s*" + MONTH_RE + r"(?: (\d{4}))?"
    m = re.fullmatch(side + r" to " + side, s, re.I)
    if m:
        p1, mo1, y1, p2, mo2, y2 = m.groups()
        y2 = int(y2) if y2 else None
        m1, m2 = MONTHS[mo1[:3].lower()], MONTHS[mo2[:3].lower()]
        if y2 is None:
            return None
        y1 = int(y1) if y1 else (y2 if m1 <= m2 else y2 - 1)
        start, _ = _part_bounds(p1.lower().replace("mid-", "mid"), y1, m1)
        _, end = _part_bounds(p2.lower().replace("mid-", "mid"), y2, m2)
        return start, end, False
    m = re.fullmatch(side, s, re.I)
    if m and m.group(3):
        p, mo, y = m.groups()
        start, end = _part_bounds(p.lower().replace("mid-", "mid"), int(y), MONTHS[mo[:3].lower()])
        return start, end, False
    return None


def _link_target(md_link, posts):
    """Map a relative markdown link in deadlines.md to a public URL."""
    m = re.match(r"\.\./news/posts/([^)#]+)\.md", md_link)
    if m:
        slug = posts.get(m.group(1))
        return f"{SITE}/news/{slug}/" if slug else None
    m = re.match(r"([a-z0-9-]+)\.md$", md_link)
    if m:
        return f"{SITE}/guides/{m.group(1)}/"
    if md_link.startswith("http"):
        return md_link
    return None


def _post_slugs():
    out = {}
    for p in (ROOT / "docs" / "news" / "posts").glob("*.md"):
        m = re.search(r"^slug:\s*(\S+)", p.read_text(encoding="utf-8"), re.M)
        if m:
            out[p.stem] = m.group(1)
    return out


def _plain(cell):
    cell = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", cell)
    return cell.replace("`", "").strip()


def _esc(text):
    return text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def _fold(line):
    raw = line.encode("utf-8")
    if len(raw) <= 75:
        return line
    out, cur = [], b""
    for ch in line:
        b = ch.encode("utf-8")
        if len(cur) + len(b) > (75 if not out else 74):
            out.append(cur.decode("utf-8"))
            cur = b""
        cur += b
    out.append(cur.decode("utf-8"))
    return "\r\n ".join(out)


def rows():
    text = (ROOT / "docs" / "guides" / "deadlines.md").read_text(encoding="utf-8")
    for line in text.splitlines():
        if not line.startswith("| ") or line.startswith("| When") or line.startswith("|---"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 5:
            continue
        yield cells[:5]


def build(today=None):
    today = today or dt.date.today()
    posts = _post_slugs()
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Runbook Lab//Microsoft 365 security deadlines//EN",
             "CALSCALE:GREGORIAN", "METHOD:PUBLISH", "X-WR-CALNAME:Runbook Lab: Microsoft 365 security deadlines",
             "X-WR-CALDESC:" + _esc("Dated Microsoft 365, Entra, Exchange, Windows and Purview changes that need an admin. "
                                    "Source: " + SITE + "/guides/deadlines/"),
             "REFRESH-INTERVAL;VALUE=DURATION:P1D", "X-PUBLISHED-TTL:P1D"]
    kept, skipped = 0, []
    for when, what, who, source, more in rows():
        parsed = parse_when(when)
        if not parsed:
            skipped.append(when)
            continue
        start, end, exact = parsed
        if end < today:
            continue
        collapsed = (end - start).days + 1 > 14
        if collapsed:  # a 2-month bar clutters every calendar day: one event on the window's first day
            end = start
        more_links = re.findall(r"\]\(([^)]+)\)", more)
        url = (_link_target(more_links[0], posts) if more_links else None) or f"{SITE}/guides/deadlines/"
        src_links = re.findall(r"\]\((https?://[^)]+)\)", source)
        note = re.search(r"\((.*?)\)", when)
        summary = f"{when}: {_plain(what)}" if not exact else _plain(what) + (f" ({note.group(1)})" if note else "")
        desc = (f"When: {when}" + ("" if exact else (" (Microsoft gives a date range, not a single day" + ("; shown on its first day" if collapsed else "") + ")")) +
                f"\nWho acts: {_plain(who)}\nSource: {_plain(source)}" +
                ("".join(f" {u}" for u in src_links)) + f"\nDetails and checks: {url}\nRunbook Lab is not affiliated with Microsoft.")
        uid = hashlib.sha1(_plain(what).encode("utf-8")).hexdigest()[:20] + "@runbooklabhq.com"
        lines += ["BEGIN:VEVENT", f"UID:{uid}", f"DTSTAMP:{stamp}",
                  f"DTSTART;VALUE=DATE:{start:%Y%m%d}", f"DTEND;VALUE=DATE:{end + dt.timedelta(days=1):%Y%m%d}",
                  "SUMMARY:" + _esc(summary), "DESCRIPTION:" + _esc(desc), f"URL:{url}", "TRANSP:TRANSPARENT", "END:VEVENT"]
        kept += 1
    if kept == 0:  # RFC 5545 needs at least one component
        lines += ["BEGIN:VEVENT", "UID:placeholder@runbooklabhq.com", f"DTSTAMP:{stamp}",
                  f"DTSTART;VALUE=DATE:{today:%Y%m%d}", f"DTEND;VALUE=DATE:{today + dt.timedelta(days=1):%Y%m%d}",
                  "SUMMARY:No upcoming dated changes listed", f"URL:{SITE}/guides/deadlines/", "TRANSP:TRANSPARENT", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    (ROOT / "docs" / "deadlines.ics").write_text("\r\n".join(_fold(x) for x in lines) + "\r\n", encoding="utf-8", newline="")
    print(f"deadlines.ics: {kept} events")
    for w in skipped:
        print(f"::warning title=deadlines.ics::row skipped, date not readable: {w}")
    return kept, skipped


def safe_build():
    """Called from gen.py: on any unexpected error write a minimal valid calendar so the strict build still passes."""
    try:
        return build()
    except Exception as e:  # noqa: BLE001
        print(f"::warning title=deadlines.ics::calendar not generated ({e}); wrote a placeholder")
        stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        d = dt.date.today()
        lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Runbook Lab//Microsoft 365 security deadlines//EN",
                 "BEGIN:VEVENT", "UID:placeholder@runbooklabhq.com", f"DTSTAMP:{stamp}",
                 f"DTSTART;VALUE=DATE:{d:%Y%m%d}", f"DTEND;VALUE=DATE:{d + dt.timedelta(days=1):%Y%m%d}",
                 "SUMMARY:See runbooklabhq.com/guides/deadlines", "END:VEVENT", "END:VCALENDAR"]
        (ROOT / "docs" / "deadlines.ics").write_text("\r\n".join(lines) + "\r\n", encoding="utf-8", newline="")
        return 0, []


if __name__ == "__main__":
    build()
