---
# Template for every new CISA KEV brief (Owner OK 2026-11-08, Analytics digest 11-08: KEV brief = most external news sessions, 0 read_completed, 0 CTA).
# Copy to docs/news/posts/YYYY-MM-DD-<slug>.md, fill from the primary sources read today, delete these comment lines.
date:
  created: YYYY-MM-DD HH:MM:00
slug: <keyword-first-slug>
categories:
  - Threats & vulnerabilities
description: "<140-160 chars: product names + the action>"
rl_type: news
rl_kits: []
rl_controls: []
---

# <What + product + CVE or date, title part <= 60 chars>

<Lead, 2 sentences: the fact with the KEV date-added, and who must act.>

<!-- more -->

!!! note rl-today "Do this today"
    **What:** <the exploited flaw(s) in CISA's KEV catalog, with CVE IDs>.<br>
    **Who is exposed:** <who runs the affected product, in one line>.<br>
    **The one action:** <one read-only check or the upgrade, with CISA's due date copied from the catalog>.<br>
    For the Microsoft 365 side of the same estate, the [M365 Hardening Kit](../../kits/m365-hardening.md) has a free Top 10 with read-only checks.

!!! note "Runbook card"
    **What changes:** …<br>
    **Who:** …<br>
    **By when:** <CISA due dates; binding only on US federal civilian agencies>.<br>
    **Do this:** 1. … 2. … 3. …<br>
    **Check:** <read-only command or portal path>.<br>
    **Source:** [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) (catalog version …) and the vendor advisory.

<Details, How to check (read-only), How to verify, Rollback/impact, Related (>= 3 internal links), Sources, Last reviewed.>
